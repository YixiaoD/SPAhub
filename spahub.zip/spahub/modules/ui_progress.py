# -*- coding: utf-8 -*-
"""
modules/ui_progress.py
======================
共享 UI 组件 —— MarqueeProgress（v12.10.114 新增；本文件于 v12.10.115 补发）。

背景 / 根因
----------
SPAhub 各处"运行中"指示用的 QProgressBar 原本走原生 indeterminate（无限流）模式：

    prog_bar.setRange(0, 0)

靠 Qt 平台 style 自带的 busy 动画来回滑动 chunk。但凡进度条挂在带自定义 stylesheet
（如 #LeftPanel { ... }）的子树下，整子树会走 QStyleSheetStyle 渲染——Windows 下该
style 不驱动原生 busy 动画的定时刷新，导致进度条"运行中却静止不动"：后台 SAS 仍在
SingleBatchRunner 线程里跑，但用户看到的是死条，体验上像卡死。

方案
----
不依赖平台 style 的隐式动画，改用一个**主线程 QTimer 周期性 setValue** 的"扫动"：

    - QProgressBar 改回 determinate：setRange(0, 100)
    - QTimer 每 tick 把 value 往前推一格，到顶回绕到 0，循环往复
    - 每次 setValue 都会主动触发 QProgressBar 重绘，不受 stylesheet 抑制

肉眼效果：进度条反复"填满 → 归零 → 填满"地循环滑动，明确表达"正在执行、未卡死"。
与 aCRF v12.10.113 同根因、同方案；BatchRunForm 为 TFLs / SDTM / ADaM 三模式共用，
一处接入三处生效。

用法（替代原 setVisible(True/False) + setRange(0, 0)）
---------------------------------------------------
    marquee = MarqueeProgress(prog_bar, parent_form)   # parent_form 作 QTimer 的 parent
    marquee.start()   # 显示进度条 + 启动扫动
    marquee.stop()    # 停止扫动 + 隐藏进度条

注意
----
- QTimer 的 parent 传 form（QObject），随表单析构一并回收，不会悬空。
- 纯主线程组件：start / stop 必须在主线程（GUI 线程）调用；后台 QThread 想驱动它，
  应 emit 信号让主线程的槽来 start / stop（符合"不在 QThread 里直接动 UI"的项目约定）。
- 动态列表里的行会被重渲（刷新 / 重新生成跑批脚本时），底层 C++ QProgressBar 可能先于
  本对象被销毁；所有触碰 bar 的地方都吞 RuntimeError，避免"Internal C++ object already
  deleted"在 timer tick 里持续抛错。
"""
from PySide6.QtCore import QObject, QTimer


class MarqueeProgress(QObject):
    """
    给一个 determinate QProgressBar（range 0-100）套一层"扫动"动画。

    用主线程 QTimer 周期 setValue 模拟 indeterminate busy 效果，规避带 stylesheet 的
    子树下原生 busy 动画不刷新的问题（v12.10.114）。

    参数
    ----
    prog_bar : QProgressBar
        目标进度条。构造时会被强制设为 determinate(0, 100) 并隐藏文字，
        即使调用方忘了 setRange(0, 100) 也兜底成立。
    parent : QObject | None
        QTimer 的 parent（一般传所属 form），随其析构而回收，避免 timer 悬空。
    """

    # 每 tick 推进的步长（value 单位）与 tick 间隔（毫秒）。
    # 步长 5 + 间隔 28ms ≈ 每 ~0.56s 走完一圈，肉眼是平滑连续的滑动而不晃眼。
    _STEP = 5
    _INTERVAL_MS = 28

    def __init__(self, prog_bar, parent=None):
        super().__init__(parent)
        self._bar = prog_bar
        self._value = 0

        # 强制 determinate + 隐藏文字（兜底，不依赖调用方先配置好）。
        try:
            self._bar.setRange(0, 100)
            self._bar.setTextVisible(False)
        except RuntimeError:
            # 底层 C++ 对象已不在——本对象保持可用，后续 start/stop 仍会安全空转。
            pass

        # timer parent 用传入的 parent（form）；为 None 时退回 self，保证总有归属。
        self._timer = QTimer(parent if parent is not None else self)
        self._timer.setInterval(self._INTERVAL_MS)
        self._timer.timeout.connect(self._tick)

    # ------------------------------------------------------------------ public
    def start(self):
        """显示进度条并启动扫动。重复调用安全（已在跑则只复位起点）。"""
        self._value = 0
        try:
            self._bar.setValue(0)
            self._bar.setVisible(True)
        except RuntimeError:
            # bar 已销毁：不再启动 timer，直接返回。
            return
        if not self._timer.isActive():
            self._timer.start()

    def stop(self):
        """停止扫动并隐藏进度条。重复调用安全。"""
        if self._timer.isActive():
            self._timer.stop()
        self._value = 0
        try:
            self._bar.setValue(0)
            self._bar.setVisible(False)
        except RuntimeError:
            # bar 已销毁，无需再操作。
            return

    def is_running(self):
        """当前是否处于扫动状态。"""
        return self._timer.isActive()

    # ----------------------------------------------------------------- private
    def _tick(self):
        """QTimer 回调：value 前进一格，到顶回绕到 0，强制重绘。"""
        try:
            self._value += self._STEP
            if self._value > 100:
                self._value = 0
            self._bar.setValue(self._value)
        except RuntimeError:
            # bar 已被销毁（行重渲 / 表单关闭）：停掉 timer 防止持续抛错。
            self._timer.stop()
