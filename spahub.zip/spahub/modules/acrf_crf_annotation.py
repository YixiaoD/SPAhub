# -*- coding: utf-8 -*-
"""
modules/acrf_annotation.py
==========================
aCRF 模块 - 04 CRF Annotation

整合两条业务流：
  • 22 Draft Annotation：（v12.10.99 起）本机 Python 子进程调部门 annodraft 工具包
                         autoanno_study_draft() → 内部自行抽取 eCRF 字段坐标（pdfminer）
                         → 套 anno 模板 → 产出 annomap.xlsx + draft.xfdf
  • 23 Final Annotation：用户基于 draft 在 Adobe 调注完成后 → 从终版 acrf.pdf 导出 xfdf →
                         调 %anno_study_final 把 xfdf 转成 anno_study.sas7bdat（供 TFLs 使用）

v12.6 关键设计：
  - 22 Draft 拆成两个独立按钮（▶ 提取 eCRF / ▶ 运行 autoanno），允许用户在两步之间
    手动编辑 annomap.xlsx 然后单独重跑 autoanno；这是用户明确要求的操作粒度。
  - 22 提取步骤"内置改动"：复现 extract_ecrf.sas 中的文件校验/复制/重命名（在 Python 端做），
    SAS 脚本只剩一行 filename pipe 调 coordination.py，避免 SAS↔Python 嵌套带来的开销
    和路径转换复杂度。
  - 23 Final"内置改动"：用户手动在 Adobe 中导出 xfdf；本模块只负责把文件名注入
    23_anno_final_call.sas 后再跑。
  - 全部 SAS 调用走 SingleBatchRunner（v12.2 已稳定的子进程 + run_sas 模式）。
  - ▶/🟥 按钮切换：与 01/02 的中止按钮同款（运行时 setVisible 切换两态）。

v12.9.5 重大改动：
  - 完全移除 pymupdf 相关代码（自动导出 / 注入 / 预览）。根因：pymupdf 的
    add_freetext_annot 不能还原 xfdf 中 line/polygon/highlight 等多种注释类型，
    一律转为 freetext + 红字黄底；color/border/fontsize 全丢失。Python 库无解。
    所以全流程改为手动：用户在 Adobe Acrobat 中 Import / Export Comments。
  - ecrf 复制逻辑改：062_acrf 下原 PDF 不动；只往 062_acrf/draft 下放重命名为
    ecrf.pdf 的副本。coordination.py 的 fp 参数同步改成指向 draft 目录。
  - 首次运行按钮锁死改为 setVisible(False)（不仅 setEnabled(False)），
    避免 race condition 中按钮残留可点击态。

v12.10.99 重大改动（22 线 SAS → 本机 Python annodraft）：
  - 22 Draft 不再走 SAS（coordination.py filename pipe + %autoanno_study_draft 宏），
    改为本机 Python 子进程直接调部门工具包 autoanno_draft.autoanno_study_draft()。
    包部署位置（部门约定）：Z:\\projects\\Z_PYTHON\\aCRF\\autoanno_draft\\。
  - 工具只有一个入口：首次运行（full）与「保存后重跑」（autoanno_only）调**同一个**
    函数、同一参数；两模式的差异只剩 UI 路径（按钮锁死语义不变）+ 是否复制源 PDF。
  - Coordination.txt 彻底退出 22 线（工具内部用 pdfminer 自行抽坐标，不产不读该文件）。
    autoanno_only 的前置检查由 Coordination.txt 改为 draft/ecrf.pdf 存在且非空。
  - 执行器换 ui_utils.ScriptRunnerThread（python -u 逐行实时回传 → sig_log，
    encoding=utf-8 + errors=replace，CREATE_NO_WINDOW，cancel 杀整棵进程树）。
    23 Final 维持 SAS（SingleBatchRunner）不动。
  - 临时 driver 脚本写 %TEMP%（不再写 utility/tools），_on_runner_thread_done 统一清理。
  - EDC 数据库定义文件（<base>/00_source_data/*数据库*.xlsx）由工具内部自动定位；
    SPAhub 侧仅做预检：找不到弹窗告警，但允许用户继续运行（同一会话只问一次）。
  - 退役：_LINUX_COORD_PY / _LINUX_PYTHON3 / _build_rc_init_block / _write_tmp_sas
    （均仅服务旧 22 线）。本机 Python 需新增依赖：PyMuPDF（pymupdf）、pdfminer.six、PyYAML。

v12.10.100 改动（本次）：
  - 后台拉起方式与 cmd 对齐：22 线临时 driver 不再"直接 import autoanno_study_draft"，
    改为 runpy 执行项目层 <base>/utility/tools/22_anno_draft_call.py（注入 --base-path /
    --ecrf-path），与用户手动跑
        C:\\Python_396\\python.exe ...\\utility\\tools\\22_anno_draft_call.py
    完全同一入口、同一行为（copy 到 draft/ecrf.pdf、EDC 自动定位、版本日志、
    autoanno 调用签名 titlecount/edc_path 全部由 call 脚本统一负责）。
    call 脚本缺失（项目未铺该文件）时自动回退到旧的"直接 import"路径，保持可用。
  - Q2 去重：_on_draft_finished 删除 _extract_issue_lines 的二次汇总打印 —— 22 线
    annodraft 已逐行实时把控制台原文（含 WARNING/ERROR 行）推到日志面板，"原始打印
    已足够"，不再追加重复总结。23 Final（SAS，无逐行流式）仍保留 _extract_issue_lines。
  - 顶部描述文案改为两行：「调用 22_anno_draft_call.py 完成草标 / 调用
    23_anno_final_call.sas 完成终标」。

v12.10.101 改动（本次）：
  - 核对 22_anno_draft_call.py 后，把回退路径（项目未铺 call 脚本时的"直接 import"）
    的 autoanno_study_draft 调用签名对齐 call 脚本：补 titlecount=4（call 脚本默认值）
    与 edc_path（SPAhub 侧 _find_latest_edc_def_xlsx 自动定位，规则与 call 脚本
    _find_source_edc 一致），避免两条路径草标行为分叉。首选 runpy 路径不变。
"""
import os
import re
import sys
import time
import uuid
import shutil
import tempfile
import subprocess
from datetime import datetime

from PySide6.QtWidgets import (QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                               QLineEdit, QFileDialog, QFrame, QProgressBar,
                               QDialog)
from PySide6.QtCore import Qt, Signal, QThread

from modules.tfls_batch_run import SingleBatchRunner
from ui_utils import (show_dialog, show_choice_dialog, primary_outline_btn_style, scan_status_lbl_style,
                      primary_btn_style, danger_btn_style, success_btn_style, light_btn_style,
                      ScriptRunnerThread)


# 路径常量（与 SAS 项目结构对齐）
_ACRF_REL = ("utility", "documentation", "06_crt_preparation", "062_acrf")
_DRAFT_REL = _ACRF_REL + ("draft",)
_META_REL = ("utility", "metadata")
_TOOLS_REL = ("utility", "tools")
# v12.10.100：项目层 annodraft 调用入口脚本（与用户手动 cmd 跑的是同一个文件）。
_ANNO_DRAFT_CALL_REL = _TOOLS_REL + ("22_anno_draft_call.py",)

# v12.10.99：部门 annodraft Python 工具包父目录候选（仿 metadata_loader 双路径探测约定）。
# 包本体 = <候选>/autoanno_draft/（含 __init__.py），部门统一维护，跨项目共享。
# 候选地位等同旧 _LINUX_COORD_PY（部门约定常量，不属于"项目内路径"硬编码范畴）。
_ANNODRAFT_PKG_PARENT_CANDIDATES = (
    r"Z:\projects\Z_PYTHON\aCRF",
    "/u01/app/sas/sas9.4/DocumentRepository/DDT/projects/Z_PYTHON/aCRF",
)


def _find_annodraft_pkg_parent() -> str:
    """v12.10.99：探测 annodraft 包父目录；返回首个含 autoanno_draft/__init__.py 的候选，
    全部不可达返回 ""（调用方负责弹错并中止）。"""
    for parent in _ANNODRAFT_PKG_PARENT_CANDIDATES:
        try:
            if os.path.isfile(os.path.join(parent, "autoanno_draft", "__init__.py")):
                return parent
        except OSError:
            continue
    return ""


def _prot_from_base_path(base_path: str) -> str:
    """v12.10.99：prot = 第 3 级目录名（base_path 的父目录名，如 HRS4357_301）。

    v0.2.43 起 annodraft 内部仅把 prot 用于日志（不再与 CRF 左上角项目代号做内容匹配），
    所以即使目录命名不规范也无害。"""
    try:
        return os.path.basename(os.path.dirname(os.path.normpath(base_path or "")))
    except Exception:
        return ""


def _find_latest_edc_def_xlsx(base_path: str) -> str:
    """v12.10.99：在 <base>/00_source_data 下找文件名含「数据库」的最新 mtime .xlsx。

    与 annodraft 内部 edc_loader 的自动定位规则一致（排除 ~$ 临时文件，不递归）。
    本函数只服务 SPAhub 侧"找不到时弹窗告警"的预检 — 真正的定位仍由工具内部完成
    （edc_path 传 None），保持单一事实来源。找不到返回 ""。"""
    src_dir = os.path.join(base_path or "", "00_source_data")
    if not os.path.isdir(src_dir):
        return ""
    best, best_m = "", -1.0
    try:
        names = os.listdir(src_dir)
    except OSError:
        return ""
    for name in names:
        if "数据库" not in name or not name.lower().endswith(".xlsx") or name.startswith("~$"):
            continue
        full = os.path.join(src_dir, name)
        try:
            m = os.path.getmtime(full)
        except OSError:
            continue
        if os.path.isfile(full) and m > best_m:
            best, best_m = full, m
    return best



def _rewrite_macro_param(sas_path: str, macro_name: str, param_name: str, new_value: str) -> tuple:
    """
    通用：把 SAS 文件里 `%<macro>(... <param>=%str(...) ...)` 中的 <param> 值改成 new_value。

    用于：
      - 22_anno_draft_call.sas：%extract_ecrf(ecrf_fname=%str(...))
      - 23_anno_final_call.sas：%anno_study_final(xfdfname=%str(...))

    匹配策略：行级，命中含 `%<macro>` 且含 `<param>=` 的行，整行覆写。
    """
    if not os.path.isfile(sas_path):
        return False, f"找不到 SAS 文件：{sas_path}"
    try:
        with open(sas_path, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
    except OSError as e:
        return False, f"读取 SAS 文件失败：{e}"

    pattern = re.compile(rf"^\s*%{re.escape(macro_name)}\s*\(", re.IGNORECASE)
    target_idx = None
    for i, line in enumerate(lines):
        if pattern.search(line) and re.search(rf"\b{re.escape(param_name)}\s*=", line, re.IGNORECASE):
            target_idx = i
            break
    if target_idx is None:
        return False, f"未找到 %{macro_name}(...{param_name}=...) 行"

    new_line = f"%{macro_name}({param_name}=%str({new_value}));\n"
    if lines[target_idx].rstrip("\r\n") == new_line.rstrip("\r\n"):
        return False, "已是目标值，无需改写"
    lines[target_idx] = new_line
    try:
        with open(sas_path, "w", encoding="utf-8") as f:
            f.writelines(lines)
    except OSError as e:
        return False, f"写回失败：{e}"
    return True, "已更新 SAS 文件"


# =============================================================================
# 后台路径扫描线程（v12.10.2 加入）
# 目的：消除 update_paths 中多次 listdir + getmtime 在 Z:\ 网络盘的累积阻塞
#      （主线程之前同步扫 062_acrf 下 .pdf + final/ 子目录 + annomap / draft / anno_study
#      共 4-5 次 IO，叠加约 0.5-1s 卡顿）。
# =============================================================================
class _CrfAnnoPathScanThread(QThread):
    """扫描 062_acrf / final / draft / annomap / anno_study 等多处 IO，结果回主线程"""
    finished_signal = Signal(int, dict)
    # results 字段（除 base_path 外都是 IO 探测结果）：
    #   acrf_dir_exists / latest_pdf_in_acrf      源 eCRF 候选（062_acrf 下排除 ecrf.pdf 的最新 pdf）
    #   final_dir_exists / latest_pdf_in_final    final 子目录下最新 pdf（fallback：acrf.pdf）
    #   final_pdf_picked                          最终选中的 final_pdf 路径
    #   xfdf_picked                               与 final_pdf 同名的 .xfdf（如果存在）
    #   annomap_path / annomap_exists             annomap.xlsx 路径与是否存在
    #   draft_dir_exists                          draft 目录是否存在
    #   anno_study_exists                         任一候选位置存在 anno_study.sas7bdat

    def __init__(self, base_path: str, token: int, parent=None):
        super().__init__(parent)
        self.base_path = base_path or ""
        self.token = token

    def _find_latest_pdf(self, dir_path):
        """复制 form 内的 _find_latest_pdf 静态方法（不能跨线程调 self.xxx 的 IO 方法）"""
        if not os.path.isdir(dir_path):
            return ""
        cands = []
        try:
            for n in os.listdir(dir_path):
                full = os.path.join(dir_path, n)
                if os.path.isfile(full) and n.lower().endswith(".pdf"):
                    try:
                        cands.append((full, os.path.getmtime(full)))
                    except OSError:
                        pass
        except OSError:
            return ""
        if not cands:
            return ""
        cands.sort(key=lambda x: x[1], reverse=True)
        return cands[0][0]

    def _find_latest_pdf_excluding(self, dir_path, exclude=None):
        if not os.path.isdir(dir_path):
            return ""
        excl = {n.lower() for n in (exclude or set())}
        cands = []
        try:
            for n in os.listdir(dir_path):
                if n.lower() in excl:
                    continue
                full = os.path.join(dir_path, n)
                if os.path.isfile(full) and n.lower().endswith(".pdf"):
                    try:
                        cands.append((full, os.path.getmtime(full)))
                    except OSError:
                        pass
        except OSError:
            return ""
        if not cands:
            return ""
        cands.sort(key=lambda x: x[1], reverse=True)
        return cands[0][0]

    def run(self):
        result = {
            "acrf_dir_exists": False,
            "latest_pdf_in_acrf": "",
            "final_dir_exists": False,
            "final_pdf_picked": "",
            "xfdf_picked": "",
            "annomap_path": "",
            "annomap_exists": False,
            "draft_dir_exists": False,
            "anno_study_exists": False,
        }
        try:
            acrf_dir = os.path.join(self.base_path, *_ACRF_REL)
            result["acrf_dir_exists"] = os.path.isdir(acrf_dir)

            if result["acrf_dir_exists"]:
                # 062_acrf 下排除 ecrf.pdf 的最新 pdf
                result["latest_pdf_in_acrf"] = self._find_latest_pdf_excluding(acrf_dir, exclude={"ecrf.pdf"})

                # final 子目录下最新 pdf
                final_dir = os.path.join(acrf_dir, "final")
                result["final_dir_exists"] = os.path.isdir(final_dir)
                if result["final_dir_exists"]:
                    latest_final = self._find_latest_pdf(final_dir)
                    if latest_final:
                        result["final_pdf_picked"] = latest_final
                if not result["final_pdf_picked"]:
                    cand_fb = os.path.join(acrf_dir, "acrf.pdf")
                    if os.path.isfile(cand_fb):
                        result["final_pdf_picked"] = cand_fb

                # 同名 .xfdf
                if result["final_pdf_picked"] and os.path.isfile(result["final_pdf_picked"]):
                    stem = os.path.splitext(result["final_pdf_picked"])[0]
                    cand_xfdf = stem + ".xfdf"
                    if os.path.isfile(cand_xfdf):
                        result["xfdf_picked"] = cand_xfdf

            # annomap.xlsx：优先 062_acrf/draft/annomap.xlsx，退路 062_acrf/annomap.xlsx
            annomap_candidates = [
                os.path.join(self.base_path, *_DRAFT_REL, "annomap.xlsx"),
                os.path.join(self.base_path, *_ACRF_REL, "annomap.xlsx"),
            ]
            picked_annomap = ""
            for p in annomap_candidates:
                if os.path.isfile(p):
                    picked_annomap = p
                    result["annomap_exists"] = True
                    break
            result["annomap_path"] = picked_annomap or annomap_candidates[0]  # 默认期望位置

            # draft 目录
            d = os.path.join(self.base_path, *_DRAFT_REL)
            result["draft_dir_exists"] = os.path.isdir(d)

            # anno_study.sas7bdat 三个候选位置
            anno_candidates = [
                os.path.join(self.base_path, *_ACRF_REL, "anno_study.sas7bdat"),
                os.path.join(self.base_path, *_DRAFT_REL, "anno_study.sas7bdat"),
                os.path.join(self.base_path, "04_crt", "anno_study.sas7bdat"),
            ]
            result["anno_study_exists"] = any(os.path.isfile(p) for p in anno_candidates)
        except Exception:
            pass
        self.finished_signal.emit(self.token, result)


# =============================================================================
# 左侧表单组件 CrfAnnotationForm
# =============================================================================
class CrfAnnotationForm(QFrame):
    """aCRF / 04 CRF Annotation：22 Draft + 23 Final 两条子流

    第一版（v12.6）布局：左面板自上而下两个子区，22 在上，23 在下。
    各子区独立运行按钮 + 输出路径展示，互不干扰。"""

    sig_log = Signal(str)
    sig_status = Signal(str, str)
    sig_step_update = Signal(str)
    sig_run_started = Signal()
    sig_run_finished = Signal()
    # v12.6：autoanno 完成且产出 annomap.xlsx 时 emit 路径，让外层 stepper 自动重载
    # annomap 编辑 tab，用户不必手动点 🔄 重新加载。
    sig_annomap_updated = Signal(str)
    # v12.7：输出文件存在性变更通知（autoanno / final 完成 → 让 stepper 重新决定按钮可见性）
    sig_outputs_changed = Signal()
    # v12.9.4：autoanno_only 专用启动/结束信号 — 让 stepper 切换 annomap tab 顶部
    # 「保存并重跑」按钮的中止状态，**不再**通过 _enter_running 联动左侧 btn_run_draft
    # （根因：_enter_running 会把 btn_run_draft 设回 setEnabled(True)，破坏首次运行后的锁死）
    sig_autoanno_started = Signal()
    # v12.9.8：sig_autoanno_finished 加参数 (has_error, has_warning, summary)
    # 让 stepper 在 annomap tab 下方显示简略结果（用户停留在 annomap tab 时也能感知运行结果）
    sig_autoanno_finished = Signal(bool, bool, str)
    # v12.9.8：Final 完成 → 让 stepper 切到「运行日志」tab（用户应该看输出而不是停在 annomap）
    sig_final_finished = Signal()

    def __init__(self):
        super().__init__()
        self.base_path = ""
        self._step_name = "CRF Annotation"
        self._runner = None  # 当前活跃 SingleBatchRunner
        self._t_start = 0.0
        # v12.9.4：当前运行模式 — "" / "full" / "autoanno_only"
        # 用于在 _on_draft_finished / _on_cancel_run 内分支处理 UI 恢复 + 是否自动弹预览
        self._autoanno_mode = ""
        # v12.10.31：用户主动中止标志（同 acrf_unzip v12.10.20 / acrf_edc_recode v12.10.17 模式）
        # 在 _on_cancel_run 设 True；_on_draft_finished / _on_final_finished 顶部检测后直接 return
        # 防止 emit 与 cancel 同时击中产生的 "double UI cleanup + 引用悬挂" 闪退
        self._cancelled = False
        # v12.10.28：跟踪运行临时文件；v12.10.99 起改名 _tmp_files_to_clean —
        # 现在装的是 %TEMP% 下的 _tmp_annodraft_*.py driver（22 线）。
        # 在 _on_runner_thread_done 中（成功/失败/中止三路径都到达）统一删除。
        self._tmp_files_to_clean = set()
        # v12.10.99：EDC 数据库定义缺失告警的"本会话已确认"标志 — 用户在弹窗里点过
        # 「继续运行」后，同一项目会话内的后续重跑只打黄色日志不再弹窗（避免
        # 保存并重跑循环被反复打断）。update_paths（切项目/刷新）时复位。
        self._edc_missing_acknowledged = False
        # v12.10.2：后台路径扫描（避免 Z:\ 网络盘多次 listdir 阻塞主线程）
        self._path_scan_token = 0
        self._retired_path_threads = []
        self._setup_ui()

    # ------------------------- UI -------------------------
    def _setup_ui(self):
        self.setObjectName("LeftPanel")
        self.setStyleSheet("#LeftPanel { background-color: #FFFFFF; border: 1px solid #E4E7ED; border-radius: 6px; }")

        # v12.7：左面板纵向二分（上=22 Draft，下=23 Final），固定比例 1:1。
        # 旧版用单 QVBoxLayout 把两子区上下堆叠，eCRF 路径行 + 状态指示 + 输出按钮行多了之后
        # 整体拥挤、视觉割裂。改成 QSplitter(Vertical)+QGroupBox 分组，外加各自带 scroll，
        # 让两条业务流在视觉/功能上彻底独立。
        from PySide6.QtWidgets import QGroupBox, QScrollArea, QSplitter

        outer = QVBoxLayout(self)
        outer.setContentsMargins(20, 20, 20, 20)
        outer.setSpacing(10)

        # ---------- 顶部刷新栏 ----------
        top_bar = QHBoxLayout()
        self.refresh_btn = QPushButton("🔄 刷新源文件")
        # v12.10.65：统一改用 home"📁 系统文件复制"同款蓝色外框样式
        self.refresh_btn.setStyleSheet(primary_outline_btn_style())
        self.refresh_btn.setCursor(Qt.PointingHandCursor)
        top_bar.addWidget(self.refresh_btn)
        self.scan_lbl = QLabel("")
        self.scan_lbl.setStyleSheet(scan_status_lbl_style())
        top_bar.addWidget(self.scan_lbl)
        top_bar.addStretch()
        outer.addLayout(top_bar)

        # 顶部标题（v12.10.100：改两行，引用与 cmd 同一个 call 脚本）
        title = QLabel("22 Draft：调用 22_anno_draft_call.py 完成草标\n"
                       "23 Final：调用 23_anno_final_call.sas 完成终标")
        title.setStyleSheet("color: #303133; font-weight: bold; font-size: 14px; border: none;")
        title.setWordWrap(True)
        outer.addWidget(title)

        # ---------- 上下分区：QSplitter ----------
        self._split = QSplitter(Qt.Vertical)
        self._split.setChildrenCollapsible(False)  # 防止用户把某区拖到 0 高度看不见
        self._split.setStyleSheet("QSplitter::handle { background-color: #EBEEF5; height: 4px; }")
        outer.addWidget(self._split, 1)

        # ============== 上区：22 Draft Annotation ==============
        gb_22 = QGroupBox("22 Draft Annotation")
        gb_22.setStyleSheet(
            "QGroupBox { font-size: 13px; font-weight: bold; color: #409EFF; "
            "border: 1px solid #E4E7ED; border-radius: 4px; margin-top: 10px; padding-top: 6px; }"
            "QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px; }"
        )
        gb22_lay = QVBoxLayout(gb_22)
        gb22_lay.setContentsMargins(12, 10, 12, 10)
        gb22_lay.setSpacing(8)
        gb22_lay.setAlignment(Qt.AlignTop)

        # eCRF 文件输入
        row1 = QHBoxLayout()
        lbl1 = QLabel("eCRF 文件：")
        lbl1.setStyleSheet("border: none; color: #606266; min-width: 110px;")
        row1.addWidget(lbl1)
        self.ecrf_entry = QLineEdit()
        self.ecrf_entry.setStyleSheet("padding: 6px; border: 1px solid #DCDFE6; border-radius: 4px;")
        self.ecrf_entry.setPlaceholderText("等待 4 级路径填全后从 062_acrf 自动定位…")
        row1.addWidget(self.ecrf_entry, 1)
        self.btn_browse_ecrf = QPushButton("浏览")
        # v12.10.68：统一改用 helper（与 TOC ▶初版TOC/🟥中止/📂打开TOC 视觉一致）
        self.btn_browse_ecrf.setStyleSheet(light_btn_style())
        self.btn_browse_ecrf.setCursor(Qt.PointingHandCursor)
        self.btn_browse_ecrf.clicked.connect(self._on_browse_ecrf)
        row1.addWidget(self.btn_browse_ecrf)
        gb22_lay.addLayout(row1)

        # 22 进度条 + 运行/中止按钮
        self.prog_22 = QProgressBar()
        self.prog_22.setVisible(False)
        self.prog_22.setFixedHeight(4)
        self.prog_22.setTextVisible(False)  # v12.10.13：4px 太矮装不下文字，关闭百分比显示避免和上方 label 重叠
        gb22_lay.addWidget(self.prog_22)

        row22 = QHBoxLayout()
        self.btn_run_draft = QPushButton("▶ 首次运行 Draft Annotation")
        # v12.9：v12.8 的写法把 disabled 选择器拼在 inline 属性后面，没有 QPushButton 父选择器
        # 包裹 → Qt 把整段当无效属性串解析，按钮反而呈现"系统默认灰"看上去像永远禁用。
        # 修正：每条都用 QPushButton{} / QPushButton:disabled{} 完整选择器。
        # v12.10.68：统一改用 primary_btn_style() 与 TOC ▶初版TOC 视觉一致
        self.btn_run_draft.setStyleSheet(primary_btn_style())
        self.btn_run_draft.setCursor(Qt.PointingHandCursor)
        self.btn_run_draft.setToolTip(
            "复制 eCRF 到 draft/ → 本机调 annodraft（autoanno_study_draft）生成 draft.xfdf + annomap.xlsx。\n"
            "运行成功后此按钮永久禁用，后续修改通过右侧「💾 保存并重跑 autoanno」。\n"
            "若需替换 eCRF 重跑，请先点击左上「🔄 刷新源文件」重置状态。"
        )
        self.btn_run_draft.clicked.connect(self.run_draft_annotation)
        row22.addWidget(self.btn_run_draft)

        self.btn_cancel_22 = QPushButton("🟥 中止")
        # v12.10.68：统一改用 helper（与 TOC ▶初版TOC/🟥中止/📂打开TOC 视觉一致）
        self.btn_cancel_22.setStyleSheet(danger_btn_style())
        self.btn_cancel_22.setCursor(Qt.PointingHandCursor)
        self.btn_cancel_22.setVisible(False)
        self.btn_cancel_22.setCursor(Qt.PointingHandCursor)
        self.btn_cancel_22.clicked.connect(self._on_cancel_run)
        row22.addWidget(self.btn_cancel_22)
        row22.addStretch()
        gb22_lay.addLayout(row22)

        # v12.8：取消 ecrf_entry 改变自动解锁的逻辑 — 用户明确要求"首次运行"严格只能跑一次。
        # 解锁路径仅有一条：左上「🔄 刷新源文件」（明确意图重置状态）。
        # 内部用 _draft_done_locked 持久标志记忆"已跑过"状态，比 isEnabled() 更可靠
        # （isEnabled 在 _enter_running/_exit_running 中会被切换，不能拿来当业务态判定）。
        self._draft_done_locked = False

        # 22 输出按钮行（默认隐藏，按需 setVisible）
        # v12.9：删除「🔍 预览 acrf」 — 与右侧 annomap tab 中的同名按钮重复
        self.btn_open_annomap = self._make_open_btn("📊 打开 annomap.xlsx", self._open_annomap)
        self.btn_open_draft = self._make_open_btn("📂 打开 draft 目录", self._open_draft_dir)
        self.btn_open_annomap.setVisible(False)
        self.btn_open_draft.setVisible(False)
        row22_open = QHBoxLayout()
        row22_open.addWidget(self.btn_open_annomap)
        row22_open.addWidget(self.btn_open_draft)
        row22_open.addStretch()
        gb22_lay.addLayout(row22_open)
        gb22_lay.addStretch()

        # ============== 下区：23 Final Annotation ==============
        gb_23 = QGroupBox("23 Final Annotation")
        gb_23.setStyleSheet(
            "QGroupBox { font-size: 13px; font-weight: bold; color: #409EFF; "
            "border: 1px solid #E4E7ED; border-radius: 4px; margin-top: 10px; padding-top: 6px; }"
            "QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px; }"
        )
        gb23_lay = QVBoxLayout(gb_23)
        gb23_lay.setContentsMargins(12, 10, 12, 10)
        gb23_lay.setSpacing(8)
        gb23_lay.setAlignment(Qt.AlignTop)

        # 终版 acrf.pdf 输入
        row2 = QHBoxLayout()
        lbl2 = QLabel("终版 acrf.pdf：")
        lbl2.setStyleSheet("border: none; color: #606266; min-width: 110px;")
        row2.addWidget(lbl2)
        self.final_pdf_entry = QLineEdit()
        self.final_pdf_entry.setStyleSheet("padding: 6px; border: 1px solid #DCDFE6; border-radius: 4px;")
        self.final_pdf_entry.setPlaceholderText("选择已在 Adobe 中调注完成的 acrf.pdf")
        row2.addWidget(self.final_pdf_entry, 1)
        self.btn_browse_final_pdf = QPushButton("浏览")
        # v12.10.68：统一改用 helper（与 TOC ▶初版TOC/🟥中止/📂打开TOC 视觉一致）
        self.btn_browse_final_pdf.setStyleSheet(light_btn_style())
        self.btn_browse_final_pdf.setCursor(Qt.PointingHandCursor)
        self.btn_browse_final_pdf.clicked.connect(self._on_browse_final_pdf)
        row2.addWidget(self.btn_browse_final_pdf)
        gb23_lay.addLayout(row2)

        # v12.8：导出 xfdf 改为「Adobe 物理操控」流程：
        #   1. 用户点「📂 用 Adobe 打开」拉起 Acrobat — 用户在 Acrobat 内手动 [Comments → Export to Data File] 导出 xfdf
        #   2. Form 在 acrf.pdf 同目录监听 .xfdf 文件出现/变更，自动填入下方 xfdf 路径
        #   3. xfdf 路径填好后才允许跑 ▶ 运行 Final Annotation
        # 旧版基于 pymupdf 的自动导出受 xfdf 方言不兼容拖累 → 已移除（用户明确不再考虑）。
        # COM 自动化（pywin32）尝试驱动 Acrobat 菜单也不可行：Acrobat 的 [Export to Data File]
        # 不在公开 IAC 接口里，必须经 Acrobat UI 触发；让用户手动一次比硬塞一个 fragile COM 调用稳得多。
        hint_box = QHBoxLayout()
        hint_lbl = QLabel("xfdf 导出：")
        hint_lbl.setStyleSheet("border: none; color: #606266; min-width: 110px;")
        hint_box.addWidget(hint_lbl)
        self.btn_open_in_adobe = QPushButton("📂 用 Adobe 打开")
        # v12.10.68：统一改用 helper（与 TOC ▶初版TOC/🟥中止/📂打开TOC 视觉一致）
        self.btn_open_in_adobe.setStyleSheet(light_btn_style())
        self.btn_open_in_adobe.setCursor(Qt.PointingHandCursor)
        self.btn_open_in_adobe.setToolTip(
            "用 Adobe Acrobat 打开终版 acrf.pdf；在 Acrobat 内通过\n"
            "  [Comments] → [Export Comments to Data File...] → 保存为 .xfdf\n"
            "导出后系统会在下方自动填入 xfdf 路径。"
        )
        self.btn_open_in_adobe.clicked.connect(self._open_pdf_in_adobe)
        hint_box.addWidget(self.btn_open_in_adobe)
        hint_box.addStretch()
        gb23_lay.addLayout(hint_box)

        # xfdf 路径展示行（自动检测填入；用户可手动浏览覆盖）
        row_xfdf = QHBoxLayout()
        lbl_xfdf = QLabel("xfdf 文件：")
        lbl_xfdf.setStyleSheet("border: none; color: #606266; min-width: 110px;")
        row_xfdf.addWidget(lbl_xfdf)
        self.xfdf_entry = QLineEdit()
        self.xfdf_entry.setStyleSheet("padding: 6px; border: 1px solid #DCDFE6; border-radius: 4px;")
        self.xfdf_entry.setPlaceholderText("用 Adobe 打开后导出 xfdf，路径会自动填入")
        row_xfdf.addWidget(self.xfdf_entry, 1)
        self.btn_browse_xfdf = QPushButton("浏览")
        # v12.10.68：统一改用 helper（与 TOC ▶初版TOC/🟥中止/📂打开TOC 视觉一致）
        self.btn_browse_xfdf.setStyleSheet(light_btn_style())
        self.btn_browse_xfdf.setCursor(Qt.PointingHandCursor)
        self.btn_browse_xfdf.clicked.connect(self._on_browse_xfdf)
        row_xfdf.addWidget(self.btn_browse_xfdf)
        gb23_lay.addLayout(row_xfdf)

        # 23 进度条 + 运行/中止按钮
        self.prog_23 = QProgressBar()
        self.prog_23.setVisible(False)
        self.prog_23.setFixedHeight(4)
        self.prog_23.setTextVisible(False)  # v12.10.13：4px 太矮装不下文字，关闭百分比显示避免和上方 label 重叠
        gb23_lay.addWidget(self.prog_23)

        row23 = QHBoxLayout()
        self.btn_run_final = QPushButton("▶ 运行 Final Annotation")
        # v12.10.68：统一改用 helper（与 TOC ▶初版TOC/🟥中止/📂打开TOC 视觉一致）
        self.btn_run_final.setStyleSheet(primary_btn_style())
        self.btn_run_final.setCursor(Qt.PointingHandCursor)
        self.btn_run_final.clicked.connect(self.run_final_anno)
        row23.addWidget(self.btn_run_final)

        self.btn_cancel_23 = QPushButton("🟥 中止")
        # v12.10.68：统一改用 helper（与 TOC ▶初版TOC/🟥中止/📂打开TOC 视觉一致）
        self.btn_cancel_23.setStyleSheet(danger_btn_style())
        self.btn_cancel_23.setCursor(Qt.PointingHandCursor)
        self.btn_cancel_23.setVisible(False)
        self.btn_cancel_23.setCursor(Qt.PointingHandCursor)
        self.btn_cancel_23.clicked.connect(self._on_cancel_run)
        row23.addWidget(self.btn_cancel_23)
        row23.addStretch()
        gb23_lay.addLayout(row23)

        # 23 输出按钮（默认隐藏）
        self.btn_open_anno_study = self._make_open_btn("📂 打开 anno_study 数据集", self._open_anno_study)
        self.btn_open_anno_study.setVisible(False)
        row23_open = QHBoxLayout()
        row23_open.addWidget(self.btn_open_anno_study)
        row23_open.addStretch()
        gb23_lay.addLayout(row23_open)
        gb23_lay.addStretch()

        # 把两区放进 splitter
        self._split.addWidget(gb_22)
        self._split.addWidget(gb_23)
        # 1:1 比例（两子区固定均分；用户可拖动 handle 微调）
        self._split.setStretchFactor(0, 1)
        self._split.setStretchFactor(1, 1)
        # 初始大小：用 setSizes 给一个可见的初值，Qt 加载完后会按 stretchFactor 自动调
        self._split.setSizes([300, 300])

    @staticmethod
    def _make_open_btn(text, cb):
        """灰底"📂 打开"小按钮通用样式"""
        b = QPushButton(text)
        b.setStyleSheet(
            "QPushButton { background-color: #F5F7FA; color: #606266; border: 1px solid #DCDFE6; "
            "padding: 4px 10px; border-radius: 4px; font-size: 12px; }"
            "QPushButton:hover { background-color: #EEF2FB; color: #409EFF; border-color: #409EFF; }"
        )
        b.setCursor(Qt.PointingHandCursor)
        b.clicked.connect(cb)
        return b

    # ------------------------- 路径推送 -------------------------
    def update_outputs_visibility(self):
        """
        v12.7：根据当前文件存在性更新三个输出按钮的可见性。

        触发时机：
          - 路径推送（update_paths 末尾）
          - autoanno 完成（_on_draft_finished 末尾）
          - Final 完成（_on_final_finished 末尾）
          - 切换步骤时（stepper 触发）

        默认隐藏，存在则 setVisible(True)。
        """
        # annomap.xlsx 存在 → 显示 📊 打开 annomap
        annomap = self._annomap_path() if self.base_path else ""
        self.btn_open_annomap.setVisible(bool(annomap and os.path.isfile(annomap)))

        # draft 目录存在 → 显示 📂 打开 draft
        if self.base_path:
            d = os.path.join(self.base_path, *_DRAFT_REL)
            self.btn_open_draft.setVisible(os.path.isdir(d))
        else:
            self.btn_open_draft.setVisible(False)

        # v12.9.1：之前残留 self.btn_preview_acrf 的引用 — 该按钮已在 v12.9 删除，
        # update_outputs_visibility 漏改导致每次切到 aCRF 页 / 刷新 / 切项目都抛
        # AttributeError，把整段 update_paths 中断，进而影响后面的"首次运行 Draft Annotation"
        # 按钮初始化（setEnabled/setToolTip 都没跑到），按钮完全不响应。
        # 现在不再在 form 端管 preview 按钮的可见性 — 它在 stepper 的 annomap tab 标题栏，
        # 由 stepper 自己根据 PDF 是否存在决定。这里只发个信号让 stepper 来做。
        try:
            self.sig_outputs_changed.emit()
        except Exception:
            pass

        # anno_study.sas7bdat 存在 → 显示 📂 打开 anno_study
        anno_study_paths = [
            os.path.join(self.base_path, *_ACRF_REL, "anno_study.sas7bdat") if self.base_path else "",
            os.path.join(self.base_path, *_DRAFT_REL, "anno_study.sas7bdat") if self.base_path else "",
            os.path.join(self.base_path, "04_crt", "anno_study.sas7bdat") if self.base_path else "",
        ]
        self.btn_open_anno_study.setVisible(
            any(p and os.path.isfile(p) for p in anno_study_paths)
        )

    def update_paths(self, base_path):
        """
        主控推送 4 级路径：自动定位 062_acrf 下最新 .pdf 作为 eCRF 输入候选。

        v12.10.2：IO 拆到后台线程（_CrfAnnoPathScanThread），主线程立即返回，
        避免 Z:\\ 网络盘多次 listdir + getmtime 累积阻塞 ~0.5-1s 卡顿。
        - 主线程做：base_path 赋值 / UI 状态重置（btn_run_draft 解锁等）/ 清空 entry / 占位
        - 后台线程做：062_acrf / final / draft / annomap / anno_study 等多处 IO 探测
        - 回主线程：根据 token 校验后 setText + 按钮 setVisible
        """
        self.base_path = base_path or ""

        # ===== 主线程立即做：UI 状态重置（用户视觉反馈，不能延迟） =====
        # v12.8：路径推送（刷新源文件 / 切项目）即解锁「首次运行」按钮 — 这是"重置"入口。
        # v12.9.5：由于锁死改用 setVisible(False)，解锁时也要 setVisible(True) 让按钮重新出现
        self._draft_done_locked = False
        # v12.10.99：切项目/刷新即复位 EDC 缺失告警的会话确认标志（新项目重新预检）
        self._edc_missing_acknowledged = False
        if hasattr(self, 'btn_run_draft'):
            self.btn_run_draft.setVisible(True)
            self.btn_run_draft.setEnabled(True)
            self.btn_run_draft.setToolTip(
                "复制 eCRF 到 draft/ → 本机调 annodraft（autoanno_study_draft）生成 draft.xfdf + annomap.xlsx。\n"
                "运行成功后此按钮会隐藏，后续修改通过右侧「💾 保存并重跑 autoanno」。\n"
                "若需替换 eCRF 重跑，请先点击左上「🔄 刷新源文件」重置状态。"
            )

        # 立即清空三个 entry + 占位提示（避免显示旧值）
        self.ecrf_entry.setText("")
        self.ecrf_entry.setPlaceholderText("⏳ 扫描 062_acrf 中…")
        self.final_pdf_entry.clear()
        self.final_pdf_entry.setPlaceholderText("⏳ 扫描 final/ 中…")
        self.xfdf_entry.clear()
        self.xfdf_entry.setPlaceholderText("⏳ 探测同名 .xfdf 中…")

        # 三个输出按钮先隐藏（最终态由后台扫描结果决定）
        if hasattr(self, 'btn_open_annomap'):
            self.btn_open_annomap.setVisible(False)
        if hasattr(self, 'btn_open_draft'):
            self.btn_open_draft.setVisible(False)
        if hasattr(self, 'btn_open_anno_study'):
            self.btn_open_anno_study.setVisible(False)

        # ===== 推后台扫描 =====
        self._path_scan_token += 1
        token = self._path_scan_token
        thread = _CrfAnnoPathScanThread(self.base_path, token, parent=self)
        thread.finished_signal.connect(self._on_path_scan_done)
        self._retired_path_threads.append(thread)
        thread.start()

    def _on_path_scan_done(self, token: int, result: dict):
        """后台扫描完成 → 主线程更新控件（含输出按钮 visibility）。"""
        if token != self._path_scan_token:
            return  # 过期结果丢弃

        # 1. ecrf_entry：062_acrf 下排除 ecrf.pdf 的最新 pdf
        if result.get("acrf_dir_exists"):
            latest = result.get("latest_pdf_in_acrf", "")
            if latest:
                self.ecrf_entry.setText(latest)
                self.ecrf_entry.setPlaceholderText("")
            else:
                self.ecrf_entry.setText("")
                self.ecrf_entry.setPlaceholderText("062_acrf 下未找到 .pdf")
        else:
            self.ecrf_entry.clear()
            self.ecrf_entry.setPlaceholderText(f"找不到目录：{os.path.join(*_ACRF_REL)}")

        # 2. final_pdf_entry / xfdf_entry
        final_picked = result.get("final_pdf_picked", "")
        xfdf_picked = result.get("xfdf_picked", "")
        if final_picked:
            self.final_pdf_entry.setText(final_picked)
            self.final_pdf_entry.setPlaceholderText("")
        else:
            self.final_pdf_entry.clear()
            self.final_pdf_entry.setPlaceholderText("")
        if xfdf_picked:
            self.xfdf_entry.setText(xfdf_picked)
            self.xfdf_entry.setPlaceholderText("")
        else:
            self.xfdf_entry.clear()
            self.xfdf_entry.setPlaceholderText("")

        # 3. 输出按钮 visibility（替代 update_outputs_visibility 的 IO 部分）
        if hasattr(self, 'btn_open_annomap'):
            self.btn_open_annomap.setVisible(bool(result.get("annomap_exists")))
        if hasattr(self, 'btn_open_draft'):
            self.btn_open_draft.setVisible(bool(result.get("draft_dir_exists")))
        if hasattr(self, 'btn_open_anno_study'):
            self.btn_open_anno_study.setVisible(bool(result.get("anno_study_exists")))

        # 4. 通知 stepper 输出存在性变更（让 stepper 同步 annomap tab 头按钮可见性）
        try:
            self.sig_outputs_changed.emit()
        except Exception:
            pass

        sender = self.sender()
        if sender is not None:
            try:
                sender.finished.connect(sender.deleteLater)
            except Exception:
                pass

    @staticmethod
    def _find_latest_pdf(dir_path):
        if not os.path.isdir(dir_path):
            return ""
        cands = []
        for n in os.listdir(dir_path):
            full = os.path.join(dir_path, n)
            if os.path.isfile(full) and n.lower().endswith(".pdf"):
                try:
                    cands.append((full, os.path.getmtime(full)))
                except OSError:
                    pass
        if not cands:
            return ""
        cands.sort(key=lambda x: x[1], reverse=True)
        return cands[0][0]

    @staticmethod
    def _find_latest_pdf_excluding(dir_path, exclude=None):
        """v12.9.5：取最新 .pdf 但排除指定文件名集合（小写比较）。

        用于 062_acrf 下选源 eCRF 候选 — 排除已经被流程处理过的 ecrf.pdf 残留，
        防止用户切项目后误把上次产物当源 PDF。
        """
        if not os.path.isdir(dir_path):
            return ""
        excl = {n.lower() for n in (exclude or set())}
        cands = []
        for n in os.listdir(dir_path):
            if n.lower() in excl:
                continue
            full = os.path.join(dir_path, n)
            if os.path.isfile(full) and n.lower().endswith(".pdf"):
                try:
                    cands.append((full, os.path.getmtime(full)))
                except OSError:
                    pass
        if not cands:
            return ""
        cands.sort(key=lambda x: x[1], reverse=True)
        return cands[0][0]

    def set_wait_hint(self, show):
        if show:
            self.scan_lbl.setText("⏳ 等待填写完整路径...")
            self.scan_lbl.setStyleSheet(scan_status_lbl_style())
        else:
            self.scan_lbl.setText("")

    # ------------------------- 浏览 / 打开 -------------------------
    def _on_browse_ecrf(self):
        start = ""
        cur = self.ecrf_entry.text().strip()
        if cur and os.path.isfile(cur):
            start = os.path.dirname(cur)
        elif self.base_path:
            cand = os.path.join(self.base_path, *_ACRF_REL)
            start = cand if os.path.isdir(cand) else self.base_path
        path, _ = QFileDialog.getOpenFileName(self, "选择 eCRF 文件（062_acrf）", start, "PDF 文件 (*.pdf)")
        if path:
            self.ecrf_entry.setText(path)
            # v12.10.29：用户主动换 ecrf → 解锁「首次运行 Draft Annotation」按钮
            # （之前 v12.9.5 之后只有刷新源文件路径会解锁，换 ecrf 不解锁导致按钮一直隐藏 —
            # 用户报告"多次跑后按钮仍留 / 改 ecrf 没解锁"就是此回滚原因）
            if cur and os.path.normpath(path) != os.path.normpath(cur):
                self._reset_draft_lock()

    def _on_browse_final_pdf(self):
        start = ""
        cur = self.final_pdf_entry.text().strip()
        if cur and os.path.isfile(cur):
            start = os.path.dirname(cur)
        elif self.base_path:
            cand = os.path.join(self.base_path, *_ACRF_REL)
            start = cand if os.path.isdir(cand) else self.base_path
        path, _ = QFileDialog.getOpenFileName(self, "选择终版 acrf.pdf", start, "PDF 文件 (*.pdf)")
        if path:
            self.final_pdf_entry.setText(path)
            # v12.9.2：用户手动改 PDF 时也同步找同名 xfdf 自动填入
            stem = os.path.splitext(path)[0]
            cand_xfdf = stem + ".xfdf"
            if os.path.isfile(cand_xfdf):
                self.xfdf_entry.setText(cand_xfdf)

    def _annomap_path(self) -> str:
        """
        返回 annomap.xlsx 应在的路径（即使文件尚未生成也返回默认期望路径）。

        autoanno 宏的输出位置在不同项目可能略有差异：
          - 优先 062_acrf/draft/annomap.xlsx（与 draft.xfdf 同目录）
          - 退路 062_acrf/annomap.xlsx
        本函数返回"已存在则真实路径，未存在则按 draft 优先策略返回期望路径"，
        让 stepper 的 _load_annomap_into_table 能优雅处理"未生成"分支（显示提示）。
        """
        if not self.base_path:
            return ""
        candidates = [
            os.path.join(self.base_path, *_DRAFT_REL, "annomap.xlsx"),
            os.path.join(self.base_path, *_ACRF_REL, "annomap.xlsx"),
        ]
        for p in candidates:
            if os.path.isfile(p):
                return p
        return candidates[0]  # 默认期望位置（draft 下）

    def _reset_draft_lock(self):
        """v12.10.29：解锁「首次运行 Draft Annotation」按钮。

        触发场景：
          (1) 主控推送新的 base_path（refresh / 切项目，update_paths 内部触发）
          (2) 用户点击 _on_browse_ecrf 选了不同的 ecrf 文件
        """
        self._draft_done_locked = False
        if hasattr(self, 'btn_run_draft'):
            self.btn_run_draft.setVisible(True)
            self.btn_run_draft.setEnabled(True)

    def _open_acrf_dir(self):
        """v12.10.29：打开 062_acrf 目录（用于 annomap 警告对话框中让用户手动删除现有 annomap）"""
        if not self.base_path:
            return
        acrf_dir = os.path.join(self.base_path, *_ACRF_REL)
        if os.path.isdir(acrf_dir):
            os.startfile(acrf_dir)
        else:
            show_dialog(self, "未找到 062_acrf 目录", f"目录不存在：\n{acrf_dir}", "warning")

    def _show_annomap_warning_dialog(self, annomap_path: str, target_ecrf: str) -> bool:
        """v12.10.29：annomap 已存在时的专属警告对话框。

        与 ui_utils.show_choice_dialog 不同 — 这里需要支持「📂 打开 062_acrf」按钮
        点击后**不关闭**对话框（让用户在文件管理器中手动删 annomap 后回来继续），
        所以无法直接复用 show_choice_dialog（它点任意按钮都 accept 关闭）。

        返回：
          True  → 用户选择「继续运行」（注意：annomap 不会被覆盖）
          False → 用户取消
        """
        dlg = QDialog(self)
        dlg.setWindowTitle("Draft Annotation — 检测到现有 annomap")
        dlg.setMinimumSize(640, 280)
        dlg.setStyleSheet("""
            QDialog { background-color: #FFFFFF; }
            QLabel { color: #303133; font-size: 14px; }
            QLabel#muted { color: #909399; font-size: 12px; }
            QPushButton { border-radius: 4px; padding: 8px 18px; font-size: 13px; font-weight: bold; }
            QPushButton#btnBlue  { background-color: #4A6FA5; color: white; border: none; }
            QPushButton#btnBlue:hover  { background-color: #6385B6; }
            QPushButton#btnPlain { background-color: #F5F7FA; color: #606266; border: 1px solid #DCDFE6; }
            QPushButton#btnPlain:hover { background-color: #E4E7ED; }
        """)
        lay = QVBoxLayout(dlg)
        lay.setContentsMargins(25, 22, 25, 18)
        lay.setSpacing(12)

        title_lbl = QLabel("⚠️ 已存在 annomap 文件")
        title_lbl.setStyleSheet("font-size: 15px; font-weight: bold; color: #E6A23C;")
        lay.addWidget(title_lbl)

        path_lbl = QLabel(f"路径：{annomap_path}")
        path_lbl.setObjectName("muted")
        path_lbl.setWordWrap(True)
        lay.addWidget(path_lbl)

        info_lbl = QLabel(
            "继续运行的影响：\n"
            "  • annomap.xlsx —— 不会覆盖（需手动删除后才会重新产生）\n"
            f"  • ecrf.pdf —— 会复制并覆盖重写到 draft/\n"
            "  • draft.xfdf —— 会重新生成（annodraft 内置坐标抽取，不再产生 Coordination.txt）"
        )
        info_lbl.setWordWrap(True)
        info_lbl.setStyleSheet("color: #303133; font-size: 13px;")
        lay.addWidget(info_lbl)

        lay.addStretch()

        result = {"continue": False}

        btn_lay = QHBoxLayout()
        btn_lay.setSpacing(10)

        # 「📂 打开 062_acrf」按钮 — 点击不关闭对话框，方便用户去删 annomap 再回来
        btn_open = QPushButton("📂 打开 062_acrf")
        btn_open.setObjectName("btnPlain")
        btn_open.clicked.connect(self._open_acrf_dir)
        btn_lay.addWidget(btn_open)

        btn_lay.addStretch()

        btn_run = QPushButton("▶ 继续运行")
        btn_run.setObjectName("btnBlue")
        btn_run.clicked.connect(lambda: (result.__setitem__("continue", True), dlg.accept()))
        btn_lay.addWidget(btn_run)

        btn_cancel = QPushButton("取消")
        btn_cancel.setObjectName("btnPlain")
        btn_cancel.clicked.connect(dlg.reject)
        btn_lay.addWidget(btn_cancel)

        lay.addLayout(btn_lay)
        dlg.exec()
        return result["continue"]

    def _open_annomap(self):
        if not self.base_path:
            return
        p = self._annomap_path()
        if p and os.path.isfile(p):
            os.startfile(p)
        else:
            show_dialog(self, "未找到 annomap", "尚未生成 annomap.xlsx。请先运行 ▶ 提取 eCRF + ▶ 运行 autoanno。", "warning")

    def _open_draft_dir(self):
        if not self.base_path:
            return
        d = os.path.join(self.base_path, *_DRAFT_REL)
        if os.path.isdir(d):
            os.startfile(d)
        else:
            show_dialog(self, "未找到 draft 目录", f"目录不存在：\n{d}", "warning")

    def _open_anno_study(self):
        """anno_study.sas7bdat 通常落在 062_acrf 或 062_acrf/draft 下。
        v12.10.31：与 home 页 .sas7bdat 行为统一 — 一律用 SAS EG 打开（修 Issue 5）。
        若未在常见位置找到则提示。"""
        if not self.base_path:
            return
        candidates = [
            os.path.join(self.base_path, *_ACRF_REL, "anno_study.sas7bdat"),
            os.path.join(self.base_path, *_DRAFT_REL, "anno_study.sas7bdat"),
            os.path.join(self.base_path, "04_crt", "anno_study.sas7bdat"),
        ]
        for p in candidates:
            if os.path.isfile(p):
                # v12.10.31：与 home 页统一，走 SAS EG
                from gui.main_window import open_with_saseg_or_default
                open_with_saseg_or_default(p, status_callback=lambda m: self.sig_log.emit(
                    f"<span style='color:#909399;'>{m}</span>"))
                return
        show_dialog(self, "未找到 anno_study", "尚未生成 anno_study.sas7bdat。请先运行 ▶ Final Annotation。", "warning")

    # ------------------------- 23 Final：xfdf 导出辅助 -------------------------
    def _open_pdf_in_adobe(self):
        """
        v12.8：把 acrf.pdf 用 Adobe Acrobat 拉起，并启动后台轮询监听 .xfdf 落地。

        流程：
          1. 校验 final_pdf_entry 路径有效
          2. 优先用 Adobe Acrobat（注册表查 'AcroRd32.exe' 或 'Acrobat.exe'）；
             找不到时退化到 os.startfile（让系统默认 PDF 应用打开）
          3. 启动 _start_xfdf_watcher：每秒扫描 acrf.pdf 同目录下 .xfdf 文件，
             命中且 mtime 比启动时新 → 自动填入 self.xfdf_entry
        """
        pdf = self.final_pdf_entry.text().strip()
        if not pdf:
            show_dialog(self, "提示", "请先选择终版 acrf.pdf。", "warning")
            return
        if not os.path.isfile(pdf):
            show_dialog(self, "错误", f"找不到 PDF：\n{pdf}", "error")
            return

        # 1. 拉起 Adobe
        adobe_exe = self._find_adobe_exe()
        try:
            if adobe_exe:
                subprocess.Popen([adobe_exe, pdf], shell=False, creationflags=0x00000008)
                self.sig_log.emit(
                    f"<span style='color:#909399;'>📂 已用 Adobe 打开：{os.path.basename(pdf)}</span>"
                )
            else:
                os.startfile(pdf)
                self.sig_log.emit(
                    f"<span style='color:#E6A23C;'>📂 未检测到 Adobe Acrobat — 已用系统默认 PDF 应用打开。"
                    f"如非 Adobe，可能无法导出 xfdf。</span>"
                )
        except Exception as e:
            show_dialog(self, "打开失败", f"无法打开 PDF：{e}", "error")
            return

        # 2. 启动 xfdf 文件监听
        self._start_xfdf_watcher(os.path.dirname(pdf))
        self.sig_log.emit(
            "<span style='color:#67C23A;'>👀 正在监听 xfdf 文件落地 — Acrobat 中导出后将自动填入「xfdf 文件」。</span>"
        )

        # v12.9.6：弹窗指引用户导出 xfdf（与 22 导入弹窗对称）
        # v12.9.7：align="right" 让弹窗右移避开 Adobe Acrobat 居中窗口
        show_dialog(
            self, "请在 Adobe 中导出 xfdf",
            f"已打开：\n  {pdf}\n\n"
            f"请在 Adobe Acrobat 中：\n"
            f"  1. 点击右侧侧边栏中 💬（评论）按钮 → 再点击 ⋮（选项）按钮 → 选择「导出所有注释到数据文件」\n"
            f"  2. 文件类型选 .xfdf 保存（建议保存到 PDF 同目录便于自动检测填入下方「xfdf 文件」框）\n"
            f"  3. 路径自动填入后点击 ▶ 运行 Final Annotation\n\n"
            f"如系统未检测到 Adobe Acrobat，可能用了默认 PDF 应用打开 — 请用 Adobe 重新打开。",
            "info", align="right"
        )

    @staticmethod
    def _find_adobe_exe():
        """探测系统中 Adobe Acrobat 可执行路径（Windows）。

        策略：
          - 注册表 HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\Acrobat.exe
          - 退路扫常见安装位置 C:\\Program Files\\Adobe\\Acrobat ...
          - 都没找到返回 None（让调用方退化到 os.startfile）
        """
        if os.name != "nt":
            return None
        try:
            import winreg
            for key_name in ("Acrobat.exe", "AcroRd32.exe"):
                try:
                    key = winreg.OpenKey(
                        winreg.HKEY_LOCAL_MACHINE,
                        rf"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\{key_name}"
                    )
                    val, _ = winreg.QueryValueEx(key, None)
                    winreg.CloseKey(key)
                    if val and os.path.isfile(val):
                        return val
                except OSError:
                    continue
        except Exception:
            pass
        # 兜底：常见安装位置
        for cand in (
            r"C:\Program Files\Adobe\Acrobat DC\Acrobat\Acrobat.exe",
            r"C:\Program Files (x86)\Adobe\Acrobat DC\Acrobat\Acrobat.exe",
            r"C:\Program Files\Adobe\Acrobat 2020\Acrobat\Acrobat.exe",
            r"C:\Program Files (x86)\Adobe\Acrobat Reader DC\Reader\AcroRd32.exe",
        ):
            if os.path.isfile(cand):
                return cand
        return None

    def _start_xfdf_watcher(self, watch_dir: str):
        """
        启动 QTimer 每秒扫描多个目录的 .xfdf 文件，命中最新就自动填入 xfdf_entry。

        v12.9：扩大监听范围 — Acrobat 的 [Export Comments to Data File] 不强制保存到
        PDF 同目录，沿用上次保存对话框的目录。早期版本只扫 PDF 同目录，用户保存到桌面就检测不到
        （这就是用户报告"导出后下方框没自动填入"的根因）。
        现在监听：watch_dir + 用户 Desktop / Documents（中英目录名都试）。
        60 秒超时自动停止避免永远空跑。
        """
        from PySide6.QtCore import QTimer
        if hasattr(self, "_xfdf_timer") and self._xfdf_timer is not None:
            try:
                self._xfdf_timer.stop()
            except Exception:
                pass

        watch_dirs = [watch_dir]
        try:
            home = os.path.expanduser("~")
            for sub in ("Desktop", "Documents", "桌面", "文档"):
                p = os.path.join(home, sub)
                if os.path.isdir(p) and p not in watch_dirs:
                    watch_dirs.append(p)
        except Exception:
            pass

        self._xfdf_watch_dirs = watch_dirs
        self._xfdf_watch_started_at = time.time() - 0.5
        self._xfdf_timer_stop_at = time.time() + 60
        self._xfdf_timer = QTimer(self)
        self._xfdf_timer.setInterval(1000)
        self._xfdf_timer.timeout.connect(self._poll_xfdf_dir)
        self._xfdf_timer.start()

    def _poll_xfdf_dir(self):
        """xfdf 监听 timer 的回调 — 在所有 watch_dirs 中找 mtime 最新的 .xfdf"""
        dirs = getattr(self, "_xfdf_watch_dirs", [])
        started_at = getattr(self, "_xfdf_watch_started_at", 0)
        stop_at = getattr(self, "_xfdf_timer_stop_at", 0)

        # 60 秒超时自动停止
        if stop_at and time.time() > stop_at:
            try:
                self._xfdf_timer.stop()
                self.sig_log.emit(
                    "<span style='color:#909399;'>⚠ xfdf 监听已超时（60s）。如需重新检测请再次点击「📂 用 Adobe 打开」。</span>"
                )
            except Exception:
                pass
            return

        all_cands = []
        for d in dirs:
            if not d or not os.path.isdir(d):
                continue
            try:
                for n in os.listdir(d):
                    if not n.lower().endswith(".xfdf"):
                        continue
                    full = os.path.join(d, n)
                    try:
                        mt = os.path.getmtime(full)
                        if mt >= started_at:
                            all_cands.append((full, mt))
                    except OSError:
                        continue
            except OSError:
                continue
        if not all_cands:
            return
        all_cands.sort(key=lambda x: x[1], reverse=True)
        latest = all_cands[0][0]
        self.xfdf_entry.setText(latest)
        self._xfdf_timer.stop()
        self.sig_log.emit(
            f"<span style='color:#67C23A;'>✅ 已自动检测到 xfdf 文件：{latest}</span>"
        )

    def _on_browse_xfdf(self):
        """xfdf 浏览按钮 — 让用户手动指定（autodetect 失败的兜底）"""
        start = ""
        cur = self.xfdf_entry.text().strip()
        if cur and os.path.isfile(cur):
            start = os.path.dirname(cur)
        elif self.final_pdf_entry.text().strip():
            start = os.path.dirname(self.final_pdf_entry.text().strip())
        elif self.base_path:
            cand = os.path.join(self.base_path, *_ACRF_REL)
            start = cand if os.path.isdir(cand) else self.base_path
        path, _ = QFileDialog.getOpenFileName(self, "选择 xfdf 文件", start, "XFDF 文件 (*.xfdf)")
        if path:
            self.xfdf_entry.setText(path)

    # ------------------------- 全局快捷键钩子 -------------------------
    def action_refresh(self):
        if self.refresh_btn.isEnabled():
            self.refresh_btn.click()

    # 03 有多个运行入口 — Ctrl+Enter 不绑定（语义不明确）

    # ------------------------- 22 Draft：提取 eCRF -------------------------
    def run_draft_annotation(self):
        """
        ▶ 运行 Draft Annotation

        v12.10.29：执行模式简化 — 删除"是否保留 Coordination.txt"二选一对话框，
        统一走 full（默认刷新 Coordination.txt + 复制覆盖 ecrf.pdf）。
        v12.10.99：底层换本机 annodraft（Python），Coordination.txt 彻底退出流程。

        新流程：
          1. 路径校验（ecrf 必须有；062_acrf 目录必须在；annodraft 包必须可达）
          2. EDC 数据库定义预检（找不到弹窗告警但允许继续，见 _check_edc_def_or_confirm）
          3. 检查 062_acrf 下是否有 annomap.xlsx：
             - 有 → 弹专属警告对话框：annomap 不会覆盖 / ecrf.pdf 会覆盖 / xfdf 会重新生成
                   提供 [📂 打开 062_acrf] [▶ 继续运行] [取消] 三按钮。
             - 没有 → 不弹对话框，log 中提示 ecrf.pdf 会被复制覆盖，直接进 full
          4. 跑 full（_do_full_draft 内部锁定按钮）
        """
        if self._is_running():
            return

        # v12.9：双重保险锁 — setEnabled(False) 在某些 Qt 环境下用户长按可能产生重复 click
        # 信号；用 _draft_done_locked 持久标志在业务层硬拒，确保锁死后 100% 不可重入。
        if getattr(self, '_draft_done_locked', False):
            self.sig_log.emit(
                "<span style='color:#909399;'>已锁定。请使用「💾 保存并重跑 autoanno」更新，"
                "或点击「🔄 刷新源文件」重置后重新提取 eCRF。</span>"
            )
            return

        ecrf_path = self.ecrf_entry.text().strip()
        if not ecrf_path:
            show_dialog(self, "提示", "请先选择 eCRF 文件。", "warning")
            return
        if not os.path.isfile(ecrf_path):
            show_dialog(self, "错误", f"找不到 eCRF 文件：\n{ecrf_path}", "error")
            return

        acrf_dir = os.path.join(self.base_path, *_ACRF_REL)
        if not os.path.isdir(acrf_dir):
            show_dialog(self, "错误", f"找不到 062_acrf 目录：\n{acrf_dir}", "error")
            return

        # v12.10.99：annodraft 包可达性前置检查（共享盘断连 / 未部署时尽早失败）
        pkg_parent = _find_annodraft_pkg_parent()
        if not pkg_parent:
            show_dialog(
                self, "annodraft 包未找到",
                "未在以下候选位置找到部门 annodraft 工具包（autoanno_draft/__init__.py）：\n"
                + "\n".join(f"  • {p}" for p in _ANNODRAFT_PKG_PARENT_CANDIDATES)
                + "\n\n请确认共享盘连接正常，或联系部门管理员部署。",
                "error"
            )
            return

        # v12.10.99：EDC 数据库定义预检（缺失 → 弹窗告警，但允许继续）
        if not self._check_edc_def_or_confirm():
            self.sig_log.emit("<span style='color:#909399;'>已取消 Draft Annotation。</span>")
            return

        # v12.9.5：062 下不再放 ecrf.pdf — 改为只往 draft/ 下放重命名为 ecrf.pdf 的副本
        target_ecrf = os.path.join(self.base_path, *_DRAFT_REL, "ecrf.pdf")

        # v12.10.29：检查 annomap.xlsx 是否已存在（062_acrf/draft 优先 / 062_acrf/ 退路）
        annomap_existing = self._annomap_path()
        annomap_exists = bool(annomap_existing and os.path.isfile(annomap_existing))

        if annomap_exists:
            ok = self._show_annomap_warning_dialog(annomap_existing, target_ecrf)
            if not ok:
                self.sig_log.emit("<span style='color:#909399;'>已取消 Draft Annotation。</span>")
                return
        else:
            # 无 annomap：仍然提示用户 ecrf.pdf 会被覆盖（写到日志而不是弹窗，减少打扰）
            self.sig_log.emit(
                "<span style='color:#909399;'>&nbsp;&nbsp;ℹ ecrf.pdf 将被复制并覆盖重写到 draft/。</span>"
            )

        # v12.10.99：统一走 full（复制源 PDF 后调 annodraft）
        self._do_full_draft(ecrf_path, pkg_parent, target_ecrf)

    def _do_full_draft(self, ecrf_path, pkg_parent, target_ecrf):
        """模式 full：复制源 PDF 到 draft/ecrf.pdf → 本机调 annodraft（v12.10.99）

        v12.9.5：062_acrf 下原 PDF 维持不动；只把它复制到 draft/ecrf.pdf。
        v12.10.99：删除旧链路（删 Coordination.txt + filename pipe 调 coordination.py +
        %autoanno_study_draft 宏）。annodraft 内部自行抽取坐标，full 与 autoanno_only
        调的是同一个 autoanno_study_draft()；full 的唯一额外动作是复制源 PDF。
        """
        # ---- Python 端：把源 PDF 复制到 draft/ecrf.pdf（062 下原 PDF 不动）----
        draft_dir = os.path.join(self.base_path, *_DRAFT_REL)
        try:
            os.makedirs(draft_dir, exist_ok=True)
        except OSError as e:
            show_dialog(self, "错误", f"无法创建 draft 目录：{e}", "error")
            return

        # 直接复制到 draft/ecrf.pdf（即一步完成"复制 + 重命名"）
        # 若已存在旧 ecrf.pdf 则先删除避免 copy2 在 Windows 上 EACCES
        if os.path.isfile(target_ecrf):
            try:
                os.remove(target_ecrf)
            except OSError:
                pass
        try:
            if os.path.abspath(ecrf_path) != os.path.abspath(target_ecrf):
                shutil.copy2(ecrf_path, target_ecrf)
        except OSError as e:
            show_dialog(self, "错误", f"复制到 draft/ecrf.pdf 失败：{e}", "error")
            return

        # ---- 写临时 driver（%TEMP%）：sys.path 注入部门包父目录 + 调唯一入口 ----
        ok, driver_path, msg = self._write_tmp_annodraft_py(pkg_parent, target_ecrf)
        if not ok:
            show_dialog(self, "错误", msg, "error")
            return

        self.sig_run_started.emit()
        self.sig_status.emit("⏳ 正在运行 Draft Annotation（full）…", "#409EFF")
        self.sig_log.emit("<span style='color:#409EFF; font-weight:bold;'>🚀 ▶ 运行 Draft Annotation（full：复制 eCRF + annodraft）</span>")
        self.sig_log.emit(f"<span style='color:#909399;'>&nbsp;&nbsp;源 PDF（062_acrf 维持不动）：{ecrf_path}</span>")
        self.sig_log.emit(f"<span style='color:#909399;'>&nbsp;&nbsp;复制并重命名到：{target_ecrf}</span>")
        self.sig_log.emit(f"<span style='color:#909399;'>&nbsp;&nbsp;调用：{os.path.join(pkg_parent, 'autoanno_draft')}（本机 Python 子进程）</span>")

        self._autoanno_mode = "full"  # v12.9.4
        self._enter_running(self.btn_run_draft, self.btn_cancel_22, self.prog_22)
        self._start_py_runner(driver_path)

    def _do_autoanno_only(self):
        """模式 autoanno_only：调同一个 annodraft 入口（v12.10.99）

        v12.10.99：旧 SAS 链路（rc 兜底宏 + %autoanno_study_draft）退役。前置检查由
        Coordination.txt 改为 draft/ecrf.pdf 存在且非空（annodraft 内部用 pdfminer
        直接读它抽坐标，full / autoanno_only 调的是同一个函数、同一参数）。

        v12.10.6 约定保留：early return（前置缺失 / driver 写盘失败 / 包不可达）时
        主动 emit sig_autoanno_finished — 防止上游（如 _on_annomap_saved）误以为
        autoanno 已启动而把按钮永久禁用。正常路径下 sig_autoanno_started 在
        _enter_autoanno_only_running 内 emit；finished 在 _on_draft_finished 内 emit。
        """
        target_ecrf = os.path.join(self.base_path, *_DRAFT_REL, "ecrf.pdf")
        if not os.path.isfile(target_ecrf) or os.path.getsize(target_ecrf) == 0:
            show_dialog(
                self, "前置缺失",
                "draft/ecrf.pdf 不存在或为空，无法重跑 autoanno。\n"
                "请先在「22 Draft Annotation」中「首次运行」（会把源 eCRF 复制到 draft/）。",
                "warning"
            )
            try:
                self.sig_autoanno_finished.emit(True, False, "前置缺失：draft/ecrf.pdf")
            except Exception:
                pass
            return

        pkg_parent = _find_annodraft_pkg_parent()
        if not pkg_parent:
            show_dialog(
                self, "annodraft 包未找到",
                "未在以下候选位置找到部门 annodraft 工具包（autoanno_draft/__init__.py）：\n"
                + "\n".join(f"  • {p}" for p in _ANNODRAFT_PKG_PARENT_CANDIDATES)
                + "\n\n请确认共享盘连接正常，或联系部门管理员部署。",
                "error"
            )
            try:
                self.sig_autoanno_finished.emit(True, False, "annodraft 包未找到")
            except Exception:
                pass
            return

        # v12.10.99：EDC 预检 — 重跑路径同样允许继续；用户取消时按 v12.10.6 约定发 finished
        if not self._check_edc_def_or_confirm():
            self.sig_log.emit("<span style='color:#909399;'>已取消 autoanno 重跑。</span>")
            try:
                self.sig_autoanno_finished.emit(True, False, "用户取消（EDC 预检）")
            except Exception:
                pass
            return

        ok, driver_path, msg = self._write_tmp_annodraft_py(pkg_parent, target_ecrf)
        if not ok:
            show_dialog(self, "错误", msg, "error")
            try:
                self.sig_autoanno_finished.emit(True, False, msg or "driver 写盘失败")
            except Exception:
                pass
            return

        self.sig_run_started.emit()
        self.sig_status.emit("⏳ 正在运行 Draft Annotation（重跑 autoanno）…", "#409EFF")
        self.sig_log.emit("<span style='color:#409EFF; font-weight:bold;'>🚀 ▶ 重跑 autoanno（annodraft，基于 draft/ecrf.pdf）</span>")
        # v12.9.4：autoanno_only **不调** _enter_running — 那会把左侧 btn_run_draft 切成中止
        # 显示并清掉锁死状态。改为仅显示 prog_22 + 禁用其它运行入口；按钮状态由 stepper
        # 通过 sig_autoanno_started/finished 管理，独立于 btn_run_draft。
        self._autoanno_mode = "autoanno_only"
        self._enter_autoanno_only_running()
        self._start_py_runner(driver_path)

    def _enter_autoanno_only_running(self):
        """v12.9.4：autoanno_only 专用 — 仅切换最小 UI，不动 btn_run_draft（保持锁死外观）。
        通过 sig_autoanno_started 通知 stepper 自行切换「保存并重跑」按钮为中止状态。"""
        self.prog_22.setRange(0, 0)
        self.prog_22.setVisible(True)
        # 禁用其它运行入口避免并发：btn_run_final + 刷新按钮（避免运行中刷新清状态）
        self.btn_run_final.setEnabled(False)
        if hasattr(self, 'refresh_btn'):
            self.refresh_btn.setEnabled(False)
        try:
            self.sig_autoanno_started.emit()
        except Exception:
            pass

    def _exit_autoanno_only_running(self):
        """v12.9.8：仅做 UI 恢复；sig_autoanno_finished 信号由调用方（_on_draft_finished /
        _on_cancel_run）按算出的 has_error/has_warning 状态决定再 emit，避免在 finished 信号
        参数中传递 None 占位。"""
        self.prog_22.setVisible(False)
        self.btn_run_final.setEnabled(True)
        if hasattr(self, 'refresh_btn'):
            self.refresh_btn.setEnabled(True)

    def _on_draft_finished(self, has_issue, summary, log_text):
        """Draft Annotation 统一回调（full 与 autoanno_only 共用）

        v12.7：完成后自动通知 stepper 切到 annomap 编辑 Tab + 在 PDF 注入 + 弹预览。
        通过 sig_annomap_updated(path) 推送 annomap 路径，stepper 端做切 Tab + 重载。

        v12.9.4 关键变更：
          - 按 self._autoanno_mode 分支决定如何恢复 UI（不再统一 _exit_running，
            那会破坏首次运行后的 btn_run_draft 锁死状态）
          - 自动弹预览仅在 autoanno_only 模式触发；full（首次运行）模式不自动弹，
            让用户主动按「🔍 预览 acrf」按钮 — 这是用户明确要求

        v12.10.31：顶部加 _cancelled 保护（修 autoanno cancel 闪退）。
          原 SingleBatchRunner 在 cancel 路径下 run() 直接 return 不 emit，
          理论上本回调不会被触发。但极偶发 race（proc 自然结束与 cancel 同步击中）
          仍可能让 finished_signal 被 emit 出来，那时 _on_cancel_run 已经做完
          UI 复位 + 状态信号 emit，本回调若再走全套流程会触发"双 UI 改动"导致
          widget 状态不一致 → 闪退。简单 return 即可（cleanup 走 _on_runner_thread_done）。
        """
        # v12.10.31：cancel 路径短路 — UI / 状态信号 / 引用清理都已在 _on_cancel_run 做过
        if getattr(self, "_cancelled", False):
            return
        mode = self._autoanno_mode or "full"  # 兼容老路径
        if mode == "autoanno_only":
            self._exit_autoanno_only_running()
        else:
            self._exit_running(self.btn_run_draft, self.btn_cancel_22, self.prog_22)
        elapsed = time.time() - self._t_start

        annomap_path = self._annomap_path()
        annomap_found = os.path.isfile(annomap_path)
        # v12.10.99：Coordination.txt 已退出 22 线（annodraft 内置坐标抽取），不再探测/展示

        # v12.9.8：拆分 error vs warning，分别用红/黄；纯 warning 不再误标红
        has_error, has_warning = self._split_has_error_warning(log_text)

        if has_error:
            # 真有 ERROR — 红
            self.sig_status.emit(f"❌ Draft 完成（含 ERROR）", "#F56C6C")
            self.sig_step_update.emit("04 CRF Annotation ❌")
            self.sig_log.emit(
                f"<span style='color:#F56C6C; font-weight:bold;'>❌ Draft 含 ERROR — {summary}</span>"
            )
            # v12.10.100：不再二次汇总 ERROR/WARNING —— annodraft 控制台原文已逐行实时打印。
        elif has_warning:
            # 仅 WARNING — 黄（autoanno 几乎一定会有，不该红色误警）
            self.sig_status.emit(f"⚠ Draft 完成（含 WARNING，{elapsed:.1f}s）", "#E6A23C")
            self.sig_step_update.emit("04 CRF Annotation ⚠️")
            self.sig_log.emit(
                f"<span style='color:#E6A23C; font-weight:bold;'>⚠ Draft 含 WARNING — {summary}</span>"
            )
            # v12.10.100：同上，去重 —— 原始逐行打印已足够，不再追加 _extract_issue_lines。
            if annomap_found:
                self.sig_log.emit(f"<span style='color:#909399;'>&nbsp;&nbsp;annomap：{annomap_path}</span>")
        else:
            # 干净通过 — 绿
            self.sig_status.emit(f"✅ Draft 完成（{elapsed:.1f}s）", "#67C23A")
            self.sig_step_update.emit("04 CRF Annotation ✅")   # v12.10.126：补漏——成功分支
            #   之前漏 emit，导致 full 模式草标干净通过时 stepper 侧沙漏图标不消、耗时计时不停。
            self.sig_log.emit(
                f"<span style='color:#67C23A; font-weight:bold;'>✅ Draft Annotation 执行完毕 — {summary}</span>"
            )
            if annomap_found:
                self.sig_log.emit(f"<span style='color:#909399;'>&nbsp;&nbsp;annomap：{annomap_path}</span>")

        # v12.9.6：full 模式跑完即锁死「首次运行」按钮（不再依赖 has_issue），
        # 直接 setVisible(False) — 直到「刷新源文件」才重新显示。
        # 根因（v12.9.5 失效）：旧版 `if not has_issue` 把锁死与"无错"绑定，但 SAS autoanno
        # 几乎一定会有 WARNING（standard 列空缺 / 字符截断等用户已报过的），has_issue=True 时
        # 按钮永远不消失。出错时用户可走「🔄 刷新源文件」重置。
        # autoanno_only 模式不动 btn_run_draft（按钮已经处于隐藏态）。
        if mode == "full":
            self._draft_done_locked = True
            self.btn_run_draft.setVisible(False)

        # 触发外层联动：刷新 annomap Tab + 显示打开按钮
        if annomap_found:
            try:
                self.sig_annomap_updated.emit(annomap_path)
            except Exception:
                pass
        # 文件存在性变更 → 让 stepper 重新决定输出按钮可见性
        try:
            self.sig_outputs_changed.emit()
        except Exception:
            pass

        # v12.9.5：删除 PyMuPDF 自动注入预览（根因：PyMuPDF 的 add_freetext_annot 不能还原
        # xfdf 中 line/polygon/highlight 等多种注释类型，颜色/边框/形状全失真）。
        # 改为提示用户用 annomap tab 中的「📋 导入 xfdf」按钮在 Adobe 中手动导入获得精确效果。
        xfdf_path = self._find_draft_xfdf()
        if xfdf_path:
            self.sig_log.emit(
                f"<span style='color:#909399;'>&nbsp;&nbsp;draft.xfdf 已生成：{xfdf_path}</span>"
            )
            self.sig_log.emit(
                "<span style='color:#909399;'>&nbsp;&nbsp;ℹ 在 annomap tab 顶部点击「📋 导入 xfdf」用 Adobe 打开 draft/ecrf.pdf 并手动 Import Comments。</span>"
            )
        else:
            self.sig_log.emit(
                "<span style='color:#E6A23C;'>&nbsp;&nbsp;⚠ 未在 draft 目录找到 .xfdf — autoanno 可能未生成 draft.xfdf。</span>"
            )

        self._autoanno_mode = ""  # v12.9.4：清空模式标志，避免下次误判
        self._cleanup_runner()

        # v12.9.8：autoanno_only 模式 emit 带状态参数的 finished 信号 → stepper 在 annomap
        # tab 下方显示简略结果（用户停留在 annomap tab 时也能感知运行结果）
        if mode == "autoanno_only":
            try:
                self.sig_autoanno_finished.emit(has_error, has_warning, summary or "")
            except Exception:
                pass

    def _find_draft_xfdf(self):
        """autoanno 宏的输出 xfdf 命名常含日期戳；找 062_acrf/draft 下最新的 .xfdf"""
        d = os.path.join(self.base_path, *_DRAFT_REL)
        if not os.path.isdir(d):
            return ""
        cands = []
        for name in os.listdir(d):
            full = os.path.join(d, name)
            if os.path.isfile(full) and name.lower().endswith(".xfdf"):
                try:
                    cands.append((full, os.path.getmtime(full)))
                except OSError:
                    pass
        if not cands:
            return ""
        cands.sort(key=lambda x: x[1], reverse=True)
        return cands[0][0]

    # ------------------------- 23 Final -------------------------
    def run_final_anno(self):
        """
        ▶ 运行 Final Annotation：
          1. 校验终版 acrf.pdf
          2. 读 xfdf_entry（v12.8：用户在 Adobe 中已手动导出，路径自动检测填入或手动浏览）
          3. 重写 23_anno_final_call.sas 中的 xfdfname 参数
          4. SingleBatchRunner 跑
        """
        if self._is_running():
            return

        pdf_path = self.final_pdf_entry.text().strip()
        if not pdf_path:
            show_dialog(self, "提示", "请先选择终版 acrf.pdf。", "warning")
            return
        if not os.path.isfile(pdf_path):
            show_dialog(self, "错误", f"找不到 PDF：\n{pdf_path}", "error")
            return

        # v12.8：xfdf 必须由用户手动导出（避开 pymupdf 序列化方言坑）
        xfdf_path = self.xfdf_entry.text().strip()
        if not xfdf_path:
            show_dialog(
                self, "缺少 xfdf 文件",
                "尚未指定 xfdf。请先点击「📂 用 Adobe 打开」在 Acrobat 中导出 xfdf，"
                "或点击「浏览」手动选择已有的 xfdf 文件。",
                "warning"
            )
            return
        if not os.path.isfile(xfdf_path):
            show_dialog(self, "错误", f"找不到 xfdf：\n{xfdf_path}", "error")
            return

        acrf_dir = os.path.join(self.base_path, *_ACRF_REL)
        if not os.path.isdir(acrf_dir):
            show_dialog(self, "错误", f"找不到 062_acrf 目录：\n{acrf_dir}", "error")
            return

        # 23_anno_final_call.sas 路径
        sas_call = os.path.join(self.base_path, *_TOOLS_REL, "23_anno_final_call.sas")
        if not os.path.isfile(sas_call):
            show_dialog(self, "错误", f"找不到 23_anno_final_call.sas：\n{sas_call}", "error")
            return

        xfdf_basename = os.path.basename(xfdf_path)

        # 23 宏要求 xfdf 与 acrf.pdf 在同一目录（062_acrf）— 若不在，复制过去
        target_xfdf = os.path.join(acrf_dir, xfdf_basename)
        if os.path.abspath(xfdf_path) != os.path.abspath(target_xfdf):
            try:
                shutil.copy2(xfdf_path, target_xfdf)
            except OSError as e:
                show_dialog(self, "错误", f"复制 xfdf 到 062_acrf 失败：{e}", "error")
                return

        # 重写 23_anno_final_call.sas
        ok, msg = _rewrite_macro_param(sas_call, "anno_study_final", "xfdfname", xfdf_basename)
        if not ok and "无需改写" not in msg:
            show_dialog(self, "错误", f"改写 23_anno_final_call.sas 失败：{msg}", "error")
            return

        self.sig_run_started.emit()
        self.sig_status.emit("⏳ 正在运行 Final Annotation…", "#409EFF")
        self.sig_log.emit("<span style='color:#409EFF; font-weight:bold;'>🚀 ▶ 运行 Final Annotation</span>")
        self.sig_log.emit(f"<span style='color:#909399;'>&nbsp;&nbsp;终版 PDF：{pdf_path}</span>")
        self.sig_log.emit(f"<span style='color:#909399;'>&nbsp;&nbsp;xfdf：{target_xfdf}</span>")
        self.sig_log.emit(f"<span style='color:#909399;'>&nbsp;&nbsp;脚本：{sas_call}</span>")
        if ok:
            self.sig_log.emit(f"<span style='color:#67C23A;'>&nbsp;&nbsp;✏️ 已改写 xfdfname=%str({xfdf_basename})</span>")

        self._enter_running(self.btn_run_final, self.btn_cancel_23, self.prog_23)
        self._start_runner(sas_call, self._on_final_finished)

    def _on_final_finished(self, has_issue, summary, log_text):
        # v12.10.31：cancel 路径短路 — UI / 状态信号 / 引用清理都已在 _on_cancel_run 做过
        if getattr(self, "_cancelled", False):
            return
        self._exit_running(self.btn_run_final, self.btn_cancel_23, self.prog_23)
        elapsed = time.time() - self._t_start

        # v12.9.8：拆分 error vs warning，分别用红/黄
        has_error, has_warning = self._split_has_error_warning(log_text)

        if has_error:
            self.sig_status.emit(f"❌ Final 完成（含 ERROR）", "#F56C6C")
            self.sig_step_update.emit("04 CRF Annotation ❌")
            self.sig_log.emit(
                f"<span style='color:#F56C6C; font-weight:bold;'>❌ Final 含 ERROR — {summary}</span>"
            )
            self.sig_log.emit(self._extract_issue_lines(log_text))
        elif has_warning:
            self.sig_status.emit(f"⚠ Final 完成（含 WARNING，{elapsed:.1f}s）", "#E6A23C")
            self.sig_step_update.emit("04 CRF Annotation ⚠️")
            self.sig_log.emit(
                f"<span style='color:#E6A23C; font-weight:bold;'>⚠ Final 含 WARNING — {summary}</span>"
            )
            self.sig_log.emit(self._extract_issue_lines(log_text))
        else:
            self.sig_status.emit(f"✅ Final 完成（{elapsed:.1f}s）", "#67C23A")
            self.sig_step_update.emit("04 CRF Annotation ✅")
            self.sig_log.emit(
                f"<span style='color:#67C23A; font-weight:bold;'>✅ Final Annotation 执行完毕 — {summary}</span>"
            )

        # v12.7：anno_study.sas7bdat 是否生成 → 让 stepper 重新决定打开按钮可见性
        try:
            self.sig_outputs_changed.emit()
        except Exception:
            pass

        # v12.9.8：通知 stepper 切到「运行日志」tab — 用户应该看输出（含 has_error/warning 提示）
        try:
            self.sig_final_finished.emit()
        except Exception:
            pass

        self._cleanup_runner()

    # ------------------------- 公共：Runner 生命周期 -------------------------
    def _is_running(self):
        if self._runner is not None and self._runner.isRunning():
            self.sig_log.emit("<span style='color:#E6A23C;'>⏳ 上一次运行尚未结束，请稍候…</span>")
            return True
        return False

    def _enter_running(self, run_btn, cancel_btn, prog_bar):
        run_btn.setVisible(False)
        cancel_btn.setVisible(True)
        prog_bar.setRange(0, 0)
        prog_bar.setVisible(True)
        # 同步禁用其它运行按钮（避免并发跑导致 SAS 会话冲突）
        for b in (self.btn_run_draft, self.btn_run_final):
            if b is not run_btn:
                b.setEnabled(False)

    def _exit_running(self, run_btn, cancel_btn, prog_bar):
        run_btn.setVisible(True)
        cancel_btn.setVisible(False)
        prog_bar.setVisible(False)
        for b in (self.btn_run_draft, self.btn_run_final):
            b.setEnabled(True)

    def _start_runner(self, sas_path, on_finished):
        """统一起 SingleBatchRunner，记录 _t_start。

        v12.10.31 关键变更（修 autoanno cancel 闪退）：
          - 创建时就连接 QThread.finished → _on_runner_thread_done（清 tmp + deleteLater）
            历史 bug：原 _cleanup_runner 在 _on_draft_finished 末尾才 connect，但
            QThread.finished 已经在 run() 返回时发过了 → connect 后再发不补发 →
            deleteLater 永远不触发 → QThread 悬挂；叠加 cancel race → 闪退。
            修法：在 start() 之前就 connect，保证 finished 发的时候 deleteLater 必触发。
          - 重置 _cancelled 标志（让本次新运行不被上次 cancel 残留状态误判）
        """
        self._cancelled = False  # v12.10.31: 重置，避免上次中止残留误判本次 finished
        self._runner = SingleBatchRunner(sas_path)
        self._runner.finished_signal.connect(on_finished)
        # v12.10.31：在 start() 前就 connect QThread.finished — 保证 deleteLater 不会被错过
        self._runner.finished.connect(self._on_runner_thread_done)
        self._t_start = time.time()
        self._runner.start()

    def _on_runner_thread_done(self):
        """v12.10.31：QThread 真正结束（cancel / normal 两条路径都到达）的统一清理点。

        触发时机：SingleBatchRunner.run() 返回后，QThread 内置 `finished` 信号 emit。
        注意：runner 的自定义 `finished_signal` 仅在正常结束发；cancel 时 run() 直接
        return 不 emit。所以 _on_draft_finished/_on_final_finished 不一定都会跑，
        但本方法靠的是 QThread.finished（run 返回必发），cancel/normal 都覆盖。

        本方法负责：
          1. 删 tmp .sas / .log / .lst 等副产物
          2. 销毁 QThread C++ 对象（deleteLater）
          3. 若 self._runner 仍指向本 thread，置 None（避免悬挂）
        """
        sender_thread = self.sender()
        # 1. 清运行临时文件 — 此时子进程已完全退出，文件句柄释放
        self._clean_tmp_files()
        # 2. 清 _runner 引用（仅当 sender 就是当前 _runner；用户在结束后又开新 runner 时不动）
        if self._runner is sender_thread:
            self._runner = None
        # 3. 销毁 QThread 对象
        if sender_thread is not None:
            try:
                sender_thread.deleteLater()
            except Exception:
                pass

    def _clean_tmp_files(self):
        """v12.10.31：抽离 tmp 清理为独立方法，让 _on_runner_thread_done 复用。
        v12.10.99：改名 _clean_tmp_files — 现在清的是 %TEMP% 下的 _tmp_annodraft_*.py
        driver（22 线）。同 stem 副产物后缀沿用老清单（兼容未来再出现 .sas 类临时件）。
        """
        if not self._tmp_files_to_clean:
            return
        for tmp_path in list(self._tmp_files_to_clean):
            stem, _ext = os.path.splitext(tmp_path)
            for suffix in (".py", ".sas", ".log", ".lst", ".res", ".stderr"):
                p = stem + suffix
                try:
                    if os.path.isfile(p):
                        os.remove(p)
                except Exception:
                    pass  # 容错：删失败（占用/权限）也不影响主流程
        self._tmp_files_to_clean.clear()

    def _on_cancel_run(self):
        """v12.10.31 重写：与 acrf_unzip v12.10.20 / acrf_edc_recode v12.10.17 模式对齐。

        修 autoanno cancel 闪退根因：
          原版调 self._cleanup_runner() 在 cancel 末尾，里面做两件事：
            (a) self._runner = None
            (b) thread_ref.finished.connect(thread_ref.deleteLater)
            (c) 立即清 tmp 文件
          问题：
            - (b) 的 connect 时机过晚 — 此时 runner 仍在 sleep 循环，finished 还没发，
              虽然能 connect 上但 emit 时双 slot（_on_draft_finished + deleteLater）
              在主线程处理顺序与 cancel 路径并发的 sig_autoanno_finished UI 改动叠加，
              偶发触发 Qt slot 嵌套的 widget 状态错乱 → 闪退。
            - (c) 立即清 tmp 文件，但 SAS 子进程刚被 kill 文件句柄可能还没释放，
              os.remove 失败被 catch（不影响），但 .sas 残留要等下次 cancel 才清。

        修法：
          - 加 _cancelled 标志（同其它模块）
          - 不在 cancel 内调 _cleanup_runner
          - 让 _start_runner 时连好的 QThread.finished → _on_runner_thread_done
            统一处理（cancel 路径也走它，因为 run() 返回必发 QThread.finished）
          - 此时 SAS 子进程已彻底退出，tmp 删除一定成功
        """
        runner = self._runner
        mode = self._autoanno_mode or "full"
        if runner is None or not runner.isRunning():
            # 已结束 — 复位 UI 防御
            if mode == "autoanno_only":
                self._exit_autoanno_only_running()
            else:
                self._exit_running(self.btn_run_draft, self.btn_cancel_22, self.prog_22)
            self._exit_running(self.btn_run_final, self.btn_cancel_23, self.prog_23)
            self._autoanno_mode = ""
            return
        # v12.10.31：标志位先于 kill — 让 _on_draft_finished 等被 emit 击中也直接 return
        # v12.10.99 注意：ScriptRunnerThread 与 SingleBatchRunner 不同 — cancel 后其 run()
        # **仍会 emit finished_signal**，全靠本标志让 _on_annodraft_py_finished 短路。
        self._cancelled = True
        if isinstance(runner, ScriptRunnerThread):
            # v12.10.99：22 线 annodraft（本机 Python 子进程）— taskkill /T 杀整棵进程树
            runner.cancel()
        else:
            runner.is_cancelled = True
            try:
                if runner.proc and runner.proc.poll() is None:
                    runner.proc.kill()
            except Exception:
                pass
        self.sig_status.emit("🛑 已中止 CRF Annotation", "#F56C6C")
        self.sig_step_update.emit("04 CRF Annotation 🟥")
        self.sig_log.emit("<span style='color:#F56C6C; font-weight:bold;'>🛑 用户已中止运行。</span>")
        # v12.9.4：按当前模式恢复 UI（autoanno_only 模式下绝不解锁 btn_run_draft）
        if mode == "autoanno_only":
            self._exit_autoanno_only_running()
            # v12.9.8：中止也算"未成功完成"，emit 给 stepper 让 annomap tab 状态行显示中止
            try:
                self.sig_autoanno_finished.emit(True, False, "已中止")
            except Exception:
                pass
        else:
            self._exit_running(self.btn_run_draft, self.btn_cancel_22, self.prog_22)
            # v12.10.31：autoanno_only 模式下不能再调 _exit_running(btn_run_final, ...)
            # 那会无条件 setEnabled(True) 解锁 btn_run_draft（_exit_running 内部不区分模式）
            # 只在 full 模式跑完才需要复位 final 区
            self._exit_running(self.btn_run_final, self.btn_cancel_23, self.prog_23)
        self._autoanno_mode = ""
        # v12.10.31：不再调 _cleanup_runner — 留给 _on_runner_thread_done 处理
        # （在 _start_runner 时连好 QThread.finished，cancel 后 ~500ms 内必触发）

    def _cleanup_runner(self):
        """v12.10.31：保留为兼容老调用方的空 stub — 实际清理工作已迁移到
        _on_runner_thread_done（QThread.finished 触发，cancel/normal 都覆盖）。

        历史调用点 _on_draft_finished / _on_final_finished 仍可调本方法（now no-op
        in cleanup 路径，仅 backstop 一下 — 真正动手的是 QThread.finished 回调）。
        """
        # 仅在极端兜底场景保留 tmp 清理（_on_runner_thread_done 没及时触发的话）
        # 但实际 _on_runner_thread_done 应该在 ~ms 级别触发，所以基本不会走到这里
        pass

    # ------------------- v12.10.99：annodraft（本机 Python）执行链 -------------------

    def _write_tmp_annodraft_py(self, pkg_parent: str, ecrf_path: str):
        """v12.10.100：生成 annodraft 临时 driver 到 %TEMP%，返回 (ok, path, msg)。

        与 cmd 对齐的拉起方式（本次变更核心）：
          - 首选：runpy 执行项目层 <base>/utility/tools/22_anno_draft_call.py，注入
            argv = [脚本, '--base-path', <base>, '--ecrf-path', <draft/ecrf.pdf>]，
            等价用户手动跑
                C:\\Python_396\\python.exe ...\\utility\\tools\\22_anno_draft_call.py
            （copy 到 draft/ecrf.pdf、EDC 自动定位、版本日志、autoanno 调用签名
            全由 call 脚本统一负责 → 单一入口，cmd 与 SPAhub 行为一致）。
          - 回退：项目未铺该 call 脚本时，退回 v12.10.99 的"直接 import 部门包"路径，
            保证旧项目可用。

        driver 写 %TEMP% 而非 utility/tools：Python driver 纯本机跑，没必要污染项目目录。
        参数全部 repr() 烧进 driver 文本（ScriptRunnerThread 不传 argv），首次运行与
        「保存后重跑」生成的 driver 内容完全相同 — 工具只有一个入口。
        edc_path 不传：call 脚本/部门包内部按规则自动定位（单一事实来源），SPAhub 侧
        _check_edc_def_or_confirm 只负责"找不到时预先告警"。
        """
        prot = _prot_from_base_path(self.base_path)
        call_script = os.path.join(self.base_path, *_ANNO_DRAFT_CALL_REL)
        # v12.10.101：回退路径(直接 import)与 call 脚本签名对齐——补 titlecount=4(call 脚本
        # 默认值) + edc_path(SPAhub 侧自动定位，与 call 脚本 _find_source_edc 同规则)，
        # 避免"项目未铺 call 脚本"时草标行为与正常路径分叉(缺 EDC / titlecount 不一致)。
        edc_path = _find_latest_edc_def_xlsx(self.base_path) or None
        code = (
            "# -*- coding: utf-8 -*-\n"
            "# SPAhub v12.10.101 自动生成的 annodraft driver — 运行结束后由 SPAhub 自动删除\n"
            "import sys\n"
            "import os\n"
            "import runpy\n"
            "import traceback\n"
            f"_CALL = {call_script!r}\n"
            f"_BASE = {self.base_path!r}\n"
            f"_ECRF = {ecrf_path!r}\n"
            f"_PKG_PARENT = {pkg_parent!r}\n"
            f"_PROT = {prot!r}\n"
            f"_EDC = {edc_path!r}\n"
            "if os.path.isfile(_CALL):\n"
            "    # ---- 首选：与 cmd 同一入口，runpy 执行 22_anno_draft_call.py ----\n"
            "    print('[driver] 调用项目层 call 脚本：%s' % _CALL)\n"
            "    sys.argv = [_CALL, '--base-path', _BASE, '--ecrf-path', _ECRF]\n"
            "    try:\n"
            "        runpy.run_path(_CALL, run_name='__main__')\n"
            "    except SystemExit:\n"
            "        raise  # 透传 call 脚本自己的退出码（如 sys.exit(1) 表示失败）\n"
            "    except Exception:\n"
            "        print('ERROR: 22_anno_draft_call.py 运行异常：')\n"
            "        traceback.print_exc(file=sys.stdout)\n"
            "        sys.exit(1)\n"
            "else:\n"
            "    # ---- 回退：项目未铺 call 脚本 → 直接 import 部门包（签名对齐 call 脚本）----\n"
            "    print('[driver] 未找到项目层 call 脚本，回退直接 import：%s' % _CALL)\n"
            "    sys.path.insert(0, _PKG_PARENT)\n"
            "    try:\n"
            "        from autoanno_draft import autoanno_study_draft\n"
            "        try:\n"
            "            from autoanno_draft import __version__ as _ver\n"
            "        except Exception:\n"
            "            _ver = '?'\n"
            "    except Exception as e:\n"
            "        print('ERROR: 导入 autoanno_draft 失败：%s' % e)\n"
            "        print('ERROR: 请确认部门包目录可达：%s' % _PKG_PARENT)\n"
            "        print('ERROR: 且本机 Python 已安装依赖：pip install pymupdf pdfminer.six pyyaml openpyxl')\n"
            "        sys.exit(2)\n"
            "    print('[driver] autoanno_draft 版本 = %s（来自 %s）' % (_ver, _PKG_PARENT))\n"
            "    if _EDC:\n"
            "        print('[driver] EDC xlsx   = %s' % _EDC)\n"
            "    try:\n"
            "        res = autoanno_study_draft(base_path=_BASE, prot=_PROT, titlecount=4,\n"
            "                                   ecrf_path=_ECRF, edc_path=_EDC, log=print)\n"
            "    except Exception:\n"
            "        print('ERROR: autoanno_study_draft 运行异常：')\n"
            "        traceback.print_exc(file=sys.stdout)\n"
            "        sys.exit(1)\n"
            "    print('')\n"
            "    print('[driver] xfdf    = %s' % (res.get('xfdf_path') or ''))\n"
            "    print('[driver] annomap = %s' % (res.get('annomap_path') or ''))\n"
        )
        uid = uuid.uuid4().hex[:8]
        path = os.path.join(tempfile.gettempdir(), f"_tmp_annodraft_{uid}.py")
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(code)
        except OSError as e:
            return False, "", f"写临时 driver 失败：{e}"
        # 记录路径供 _on_runner_thread_done 在 finished/cancel 路径统一删除
        self._tmp_files_to_clean.add(path)
        return True, path, "OK"

    def _start_py_runner(self, driver_path):
        """v12.10.99：统一起 ScriptRunnerThread 跑 annodraft driver（22 线专用）。

        与 _start_runner（SAS / SingleBatchRunner，23 线沿用）镜像：
          - start() 前连 QThread.finished → _on_runner_thread_done（清 tmp + deleteLater）
          - 重置 _cancelled
          - line_signal 实时逐行 → _on_annodraft_line → sig_log（"日志打印控制台内容"）
        """
        self._cancelled = False
        self._runner = ScriptRunnerThread(driver_path, cwd=tempfile.gettempdir())
        self._runner.line_signal.connect(self._on_annodraft_line)
        self._runner.finished_signal.connect(self._on_annodraft_py_finished)
        self._runner.finished.connect(self._on_runner_thread_done)
        self._t_start = time.time()
        self._runner.start()

    def _on_annodraft_line(self, line):
        """v12.10.99：annodraft 子进程 stdout 逐行回传 → 按内容着色推到日志面板。
        ERROR 红 / WARNING 黄 / Step 标题与 [driver] 行蓝 / 其余灰。"""
        s = (line or "").rstrip()
        if not s:
            return
        safe = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        up = s.lstrip().upper()
        if up.startswith("ERROR"):
            color = "#F56C6C"
        elif up.startswith("WARNING"):
            color = "#E6A23C"
        elif s.lstrip().startswith("===") or s.lstrip().startswith("[driver]"):
            color = "#409EFF"
        else:
            color = "#606266"
        self.sig_log.emit(f"<span style='color:{color};'>&nbsp;&nbsp;{safe}</span>")

    def _on_annodraft_py_finished(self, returncode, full_output):
        """v12.10.99：ScriptRunnerThread.finished_signal → 适配成 _on_draft_finished 三元组。

        注意：ScriptRunnerThread 在 cancel 路径**也会** emit finished_signal（与
        SingleBatchRunner 不同），所以 _cancelled 短路必须放在最前 — UI 复位与状态
        信号都已在 _on_cancel_run 做过，这里再走全套会触发双 UI 改动。

        判定映射：
          - has_error   ← returncode != 0（driver 内 import 失败 / 运行异常都先打
                          'ERROR: ...' 再非零退出；硬崩兜底由合成行补足）
          - has_warning ← 输出含 'WARNING:' 行（_split_has_error_warning 同款关键字，
                          覆盖工具运行中日志 + driver 尾部的 warnings 汇总）
        """
        if getattr(self, "_cancelled", False):
            return
        log_text = full_output or ""
        if returncode != 0 and not any(
            ln.strip().upper().startswith("ERROR") for ln in log_text.splitlines()
        ):
            # 硬崩兜底（解释器被杀 / OOM 等没来得及打 ERROR 行）：合成一行让
            # _split_has_error_warning / _extract_issue_lines 正常工作
            log_text = f"ERROR: annodraft 子进程异常退出（退出码 {returncode}）\n" + log_text
        summary = "✅ 运行成功" if returncode == 0 else f"❌ annodraft 退出码 {returncode}"
        self._on_draft_finished(returncode != 0, summary, log_text)

    def _check_edc_def_or_confirm(self) -> bool:
        """v12.10.99：EDC 数据库定义文件预检。返回 True=继续运行，False=用户取消。

        找到 → 灰色日志提示（annodraft 内部会按同规则再次定位，这里只是给用户确认感）。
        找不到 → 弹 question 对话框告警，但允许继续（用户确认的策略）；同一会话点过
        「继续」后置 _edc_missing_acknowledged，后续重跑只打黄色日志不再弹窗。
        """
        edc = _find_latest_edc_def_xlsx(self.base_path)
        if edc:
            self.sig_log.emit(
                f"<span style='color:#909399;'>&nbsp;&nbsp;EDC 数据库定义：{edc}（annodraft 内部自动定位）</span>"
            )
            return True
        if self._edc_missing_acknowledged:
            self.sig_log.emit(
                "<span style='color:#E6A23C;'>&nbsp;&nbsp;⚠ 00_source_data 未找到「数据库」.xlsx — "
                "EDC gap-fill 将跳过（本会话已确认，继续运行）。</span>"
            )
            return True
        ok = show_dialog(
            self, "未找到 EDC 数据库定义文件",
            f"在 {os.path.join(self.base_path, '00_source_data')} 下\n"
            "未找到文件名含「数据库」的 .xlsx。\n\n"
            "annodraft 将跳过 EDC gap-fill 步骤（评分/问卷类表单可能缺少 QS 字段级注释），\n"
            "其余注释流程不受影响。\n\n"
            "是否继续运行？",
            "question"
        )
        if ok:
            self._edc_missing_acknowledged = True
        return ok

    @staticmethod
    def _split_has_error_warning(log_text: str):
        """v12.9.8：拆分 has_error / has_warning，让上层能区分着色（红 vs 黄）。

        根因：旧版 has_issue 混合两者，无论是单 WARNING 还是真 ERROR 都笼统标红，
        让用户产生"任何运行都有错"的错误心理预期。
        """
        if not log_text:
            return False, False
        has_err, has_warn = False, False
        for line in log_text.splitlines():
            up = line.strip().upper()
            if up.startswith("ERROR:"):
                has_err = True
            elif up.startswith("WARNING:"):
                has_warn = True
            if has_err and has_warn:
                break
        return has_err, has_warn

    @staticmethod
    def _extract_issue_lines(log_text: str) -> str:
        """从 SAS 日志抽 ERROR/WARNING 行做前端展示（与其他 form 同款）"""
        if not log_text:
            return "<i style='color:#909399;'>(SAS 未返回日志内容)</i>"
        out = []
        for line in log_text.splitlines():
            s = line.strip()
            up = s.upper()
            if up.startswith("ERROR:") or up.startswith("WARNING:"):
                color = "#F56C6C" if up.startswith("ERROR:") else "#E6A23C"
                safe = (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))
                out.append(f"<span style='color:{color};'>&nbsp;&nbsp;{safe}</span>")
                if len(out) >= 8:
                    out.append("<i style='color:#909399;'>&nbsp;&nbsp;… 更多详见日志文件 …</i>")
                    break
        if not out:
            return "<i style='color:#909399;'>(未匹配到标准 ERROR/WARNING 行)</i>"
        return "<br>".join(out)
