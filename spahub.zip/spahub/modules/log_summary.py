r"""
modules/log_summary.py
======================
v12.10.60：日志「导出」改为「汇总」——把面板里的全部日志文本追加到一个
**全团队共享**的 Excel 汇总簿，取代旧的「导出 .txt 到 <base>/99_archive」。

汇总簿固定路径（写死的共享盘根，不放进 base_path / repo_root 计算，因为它本就
是跨项目、跨用户的团队级文件）：

    Z:\projects\Z_PYTHON\SPAhub\使用反馈.xlsx

列（与需求图一致，header 固定 + 填色 + 自动筛选）：

    项目 | 模块 | 步骤 | 日志信息 | 提交日期 | 提交人 | 负责人 | 解决方案

字段来源：
  - 项目：    四级路径拼接（调用方传入，通常是 stepper 当前 base_path 全路径）
  - 模块：    acrf / sdtm / adam / tfls ...（调用方传入）
  - 步骤：    "01 Unzip Source" 之类（调用方传入 step_name）
  - 日志信息：面板里 QTextEdit.toPlainText() 全文（调用方传入）
  - 提交日期：写入当天 yyyy-mm-dd
  - 提交人：  当前 Windows 登录名 → 中文名（USERNAME_TO_CN 映射；查不到回退登录名）
  - 负责人 / 解决方案：留空，供后续人工填写

设计约束（遵守项目红线）：
  * 不在 QThread 里调用本模块的 UI 部分——本模块不弹窗、不 setText，只返回结果，
    由调用方（主线程）决定如何提示用户。
  * GBK / 中文路径：所有文件读写都不依赖控制台编码。
  * 共享盘并发：用户侧已把该 xlsx 设为共享模式；这里再加一层「打开失败就短暂
    重试」兜底，避免别人临时用 Excel 打开时一次失败就丢记录。最终失败把内容
    落到本地降级文件，返回明确错误信息让调用方提示用户。
"""

import os
import time
from datetime import datetime

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side


# ---------------------------------------------------------------------------
# 共享汇总簿位置（团队级，跨项目跨用户）
# ---------------------------------------------------------------------------
SUMMARY_DIR = r"Z:\projects\Z_PYTHON\SPAhub"
SUMMARY_FILENAME = "使用反馈.xlsx"
SUMMARY_PATH = os.path.join(SUMMARY_DIR, SUMMARY_FILENAME)

SHEET_NAME = "反馈"
HEADERS = ["项目", "模块", "步骤", "日志信息", "提交日期", "提交人", "负责人", "解决方案"]

# 各列宽度（与 header 顺序对应）
_COL_WIDTHS = [40, 10, 20, 70, 14, 12, 12, 30]
# 日志信息列行高上限（磅）——控制行高，避免一条几千行的日志把整行撑爆
_MAX_ROW_HEIGHT = 120.0
_LINE_HEIGHT = 15.0  # 估算每行约 15 磅

# 样式
_HEADER_FILL = PatternFill(start_color="D4A017", end_color="D4A017", fill_type="solid")
_HEADER_FONT = Font(name="微软雅黑", bold=True, size=11, color="000000")
_BODY_FONT = Font(name="微软雅黑", size=10)
_BORDER = Border(
    left=Side("thin"), right=Side("thin"), top=Side("thin"), bottom=Side("thin")
)
_HEADER_ALIGN = Alignment(horizontal="center", vertical="center")
_BODY_ALIGN = Alignment(horizontal="left", vertical="top", wrap_text=True)


# ---------------------------------------------------------------------------
# 用户名（Windows 登录名）→ 中文名 映射（来自部门花名册截图）
# 查不到时回退到登录名本身。
# ---------------------------------------------------------------------------
USERNAME_TO_CN = {
    "liy167": "李雨",
    "jinghf1": "景贺帆",
    "jinc6": "金澄",
    "xull": "徐玲玲",
    "huangr3": "黄荣",
    "lix91": "李习",
    "yangx26": "杨雪",
    "wangyq13": "王羽琪",
    "chengg1": "成岗",
    "pangfy": "庞富元",
    "gaomc": "高默超",
    "zhengyl5": "郑裕玲",
    "zhaiq3": "翟琪",
    "lius37": "刘帅",
    "zhengm5": "郑敏",
    "wangp36": "王萍",
    "dongq5": "董秋丽",
    "zhuy53": "朱莹",
    "mah6": "马恒瑄",
    "sunh57": "孙航",
    "maw16": "马文卜",
    "liuy395": "刘奕杉",
    "renjl": "任建玲",
    "zhangl316": "张刘超",
    "chens100": "陈诗晏",
    "jinx33": "金璇",
    "zhuj76": "朱婧博",
    "fum7": "傅鸣杰",
    "zhangj560": "张洁菡",
    "liup71": "刘珮琳",
}


def current_windows_username() -> str:
    """取当前 Windows 登录名（域名账号短名）。多重兜底，避免任一来源缺失。"""
    for getter in (
        lambda: os.environ.get("USERNAME", ""),
        lambda: os.environ.get("USER", ""),
        lambda: os.getlogin(),
    ):
        try:
            val = (getter() or "").strip()
            if val:
                return val
        except Exception:
            continue
    return ""


def resolve_submitter_cn(username: str = "") -> str:
    """登录名 → 中文名；查不到回退到登录名（小写匹配，原样返回值）。"""
    uname = (username or current_windows_username()).strip()
    if not uname:
        return "(未知用户)"
    # 映射表 key 全小写比对，避免大小写差异漏匹配
    cn = USERNAME_TO_CN.get(uname.lower())
    return cn if cn else uname


def _estimate_row_height(log_text: str) -> float:
    """按日志行数估算行高，封顶 _MAX_ROW_HEIGHT，避免超长日志撑爆整行。"""
    n_lines = log_text.count("\n") + 1 if log_text else 1
    h = min(n_lines, 8) * _LINE_HEIGHT  # 最多按 8 行算高度，再多就靠滚动/封顶
    return min(max(h, _LINE_HEIGHT), _MAX_ROW_HEIGHT)


def _build_new_workbook() -> "openpyxl.Workbook":
    """新建带表头（填色 + 居中）+ 自动筛选 + 列宽 + 冻结首行 的工作簿。"""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = SHEET_NAME
    for c, h in enumerate(HEADERS, 1):
        cell = ws.cell(row=1, column=c, value=h)
        cell.fill = _HEADER_FILL
        cell.font = _HEADER_FONT
        cell.border = _BORDER
        cell.alignment = _HEADER_ALIGN
    for i, w in enumerate(_COL_WIDTHS):
        ws.column_dimensions[openpyxl.utils.get_column_letter(i + 1)].width = w
    last_col = openpyxl.utils.get_column_letter(len(HEADERS))
    ws.auto_filter.ref = f"A1:{last_col}1"
    ws.freeze_panes = "A2"
    ws.row_dimensions[1].height = 22.0
    return wb


def _ensure_header_styled(ws) -> None:
    """已存在的簿——保证表头存在且带筛选（兼容用户手工建过/格式丢了的情况）。"""
    # 表头若空就补
    if all((ws.cell(row=1, column=c).value in (None, "")) for c in range(1, len(HEADERS) + 1)):
        for c, h in enumerate(HEADERS, 1):
            cell = ws.cell(row=1, column=c, value=h)
            cell.fill = _HEADER_FILL
            cell.font = _HEADER_FONT
            cell.border = _BORDER
            cell.alignment = _HEADER_ALIGN
        for i, w in enumerate(_COL_WIDTHS):
            ws.column_dimensions[openpyxl.utils.get_column_letter(i + 1)].width = w
        ws.freeze_panes = "A2"
        ws.row_dimensions[1].height = 22.0
    # 自动筛选始终覆盖到当前数据末行
    last_col = openpyxl.utils.get_column_letter(len(HEADERS))
    last_row = ws.max_row if ws.max_row >= 1 else 1
    ws.auto_filter.ref = f"A1:{last_col}{last_row}"


def _append_row(ws, project: str, module: str, step: str, log_text: str,
                submit_date: str, submitter: str) -> int:
    """在末尾追加一行并套用样式，返回新行号。负责人/解决方案留空。"""
    r = ws.max_row + 1
    # 若 ws 只有空表（max_row==1 但首行就是 header），append 到第 2 行
    if ws.max_row == 1 and ws.cell(row=1, column=1).value == HEADERS[0]:
        r = 2
    values = [project, module, step, log_text, submit_date, submitter, "", ""]
    for c, val in enumerate(values, 1):
        cell = ws.cell(row=r, column=c, value=val)
        cell.font = _BODY_FONT
        cell.border = _BORDER
        cell.alignment = _BODY_ALIGN
    ws.row_dimensions[r].height = _estimate_row_height(log_text)
    return r


def append_log_summary(project: str, module: str, step: str, log_text: str,
                       username: str = "", summary_path: str = "",
                       retries: int = 3, retry_wait: float = 0.8) -> dict:
    """把一条日志记录追加到共享汇总簿。

    参数：
      project    : 项目（四级路径拼接的完整字符串）
      module     : 模块（acrf / sdtm / adam / tfls ...）
      step       : 步骤（如 "01 Unzip Source"）
      log_text   : 面板日志全文（QTextEdit.toPlainText()）
      username   : 可选，显式传 Windows 登录名；默认自动取当前用户
      summary_path: 可选，覆盖默认汇总簿路径（测试用）
      retries    : 写盘失败重试次数（应对别人临时用 Excel 打开导致的占用）
      retry_wait : 每次重试间隔秒

    返回 dict：
      {
        "ok": bool,
        "path": <实际写入的文件路径>,
        "row": <新行号 or None>,
        "submitter": <提交人中文名>,
        "fallback": bool,          # True 表示写到了本地降级文件
        "error": <错误信息 or "">,
      }
    """
    path = (summary_path or SUMMARY_PATH).strip()
    submitter = resolve_submitter_cn(username)
    submit_date = datetime.now().strftime("%Y-%m-%d")
    log_text = log_text if log_text is not None else ""

    last_err = ""
    for attempt in range(max(1, retries)):
        try:
            os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
            if os.path.isfile(path):
                wb = openpyxl.load_workbook(path)
                ws = wb[SHEET_NAME] if SHEET_NAME in wb.sheetnames else wb.active
                _ensure_header_styled(ws)
            else:
                wb = _build_new_workbook()
                ws = wb[SHEET_NAME]
            row = _append_row(ws, project, module, step, log_text, submit_date, submitter)
            # 追加后刷新筛选范围到末行
            last_col = openpyxl.utils.get_column_letter(len(HEADERS))
            ws.auto_filter.ref = f"A1:{last_col}{ws.max_row}"
            wb.save(path)
            return {
                "ok": True, "path": path, "row": row, "submitter": submitter,
                "fallback": False, "error": "",
            }
        except PermissionError as e:
            last_err = f"文件被占用（可能他人正用 Excel 打开）：{e}"
            time.sleep(retry_wait)
        except Exception as e:
            last_err = f"{type(e).__name__}: {e}"
            time.sleep(retry_wait)

    # 全部重试失败 → 落本地降级文件，保证日志不丢
    fb = _write_local_fallback(project, module, step, log_text, submit_date, submitter)
    return {
        "ok": False, "path": fb.get("path", ""), "row": fb.get("row"),
        "submitter": submitter, "fallback": True,
        "error": f"写共享汇总簿失败，已暂存本地：{last_err}",
    }


def _write_local_fallback(project, module, step, log_text, submit_date, submitter) -> dict:
    """共享盘写失败时，把记录追加到用户本地的降级 xlsx，避免丢数据。

    位置：<用户主目录>/SPAhub_使用反馈_暂存.xlsx
    """
    fb_path = os.path.join(os.path.expanduser("~"), "SPAhub_使用反馈_暂存.xlsx")
    try:
        if os.path.isfile(fb_path):
            wb = openpyxl.load_workbook(fb_path)
            ws = wb[SHEET_NAME] if SHEET_NAME in wb.sheetnames else wb.active
            _ensure_header_styled(ws)
        else:
            wb = _build_new_workbook()
            ws = wb[SHEET_NAME]
        row = _append_row(ws, project, module, step, log_text, submit_date, submitter)
        last_col = openpyxl.utils.get_column_letter(len(HEADERS))
        ws.auto_filter.ref = f"A1:{last_col}{ws.max_row}"
        wb.save(fb_path)
        return {"path": fb_path, "row": row}
    except Exception:
        return {"path": "", "row": None}
