# -*- coding: utf-8 -*-
"""
modules/sdtm_generate.py
========================
SDTM 模块 - 02 SDTM Gen（双子步合一）（v12.10.34 起：原 03，顺移到 02）

业务结构：
  • 第一步 generate_pds：调 %generate_pds 生成 PDS（Project Definition Spec）
      - libname 锁死为 sdtm（不展示给用户）
      - dataset：CheckableComboBox（多选） — 可选项 = anno_study 扫描结果
        + 默认追加 ta / tv / ti / ts / te / dv 6 个常见 trial-design 域
        勾选时自动以 "a, b, c" 形式合入输入框；输入框可继续手动追加
      - type：默认 replace
      - 高级参数（默认折叠，蓝色字体与 tfls 05 combine 一致）：igver / updatepage / debug
      - 「📂 打开 PDS」按钮：打开 SDTMSPEC 对应的 xlsx
  • 第二步 sdtm_template：调 %sdtm_template
      - dom：CheckableComboBox（多选） — **数据源是 SDTM PDS xlsx 的 Datasets sheet 的 Dataset 列**
        （由第一步 generate_pds 生成；通过文件 mtime 探针自动刷新）
      - 高级参数（折叠 + 蓝色）：testmod
      - v12.10.5：原「📂 在 EG 中打开 061_data」按钮已移除 — 用户从右上 Launch SAS EG 进入

执行机制：
  - 每次提交在 utility/tools/ 下写 temp_<uuid>.sas（autorun + 用户宏调用）
  - SingleBatchRunner 跑 → 完成后清理 temp.sas + .log
  - 日志着色严格区分 ERROR / WARNING（红 vs 黄不混用）
  - **日志仅在"刷新 domain list"时清空**；运行时累加（用户频繁提交需保留历史）

domain_list 异步扫描线程化避免主线程卡顿。

CheckableComboBox 实现要点：
  - 用 QStandardItemModel 给每个 item 设 Qt.CheckStateRole = Unchecked
  - 拦截 view().pressed → 切换勾选状态而不立即关闭弹出
  - 勾选变化时同步把"当前选中集合"以 ", " 拼接写入 lineEdit
  - 用户手动编辑 lineEdit 时不反向同步勾选（避免循环），但提交前会再校验格式
"""
import os
import re
import time

from PySide6.QtWidgets import (QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                               QLineEdit, QFrame, QProgressBar, QComboBox,
                               QGroupBox, QSplitter, QToolButton, QWidget, QScrollArea)
from PySide6.QtCore import Qt, Signal, QThread, QEvent, QTimer
from PySide6.QtGui import QStandardItem, QStandardItemModel

from modules.tfls_batch_run import SingleBatchRunner
from modules.sdtm_common import (
    scan_domain_list, read_setup_macro,
    write_temp_sas, cleanup_temp_sas, append_temp_log_to_permanent,
    classify_log_severity, extract_issue_lines_html, severity_finished_html,
    find_sdtm_pds_xlsx, list_pds_datasets,
)
from ui_utils import (show_dialog, primary_outline_btn_style, scan_status_lbl_style,
                      unified_scrollbar_style)


# %generate_pds 的 type 取值
_PDS_TYPE_OPTIONS = ["replace", "add", "remove", "update_metadata"]
# y/n 类参数取值（updatepage / debug / testmod）
_YN_OPTIONS = ["n", "y"]
# 第一步 dataset 默认追加的 trial-design 域（用户明确要求）
_TRIAL_DESIGN_EXTRA = ["ta", "tv", "ti", "ts", "te", "dv"]
# 域名格式校验：恰好 2 位英文字母（大小写不敏感，提交前 lower）
_RE_TWO_LETTER = re.compile(r"^[A-Za-z]{2}$")


# =============================================================================
# 多选 ComboBox（带 checkbox） — 与输入框联动 + "已使用"灰底记忆 + 覆盖确认
# =============================================================================
# 已使用项的灰底色（与"禁用态"区分 — 这里仍可点击，只是视觉提示"已运行过"）
_USED_BG_COLOR = "#E4E7ED"          # 浅灰背景
_USED_FG_COLOR = "#909399"          # 灰字（次要文本）


# =============================================================================
# 禁滚轮 ComboBox —— 表单可滚动后，鼠标滚轮划过下拉框会误改选项；
# v12.10.121：统一忽略 wheel 事件（把滚动交还给外层 QScrollArea）。
# =============================================================================
class _NoWheelComboBox(QComboBox):
    def wheelEvent(self, e):
        e.ignore()


class CheckableComboBox(_NoWheelComboBox):
    """
    多选 QComboBox：每个 item 带 checkbox，勾选状态同步到 lineEdit（可编辑）。

    v12.10.2 新增"使用记忆"：
      - mark_used(items)：把 items 加入 _used_set，并给对应 model item 设灰底
        （视觉提示：这些 domain 已经被提交运行过）
      - clear_selection_keep_used()：取消所有勾选 + 清空 lineEdit，但 _used_set / 灰底保留
      - confirm_overwrite_callback：可选 hook（callable: text → bool），
        eventFilter 中"用户从未勾→勾上"且该项是 used 时调用，返回 True 才真正切换勾选；
        返回 False 不切换（用户拒绝覆盖）。

    交互：
      - 点击 item → 切换勾选状态（不立即关闭下拉）
      - 切换前若是 used 项且尝试勾选，触发 confirm_overwrite_callback
      - 勾选变化 → 把所有勾选项以 ", " 拼接 setText 到 lineEdit
      - 用户手动编辑 lineEdit → 不反向同步勾选状态（避免循环）；
        提交时由调用方解析 lineEdit 字面量（用户的原始意图为准）
    """
    selection_changed = Signal()  # 勾选项变化（用户动作或外部 set_checked_items）

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setEditable(True)
        self._model = QStandardItemModel(self)
        self.setModel(self._model)
        # 拦截下拉视图的 mouse press，让点击切换勾选而不关闭弹出
        self.view().viewport().installEventFilter(self)
        # 默认行为：lineEdit 用户编辑不触发 setCurrentIndex
        self.setInsertPolicy(QComboBox.NoInsert)

        # 使用记忆 / 覆盖确认
        self._used_set = set()  # 已运行过的 domain 文本（lower）
        self.confirm_overwrite_callback = None  # 调用方可设置此 callable: text → bool

    def addCheckableItems(self, items):
        """重置 items；item 文本来自传入 list；初始全部 Unchecked。

        used 标记保留：若新 items 中包含 _used_set 中的 text，自动恢复灰底。
        """
        self._model.clear()
        for it in items:
            txt = "" if it is None else str(it)
            item = QStandardItem(txt)
            item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsUserCheckable)
            item.setData(Qt.Unchecked, Qt.CheckStateRole)
            # 若该 text 是 used，恢复灰底
            if txt.strip().lower() in self._used_set:
                self._apply_used_style(item)
            self._model.appendRow(item)

    def checked_items(self):
        """返回当前所有勾选项的文本列表（按下拉顺序）。"""
        out = []
        for i in range(self._model.rowCount()):
            it = self._model.item(i)
            if it.data(Qt.CheckStateRole) == Qt.Checked:
                out.append(it.text())
        return out

    def set_checked_by_text(self, texts):
        """把指定文本集合勾选起来；不在 model 中的文本忽略。"""
        target = set(t.strip().lower() for t in (texts or []) if t)
        for i in range(self._model.rowCount()):
            it = self._model.item(i)
            on = it.text().strip().lower() in target
            it.setData(Qt.Checked if on else Qt.Unchecked, Qt.CheckStateRole)
        self._sync_lineedit_from_checks()

    def clear_all_checks(self):
        for i in range(self._model.rowCount()):
            self._model.item(i).setData(Qt.Unchecked, Qt.CheckStateRole)
        self._sync_lineedit_from_checks()

    # ---- 使用记忆 / 覆盖确认 -----------------------------------------------
    def mark_used(self, items):
        """把 items 加入 _used_set + 给对应 model item 设灰底。"""
        for raw in (items or []):
            t = (raw or "").strip().lower()
            if t:
                self._used_set.add(t)
        # 把 model 中匹配项设灰底
        for i in range(self._model.rowCount()):
            it = self._model.item(i)
            if it.text().strip().lower() in self._used_set:
                self._apply_used_style(it)

    def is_used(self, text: str) -> bool:
        return (text or "").strip().lower() in self._used_set

    def clear_used_set(self):
        """清空 used 标记（恢复所有 item 的默认背景）。"""
        self._used_set.clear()
        for i in range(self._model.rowCount()):
            it = self._model.item(i)
            self._clear_used_style(it)

    def clear_selection_keep_used(self):
        """取消所有勾选 + 清空 lineEdit，但保留 _used_set 与灰底视觉记忆。"""
        for i in range(self._model.rowCount()):
            self._model.item(i).setData(Qt.Unchecked, Qt.CheckStateRole)
        if self.lineEdit() is not None:
            self.lineEdit().setText("")
        self.selection_changed.emit()

    def _apply_used_style(self, item):
        """给 item 套灰底 + 灰字（视觉表示"已使用过"）。"""
        from PySide6.QtGui import QBrush, QColor
        item.setData(QBrush(QColor(_USED_BG_COLOR)), Qt.BackgroundRole)
        item.setData(QBrush(QColor(_USED_FG_COLOR)), Qt.ForegroundRole)

    def _clear_used_style(self, item):
        item.setData(None, Qt.BackgroundRole)
        item.setData(None, Qt.ForegroundRole)

    # ---- 交互：点击 → 切换勾选 ---------------------------------------------
    def eventFilter(self, obj, event):
        """点击下拉项 → 切换勾选；不关闭弹出。
           若试图勾选 used 项，调用 confirm_overwrite_callback 让外层弹窗确认。"""
        if obj is self.view().viewport() and event.type() == QEvent.MouseButtonRelease:
            idx = self.view().indexAt(event.pos())
            if idx.isValid():
                it = self._model.itemFromIndex(idx)
                if it is not None and (it.flags() & Qt.ItemIsUserCheckable):
                    cur = it.data(Qt.CheckStateRole)
                    going_to_check = (cur != Qt.Checked)

                    # 如果是"从未勾→勾上" + 该项是 used → 走覆盖确认
                    if (going_to_check and self.is_used(it.text())
                            and callable(self.confirm_overwrite_callback)):
                        try:
                            allowed = bool(self.confirm_overwrite_callback(it.text()))
                        except Exception:
                            allowed = True  # 回调抛异常时不阻断
                        if not allowed:
                            return True  # 用户拒绝覆盖 → 不切换勾选

                    new_state = Qt.Unchecked if cur == Qt.Checked else Qt.Checked
                    it.setData(new_state, Qt.CheckStateRole)
                    self._sync_lineedit_from_checks()
                    return True  # 吞掉 release，避免 QComboBox 关闭弹出
        return super().eventFilter(obj, event)

    def _sync_lineedit_from_checks(self):
        """把当前勾选项以 ", " 拼接写入 lineEdit。"""
        sel = [t for t in self.checked_items() if t]  # 过滤空字符串占位
        text = ", ".join(sel)
        le = self.lineEdit()
        if le is not None and le.text() != text:
            le.setText(text)
        self.selection_changed.emit()


# =============================================================================
# domain_list 后台扫描线程（用于第一步 dataset combo —— anno_study 来源）
# =============================================================================
class _DomainScanThread(QThread):
    """扫描 anno_study.sas7bdat → 产出 domain_list（避免主线程阻塞）"""
    finished_signal = Signal(bool, list, str)  # ok, items, err

    def __init__(self, base_path: str, parent=None):
        super().__init__(parent)
        self.base_path = base_path

    def run(self):
        try:
            ok, items, err = scan_domain_list(self.base_path)
            self.finished_signal.emit(ok, items, err)
        except Exception as e:
            self.finished_signal.emit(False, ["", "sv", "se"], f"domain_list 扫描异常：{e}")


# =============================================================================
# SDTM PDS 探针线程：定期检查 PDS xlsx 的 mtime + **在子线程内 parse**
# 让主线程仅做 setText，避免 openpyxl 加载 xlsx 在主线程阻塞 0.5-1.5s（Z:\ 网络盘）
# v12.10.3 修复：用户反馈 dom 下拉"严重迟滞甚至点不出"——
#   根因是 _on_pds_changed 在主线程调 list_pds_datasets，触发主线程长 IO →
#   combo 在重建时 view 被 reset，下拉无法点开。
#   修复：watcher 一次性返回 (path, mtime, items)，主线程仅做 addCheckableItems。
#   附加修复：mtime 真变化才 emit；间隔 2s → 5s（PDS 不会高频变化）。
# =============================================================================
class _PdsWatcher(QThread):
    """
    后台轮询 SDTM PDS 文件的 mtime，**且在子线程内解析 datasets sheet**，
    主线程仅在收到 emit 后调 addCheckableItems（无 IO 开销）。

    停止机制：通过 self._stop 软标志 + finished_signal 自然退出。
    """
    pds_changed = Signal(str, float, list)   # path, new_mtime, items[domain]
    not_found = Signal()                     # v12.10.4：找不到 PDS 时 emit 一次（首次扫描时）

    def __init__(self, base_path: str, sdtmspec_name: str = "", interval_s: float = 5.0,
                 parent=None):
        super().__init__(parent)
        self.base_path = base_path or ""
        self.sdtmspec_name = sdtmspec_name or ""
        # v12.10.3：5s 间隔（PDS 文件不会高频变化；2s 太密集，叠加 listdir/openpyxl IO 拖慢响应）
        self.interval_s = max(1.0, interval_s)
        self._stop = False
        self._last_path = ""
        self._last_mtime = 0.0
        self._not_found_emitted = False  # 仅 emit 一次，避免反复刷屏

    def stop(self):
        self._stop = True

    def _scan_once(self):
        """一次完整扫描：定位文件 → mtime 比较 → 必要时 parse → emit。
           完全在子线程跑，主线程零阻塞。"""
        path = find_sdtm_pds_xlsx(self.base_path, self.sdtmspec_name)
        if not path:
            # 找不到 PDS — 首次扫描时通知主线程让用户知道
            if not self._not_found_emitted:
                self._not_found_emitted = True
                try:
                    self.not_found.emit()
                except Exception:
                    pass
            return
        try:
            mtime = os.path.getmtime(path) if os.path.isfile(path) else 0.0
        except Exception:
            mtime = 0.0
        # 严格判定 mtime 真变化（避免误触发：路径不变 + mtime 在 ±0.5s 内视为同一文件）
        path_changed = (path != self._last_path)
        mtime_changed = (abs(mtime - self._last_mtime) > 0.5)
        if path_changed or mtime_changed:
            self._last_path = path
            self._last_mtime = mtime
            # 在**子线程**里 parse — 主线程零 IO
            ok, items, err = list_pds_datasets(path)
            self.pds_changed.emit(path, mtime, items if ok else [])
            # 重置 not_found 标记 — 下次找不到时仍会通知
            self._not_found_emitted = False

    def run(self):
        # 启动时立即扫一次（替代 form 端 _kick_pds_watcher 中的同步加载）
        if not self._stop:
            try:
                self._scan_once()
            except Exception:
                pass
        # 主循环
        while not self._stop:
            for _ in range(int(self.interval_s * 10)):
                if self._stop:
                    break
                self.msleep(100)
            if self._stop:
                break
            try:
                self._scan_once()
            except Exception:
                pass


# =============================================================================
# 折叠组件辅助：标题用蓝色字体（参考 tfls 05 combine "▶ 高级参数"）
# =============================================================================
class _CollapseSection(QWidget):
    """简易可折叠区域：标题（QPushButton 蓝色）+ 内容（QFrame）

    点击标题切换内容可见性。默认折叠。
    样式与 modules/tfls_combine.py 中"▶ 高级参数"按钮一致：
        QPushButton { background: transparent; border: none; color: #409EFF;
                      font-size: 13px; font-weight: bold; text-align: left; padding: 4px 0; }
        QPushButton:hover { color: #66B1FF; }
    """

    def __init__(self, title: str = "高级参数", parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(4)

        self.toggle_btn = QPushButton(f"▶ {title}")
        self.toggle_btn.setStyleSheet("""
            QPushButton { background: transparent; border: none; color: #409EFF;
                          font-size: 13px; font-weight: bold; text-align: left; padding: 4px 0; }
            QPushButton:hover { color: #66B1FF; }
        """)
        self.toggle_btn.setCursor(Qt.PointingHandCursor)
        self.toggle_btn.clicked.connect(self._on_toggle_clicked)
        lay.addWidget(self.toggle_btn, 0, Qt.AlignLeft)

        self.content = QFrame()
        self.content.setStyleSheet(
            "QFrame { background: #FAFBFC; border: 1px dashed #DCDFE6; border-radius: 4px; }"
        )
        self.content_lay = QVBoxLayout(self.content)
        self.content_lay.setContentsMargins(10, 8, 10, 8)
        self.content_lay.setSpacing(6)
        self.content.setVisible(False)
        lay.addWidget(self.content)

        self._title = title
        self._expanded = False

    def _on_toggle_clicked(self):
        self._expanded = not self._expanded
        self.content.setVisible(self._expanded)
        arrow = "▼" if self._expanded else "▶"
        self.toggle_btn.setText(f"{arrow} {self._title}")

    def addRow(self, layout):
        self.content_lay.addLayout(layout)


# =============================================================================
# 左侧表单组件 SdtmGenerateForm
# =============================================================================
class SdtmGenerateForm(QFrame):
    """SDTM / 02 SDTM Gen 的左侧业务表单（双子步合一）"""

    # 通用 — 左侧步骤栏 / 整体状态
    sig_status = Signal(str, str)         # v12.10.5：保留兼容（不再使用），改用下面双子步独立信号
    sig_status_pds = Signal(str, str)     # v12.10.5：generate_pds 子步状态（text, color）
    sig_status_tpl = Signal(str, str)     # v12.10.5：sdtm_template 子步状态（text, color）
    sig_step_update = Signal(str)
    sig_run_started = Signal()      # 任一子步启动 → stepper 用作开始计时
    sig_run_finished = Signal()     # 任一子步结束 → stepper 用作停止计时（保留 — 兼容老 connect）

    # v12.10.10：双子步独立的 finished 信号 — stepper 用复合 key（"SDTM Gen:pds" / "SDTM Gen:tpl"）
    # 维护各自计时；不能用通用 sig_run_finished 因为它不区分子步，stop 错误的 key 会让计时器
    # 仍在跑或 stat label 残留旧耗时。
    sig_run_finished_pds = Signal()
    sig_run_finished_tpl = Signal()

    # 双子步独立日志信号 — stepper 端 connect 到对应 tab
    sig_log_pds = Signal(str)        # %generate_pds 子步日志
    sig_log_template = Signal(str)   # %sdtm_template 子步日志

    # 子步独立"启动"/"刷新"信号 — stepper 用来控制 tab 切换 + 清空时机
    sig_run_started_pds = Signal()        # 启动 generate_pds → 切到 generate_pds tab
    sig_run_started_template = Signal()   # 启动 sdtm_template → 切到 sdtm_template tab
    sig_clear_log_pds = Signal()          # 仅"刷新 domain list"才发 → 清空 PDS tab
    sig_clear_log_template = Signal()     # 仅"刷新 domain list"才发 → 清空 Template tab

    def __init__(self):
        super().__init__()
        self.base_path = ""
        self._step_name = "SDTM Gen"

        self._runner_pds = None
        self._runner_template = None
        self._temp_sas_pds = ""
        self._temp_sas_template = ""
        self._t_start_pds = 0.0
        self._t_start_template = 0.0

        # 第一步 dataset combo 数据源（来自 anno_study + trial-design extra）
        self._anno_domains = ["", "sv", "se"]
        self._scan_thread = None

        # 第二步 dom combo 数据源（来自 SDTM PDS Datasets sheet）
        self._pds_domains = []
        self._pds_watcher = None
        self._cur_pds_path = ""

        # 子步骤完成情况：用于汇总 step_update 文案
        self._pds_status = "idle"        # idle / running / ok / warn / err / cancelled
        self._template_status = "idle"

        self._setup_ui()

    # ------------------------- UI -------------------------
    def _setup_ui(self):
        self.setObjectName("LeftPanel")
        self.setStyleSheet("#LeftPanel { background-color: #FFFFFF; border: 1px solid #E4E7ED; border-radius: 6px; }")
        outer = QVBoxLayout(self)
        outer.setContentsMargins(20, 20, 20, 20)
        outer.setSpacing(10)

        # 顶部刷新栏
        top_bar = QHBoxLayout()
        self.refresh_btn = QPushButton("🔄 刷新 domain list")
        # v12.10.65：与其它模块"🔄 刷新源文件"按钮统一改为 home 同款蓝色外框样式
        # （文案不同但功能等同 — 都是 form 顶部刷新栏的扫描源数据按钮）
        self.refresh_btn.setStyleSheet(primary_outline_btn_style())
        self.refresh_btn.setCursor(Qt.PointingHandCursor)
        self.refresh_btn.clicked.connect(self._on_refresh_clicked)
        top_bar.addWidget(self.refresh_btn)
        self.scan_lbl = QLabel("")
        self.scan_lbl.setStyleSheet(scan_status_lbl_style())
        top_bar.addWidget(self.scan_lbl)
        top_bar.addStretch()
        outer.addLayout(top_bar)

        title = QLabel("使用 generate_pds 生成 PDS、使用 sdtm_template 生成 SDTM 程序模板。")
        title.setStyleSheet("color: #303133; font-weight: bold; font-size: 14px; border: none;")
        title.setWordWrap(True)
        outer.addWidget(title)

        # 上下分区
        self._split = QSplitter(Qt.Vertical)
        self._split.setChildrenCollapsible(False)
        self._split.setStyleSheet("QSplitter::handle { background-color: #EBEEF5; height: 4px; }")
        outer.addWidget(self._split, 1)

        # ============== 上区：generate_pds ==============
        # v12.10.120：各套一层 QScrollArea —— 高级参数展开后窗口较小时内容装不下，
        # 给上下两块各自加右侧竖向滚动条（横向关闭），避免底部运行按钮被裁。
        self._split.addWidget(self._wrap_scroll(self._build_pds_groupbox()))
        # ============== 下区：sdtm_template ==============
        self._split.addWidget(self._wrap_scroll(self._build_template_groupbox()))
        self._split.setSizes([1, 1])

    @staticmethod
    def _wrap_scroll(inner: QWidget) -> QScrollArea:
        """把一个块包进按需竖向滚动的 QScrollArea（横向关闭、无边框、随宽自适应）。"""
        sa = QScrollArea()
        sa.setWidget(inner)
        sa.setWidgetResizable(True)
        sa.setFrameShape(QFrame.NoFrame)
        sa.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        sa.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        # v12.10.121：显式白底 —— QScrollArea/viewport 默认灰底会透出（v120 加滚动条后
        # 背景变灰）；unified_scrollbar_style 只管 QScrollBar，不设区域底色，这里补白。
        sa.setStyleSheet("QScrollArea{background:#FFFFFF;border:none;}" + unified_scrollbar_style())
        sa.viewport().setStyleSheet("background:#FFFFFF;")
        return sa

    # ---------- 子区域 1：generate_pds ----------
    def _build_pds_groupbox(self) -> QGroupBox:
        gb = QGroupBox("第一步：%generate_pds（libname=sdtm）")
        gb.setStyleSheet(
            "QGroupBox { font-size: 13px; font-weight: bold; color: #409EFF; "
            "border: 1px solid #E4E7ED; border-radius: 4px; margin-top: 10px; padding-top: 6px; }"
            "QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px; }"
        )
        lay = QVBoxLayout(gb)
        lay.setContentsMargins(12, 10, 12, 10)
        lay.setSpacing(8)
        lay.setAlignment(Qt.AlignTop)

        # 行：dataset（多选 CheckableComboBox）
        row_ds = QHBoxLayout()
        lbl_ds = QLabel("dataset：")
        lbl_ds.setStyleSheet("border: none; color: #606266; min-width: 90px; font-weight: normal;")
        row_ds.addWidget(lbl_ds)
        self.pds_ds_combo = CheckableComboBox()
        self.pds_ds_combo.setStyleSheet(
            "padding: 6px 10px; border: 1px solid #DCDFE6; border-radius: 4px; background: #FFFFFF; color: #606266; font-weight: normal;")
        self.pds_ds_combo.setToolTip(
            "下拉勾选多个 domain（自动用 ', ' 拼接到输入框）；也可直接在输入框追加自定义 2 字母 domain。\n"
            "多选示例：ta, te, ti, tv, ts\n"
            "灰底 = 已运行过的 domain — 再次勾选会弹窗确认是否覆盖。"
        )
        # 挂上"覆盖确认"回调：用户勾选灰底（已运行过）项时弹窗
        self.pds_ds_combo.confirm_overwrite_callback = self._confirm_overwrite_pds_dataset
        self._reload_pds_combo_items()
        row_ds.addWidget(self.pds_ds_combo, 1)
        lay.addLayout(row_ds)

        # 行：type
        row_tp = QHBoxLayout()
        lbl_tp = QLabel("type：")
        lbl_tp.setStyleSheet("border: none; color: #606266; min-width: 90px; font-weight: normal;")
        row_tp.addWidget(lbl_tp)
        self.pds_type_combo = _NoWheelComboBox()
        self.pds_type_combo.addItems(_PDS_TYPE_OPTIONS)
        self.pds_type_combo.setStyleSheet(
            "padding: 6px 10px; border: 1px solid #DCDFE6; border-radius: 4px; background: #FFFFFF; color: #606266; font-weight: normal;")
        row_tp.addWidget(self.pds_type_combo, 1)
        lay.addLayout(row_tp)

        # 高级参数（折叠，蓝色字体）：igver / updatepage / debug
        self.pds_advanced = _CollapseSection("高级参数（igver / updatepage / debug）")
        # igver
        adv_row1 = QHBoxLayout()
        lbl_iv = QLabel("igver：")
        lbl_iv.setStyleSheet("border: none; color: #606266; min-width: 90px; font-weight: normal;")
        adv_row1.addWidget(lbl_iv)
        self.pds_igver_entry = QLineEdit()
        self.pds_igver_entry.setPlaceholderText("可空，例如 3.3（SDTM）/ 1.1（ADaM）")
        self.pds_igver_entry.setStyleSheet(
            "padding: 6px; border: 1px solid #DCDFE6; border-radius: 4px; background: #FFFFFF; color: #606266; font-weight: normal;")
        adv_row1.addWidget(self.pds_igver_entry, 1)
        self.pds_advanced.addRow(adv_row1)
        # updatepage
        adv_row2 = QHBoxLayout()
        lbl_up = QLabel("updatepage：")
        lbl_up.setStyleSheet("border: none; color: #606266; min-width: 90px; font-weight: normal;")
        adv_row2.addWidget(lbl_up)
        self.pds_updatepage_combo = _NoWheelComboBox()
        self.pds_updatepage_combo.addItems(_YN_OPTIONS)
        self.pds_updatepage_combo.setStyleSheet(
            "padding: 6px 10px; border: 1px solid #DCDFE6; border-radius: 4px; background: #FFFFFF; color: #606266; font-weight: normal;")
        adv_row2.addWidget(self.pds_updatepage_combo, 1)
        self.pds_advanced.addRow(adv_row2)
        # debug
        adv_row3 = QHBoxLayout()
        lbl_db = QLabel("debug：")
        lbl_db.setStyleSheet("border: none; color: #606266; min-width: 90px; font-weight: normal;")
        adv_row3.addWidget(lbl_db)
        self.pds_debug_combo = _NoWheelComboBox()
        self.pds_debug_combo.addItems(_YN_OPTIONS)
        self.pds_debug_combo.setStyleSheet(
            "padding: 6px 10px; border: 1px solid #DCDFE6; border-radius: 4px; background: #FFFFFF; color: #606266; font-weight: normal;")
        adv_row3.addWidget(self.pds_debug_combo, 1)
        self.pds_advanced.addRow(adv_row3)
        lay.addWidget(self.pds_advanced)

        # 进度条
        self.pds_prog = QProgressBar()
        self.pds_prog.setVisible(False)
        self.pds_prog.setFixedHeight(4)
        self.pds_prog.setTextVisible(False)  # v12.10.13：4px 太矮装不下文字，关闭百分比显示避免和上方 label 重叠
        lay.addWidget(self.pds_prog)

        # 按钮行：▶ 运行 / 🟥 中止 / 📂 打开 PDS
        btn_row = QHBoxLayout()
        self.btn_run_pds = QPushButton("▶ 运行 generate_pds")
        self.btn_run_pds.setStyleSheet(
            "background-color: #4A6FA5; color: white; border: none; padding: 8px 18px; border-radius: 4px; font-weight: bold;")
        self.btn_run_pds.setCursor(Qt.PointingHandCursor)
        self.btn_run_pds.clicked.connect(self.run_generate_pds)
        btn_row.addWidget(self.btn_run_pds)

        self.btn_cancel_pds = QPushButton("🟥 中止")
        self.btn_cancel_pds.setStyleSheet(
            "background-color: #FEF0F0; color: #F56C6C; border: 1px solid #FBC4C4; padding: 8px 16px; border-radius: 4px; font-weight: bold;")
        self.btn_cancel_pds.setVisible(False)
        self.btn_cancel_pds.setCursor(Qt.PointingHandCursor)
        self.btn_cancel_pds.clicked.connect(self._on_cancel_pds)
        btn_row.addWidget(self.btn_cancel_pds)

        self.btn_open_pds = QPushButton("📂 打开 PDS")
        self.btn_open_pds.setStyleSheet(
            "background-color: #3F9A6E; color: white; border: none; padding: 8px 14px; border-radius: 4px; font-weight: bold;")
        self.btn_open_pds.setCursor(Qt.PointingHandCursor)
        self.btn_open_pds.clicked.connect(self._open_pds_file)
        btn_row.addWidget(self.btn_open_pds)
        btn_row.addStretch()
        lay.addLayout(btn_row)

        return gb

    # ---------- 子区域 2：sdtm_template ----------
    def _build_template_groupbox(self) -> QGroupBox:
        gb = QGroupBox("第二步：%sdtm_template")
        gb.setStyleSheet(
            "QGroupBox { font-size: 13px; font-weight: bold; color: #409EFF; "
            "border: 1px solid #E4E7ED; border-radius: 4px; margin-top: 10px; padding-top: 6px; }"
            "QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px; }"
        )
        lay = QVBoxLayout(gb)
        lay.setContentsMargins(12, 10, 12, 10)
        lay.setSpacing(8)
        lay.setAlignment(Qt.AlignTop)

        # 行：dom（多选 CheckableComboBox）— 数据源是 SDTM PDS Datasets sheet
        row_dom = QHBoxLayout()
        lbl_dom = QLabel("dom：")
        lbl_dom.setStyleSheet("border: none; color: #606266; min-width: 90px; font-weight: normal;")
        row_dom.addWidget(lbl_dom)
        self.tpl_dom_combo = CheckableComboBox()
        self.tpl_dom_combo.setStyleSheet(
            "padding: 6px 10px; border: 1px solid #DCDFE6; border-radius: 4px; background: #FFFFFF; color: #606266; font-weight: normal;")
        self.tpl_dom_combo.setToolTip(
            "数据源 = SDTM PDS（utility/documentation 下） Datasets sheet 的 Dataset 列；\n"
            "由第一步 generate_pds 产生 — 该文件 mtime 变化时自动刷新此下拉。\n"
            "也可在输入框直接追加自定义 2 字母 domain，多个用 ', ' 分隔。\n"
            "灰底 = 已运行过的 domain — 再次勾选会弹窗确认是否覆盖。"
        )
        # 挂上"覆盖确认"回调（与第一步 dataset 对称）
        self.tpl_dom_combo.confirm_overwrite_callback = self._confirm_overwrite_template_dom
        self._reload_template_combo_items()
        row_dom.addWidget(self.tpl_dom_combo, 1)
        lay.addLayout(row_dom)

        # 高级参数（折叠 + 蓝色）：testmod
        self.tpl_advanced = _CollapseSection("高级参数（testmod）")
        adv_row = QHBoxLayout()
        lbl_tm = QLabel("testmod：")
        lbl_tm.setStyleSheet("border: none; color: #606266; min-width: 90px; font-weight: normal;")
        adv_row.addWidget(lbl_tm)
        self.tpl_testmod_combo = _NoWheelComboBox()
        self.tpl_testmod_combo.addItems(_YN_OPTIONS)
        self.tpl_testmod_combo.setStyleSheet(
            "padding: 6px 10px; border: 1px solid #DCDFE6; border-radius: 4px; background: #FFFFFF; color: #606266; font-weight: normal;")
        adv_row.addWidget(self.tpl_testmod_combo, 1)
        self.tpl_advanced.addRow(adv_row)
        lay.addWidget(self.tpl_advanced)

        # 进度条
        self.tpl_prog = QProgressBar()
        self.tpl_prog.setVisible(False)
        self.tpl_prog.setFixedHeight(4)
        self.tpl_prog.setTextVisible(False)  # v12.10.13：4px 太矮装不下文字，关闭百分比显示避免和上方 label 重叠
        lay.addWidget(self.tpl_prog)

        # 按钮行
        btn_row = QHBoxLayout()
        self.btn_run_tpl = QPushButton("▶ 运行 sdtm_template")
        self.btn_run_tpl.setStyleSheet(
            "background-color: #4A6FA5; color: white; border: none; padding: 8px 18px; border-radius: 4px; font-weight: bold;")
        self.btn_run_tpl.setCursor(Qt.PointingHandCursor)
        self.btn_run_tpl.clicked.connect(self.run_sdtm_template)
        btn_row.addWidget(self.btn_run_tpl)

        self.btn_cancel_tpl = QPushButton("🟥 中止")
        self.btn_cancel_tpl.setStyleSheet(
            "background-color: #FEF0F0; color: #F56C6C; border: 1px solid #FBC4C4; padding: 8px 16px; border-radius: 4px; font-weight: bold;")
        self.btn_cancel_tpl.setVisible(False)
        self.btn_cancel_tpl.setCursor(Qt.PointingHandCursor)
        self.btn_cancel_tpl.clicked.connect(self._on_cancel_tpl)
        btn_row.addWidget(self.btn_cancel_tpl)

        # v12.10.5：删除「📂 在 EG 中打开 061_data」按钮（用户决定走右上 Launch SAS EG）
        # 保留 _launch_eg_open_061data 方法名空实现兼容旧引用（避免 connect 时 AttributeError）
        btn_row.addStretch()
        lay.addLayout(btn_row)

        return gb

    # ------------------------- 路径推送 -------------------------
    def update_paths(self, base_path):
        # 切项目：清两 combo 的 used 记忆（不同项目的 domain 集是独立的）
        if base_path != self.base_path:
            try:
                self.pds_ds_combo.clear_used_set()
                self.pds_ds_combo.lineEdit().setText("")
                self.tpl_dom_combo.clear_used_set()
                self.tpl_dom_combo.lineEdit().setText("")
            except Exception:
                pass
        self.base_path = base_path or ""
        # 启动后台扫描 anno_study domain_list（用于第一步 dataset）
        self._kick_anno_scan()
        # 启动 / 重启 PDS 探针（用于第二步 dom）
        self._kick_pds_watcher()

    def set_wait_hint(self, show):
        if show:
            self.scan_lbl.setText("⏳ 等待填写完整路径...")
            self.scan_lbl.setStyleSheet(scan_status_lbl_style())
        else:
            self.scan_lbl.setText("")

    # ------------------------- 刷新按钮：清两 tab 日志 + 重新扫描 + 清 used -------------------------
    def _on_refresh_clicked(self):
        """🔄 刷新 domain list：清两 tab 日志 + 清两 combo 的 used 记忆 + 重启扫描。"""
        # 仅刷新会清空（运行时不清）— 通过专用信号通知 stepper
        self.sig_clear_log_pds.emit()
        self.sig_clear_log_template.emit()
        # 清 used 记忆 + 输入框
        try:
            self.pds_ds_combo.clear_used_set()
            self.pds_ds_combo.clear_all_checks()
            self.pds_ds_combo.lineEdit().setText("")
            self.tpl_dom_combo.clear_used_set()
            self.tpl_dom_combo.clear_all_checks()
            self.tpl_dom_combo.lineEdit().setText("")
        except Exception:
            pass
        self._kick_anno_scan()
        self._kick_pds_watcher()

    # ------------------------- 覆盖确认弹窗（CheckableComboBox 回调） -------------------------
    # 实际接线在 _setup_ui 中给两个 combo 分别挂 _confirm_overwrite_pds_dataset /
    # _confirm_overwrite_template_dom；它们都用 QMessageBox.question 弹覆盖确认。
    # （此处不重复定义；见 _on_pds_finished 后的 _confirm_overwrite_pds_dataset 与
    #  _on_template_finished 后的 _confirm_overwrite_template_dom）

    # ------------------------- domain_list 扫描（第一步 dataset） -------------------------
    def _kick_anno_scan(self):
        if not self.base_path:
            return
        if self._scan_thread is not None and self._scan_thread.isRunning():
            return
        self.scan_lbl.setText("⏳ 正在扫描 anno_study domain_list...")
        self.scan_lbl.setStyleSheet(scan_status_lbl_style("#409EFF"))
        self._scan_thread = _DomainScanThread(self.base_path, parent=self)
        self._scan_thread.finished_signal.connect(self._on_anno_scan_done)
        self._scan_thread.start()

    def _on_anno_scan_done(self, ok, items, err):
        # 缓存扫描结果
        self._anno_domains = items if items else ["", "sv", "se"]
        # 刷新第一步 combo 的下拉项（合入 trial-design extra）
        self._reload_pds_combo_items()
        if ok:
            n = len([x for x in self._anno_domains if x])
            self.scan_lbl.setText(f"✅ anno_study 已就绪（{n} 项）+ 默认追加 ta/tv/ti/ts/te/dv")
            self.scan_lbl.setStyleSheet(scan_status_lbl_style("#67C23A"))
        else:
            self.scan_lbl.setText(f"⚠ {err}（已使用 sv/se 兜底列表）")
            self.scan_lbl.setStyleSheet(scan_status_lbl_style())
        try:
            self._scan_thread.finished.connect(self._scan_thread.deleteLater)
        except Exception:
            pass

    def _reload_pds_combo_items(self):
        """合并 anno_study 扫描结果 + 默认 trial-design extras → 第一步 combo items。"""
        merged = []
        seen = set()
        # anno 结果
        for x in self._anno_domains:
            if not x:
                continue
            xl = x.strip().lower()
            if xl and xl not in seen:
                merged.append(xl)
                seen.add(xl)
        # 追加默认 trial-design 域（用户要求）
        for x in _TRIAL_DESIGN_EXTRA:
            if x not in seen:
                merged.append(x)
                seen.add(x)
        # 应用到 combo（保留用户已勾选项的勾选状态）
        cur_checked = set(self.pds_ds_combo.checked_items()) if hasattr(self, "pds_ds_combo") else set()
        cur_text = self.pds_ds_combo.lineEdit().text() if hasattr(self, "pds_ds_combo") else ""
        self.pds_ds_combo.addCheckableItems(merged)
        if cur_checked:
            self.pds_ds_combo.set_checked_by_text(list(cur_checked))
        # 还原用户手动文本（addCheckableItems 会清 lineEdit；若有手输需保留）
        if cur_text and not cur_checked:
            self.pds_ds_combo.lineEdit().setText(cur_text)

    # ------------------------- SDTM PDS 探针（第二步 dom） -------------------------
    def _kick_pds_watcher(self):
        """
        启动 / 重启 PDS mtime 探针线程。

        v12.10.3 修复：原版 _kick_pds_watcher 在启动 watcher 之前**主线程同步**调用了
        find_sdtm_pds_xlsx + list_pds_datasets — 这两步都是 Z:\\ 网络盘 IO（os.walk +
        openpyxl.load_workbook），合计 0.5-1.5s 阻塞，是 dom combo "点不出下拉"的
        核心原因之一。
        修复：完全去掉主线程同步加载 — 让 watcher 在子线程内做完所有 IO 再 emit 结果。
        watcher 的 run() 启动时会立即扫一次，毫秒内 emit 第一个 pds_changed → 主线程
        setText；之后按 5s 间隔轮询。
        """
        # 停止已有线程
        if self._pds_watcher is not None:
            try:
                self._pds_watcher.stop()
                self._pds_watcher.wait(1000)
            except Exception:
                pass
            self._pds_watcher = None

        if not self.base_path:
            self._pds_domains = []
            self._reload_template_combo_items()
            return

        # 读 SDTMSPEC（这一步是单文件 openpyxl 加载 —— 主线程做就做了，与 IO 同步加载相比
        # 这步只做一次且不在轮询里，影响小；但仍可考虑后续也搬到线程内）
        sdtmspec_name = ""
        setup_path = os.path.join(self.base_path, "utility", "documentation", "setup.xlsx")
        if os.path.isfile(setup_path):
            try:
                sdtmspec_name, _, _ = read_setup_macro(setup_path, "SDTMSPEC")
            except Exception:
                sdtmspec_name = ""

        # 启动 watcher（5s 间隔；run() 会立即扫一次再进入循环）
        self._pds_watcher = _PdsWatcher(self.base_path, sdtmspec_name, interval_s=5.0, parent=self)
        self._pds_watcher.pds_changed.connect(self._on_pds_changed)
        self._pds_watcher.not_found.connect(self._on_pds_not_found)
        self._pds_watcher.start()

        # v12.10.4：诊断日志 — 让用户看到 watcher 已启动 + 配置
        self.sig_log_template.emit(
            f"<span style='color:#909399;'>"
            f"🔍 PDS 探针已启动（间隔 5s，SDTMSPEC={sdtmspec_name or '未配置'}）"
            f"</span>"
        )
        # 重置"已记日志"缓存 — 让首次 emit 一定会被记录
        self._last_logged_pds_path = ""
        self._last_logged_pds_count = -1

    def _on_pds_changed(self, path, mtime, items):
        """
        watcher 子线程已完成 IO + 解析 → 主线程仅做 setText。
        items 是已解析好的 list[domain]（lower / 去空 / 去重）。

        v12.10.4：加诊断日志输出到 sig_log_template — 让用户看到 watcher 工作状态。
        v12.10.5：默认过滤掉 supp* 开头的 supplemental qualifier domains（如 SUPPAE / SUPPCE）。
                  这些域通常由 main domain（AE/CE/...）自动派生，sdtm_template 不直接对它们调用模板。
                  用户如确实需要 supp* domain，可在 lineEdit 中手动追加（如 "suppae, suppce"），
                  CheckableComboBox 支持自由文本编辑。
        策略：
          - 首次找到 PDS / PDS 文件路径变化 → 输出"📊 PDS 已加载：<path>，<N> 个 datasets"
          - dataset 数量增减 → 输出"🔄 PDS 数据集列表更新：<旧 N> → <新 N>"
          - 静默场景：mtime 变但 datasets 数不变 → 不打日志（避免刷屏）
        """
        # v12.10.5：默认过滤 supp* 域（保留原始 items 用于日志诊断展示）
        raw_items = list(items or [])
        filtered_items = [d for d in raw_items if not d.lower().startswith("supp")]
        n_filtered_out = len(raw_items) - len(filtered_items)

        old_path = getattr(self, "_last_logged_pds_path", "")
        old_count = getattr(self, "_last_logged_pds_count", -1)
        new_count = len(filtered_items)

        if old_path != path:
            # 首次加载或路径变化
            sample = ", ".join(filtered_items[:8]) + ("..." if new_count > 8 else "")
            extra = f"（已过滤 {n_filtered_out} 个 supp* 域）" if n_filtered_out > 0 else ""
            self.sig_log_template.emit(
                f"<span style='color:#67C23A;'>📊 PDS 已加载：</span>"
                f"<span style='color:#909399;'>{path}</span>"
                f"<br>&nbsp;&nbsp;&nbsp;<span style='color:#606266;'>含 {new_count} 个 datasets：{sample}{extra}</span>"
                f"<br>&nbsp;&nbsp;&nbsp;<span style='color:#909399;font-size:11px;'>"
                f"如需 supp* 域，请在 dom 输入框直接追加（例：suppae, suppce）</span>"
            )
            self._last_logged_pds_path = path
            self._last_logged_pds_count = new_count
        elif old_count != new_count:
            # 同一个文件但数量变化（generate_pds 后追加了新 dataset）
            self.sig_log_template.emit(
                f"<span style='color:#409EFF;'>🔄 PDS 数据集列表更新：{old_count} → {new_count}</span>"
            )
            self._last_logged_pds_count = new_count
        # 否则静默（mtime 变化但内容数不变）

        self._pds_domains = filtered_items
        self._cur_pds_path = path
        self._reload_template_combo_items()

    def _on_pds_not_found(self):
        """
        watcher 首次扫描没找到 PDS xlsx — 通知用户。
        提示用户：(a) SDTMSPEC 是否在 setup.xlsx 中正确配置 (b) 是否还没跑过 generate_pds
        """
        # 仅一次性输出（watcher 内已用 _not_found_emitted 控制频率）
        self.sig_log_template.emit(
            "<span style='color:#E6A23C;'>"
            "⚠ 未在 utility/documentation 下找到 SDTM PDS xlsx。"
            "<br>&nbsp;&nbsp;&nbsp;请确认：(a) setup.xlsx 中 SDTMSPEC 是否已配置；"
            "(b) 是否已跑过 generate_pds 生成 PDS。"
            "<br>&nbsp;&nbsp;&nbsp;dom 下拉将保持空白，直到 PDS 文件出现（探针自动检测）。"
            "</span>"
        )
        # dom combo 仍保持空（_pds_domains = []）
        if not self._pds_domains:
            self._reload_template_combo_items()

    def _reload_template_combo_items(self):
        """
        刷新第二步 dom combo 的可选项（保留勾选）。

        v12.10.3 修复：用户反馈"点不出下拉菜单" — 根因之一是每次 watcher tick
        都无条件 addCheckableItems → model.clear() → 正在打开的下拉被强制关闭。
        修复：
          (a) items 与上次一致时直接跳过 — 减少 model 重建次数
          (b) 下拉**正在打开**时延后到下一次 watcher tick 才重建 — 不打断用户
        """
        if not hasattr(self, "tpl_dom_combo"):
            return

        # 用 items 集合判定是否真变化（顺序无关）
        new_set = set(self._pds_domains or [])
        old_set = getattr(self, "_tpl_combo_items_cache", None)
        if old_set is not None and new_set == old_set:
            return  # items 没变 → 跳过重建（避免下拉被频繁 reset）

        # 下拉正在弹出 → 跳过本次，等下次 tick（用户关掉下拉后）
        try:
            view = self.tpl_dom_combo.view()
            if view is not None and view.isVisible():
                return
        except Exception:
            pass

        cur_checked = set(self.tpl_dom_combo.checked_items())
        cur_text = self.tpl_dom_combo.lineEdit().text()
        self.tpl_dom_combo.addCheckableItems(self._pds_domains)
        if cur_checked:
            self.tpl_dom_combo.set_checked_by_text(list(cur_checked))
        if cur_text and not cur_checked:
            self.tpl_dom_combo.lineEdit().setText(cur_text)
        self._tpl_combo_items_cache = new_set

    # ------------------------- 打开 PDS -------------------------
    def _open_pds_file(self):
        if not self.base_path:
            show_dialog(self, "提示", "请先填写完整 4 级路径。", "warning")
            return
        sdtmspec_name = ""
        setup_path = os.path.join(self.base_path, "utility", "documentation", "setup.xlsx")
        if os.path.isfile(setup_path):
            sdtmspec_name, _, _ = read_setup_macro(setup_path, "SDTMSPEC")
        path = find_sdtm_pds_xlsx(self.base_path, sdtmspec_name)
        if not path:
            show_dialog(self, "未找到", "未在 utility/documentation 下找到 SDTM PDS xlsx。\n"
                        "请确认 setup.xlsx 中 SDTMSPEC 已配置，且 generate_pds 已成功运行。",
                        "warning")
            return
        try:
            os.startfile(path)
        except Exception as e:
            show_dialog(self, "打开失败", f"无法打开 PDS 文件：\n{path}\n\n{e}", "error")

    # ------------------------- 全局快捷键钩子 -------------------------
    def action_refresh(self):
        if self.refresh_btn.isEnabled():
            self.refresh_btn.click()

    def action_run(self):
        # 默认运行第一步
        if self.btn_run_pds.isVisible() and self.btn_run_pds.isEnabled():
            self.btn_run_pds.click()

    # ============================================================================
    # 提交前格式校验
    # ============================================================================
    @staticmethod
    def _validate_domain_csv(text: str):
        """
        校验 "a, b, c" 形式的 domain 列表：每个非空 token 必须恰为 2 位英文字母。
        允许整体为空（→ 全 domain）。

        返回 (ok: bool, normalized: str, bad_tokens: list[str])
          normalized 是 trim + lower 后的 ", " 拼接形式（即使 ok=False 也返回最佳归一）
        """
        raw = (text or "").strip()
        if not raw:
            return True, "", []
        tokens = [t.strip() for t in raw.split(",")]
        clean = []
        bad = []
        for t in tokens:
            if not t:
                continue
            if _RE_TWO_LETTER.match(t):
                clean.append(t.lower())
            else:
                bad.append(t)
        return (len(bad) == 0), ", ".join(clean), bad

    # ============================================================================
    # v12.10.31：覆盖检测（修 Issue 6）
    # ============================================================================
    def _confirm_pds_overwrite_if_any(self, ds: str) -> bool:
        """检查 PDS xlsx 是否已含本次提交的 domain（含派生 SUPP<dom>）。
        命中则弹 question 确认。返回 True = 继续运行；False = 用户取消。

        策略：
          - 用 read_setup_macro 拿 SDTMSPEC，确定 PDS 路径
          - read_only=True 用 openpyxl 扫 Datasets sheet（C列以前的"Dataset"列），
            把已有 Dataset 名收一个 set
          - 将本次 ds 拆出每个 dom，加上 supp<dom>（不区分大小写，PDS 习惯用小写）
            逐一检查命中
          - 返回前关闭 wb，避免文件锁
        网络盘 IO 在 0.5~1s 数量级；用户可接受。失败时（找不到 PDS / 解析异常）
        默认认为"无冲突"放行 — 因为一旦真冲突，generate_pds 自身也会在 SAS 层报错，
        不至于漏检后果太严重。
        """
        if not ds:
            return True
        # 切目标 PDS xlsx
        sdtmspec_name = ""
        try:
            setup_path = os.path.join(self.base_path, "utility", "documentation", "setup.xlsx")
            if os.path.isfile(setup_path):
                sdtmspec_name, _, _ = read_setup_macro(setup_path, "SDTMSPEC")
        except Exception:
            sdtmspec_name = ""
        try:
            pds_path = find_sdtm_pds_xlsx(self.base_path, sdtmspec_name)
        except Exception:
            pds_path = ""
        if not pds_path or not os.path.isfile(pds_path):
            return True  # 无 PDS = 全新生成 = 不算覆盖

        # 读 PDS 已有 Dataset 列
        existing = set()
        try:
            import openpyxl
            wb = openpyxl.load_workbook(pds_path, data_only=True, read_only=True)
            try:
                if "Datasets" in wb.sheetnames:
                    ws = wb["Datasets"]
                    # 第 1 行表头，第 2 行起数据；Dataset 一般在 A 列
                    for row in ws.iter_rows(min_row=2, values_only=True):
                        if not row:
                            continue
                        v = row[0] if len(row) > 0 else None
                        if v is None:
                            continue
                        s = str(v).strip().lower()
                        if s:
                            existing.add(s)
            finally:
                wb.close()
        except Exception:
            return True  # 解析失败 → 静默放行，让 SAS 层兜底

        # 比对
        target_doms = [t.strip().lower() for t in ds.split(",") if t.strip()]
        conflicts = []
        for d in target_doms:
            if d in existing:
                conflicts.append(d)
            supp = "supp" + d
            if supp in existing:
                conflicts.append(supp)
        if not conflicts:
            return True

        confirm = show_dialog(
            self, "覆盖确认 — PDS 中已存在以下 domain",
            f"PDS 文件：\n  {os.path.basename(pds_path)}\n\n"
            f"已存在 {len(conflicts)} 项将被本次 %generate_pds 覆盖：\n"
            f"  {', '.join(sorted(set(conflicts)))}\n\n"
            f"是否继续？",
            "question"
        )
        return bool(confirm)

    def _confirm_template_overwrite_if_any(self, dom: str) -> bool:
        """检查 06_programs/061_data 下是否已存在本次提交 dom 的 .sas / _qc.sas。
        命中则弹 question 确认。返回 True = 继续运行；False = 用户取消。
        """
        if not dom:
            return True
        target_dir = os.path.join(self.base_path, "06_programs", "061_data")
        if not os.path.isdir(target_dir):
            return True  # 首次跑 → 无目录 → 无冲突

        target_doms = [t.strip().lower() for t in dom.split(",") if t.strip()]
        conflicts = []
        for d in target_doms:
            for fn in (f"{d}.sas", f"{d}_qc.sas"):
                full = os.path.join(target_dir, fn)
                if os.path.isfile(full):
                    conflicts.append(fn)
        if not conflicts:
            return True

        confirm = show_dialog(
            self, "覆盖确认 — 06_programs/061_data 下已存在",
            f"目录：\n  {target_dir}\n\n"
            f"已存在 {len(conflicts)} 个同名 .sas 将被本次 %sdtm_template 覆盖：\n"
            f"  {', '.join(sorted(set(conflicts)))}\n\n"
            f"是否继续？",
            "question"
        )
        return bool(confirm)

    # ============================================================================
    # 第一步运行入口：generate_pds
    # ============================================================================
    def run_generate_pds(self):
        if not self.base_path:
            show_dialog(self, "提示", "请先填写完整 4 级路径。", "warning")
            return
        if self._runner_pds is not None and self._runner_pds.isRunning():
            self.sig_log_pds.emit("<span style='color:#E6A23C;'>⏳ 上一次 generate_pds 仍在运行中，请稍候…</span>")
            return

        # 提交前校验 dataset 格式
        ds_text = self.pds_ds_combo.lineEdit().text()
        ok, normalized, bad = self._validate_domain_csv(ds_text)
        if not ok:
            show_dialog(
                self, "dataset 格式不合法",
                ("以下输入项不是 2 位英文字母 domain（请用英文逗号分隔）：\n\n  • " +
                 "\n  • ".join(bad) +
                 "\n\n请修改输入框内容后重试。空白 = 处理 PDT 中全部 SDTM/ADaM domain。"),
                "warning"
            )
            return
        # 用归一化后的值（lower + trim）
        ds = normalized

        type_ = self.pds_type_combo.currentText().strip() or "replace"
        igver = self.pds_igver_entry.text().strip()
        updatepage = self.pds_updatepage_combo.currentText().strip() or "n"
        debug = self.pds_debug_combo.currentText().strip() or "n"

        # v12.10.31：覆盖检测（修 Issue 6）
        # 在 PDS xlsx 中扫描"是否已存在用户本次提交的 domain 行 + supp 派生行"。
        # type=replace 会改写已有行，type=add 在已有时报错；任何一种情况下，用户
        # 都应在覆盖前明确知情。检测策略：
        #   - 用 read_only=True 快速扫 Datasets sheet 的 Dataset 列
        #   - 命中（含 SUPP<dom>）即列入 conflicting，弹 question 让用户确认
        #   - dataset 为空（=全 domain）时跳过检测（用户已知是全量重生成）
        if ds and not self._confirm_pds_overwrite_if_any(ds):
            self.sig_log_pds.emit("<span style='color:#909399;'>已取消 generate_pds（用户拒绝覆盖）。</span>")
            return

        parts = ["libname=sdtm"]
        if igver:
            parts.append(f"igver={igver}")
        parts.append(f"dataset=%str({ds})")
        parts.append(f"updatepage={updatepage}")
        parts.append(f"type={type_}")
        parts.append(f"debug={debug}")
        macro_call = f"%generate_pds({', '.join(parts)});"
        self._last_macro_call_pds = macro_call  # v12.10.8：传给 _on_pds_finished 写永久 log 头

        try:
            self._temp_sas_pds = write_temp_sas(self.base_path, macro_call, prefix="temp_generate_pds")
        except Exception as e:
            show_dialog(self, "错误", f"无法在 utility/tools 下创建临时脚本：\n{e}", "error")
            return

        # v12.10.2：把本次提交涉及的 domain 暂存到 self._submitted_pds_doms；
        # 仅在 _on_pds_finished（运行完成 — 不论 ok/warn/err）时调 mark_used。
        # 取消（_on_cancel_pds）则不 mark，避免误标灰底。
        self._submitted_pds_doms = (
            [t.strip() for t in ds.split(",") if t.strip()] if ds else []
        )

        # UI 进入运行态
        self._pds_status = "running"
        self.sig_run_started_pds.emit()    # stepper：切到 generate_pds tab（不清日志）
        self.sig_run_started.emit()
        self.sig_status_pds.emit("⏳ 正在执行 generate_pds…", "#409EFF")
        self.sig_log_pds.emit(
            f"<span style='color:#409EFF; font-weight:bold;'>🚀 提交 %generate_pds</span>"
        )
        self.sig_log_pds.emit(
            f"<span style='color:#909399;'>&nbsp;&nbsp;调用：{macro_call}</span>"
        )
        self.sig_log_pds.emit(
            f"<span style='color:#909399;'>&nbsp;&nbsp;临时脚本：{self._temp_sas_pds}</span>"
        )

        self.btn_run_pds.setVisible(False)
        self.btn_cancel_pds.setVisible(True)
        self.pds_prog.setRange(0, 0)
        self.pds_prog.setVisible(True)

        self._runner_pds = SingleBatchRunner(self._temp_sas_pds)
        self._runner_pds.finished_signal.connect(self._on_pds_finished)
        self._t_start_pds = time.time()
        self._runner_pds.start()

    def _on_cancel_pds(self):
        runner = self._runner_pds
        if runner is None or not runner.isRunning():
            self._reset_pds_ui()
            return
        runner.is_cancelled = True
        try:
            if runner.proc and runner.proc.poll() is None:
                runner.proc.kill()
        except Exception:
            pass
        self._pds_status = "cancelled"
        self.sig_log_pds.emit("<span style='color:#F56C6C; font-weight:bold;'>🛑 用户已中止 generate_pds 运行。</span>")
        self.sig_status_pds.emit("🛑 已中止 generate_pds", "#F56C6C")
        self._reset_pds_ui()
        self._refresh_step_label()
        # v12.10.8：中止时也追加 temp.log 内容（SAS 进程被 kill 前可能已写部分 log，
        # 用户中止后想看为什么中止 / 中止前到了哪一步）
        elapsed_cancel = time.time() - getattr(self, "_t_start_pds", time.time())
        permanent_log = append_temp_log_to_permanent(
            self._temp_sas_pds, "26_generate_pds_call.log",
            macro_call=getattr(self, "_last_macro_call_pds", "") + "  [USER CANCELLED]",
            elapsed_sec=elapsed_cancel,
        )
        if permanent_log and os.path.exists(permanent_log):
            self.sig_log_pds.emit(
                f"<span style='color:#909399;'>&nbsp;&nbsp;详细日志（追加模式 — 含历次运行）：{permanent_log}</span>"
            )
        cleanup_temp_sas(self._temp_sas_pds)
        self._temp_sas_pds = ""
        self._runner_pds = None
        self.sig_run_finished_pds.emit()
        self.sig_run_finished.emit()

    def _reset_pds_ui(self):
        self.pds_prog.setVisible(False)
        self.btn_run_pds.setVisible(True)
        self.btn_cancel_pds.setVisible(False)

    def _on_pds_finished(self, has_issue, summary, log_text):
        self._reset_pds_ui()
        elapsed = time.time() - self._t_start_pds

        sev = classify_log_severity(log_text)
        severity = sev["severity"]

        if severity == "error":
            self._pds_status = "err"
            self.sig_log_pds.emit(severity_finished_html("generate_pds", severity, summary))
            self.sig_log_pds.emit(extract_issue_lines_html(log_text))
            self.sig_status_pds.emit("❌ generate_pds 完成（含 ERROR）", "#F56C6C")
        elif severity == "warning":
            self._pds_status = "warn"
            self.sig_log_pds.emit(severity_finished_html("generate_pds", severity, summary))
            self.sig_log_pds.emit(extract_issue_lines_html(log_text))
            self.sig_status_pds.emit("⚠️ generate_pds 完成（含 WARNING）", "#E6A23C")
        else:
            self._pds_status = "ok"
            self.sig_log_pds.emit(severity_finished_html("generate_pds", severity, summary, elapsed))
            self.sig_status_pds.emit(f"✅ generate_pds 完成（{elapsed:.1f}s）", "#67C23A")

        # v12.10.8：把本次 temp.log 内容追加到永久 log 文件
        # （cleanup_temp_sas 紧接着会删 temp.log，所以追加必须在 cleanup 之前）
        permanent_log = append_temp_log_to_permanent(
            self._temp_sas_pds, "26_generate_pds_call.log",
            macro_call=getattr(self, "_last_macro_call_pds", ""),
            elapsed_sec=elapsed,
        )
        if permanent_log and os.path.exists(permanent_log):
            self.sig_log_pds.emit(
                f"<span style='color:#909399;'>&nbsp;&nbsp;详细日志（追加模式 — 含历次运行）：{permanent_log}</span>"
            )

        cleanup_temp_sas(self._temp_sas_pds)
        self._temp_sas_pds = ""

        # v12.10.2：完成（不论 ok/warn/err）后才 mark_used；取消则不标
        if getattr(self, "_submitted_pds_doms", None):
            self.pds_ds_combo.mark_used(self._submitted_pds_doms)
        self._submitted_pds_doms = []

        # 运行结束自动清空 dataset 选择 + lineEdit（保留灰底记忆）
        # 让用户回到"等待重新勾选"的初始状态；若再次勾选灰底项会弹窗确认覆盖
        self.pds_ds_combo.clear_selection_keep_used()

        self._refresh_step_label()
        thread_ref = self._runner_pds
        self._runner_pds = None
        if thread_ref is not None:
            try:
                thread_ref.finished.connect(thread_ref.deleteLater)
            except Exception:
                pass
        self.sig_run_finished_pds.emit()
        self.sig_run_finished.emit()

    def _confirm_overwrite_pds_dataset(self, text: str) -> bool:
        """
        用户尝试勾选已运行过的（灰底）domain 时的覆盖确认。
        返回 True → 允许覆盖（CheckableComboBox 会真切换为已勾）；
        返回 False → 不切换勾选（用户拒绝）。
        """
        from PySide6.QtWidgets import QMessageBox
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Warning)
        box.setWindowTitle("确认覆盖")
        box.setText(f"已为 domain '{text}' 生成过 PDS。是否要覆盖重跑？")
        box.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        box.setDefaultButton(QMessageBox.No)
        return box.exec() == QMessageBox.Yes

    # ============================================================================
    # 第二步运行入口：sdtm_template
    # ============================================================================
    def run_sdtm_template(self):
        if not self.base_path:
            show_dialog(self, "提示", "请先填写完整 4 级路径。", "warning")
            return
        if self._runner_template is not None and self._runner_template.isRunning():
            self.sig_log_template.emit("<span style='color:#E6A23C;'>⏳ 上一次 sdtm_template 仍在运行中，请稍候…</span>")
            return

        # 校验 dom 格式
        dom_text = self.tpl_dom_combo.lineEdit().text()
        ok, normalized, bad = self._validate_domain_csv(dom_text)
        if not ok:
            show_dialog(
                self, "dom 格式不合法",
                ("以下输入项不是 2 位英文字母 domain（请用英文逗号分隔）：\n\n  • " +
                 "\n  • ".join(bad) +
                 "\n\n请修改输入框内容后重试。空白 = 处理全部 SDTM domain。"),
                "warning"
            )
            return
        dom = normalized

        # v12.10.31：覆盖检测（修 Issue 6）
        # sdtm_template 输出 06_programs/061_data/<dom>.sas + <dom>_qc.sas。
        # 已存在的同名 .sas 会被宏覆盖（无 backup）→ 弹窗确认。
        if dom and not self._confirm_template_overwrite_if_any(dom):
            self.sig_log_template.emit("<span style='color:#909399;'>已取消 sdtm_template（用户拒绝覆盖）。</span>")
            return

        testmod = self.tpl_testmod_combo.currentText().strip() or "n"

        parts = []
        parts.append(f"dom=%str({dom})")
        parts.append(f"testmod={testmod}")
        macro_call = f"%sdtm_template({', '.join(parts)});"
        self._last_macro_call_template = macro_call  # v12.10.8：传给 _on_template_finished 写永久 log 头

        try:
            self._temp_sas_template = write_temp_sas(self.base_path, macro_call, prefix="temp_sdtm_template")
        except Exception as e:
            show_dialog(self, "错误", f"无法在 utility/tools 下创建临时脚本：\n{e}", "error")
            return

        # v12.10.2：暂存提交的 dom 列表（与第一步对称），完成时再 mark_used
        self._submitted_template_doms = (
            [t.strip() for t in dom.split(",") if t.strip()] if dom else []
        )

        self._template_status = "running"
        self.sig_run_started_template.emit()  # stepper：切到 sdtm_template tab（不清日志）
        self.sig_run_started.emit()
        self.sig_status_tpl.emit("⏳ 正在执行 sdtm_template…", "#409EFF")
        self.sig_log_template.emit(
            f"<span style='color:#409EFF; font-weight:bold;'>🚀 提交 %sdtm_template</span>"
        )
        self.sig_log_template.emit(
            f"<span style='color:#909399;'>&nbsp;&nbsp;调用：{macro_call}</span>"
        )
        self.sig_log_template.emit(
            f"<span style='color:#909399;'>&nbsp;&nbsp;临时脚本：{self._temp_sas_template}</span>"
        )

        self.btn_run_tpl.setVisible(False)
        self.btn_cancel_tpl.setVisible(True)
        self.tpl_prog.setRange(0, 0)
        self.tpl_prog.setVisible(True)

        self._runner_template = SingleBatchRunner(self._temp_sas_template)
        self._runner_template.finished_signal.connect(self._on_template_finished)
        self._t_start_template = time.time()
        self._runner_template.start()

    def _on_cancel_tpl(self):
        runner = self._runner_template
        if runner is None or not runner.isRunning():
            self._reset_tpl_ui()
            return
        runner.is_cancelled = True
        try:
            if runner.proc and runner.proc.poll() is None:
                runner.proc.kill()
        except Exception:
            pass
        self._template_status = "cancelled"
        self.sig_log_template.emit("<span style='color:#F56C6C; font-weight:bold;'>🛑 用户已中止 sdtm_template 运行。</span>")
        self.sig_status_tpl.emit("🛑 已中止 sdtm_template", "#F56C6C")
        self._reset_tpl_ui()
        self._refresh_step_label()
        # v12.10.8：中止时追加 temp.log
        elapsed_cancel = time.time() - getattr(self, "_t_start_template", time.time())
        permanent_log = append_temp_log_to_permanent(
            self._temp_sas_template, "27_sdtm_template_call.log",
            macro_call=getattr(self, "_last_macro_call_template", "") + "  [USER CANCELLED]",
            elapsed_sec=elapsed_cancel,
        )
        if permanent_log and os.path.exists(permanent_log):
            self.sig_log_template.emit(
                f"<span style='color:#909399;'>&nbsp;&nbsp;详细日志（追加模式 — 含历次运行）：{permanent_log}</span>"
            )
        cleanup_temp_sas(self._temp_sas_template)
        self._temp_sas_template = ""
        self._runner_template = None
        self.sig_run_finished_tpl.emit()
        self.sig_run_finished.emit()

    def _reset_tpl_ui(self):
        self.tpl_prog.setVisible(False)
        self.btn_run_tpl.setVisible(True)
        self.btn_cancel_tpl.setVisible(False)

    def _on_template_finished(self, has_issue, summary, log_text):
        self._reset_tpl_ui()
        elapsed = time.time() - self._t_start_template

        sev = classify_log_severity(log_text)
        severity = sev["severity"]

        if severity == "error":
            self._template_status = "err"
            self.sig_log_template.emit(severity_finished_html("sdtm_template", severity, summary))
            self.sig_log_template.emit(extract_issue_lines_html(log_text))
            self.sig_status_tpl.emit("❌ sdtm_template 完成（含 ERROR）", "#F56C6C")
        elif severity == "warning":
            self._template_status = "warn"
            self.sig_log_template.emit(severity_finished_html("sdtm_template", severity, summary))
            self.sig_log_template.emit(extract_issue_lines_html(log_text))
            self.sig_status_tpl.emit("⚠️ sdtm_template 完成（含 WARNING）", "#E6A23C")
        else:
            self._template_status = "ok"
            self.sig_log_template.emit(severity_finished_html("sdtm_template", severity, summary, elapsed))
            self.sig_status_tpl.emit(f"✅ sdtm_template 完成（{elapsed:.1f}s）", "#67C23A")

        # v12.10.8：把本次 temp.log 内容追加到永久 log 文件
        permanent_log = append_temp_log_to_permanent(
            self._temp_sas_template, "27_sdtm_template_call.log",
            macro_call=getattr(self, "_last_macro_call_template", ""),
            elapsed_sec=elapsed,
        )
        if permanent_log and os.path.exists(permanent_log):
            self.sig_log_template.emit(
                f"<span style='color:#909399;'>&nbsp;&nbsp;详细日志（追加模式 — 含历次运行）：{permanent_log}</span>"
            )

        cleanup_temp_sas(self._temp_sas_template)
        self._temp_sas_template = ""

        # v12.10.2：完成后 mark_used；取消则不标
        if getattr(self, "_submitted_template_doms", None):
            self.tpl_dom_combo.mark_used(self._submitted_template_doms)
        self._submitted_template_doms = []

        # 运行结束自动清空 dom 选择 + lineEdit（保留灰底记忆）— 与第一步对称
        self.tpl_dom_combo.clear_selection_keep_used()

        self._refresh_step_label()
        thread_ref = self._runner_template
        self._runner_template = None
        if thread_ref is not None:
            try:
                thread_ref.finished.connect(thread_ref.deleteLater)
            except Exception:
                pass
        self.sig_run_finished_tpl.emit()
        self.sig_run_finished.emit()

    def _confirm_overwrite_template_dom(self, text: str) -> bool:
        """
        用户尝试勾选已运行过的（灰底）dom 时的覆盖确认（与 dataset 对称）。
        返回 True → 允许覆盖；False → 不切换勾选。
        """
        from PySide6.QtWidgets import QMessageBox
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Warning)
        box.setWindowTitle("确认覆盖")
        box.setText(f"已为 dom '{text}' 生成过 SDTM 程序模板。是否要覆盖重跑？")
        box.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        box.setDefaultButton(QMessageBox.No)
        return box.exec() == QMessageBox.Yes

    # ============================================================================
    # 步骤栏文案汇总：以两子步中"最差"状态为准
    # ============================================================================
    def _refresh_step_label(self):
        statuses = (self._pds_status, self._template_status)
        if "running" in statuses:
            return
        if statuses == ("idle", "idle"):
            return
        if "err" in statuses:
            self.sig_step_update.emit("02 SDTM Gen ❌")
        elif "cancelled" in statuses:
            self.sig_step_update.emit("02 SDTM Gen 🟥")
        elif "warn" in statuses:
            self.sig_step_update.emit("02 SDTM Gen ⚠️")
        elif "ok" in statuses:
            self.sig_step_update.emit("02 SDTM Gen ✅")
