# -*- coding: utf-8 -*-
"""
modules/m5_codelist_runner.py
=============================
M5「02 PDS for Codelist」独立子进程脚本（v12.10.112 加入）。

与 m5_pds_runner.py 同款方案（剥离子进程，避免 pandas/openpyxl 持 GIL 卡 UI）：
  调用外部包 crt_codelist，依据 *_PDS_vars.xlsx（步骤 01 的产物）+ 实际数据 +
  CDISC CT 文件，生成 *_PDS_codelist.xlsx。

入口：crt_codelist.run.run(cfg, out_path=None, verbose=True) -> str
  cfg = crt_codelist.Config(ra_root=..., libname=..., lng=..., igver=..., sdtmctve=...,
                            adamctve=..., debug=..., xpt_dir_override=...,
                            sysmeta_override=..., sysdoc_override=..., rameta_dir_override=...)

注意：crt_codelist.Config.__post_init__ 较重（读 *_vars.xlsx 的 Define sheet 取 IG 版本、
从 sysmeta + 00_source_data 解析 CT 版本）。部分路径（vars_path / ct 文件 / template）
没有构造期 override 形参，故在 Config 构造完成后**后置覆盖属性**
（io_read.load_inputs 在运行期读取这些属性，后置覆盖即生效）。

调用约定（同 m5_pds_runner）：父进程把参数 JSON 写 stdin，子进程逐行 stdout JSON：
  {"level":"info|ok|warn|err","msg":...} / {"level":"progress","val":int,"msg":...}
  / {"level":"result","ok":bool,"out_paths":[...],"msg":...}
"""
import sys
import os
import json

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    from _no_window_popen import install as _install_no_window_popen
    _install_no_window_popen()
except Exception:
    pass

_REAL_STDOUT = sys.stdout


def emit(level, msg="", **extra):
    obj = {"level": level, "msg": msg}
    if extra:
        obj.update(extra)
    try:
        _REAL_STDOUT.write(json.dumps(obj, ensure_ascii=False) + "\n")
        _REAL_STDOUT.flush()
    except Exception:
        pass


class _JsonStream:
    def __init__(self):
        self._buf = ""

    def write(self, text):
        if not text:
            return
        self._buf += text
        while "\n" in self._buf:
            line, self._buf = self._buf.split("\n", 1)
            self._emit_line(line)

    def _emit_line(self, line):
        line = line.rstrip("\r")
        if not line.strip():
            return
        up = line.upper()
        if "ERROR" in up or "❌" in line:
            lvl = "err"
        elif "WARNING" in up or "[WARN]" in up or "⚠" in line:
            lvl = "warn"
        elif "✅" in line:
            lvl = "ok"
        else:
            lvl = "info"
        emit(lvl, line)

    def flush(self):
        if self._buf.strip():
            self._emit_line(self._buf)
            self._buf = ""

    close = flush


def main():
    raw = sys.stdin.read()
    try:
        params = json.loads(raw)
    except Exception as e:
        emit("result", f"参数解析失败：{e}", ok=False)
        return 1

    crt_dir = (params.get("crt_import_dir") or "").strip()
    if crt_dir and crt_dir not in sys.path:
        sys.path.append(crt_dir)
    cfg_kwargs = params.get("cfg_kwargs") or {}
    post_overrides = params.get("post_overrides") or {}
    run_kwargs = params.get("run_kwargs") or {}

    sys.stdout = _JsonStream()
    sys.stderr = sys.stdout
    try:
        emit("progress", "正在加载外部包 crt_codelist (首次加载 pandas 可能稍长)...", val=5)
        import importlib
        try:
            crt_codelist = importlib.import_module("crt_codelist")
            crt_run_mod = importlib.import_module("crt_codelist.run")
        except Exception as e:
            emit("result",
                 "无法导入外部包 crt_codelist。请确认 sys.path 下存在 crt_codelist/ 包，"
                 f"且已安装依赖 pandas / openpyxl / pyreadstat。\n[原始异常] {e}",
                 ok=False)
            return 1

        Config = getattr(crt_codelist, "Config", None)
        run = getattr(crt_run_mod, "run", None)
        if Config is None or not callable(run):
            emit("result", "crt_codelist 包结构异常：未找到 Config 或 run.run。", ok=False)
            return 1

        emit("progress", "正在构造 Config（读 Define IG 版本 + 解析 CT 版本）...", val=15)
        cfg = Config(**cfg_kwargs)

        # 后置覆盖：load_inputs 运行期读取的、且 Config 无构造期 override 形参的路径
        libname = (cfg_kwargs.get("libname") or "sdtm").strip().lower()
        v = (post_overrides.get("vars_path") or "").strip()
        if v:
            cfg.vars_path = v
        v = (post_overrides.get("ct_path") or "").strip()
        if v:
            if libname == "sdtm":
                cfg.sdtm_ct_path = v
            else:
                cfg.adam_ct_path = v
        v = (post_overrides.get("template_path") or "").strip()
        if v:
            cfg.template_path = v

        emit("progress", "正在生成 PDS Codelist (spec_codelist) ...", val=25)
        result = run(cfg, **run_kwargs)

        if isinstance(result, tuple):
            out_paths = [str(p) for p in result if p]
        elif result:
            out_paths = [str(result)]
        else:
            out_paths = []

        emit("progress", "生成成功！", val=100)
        emit("result", "", ok=True, out_paths=out_paths)
        return 0
    except Exception as e:
        emit("result", str(e), ok=False)
        return 1
    finally:
        sys.stdout = _REAL_STDOUT
        sys.stderr = _REAL_STDOUT


if __name__ == "__main__":
    sys.exit(main())
