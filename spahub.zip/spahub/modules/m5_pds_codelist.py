# -*- coding: utf-8 -*-
"""
modules/m5_pds_codelist.py
==========================
M5 模块 - 03 PDS for Codelist

完全复刻 02 PDS for vars 的 UI 与接口逻辑，只是换成外部包 crt_codelist：
依据 *_PDS_vars.xlsx（步骤 02 产物）+ 实际 XPT 数据 + CDISC CT 文件，生成
*_PDS_codelist.xlsx（spec_codelist）。

入口：crt_codelist.run.run(cfg, out_path=None, verbose=True) -> str
  cfg = crt_codelist.Config(ra_root, libname, igver, sdtmctve, adamctve, lng, debug,
                            sysmeta_override, sysdoc_override, xpt_dir_override,
                            rameta_dir_override, prot)

UI（与 01 同构）：
  - libname 下拉框（sdtm / adam，滚轮锁定）。切换即重填下方源文件。
  - 源文件输入（自动填写 + 浏览，允许用户自选）：
      1. vars（输入 _vars.xlsx，步骤 02 产物）
      2. codelist（输出）
      3. xpt_dir
      4. sysmeta（CT / 映射文件所在目录）
  - 高级参数（默认折叠，固定选项做下拉、滚轮锁定）：
      lng(cn/en) / igver(留空自动) / sdtmctve(留空自动) / adamctve(留空自动) /
      debug(False/True) / CT 文件(留空自动) / template(留空自动) /
      sysdoc(留空自动) / rameta_dir(留空自动)

运行机制（与 01 同款）：
  后台 QThread 只起子进程 modules.m5_codelist_runner 并阻塞读其 stdout（释放 GIL，
  UI 不卡），重活（pandas/openpyxl）都在子进程。子进程 JSON 行 → log/progress/finished。

注意：crt_codelist.Config.__post_init__ 较重（读 Define IG 版本、解析 CT 版本），
  不能在 UI 线程构造 Config 做预览/自动填写 —— 故自动填写改用**轻量路径推导**
  （仅 path join，不读文件），与 config.py 的命名约定保持一致。

依赖（crt_codelist 运行时）：pandas / openpyxl / pyreadstat（需全局安装，勿用 venv）。
"""
import os
import re
import sys
import html

# ================= 外部工具包路径注册 =================
# crt_codelist 与 crt_vars 同处 Z:\projects\Z_PYTHON\CRT 下。登记「含包目录的那一层」。
_CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
_PARENT_DIR = os.path.dirname(_CURRENT_DIR)

_CRT_ROOT = r"Z:\projects\Z_PYTHON\CRT"
for _c in (os.path.join(_PARENT_DIR, "CRT"), os.path.join(os.path.dirname(_PARENT_DIR), "CRT")):
    if os.path.isdir(_c):
        _CRT_ROOT = _c
        break


def _resolve_crt_import_dir():
    """返回应加入 sys.path 的目录（其下存在 crt_codelist/ 包目录）。
    兼容 <CRT>/crt_codelist 与 <CRT>/crt_py/crt_codelist 两种布局；
    再兜底用 crt_vars 的存在性判断（两包同级）。"""
    for sub in ("", "crt_py"):
        base = os.path.join(_CRT_ROOT, sub) if sub else _CRT_ROOT
        if os.path.isfile(os.path.join(base, "crt_codelist", "__init__.py")):
            return base
        if os.path.isfile(os.path.join(base, "crt_vars", "__init__.py")):
            return base
    return _CRT_ROOT


_CRT_IMPORT_DIR = _resolve_crt_import_dir()
if _CRT_IMPORT_DIR and _CRT_IMPORT_DIR not in sys.path:
    sys.path.append(_CRT_IMPORT_DIR)
# ======================================================

from PySide6.QtWidgets import (QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                               QLineEdit, QComboBox, QFileDialog, QFrame, QProgressBar,
                               QWidget)
from PySide6.QtCore import Qt, QThread, Signal

from ui_utils import show_dialog, primary_outline_btn_style, scan_status_lbl_style


_LIBNAME_OPTIONS = ["sdtm", "adam"]
_LNG_OPTIONS = ["cn", "en"]          # 注意 crt_codelist 用小写
_BOOL_OPTIONS = ["False", "True"]    # debug 默认 False

_COMBO_STYLE = ("padding: 6px 10px; border: 1px solid #DCDFE6; border-radius: 4px; "
                "background: #FFFFFF; color: #606266; font-weight: normal;")
_ENTRY_STYLE = "padding: 6px; border: 1px solid #DCDFE6; border-radius: 4px;"
_BROWSE_STYLE = ("background-color: #F5F7FA; color: #606266; border: 1px solid #DCDFE6; "
                 "padding: 6px 12px; border-radius: 4px;")


class _NoWheelComboBox(QComboBox):
    """滚轮锁定下拉框：滚轮只滚动外层页面、不改选项（改值只能点击）。"""
    def wheelEvent(self, event):
        event.ignore()


# =============================================================================
# 高级参数折叠区
# =============================================================================
class _CollapseSection(QFrame):
    def __init__(self, title="高级参数", parent=None):
        super().__init__(parent)
        self.setStyleSheet("QFrame { border: none; }")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(4)

        self.toggle_btn = QPushButton(f"▶ {title}")
        self.toggle_btn.setStyleSheet("""
            QPushButton { background: transparent; border: none; color: #409EFF;
                          font-size: 13px; font-weight: bold; text-align: left; padding: 4px 0; }
            QPushButton:hover { color: #66B1FF; }
        """)
        self.toggle_btn.setCursor(Qt.PointingHandCursor)
        self.toggle_btn.clicked.connect(self._on_toggle_clicked)
        lay.addWidget(self.toggle_btn, 0, Qt.AlignLeft)

        self.content = QFrame()
        self.content.setStyleSheet(
            "QFrame { background: #FAFBFC; border: 1px dashed #DCDFE6; border-radius: 4px; }")
        self.content_lay = QVBoxLayout(self.content)
        self.content_lay.setContentsMargins(10, 8, 10, 8)
        self.content_lay.setSpacing(8)
        self.content.setVisible(False)
        lay.addWidget(self.content)

        self._title = title
        self._expanded = False

    def _on_toggle_clicked(self):
        self._expanded = not self._expanded
        self.content.setVisible(self._expanded)
        self.toggle_btn.setText(f"{'▼' if self._expanded else '▶'} {self._title}")

    def addRow(self, layout):
        self.content_lay.addLayout(layout)


# =============================================================================
# 轻量路径推导（复刻 crt_codelist/config.py 的命名约定，但不读文件、不做校验）
# =============================================================================
def _derive_paths(base_path, libname):
    """从 base_path + libname 推导可展示的默认路径（不构造重 Config）。"""
    norm = os.path.normpath(base_path)
    leaf = os.path.basename(norm)
    parent = os.path.basename(os.path.dirname(norm))
    study = f"{parent}_{leaf}" if parent else leaf
    sdtm = (libname == "sdtm")

    doc = os.path.join(base_path, "utility", "documentation")
    sub = "065_define_sdtm" if sdtm else "066_define_adam"
    define_dir = os.path.join(doc, "06_crt_preparation", sub)
    token = "SDTM_PDS" if sdtm else "ADAM_PDS"
    spec_name = f"{study}_{token}"
    vars_path = os.path.join(define_dir, f"{spec_name}_vars.xlsx")
    codelist_path = os.path.join(define_dir, f"{spec_name}_codelist.xlsx")
    if sdtm:
        xpt_dir = os.path.join(base_path, "04_crt", "tabulations", "sdtm")
    else:
        xpt_dir = os.path.join(base_path, "04_crt", "analysis", "adam", "datasets")

    # projects_root：向上找名为 projects 的祖先（复刻 config._find_projects_root 简版）
    parts = [p for p in re.split(r"[\\/]+", base_path.strip()) if p]
    projects_root = ""
    for i, p in enumerate(parts):
        if p.lower() == "projects":
            head = parts[:i + 1]
            if base_path.startswith("\\\\"):
                projects_root = "\\\\" + os.sep.join(head)
            elif ":" in parts[0]:
                projects_root = parts[0] + os.sep + os.sep.join(head[1:])
            else:
                projects_root = os.sep + os.sep.join(head)
            break
    sysmeta = os.path.join(projects_root, "utility", "metadata") if projects_root else ""

    return {
        "vars_path": vars_path,
        "codelist_path": codelist_path,
        "xpt_dir": xpt_dir,
        "sysmeta": sysmeta,
    }


# =============================================================================
# 后台运行线程 —— 起子进程 + 读 stdout（重活在子进程，避免 GIL 卡 UI）
# =============================================================================
class PdsForCodelistRunner(QThread):
    log_signal = Signal(str)
    progress_signal = Signal(int, str)
    finished_signal = Signal(bool, str)

    def __init__(self, cfg_kwargs, post_overrides, run_kwargs):
        super().__init__()
        self.cfg_kwargs = dict(cfg_kwargs)
        self.post_overrides = dict(post_overrides)
        self.run_kwargs = dict(run_kwargs)
        self.is_cancelled = False
        self.proc = None

    def cancel(self):
        self.is_cancelled = True
        p = self.proc
        if p is None:
            return
        try:
            if p.poll() is None:
                if os.name == "nt":
                    import subprocess
                    subprocess.run(
                        ["taskkill", "/F", "/T", "/PID", str(p.pid)],
                        creationflags=0x08000000,
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                    )
                else:
                    p.kill()
        except Exception:
            try:
                p.kill()
            except Exception:
                pass

    def run(self):
        import subprocess
        import json as _json
        from app_paths import child_command_m5_codelist, app_root

        payload = _json.dumps({
            "crt_import_dir": _CRT_IMPORT_DIR,
            "cfg_kwargs": self.cfg_kwargs,
            "post_overrides": self.post_overrides,
            "run_kwargs": self.run_kwargs,
        }, ensure_ascii=False)

        env = os.environ.copy()
        env["PYTHONIOENCODING"] = "utf-8"
        env["PYTHONUTF8"] = "1"

        try:
            self.proc = subprocess.Popen(
                child_command_m5_codelist(),
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                cwd=app_root(),
                encoding="utf-8",
                errors="replace",
                bufsize=1,
                env=env,
                creationflags=0x08000000,
            )
        except Exception as e:
            self.finished_signal.emit(False, f"❌ 启动子进程失败：{e}")
            return

        try:
            self.proc.stdin.write(payload + "\n")
            self.proc.stdin.flush()
            self.proc.stdin.close()
        except Exception as e:
            self.finished_signal.emit(False, f"❌ 向子进程写参数失败：{e}")
            try:
                self.proc.kill()
            except Exception:
                pass
            return

        ok = False
        final_msg = ""
        out_paths = []
        got_result = False
        try:
            for raw_line in self.proc.stdout:
                if self.is_cancelled:
                    break
                line = (raw_line or "").rstrip()
                if not line:
                    continue
                try:
                    obj = _json.loads(line)
                except Exception:
                    self.log_signal.emit(html.escape(line))
                    continue
                lvl = (obj.get("level") or "info").lower()
                if lvl == "progress":
                    self.progress_signal.emit(int(obj.get("val", 0) or 0), str(obj.get("msg", "")))
                elif lvl == "result":
                    got_result = True
                    ok = bool(obj.get("ok"))
                    final_msg = str(obj.get("msg", "") or "")
                    out_paths = list(obj.get("out_paths") or [])
                else:
                    self.log_signal.emit(html.escape(str(obj.get("msg", ""))))
        except Exception as e:
            self.log_signal.emit(f"<span style='color:#E6A23C;'>&gt; 读子进程 stdout 异常：{html.escape(str(e))}</span>")

        try:
            rc = self.proc.wait(timeout=30)
        except Exception:
            try:
                self.proc.kill()
            except Exception:
                pass
            rc = -1

        if self.is_cancelled:
            return

        if got_result and ok:
            msg = ("✅ 已生成：\n  " + "\n  ".join(out_paths)) if out_paths else (final_msg or "✅ spec_codelist 生成完成。")
            self.finished_signal.emit(True, msg)
        elif got_result and not ok:
            self.finished_signal.emit(False, f"❌ {final_msg}" if final_msg else "❌ crt_codelist 执行失败。")
        else:
            self.finished_signal.emit(False, f"❌ 子进程异常结束（exit={rc}），未返回结果。")


# =============================================================================
# 左侧表单组件 PdsForCodelistForm
# =============================================================================
class PdsForCodelistForm(QFrame):
    sig_log = Signal(str)
    sig_status = Signal(str, str)
    sig_step_update = Signal(str)
    sig_run_started = Signal()
    sig_run_finished = Signal()

    def __init__(self):
        super().__init__()
        self.base_path = ""
        self._setup_ui()

    def _show_msg(self, title, text, msg_type="info"):
        return show_dialog(self, title, text, msg_type)

    # ------------------------- UI 构造 -------------------------
    def _setup_ui(self):
        self.setObjectName("LeftPanel")
        self.setStyleSheet("#LeftPanel { background-color: #FFFFFF; border: 1px solid #E4E7ED; border-radius: 6px; }")
        form_layout = QVBoxLayout(self)
        form_layout.setAlignment(Qt.AlignTop)
        form_layout.setContentsMargins(25, 25, 25, 25)
        form_layout.setSpacing(16)

        self._step_name = "PDS for Codelist"
        top_bar = QHBoxLayout()
        self.refresh_btn = QPushButton("🔄 刷新源文件")
        self.refresh_btn.setStyleSheet(primary_outline_btn_style())
        self.refresh_btn.setCursor(Qt.PointingHandCursor)
        self.refresh_btn.clicked.connect(self.action_refresh)
        top_bar.addWidget(self.refresh_btn)
        self.scan_lbl = QLabel("")
        self.scan_lbl.setStyleSheet(scan_status_lbl_style())
        top_bar.addWidget(self.scan_lbl)
        top_bar.addStretch()
        form_layout.addLayout(top_bar)

        # v12.10.125：重编号后 PDS for vars 为步骤 02（01 是 Convert2XPT），描述"步骤 01"→"步骤 02"
        title = QLabel("基于 _vars.xlsx（步骤 02 产物）+ XPT + CDISC CT，调用 crt_codelist 生成 codelist spec。")
        title.setStyleSheet("color: #303133; font-weight: bold; font-size: 14px; border: none;")
        title.setWordWrap(True)
        form_layout.addWidget(title)

        self.prog = QProgressBar()
        self.prog.setVisible(False)
        self.prog.setFixedHeight(4)
        form_layout.addWidget(self.prog)

        # ---------- libname 下拉（原生右侧箭头 + 滚轮锁定） ----------
        lib_row = QHBoxLayout()
        lib_lbl = QLabel("libname：")
        lib_lbl.setStyleSheet("border: none; color: #606266; min-width: 150px;")
        lib_row.addWidget(lib_lbl)
        self.libname_combo = _NoWheelComboBox()
        self.libname_combo.setStyleSheet(_COMBO_STYLE)
        self.libname_combo.addItems(_LIBNAME_OPTIONS)
        self.libname_combo.currentIndexChanged.connect(self._on_libname_changed)
        lib_row.addWidget(self.libname_combo, 1)
        # v12.10.131：libname 现由 M5 顶部「数据类型」总开关驱动，整行包一层 QWidget 后隐藏
        # （combo 仍作状态容器，setCurrentText 触发 _on_libname_changed → _fill_paths 重填）。
        self._libname_row = QWidget()
        self._libname_row.setLayout(lib_row)
        form_layout.addWidget(self._libname_row)
        self._libname_row.setVisible(False)

        # ---------- 源文件输入（自动填写 + 浏览） ----------
        def add_row(label_text, browse, filter_str="*.xlsx"):
            l = QHBoxLayout()
            lbl = QLabel(label_text)
            lbl.setStyleSheet("border: none; color: #606266; min-width: 150px;")
            l.addWidget(lbl)
            entry = QLineEdit()
            entry.setStyleSheet(_ENTRY_STYLE)
            l.addWidget(entry)
            b = QPushButton("浏览")
            b.setStyleSheet(_BROWSE_STYLE)
            if browse == "dir":
                b.clicked.connect(lambda checked=False, e=entry: e.setText(
                    QFileDialog.getExistingDirectory(self, "选择目录",
                        e.text() if os.path.isdir(e.text()) else self.base_path) or e.text()))
            else:
                b.clicked.connect(lambda checked=False, e=entry, f=filter_str: e.setText(
                    QFileDialog.getOpenFileName(self, "选择文件",
                        os.path.dirname(e.text()) if os.path.isfile(e.text()) else self.base_path, f)[0] or e.text()))
            l.addWidget(b)
            form_layout.addLayout(l)
            return entry

        self.vars_entry = add_row("1. vars（输入 _vars.xlsx）：", "file", "*.xlsx")
        # v12.10.121：「输出 codelist」不再展示 —— 自动按 Config 派生，保留为**隐藏字段**
        # （仍由 _fill_from_config 填充）供 runner 的 out_path 与「打开 define 目录」使用。
        self.codelist_entry = QLineEdit()
        self.xpt_dir_entry = add_row("2. xpt_dir：", "dir")
        self.sysmeta_entry = add_row("3. sysmeta（CT/映射目录）：", "dir")

        # ---------- 高级参数（折叠） ----------
        # v12.10.121：标题列出具体参数名（与 SDTM-Gen 高级参数一致）
        self.adv = _CollapseSection("高级参数（lng / debug / CT 文件）")

        def _adv_combo_row(label_text, options, default):
            row = QHBoxLayout()
            lbl = QLabel(label_text)
            lbl.setStyleSheet("border: none; color: #606266; min-width: 150px;")
            row.addWidget(lbl)
            combo = _NoWheelComboBox()
            combo.setStyleSheet(_COMBO_STYLE)
            combo.addItems(options)
            if default in options:
                combo.setCurrentIndex(options.index(default))
            row.addWidget(combo, 1)
            self.adv.addRow(row)
            return combo

        def _adv_text_row(label_text, placeholder="", browse=None, filter_str="*.xlsx"):
            row = QHBoxLayout()
            lbl = QLabel(label_text)
            lbl.setStyleSheet("border: none; color: #606266; min-width: 150px;")
            row.addWidget(lbl)
            entry = QLineEdit()
            entry.setStyleSheet(_ENTRY_STYLE)
            entry.setPlaceholderText(placeholder)
            row.addWidget(entry, 1)
            if browse:
                b = QPushButton("浏览")
                b.setStyleSheet(_BROWSE_STYLE)
                if browse == "dir":
                    b.clicked.connect(lambda checked=False, e=entry: e.setText(
                        QFileDialog.getExistingDirectory(self, "选择目录",
                            e.text() if os.path.isdir(e.text()) else self.base_path) or e.text()))
                else:
                    b.clicked.connect(lambda checked=False, e=entry, f=filter_str: e.setText(
                        QFileDialog.getOpenFileName(self, "选择文件",
                            os.path.dirname(e.text()) if os.path.isfile(e.text()) else self.base_path, f)[0] or e.text()))
                row.addWidget(b)
            self.adv.addRow(row)
            return entry

        self.lng_combo = _adv_combo_row("lng（语言）：", _LNG_OPTIONS, "cn")
        self.debug_combo = _adv_combo_row("debug（不写输出）：", _BOOL_OPTIONS, "False")
        self.igver_entry = _adv_text_row("igver：", "留空 → 自动从 Define 读")
        self.sdtmctve_entry = _adv_text_row("sdtmctve：", "留空 → 自动（YYYY-MM-DD）")
        self.adamctve_entry = _adv_text_row("adamctve：", "留空 → 自动（YYYY-MM-DD）")
        self.ct_entry = _adv_text_row("CT 文件：", "留空 → 按 sysmeta 自动定位", browse="file", filter_str="*.xls*")
        self.template_entry = _adv_text_row("template：", "留空 → 自动定位 PDS 模板", browse="file")
        self.sysdoc_entry = _adv_text_row("sysdoc：", "留空 → projects/utility/documentation", browse="dir")
        self.rameta_entry = _adv_text_row("rameta_dir：", "留空 → ra_root/utility/metadata", browse="dir")

        form_layout.addWidget(self.adv)

        # ---------- 运行按钮区 ----------
        bl = QHBoxLayout()
        self.run_btn = QPushButton("▶ 生成 spec_codelist")
        self.run_btn.setStyleSheet(
            "background-color: #4A6FA5; color: white; border: none; padding: 8px 20px; border-radius: 4px; font-weight: bold;")
        self.run_btn.clicked.connect(self.execute_run)
        bl.addWidget(self.run_btn)

        self.cancel_btn = QPushButton("🟥 中止")
        self.cancel_btn.setStyleSheet(
            "background-color: #FEF0F0; color: #F56C6C; border: 1px solid #FBC4C4; padding: 8px 20px; border-radius: 4px; font-weight: bold;")
        self.cancel_btn.setVisible(False)
        self.cancel_btn.clicked.connect(self.cancel_run)
        bl.addWidget(self.cancel_btn)

        open_btn = QPushButton("📂 打开 define 目录")
        open_btn.setStyleSheet(
            "background-color: #3F9A6E; color: white; border: none; padding: 8px 20px; border-radius: 4px; font-weight: bold;")
        open_btn.clicked.connect(self._open_define_dir)
        bl.addWidget(open_btn)
        bl.addStretch()
        form_layout.addLayout(bl)
        form_layout.addStretch()

    # ------------------------- 自动填写 -------------------------
    def _fill_paths(self):
        if not self.base_path or not os.path.isdir(self.base_path):
            for e in (self.vars_entry, self.codelist_entry, self.xpt_dir_entry, self.sysmeta_entry):
                e.clear()
            return
        d = _derive_paths(self.base_path, self.libname_combo.currentText().strip() or "sdtm")
        self.vars_entry.setText(d["vars_path"])
        self.codelist_entry.setText(d["codelist_path"])
        self.xpt_dir_entry.setText(d["xpt_dir"])
        self.sysmeta_entry.setText(d["sysmeta"])

    def _on_libname_changed(self, *args):
        self._fill_paths()

    def _open_define_dir(self):
        d = ""
        cl = self.codelist_entry.text().strip()
        if cl:
            d = os.path.dirname(cl)
        if d and os.path.isdir(d):
            try:
                os.startfile(d)
            except Exception:
                pass
        else:
            self._show_msg("提示", f"define 目录尚不存在或未填写：\n{d or '(未知)'}", "info")

    # ------------------------- 数据类型总开关 -------------------------
    def set_data_type(self, data_type):
        """v12.10.131：由 M5Widget 顶部「数据类型」总开关驱动，设置 libname 并重填派生路径。
        canonical: "sdtm" / "adam"（大小写不敏感）。"""
        target = "adam" if (data_type or "").strip().lower() == "adam" else "sdtm"
        if self.libname_combo.currentText() != target:
            self.libname_combo.setCurrentText(target)   # 触发 _on_libname_changed → _fill_paths
        else:
            self._fill_paths()                           # 值未变不发信号，显式重填一次

    # ------------------------- 路径推送 -------------------------
    def update_paths(self, base_path):
        self.base_path = base_path
        self._fill_paths()

    # ------------------------- 等待提示 -------------------------
    def set_wait_hint(self, show):
        if show:
            self.scan_lbl.setText("⏳ 等待填写完整路径...")
            self.scan_lbl.setStyleSheet(scan_status_lbl_style())
        else:
            self.scan_lbl.setText("")

    # ------------------------- 快捷键钩子 -------------------------
    def action_refresh(self):
        self._fill_paths()

    def action_run(self):
        btn = getattr(self, "run_btn", None)
        if btn is not None and btn.isEnabled() and btn.isVisible():
            btn.click()

    # ------------------------- 参数收集 -------------------------
    def _collect_cfg_kwargs(self):
        def _opt(t):
            t = (t or "").strip()
            return t

        return {
            "ra_root": self.base_path,
            "libname": self.libname_combo.currentText().strip() or "sdtm",
            "lng": self.lng_combo.currentText().strip() or "cn",
            "igver": _opt(self.igver_entry.text()),
            "sdtmctve": _opt(self.sdtmctve_entry.text()),
            "adamctve": _opt(self.adamctve_entry.text()),
            "debug": (self.debug_combo.currentText().strip() == "True"),
            "xpt_dir_override": _opt(self.xpt_dir_entry.text()),
            "sysmeta_override": _opt(self.sysmeta_entry.text()),
            "sysdoc_override": _opt(self.sysdoc_entry.text()),
            "rameta_dir_override": _opt(self.rameta_entry.text()),
        }

    def _collect_post_overrides(self):
        return {
            "vars_path": self.vars_entry.text().strip(),
            "ct_path": self.ct_entry.text().strip(),
            "template_path": self.template_entry.text().strip(),
        }

    def _collect_run_kwargs(self):
        return {
            "out_path": self.codelist_entry.text().strip() or None,
            "verbose": True,
        }

    # ------------------------- 执行 / 取消 / 回调 -------------------------
    def execute_run(self):
        if not self.base_path or not os.path.isdir(self.base_path):
            self._show_msg("错误", "项目路径（四级目录）无效，请先在顶部选择完整 csr 路径！", "error")
            return

        vars_path = self.vars_entry.text().strip()
        if not vars_path:
            self._show_msg("错误", "vars（输入 _vars.xlsx）路径不能为空，请先运行步骤 02 或填写！", "error")
            return
        if not os.path.isfile(vars_path):
            self._show_msg("错误",
                           f"vars 文件不存在：\n{vars_path}\n\n请先运行「02 PDS for vars」生成它。", "error")
            return

        # 输出覆盖检测（与 01 同款）
        codelist_out = self.codelist_entry.text().strip()
        if codelist_out and os.path.isfile(codelist_out):
            confirm = self._show_msg(
                "覆盖警告",
                f"检测到目标输出已存在：\n\n{os.path.basename(codelist_out)}\n\n"
                "本次生成将直接覆盖原有文件，是否确认继续？",
                "question")
            if not confirm:
                self.sig_log.emit("<span style='color:#909399;'>已取消生成任务（用户取消覆盖）。</span>")
                return

        cfg_kwargs = self._collect_cfg_kwargs()
        post_overrides = self._collect_post_overrides()
        run_kwargs = self._collect_run_kwargs()

        self.sig_run_started.emit()

        self.run_btn.hide()
        self.cancel_btn.show()
        self.prog.setRange(0, 0)
        self.prog.setVisible(True)
        self.prog.setValue(0)

        self.sig_log.emit(
            f"<span style='color:#409EFF;'>> 启动 PDS for Codelist（crt_codelist，libname={cfg_kwargs['libname']}）...</span>")
        self.sig_status.emit("⏳ 正在执行中...", "#409EFF")

        self.runner = PdsForCodelistRunner(cfg_kwargs, post_overrides, run_kwargs)
        self.runner.log_signal.connect(self._on_log)
        self.runner.progress_signal.connect(self._on_progress)
        self.runner.finished_signal.connect(self._on_finished)
        self.runner.start()

    def _on_log(self, text):
        color = "#606266"
        if "ERROR" in text or "❌" in text:
            color = "#F56C6C"
        elif "WARNING" in text or "⚠️" in text:
            color = "#E6A23C"
        elif "✅" in text:
            color = "#67C23A"
        self.sig_log.emit(f"<span style='color:{color};'>{text}</span>")

    def _on_progress(self, val, msg):
        self.sig_log.emit(f"<b>{html.escape(str(msg))}</b>")

    def _on_finished(self, success, msg):
        if hasattr(self, "runner") and self.runner.is_cancelled:
            return
        self.cancel_btn.hide()
        self.run_btn.show()
        self.prog.setVisible(False)

        if success:
            self.sig_status.emit("✅ spec_codelist 生成成功！", "#67C23A")
            self.sig_step_update.emit("03 PDS for Codelist ✅")
            if msg:
                self.sig_log.emit(f"<span style='color:#67C23A; font-weight:bold;'>{html.escape(msg)}</span>")
        else:
            self.sig_status.emit("❌ 生成失败！", "#F56C6C")
            self.sig_step_update.emit("03 PDS for Codelist ❌")
            self._show_msg("错误", msg, "error")
        self.sig_run_finished.emit()

    def cancel_run(self):
        if hasattr(self, "runner") and self.runner.isRunning():
            self.runner.cancel()
            self.runner.wait(5000)
        self.cancel_btn.hide()
        self.run_btn.show()
        self.prog.setVisible(False)

        self.sig_status.emit("🛑 已中止", "#F56C6C")
        self.sig_step_update.emit("03 PDS for Codelist 🟥")
        self.sig_log.emit("<span style='color:#F56C6C; font-weight:bold;'>[已中止] 🛑 用户手动取消了执行。</span>")
        self.sig_run_finished.emit()
