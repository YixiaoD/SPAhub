# -*- coding: utf-8 -*-
"""
modules/sdtm_pdt.py
===================
SDTM 模块 - 01 PDT Gen（v12.10.34 起：原 02，顺移到 01；Import EDC Definition 已转移到 aCRF-03）

完全复用 TFLs / 01 PDT Gen 的 PDTRunner + PDTForm，仅做以下差异：
  - 步骤名"01 PDT Gen"（不带 SDTM 前缀）
  - 顶部描述："生成数据集（SDTM/ADaM）专用 PDT 文件"
  - 调用 25_generate_pdt_call.sas，但**toc 默认值是字符串 "NULL"**：
      * UI 与 tfls 完全一致（TOC XLSX 输入栏 + 浏览按钮）
      * update_paths 时若用户尚未填入，自动塞 "NULL" 占位
      * 用户保留覆盖能力：可手动改成具体 toc 文件名 / 用浏览按钮选具体 .xlsx
      * 提交 SAS 时把 %gen_pdt(toc=%str(...)) 替换成用户当前值（NULL 或文件名）
  - 复用父类的 _post_process_pdt_formulas（win32com 自动公式重算 + openpyxl 兜底注入）
  - 严格区分 ERROR / WARNING（标红 / 标黄不混用）

v12.10.105：修复切换项目后 toc_entry 沿用上个项目残留 TOC 文件名的问题。
  - 旧逻辑 `if not cur: setText("NULL")` 只在为空时填默认，导致用户在 A 项目手输/浏览
    选过的 TOC 文件名在切到 B 项目后被保留（与 acrf_import_edcdef v12.10.104 同类 bug）。
  - 改为：切换项目（base 变）→ 一律重置为 "NULL"；同项目刷新 → 维持原「为空填 NULL、
    有值保留」行为。
"""
import os
import re
import time

from PySide6.QtWidgets import QLabel, QFileDialog, QPushButton
from PySide6.QtCore import Qt

from modules.tfls_pdt import PDTForm, PDTRunner
from modules.sdtm_common import (classify_log_severity, extract_issue_lines_html,
                                 severity_finished_html,
                                 detect_macro_abort, extract_abort_context_html)
from ui_utils import show_dialog


class SdtmPdtForm(PDTForm):
    """
    SDTM / 01 PDT Gen 表单。

    与 PDTForm 的差异：
      - update_paths(base_path) 单参数版：自动定位 PDT.xlsx；toc_entry 若空则填 "NULL"
      - execute_pdt 覆写：把 SAS 脚本里的 toc 参数替换为用户输入值（不强制锁死）
      - 顶部描述文案改为 SDTM/ADaM 语义
      - sig_step_update / 状态文案改为 "01 PDT Gen ✅/⚠️/❌/🟥"
      - 完成回调严格按 ERROR/WARNING 分级着色
    """

    def __init__(self):
        super().__init__()
        # 重设步骤名（与 stepper 中 step 名 "PDT Gen" 一致）
        self._step_name = "PDT Gen"
        # v12.10.105: 记录上一次 update_paths 的 base_path（normcase 归一化），
        # 用于判断是否切换了项目 → 切项目时把 toc_entry 重置为默认 "NULL"，
        # 不沿用上个项目残留的 TOC 文件名（与 acrf_import_edcdef v12.10.104 同类修复）。
        self._toc_last_base = None
        # 顶部描述改为 SDTM 语义
        self._tweak_desc_label()
        # 把"浏览"按钮的起始目录从 base_path（csr 根）改成 utility/documentation/03_statistics
        # （用户要求：toc=NULL 是默认值，但用户点浏览选 toc 文件时应直接定位到 TOC 实际所在目录）
        self._hijack_toc_browse_btn()
        # 接管 toc 浏览按钮的 click → 起点定位 utility/documentation/03_statistics
        # （父类 PDTForm._setup_ui 把"浏览"按钮 connect 了一个起点为 base_path 的 lambda；
        #  我们 disconnect 旧 lambda 后 connect 自己的 slot，让对话框默认进入 03_statistics）
        self._rebind_toc_browse_button()

    def _rebind_toc_browse_button(self):
        """把 PDTForm 中"浏览"按钮的 click 从父类 lambda 切到 _on_browse_toc_sdtm。"""
        for btn in self.findChildren(QPushButton):
            if btn.text() == "浏览":
                try:
                    btn.clicked.disconnect()
                except Exception:
                    pass
                btn.clicked.connect(self._on_browse_toc_sdtm)
                break

    def _on_browse_toc_sdtm(self):
        """
        TOC 浏览按钮：起点优先逻辑（与父类不同）：
          1. 当前 toc_entry 为有效文件路径（且非 NULL）→ 起点 = 该文件父目录
          2. base_path 下存在 utility/documentation/03_statistics → 起点 = 该目录
          3. base_path 下存在 utility/documentation → 起点 = 该目录
          4. 兜底 = self.base_path

        让用户的常用场景（SDTM/ADaM 模式 toc=NULL，需要切到 TFLs 模式时浏览选 TOC.xlsx）
        默认就跳到 03_statistics，不必逐级点开。
        """
        cur = (self.toc_entry.text() or "").strip()
        if cur and cur.upper() != "NULL" and os.path.isfile(cur):
            start_dir = os.path.dirname(cur)
        elif self.base_path:
            doc_03stat = os.path.join(self.base_path, "utility", "documentation", "03_statistics")
            doc_root = os.path.join(self.base_path, "utility", "documentation")
            if os.path.isdir(doc_03stat):
                start_dir = doc_03stat
            elif os.path.isdir(doc_root):
                start_dir = doc_root
            else:
                start_dir = self.base_path
        else:
            start_dir = ""
        path, _ = QFileDialog.getOpenFileName(self, "选择 TOC.xlsx", start_dir, "*.xlsx")
        if path:
            self.toc_entry.setText(path)

    def _tweak_desc_label(self):
        """把父类的 "基于 TOC.xlsx，在 utility\\documentation 下生成最新版 PDT。" 替换。"""
        try:
            for child in self.findChildren(QLabel):
                if "基于 TOC.xlsx" in child.text() or "TOC.xlsx" in child.text():
                    child.setText("生成数据集（SDTM/ADaM）专用 PDT 文件。")
                    break
        except Exception:
            pass

    def _hijack_toc_browse_btn(self):
        """把父类"浏览"按钮的 clicked 连接改为：起始目录 = utility/documentation/03_statistics

        父类 PDTForm._setup_ui 里 browse_btn 是局部变量没保存到 self；这里用 findChildren
        定位文本为"浏览"且与 toc_entry 同父布局的 QPushButton，先 disconnect 旧 lambda 再
        重连新 lambda。
        """
        from PySide6.QtWidgets import QPushButton, QFileDialog
        try:
            for btn in self.findChildren(QPushButton):
                if btn.text() == "浏览":
                    # disconnect 父类的旧 lambda；用 try 容错（重复 disconnect 不抛）
                    try:
                        btn.clicked.disconnect()
                    except Exception:
                        pass

                    def _on_browse_toc():
                        # 起始目录优先：toc_entry 当前是有效文件 → 其所在目录；
                        # 否则 base_path/utility/documentation/03_statistics（用户要求）；
                        # 兜底 base_path。
                        cur = self.toc_entry.text().strip()
                        if cur and os.path.isfile(cur):
                            start_dir = os.path.dirname(cur)
                        else:
                            stat_dir = os.path.join(self.base_path or "",
                                                    "utility", "documentation", "03_statistics")
                            start_dir = stat_dir if os.path.isdir(stat_dir) else (self.base_path or "")
                        path, _ = QFileDialog.getOpenFileName(
                            self, "选择 TOC", start_dir, "*.xlsx"
                        )
                        if path:
                            self.toc_entry.setText(path)

                    btn.clicked.connect(_on_browse_toc)
                    break
        except Exception:
            pass

    # ------------------------- 路径推送（覆写） -------------------------
    def update_paths(self, base_path):
        """
        与父类 update_paths(base_path, toc_path, pdt_path) 不同：
          - 入参只有 base_path
          - PDT 路径自动从 utility/documentation 下扫"以 PDT.xlsx 结尾"的文件，取 mtime 最新
          - toc_entry 默认填 "NULL"（用户可改成具体 toc 文件名或用浏览按钮选）
        """
        self.base_path = base_path or ""
        self.toc_path = ""

        # 自动定位 PDT 文件
        doc_dir = os.path.join(self.base_path, "utility", "documentation")
        try:
            pdt_files = [f for f in os.listdir(doc_dir)
                         if f.endswith("PDT.xlsx") and not f.startswith("~")] if os.path.isdir(doc_dir) else []
        except Exception:
            pdt_files = []
        if pdt_files:
            pdt_files.sort(key=lambda f: os.path.getmtime(os.path.join(doc_dir, f)), reverse=True)
            self.pdt_path = os.path.join(doc_dir, pdt_files[0])
        else:
            self.pdt_path = os.path.join(doc_dir, "PDT.xlsx")

        # toc_entry 默认填 "NULL"
        # v12.10.105: 区分「切换项目」与「同项目刷新」，修复切项目后沿用旧项目 TOC 文件名的问题：
        #   · 切换项目（base 变）→ 一律重置为默认 "NULL"，不沿用上个项目残留的 TOC 文件名。
        #   · 同项目刷新且当前为空 → 填默认 "NULL"。
        #   · 同项目刷新且已有值（用户手输 / 浏览选过 / 之前的 NULL）→ 保留不动。
        base_norm = os.path.normcase(os.path.normpath(self.base_path)) if self.base_path else ""
        base_changed = (base_norm != self._toc_last_base)
        self._toc_last_base = base_norm

        cur = self.toc_entry.text().strip()
        if base_changed or not cur:
            self.toc_entry.setText("NULL")

        self.edit_btn.setVisible(os.path.isfile(self.pdt_path))

    # ------------------------- 执行（覆写） -------------------------
    def execute_pdt(self):
        """
        覆写父类 execute_pdt：
          - 取用户输入的 toc 值（默认 "NULL"）
          - 若不是 "NULL"，则要求文件存在（保留父类的文件存在校验）
          - 改写 SAS 脚本：把 %gen_pdt(toc=%str(...)) / %generate_pdt(toc=%str(...)) 中的 toc
            替换为用户当前值
        """
        toc_input = self.toc_entry.text().strip()
        if not toc_input:
            self._show_msg(
                "提示",
                "TOC XLSX 不能为空。SDTM/ADaM-only 模式请填 NULL；如需含 TFLs 请选具体 TOC 文件。",
                "warning",
            )
            return

        # 非 NULL 时强校验文件存在（与父类对齐）
        if toc_input.upper() != "NULL":
            if not os.path.exists(toc_input):
                self._show_msg("错误", f"TOC 文件不存在：\n{toc_input}", "error")
                return

        sas_script = os.path.join(self.base_path, "utility", "tools", "25_generate_pdt_call.sas")
        if not os.path.exists(sas_script):
            self._show_msg("错误", "找不到 SAS 脚本！", "error")
            return

        # 注入 toc 值：NULL 时直接传 NULL；文件名时传 basename（与父类策略一致）
        if toc_input.upper() == "NULL":
            new_toc_repr = "NULL"
        else:
            new_toc_repr = os.path.basename(toc_input)

        try:
            with open(sas_script, "r", encoding="utf-8") as f:
                content = f.read()
            new_content = re.sub(
                r'(?i)%(gen_pdt|generate_pdt)\s*\(\s*toc\s*=\s*%str\([^)]*\)\s*\)\s*;?',
                rf'%\1(toc=%str({new_toc_repr}));',
                content,
            )
            with open(sas_script, "w", encoding="utf-8") as f:
                f.write(new_content)
        except PermissionError:
            self._show_msg("权限拒绝", "文件被占用，请关闭关联程序后重试！", "error")
            return

        # 触发 sig_run_started（清日志 + 启动计时）
        self.sig_run_started.emit()
        self._run_start_time = time.time() - 2.0

        self.run_btn.hide()
        self.cancel_btn.show()
        self.progress_bar.setVisible(True)
        self.edit_btn.setVisible(False)

        self.sig_log.emit(
            f'<span style="color:#409EFF;">> 正在向 SAS 服务器提交任务（toc={new_toc_repr}）…</span>'
        )
        self.sig_status.emit("⏳ 正在执行中...", "#409EFF")

        self.thread = PDTRunner(sas_script)
        self.thread.log_signal.connect(
            lambda msg: self.sig_log.emit(f'<span style="color:#F56C6C; font-weight:bold;">{msg}</span>'))
        self.thread.finished_signal.connect(self.on_execute_finished)
        self.thread.start()

    # ------------------------- 完成回调（严格区分 ERROR/WARNING） -------------------------
    def on_execute_finished(self, has_issue, summary, log_text, source_label):
        """
        与父类逻辑一致，但：
          - 整行汇总按 ERROR / WARNING 分级着色（不混用红色）
          - sig_step_update 文案改为 "01 PDT Gen ..."
          - 仍调用父类的 _post_process_pdt_formulas（win32com / openpyxl 公式重算）
        """
        if hasattr(self, 'thread') and self.thread.is_cancelled:
            return

        self.cancel_btn.hide()
        self.run_btn.show()
        self.progress_bar.setVisible(False)

        # 抽取错误行 → HTML（红/黄分色）
        sev = classify_log_severity(log_text)
        severity = sev["severity"]
        trigger_archive = False
        if log_text:
            for line in log_text.split('\n'):
                if "already exists" in line.lower():
                    trigger_archive = True
                    break

        # v12.10.7：%abort 场景特殊处理 — 倒扫前 15 行 NOTE/ERROR/WARNING 上下文
        is_abort = detect_macro_abort(log_text)
        if is_abort:
            self.sig_log.emit(
                "<span style='color:#F56C6C; font-weight:bold;'>❌ SAS 宏触发 %ABORT —— 真实根因见下方上下文：</span>"
            )
            self.sig_log.emit(extract_abort_context_html(log_text, n_before=15))
        elif severity in ("error", "warning"):
            self.sig_log.emit(extract_issue_lines_html(log_text))
        else:
            self.sig_log.emit('<span style="color:#67C23A;">> 运行完毕，日志干净，无 ERROR / WARNING。</span>')

        # v12.10.7：始终在末尾显示完整 .log 路径
        if source_label:
            self.sig_log.emit(
                f"<span style='color:#909399;'>&nbsp;&nbsp;📄 完整日志：{source_label}</span>"
            )

        if trigger_archive:
            archive_dir = os.path.join(self.base_path, "utility", "documentation", "99_archive")
            self.sig_show_archive.emit(True, archive_dir)

        # 检查 PDT 是否真的写入
        pdt_success = False
        if os.path.isfile(self.pdt_path):
            for _ in range(3):
                file_mtime = os.path.getmtime(self.pdt_path)
                file_size = os.path.getsize(self.pdt_path)
                if file_mtime >= getattr(self, '_run_start_time', 0) - 2.0 and file_size > 0:
                    pdt_success = True
                    break
                time.sleep(0.5)

        # 复用父类的 win32com / openpyxl 公式后处理
        if pdt_success:
            try:
                self._post_process_pdt_formulas(self.pdt_path)
            except Exception as e:
                self.sig_log.emit(
                    f'<span style="color:#F56C6C; font-weight:bold;">> PDT 后处理注入值失败: {str(e)}</span>'
                )

        self.edit_btn.setVisible(os.path.isfile(self.pdt_path))

        # 最终 step / status 文案
        if not pdt_success:
            self.sig_step_update.emit("01 PDT Gen ❌")
            self.sig_status.emit("❌ PDT 生成失败：未检测到有效的文件更新。", "#F56C6C")
        elif severity == "error":
            self.sig_step_update.emit("01 PDT Gen ❌")
            self.sig_status.emit("❌ PDT 已生成，但日志含 ERROR，请严格审阅！", "#F56C6C")
        elif severity == "warning":
            self.sig_step_update.emit("01 PDT Gen ⚠️")
            self.sig_status.emit("⚠️ PDT 已生成，但日志含 WARNING（无 ERROR）。", "#E6A23C")
        elif trigger_archive:
            self.sig_step_update.emit("01 PDT Gen ⚠️")
            self.sig_status.emit("⚠️ PDT 生成触发了历史归档保护。", "#E6A23C")
        else:
            self.sig_step_update.emit("01 PDT Gen ✅")
            self.sig_status.emit("✅ PDT 成功生成（SDTM/ADaM），日志完全干净！", "#67C23A")

    # ------------------------- 中止 step 文案 -------------------------
    def cancel_pdt(self):
        if hasattr(self, 'thread') and self.thread.isRunning():
            self.thread.is_cancelled = True
        self.cancel_btn.hide()
        self.run_btn.show()
        self.progress_bar.setVisible(False)

        self.sig_step_update.emit("01 PDT Gen 🟥")
        self.sig_log.emit("<span style='color:#F56C6C; font-weight:bold;'>[已中止] 🛑 用户手动取消了执行。</span>")
        self.sig_status.emit("🛑 已中止", "#F56C6C")
