# -*- coding: utf-8 -*-
"""
modules/tfls_init_pgm_gitlab.py
================================
03 Initial PGM 模块的 GitLab 推送子功能（仅 TFLs 模式启用；ADaM 模式下不暴露）。

变更记录：
  v12.10.31  首版：树形对话框 + Stage 1/2 双线程编排 + GitStashPanel
  v12.10.32  修复 find_repo_root 在网络盘 (SMB Z: 盘) 上偶现的
             "os.path.exists(.git) 返回 False" 问题：先用
             `git rev-parse --show-toplevel` 让 git CLI 自己定位，
             失败再 fallback 到手工搜索；同时给失败诊断附上所有
             尝试过的路径。
  v12.10.33  增加 git "dubious ownership" 检测与一键信任流程：
             - check_repo_access() 区分 ok / dubious_ownership /
               not_a_repo / other 四种 git 访问状态；
             - SafeDirectoryDialog 让用户一键执行
               `git config --global --add safe.directory <...>`；
             - 区分"无法识别分支"和"detached HEAD"两种情况，给
               不同提示（之前一律说成 detached HEAD，误导用户）。
  v12.10.34  推送对话框增加"🔄 仅 Pull 更新"按钮：
             - PullOnlyRunner 用 git pull --ff-only 安全更新本地：
               只在能 fast-forward 时拉取，diverged / dirty tree 时
               git 自己拒绝（本地零变化，不留 MERGE_HEAD）；
             - 按 reason 分支给针对性引导（diverged → 走 push 流程，
               dirty_tree → 先 commit/stash，network → 检查 VPN）；
             - 成功且有 ff 更新时弹"继续推送 →"快捷入口。
  v12.10.35  凭据相关防护 + 身份展示：
             - classify_git_error() 分类 auth / network / other 错误；
             - CredentialErrorDialog 三按钮快捷修复（打开凭据管理器 /
               打开 GitLab PAT 页 / 测试连接）；
             - GitlabPushExecuteRunner 加 push 前 ls-remote 预检 —
               token 过期时**在生成 commit 前**拦截，避免留 orphan commit；
             - SasFilesTreeDialog 顶部展示 commit author + GCM push 用户，
               并在两者不一致时给 ⚠️ 提示（合规追溯需要）；
             - Stage 1 / Stage 2 / PullOnly 失败时 status_dict 统一带
               error_type 字段，三个 done 回调据此路由到 CredentialErrorDialog。
  v12.10.59  修复"git 仅当前用户安装 → 部分机器/账号报『未找到 git 可执行文件』"：
             - 新增 _resolve_git_exe()：不再单纯依赖 PATH，按
               SPAHUB_GIT_EXE 环境变量覆盖 → shutil.which → Git for Windows
               标准安装目录（系统级 C:\\Program Files\\Git 与用户级
               %LOCALAPPDATA%\\Programs\\Git 都覆盖）逐一探测绝对路径，命中即缓存。
             - run_git() 与 get_push_credential_username() 两处裸命令 "git"
               全部换成解析出的绝对路径（Windows 下对裸命令名的查找用的是
               调用进程自身 PATH，往 env['PATH'] 注入无效，故必须传绝对路径）。
             - 真探测不到时 run_git 的 FileNotFoundError 提示补充"已尝试标准
               安装目录"，并提示可设 SPAHUB_GIT_EXE 指定路径。
  v12.10.60  修复"点击🚀推送至 GitLab 后主界面卡死 ≥5s"：
             - 病因：start_gitlab_push 在主线程同步串跑 6~7 次 git 子进程
               （find_repo_root / check_repo_access / git_current_branch /
               scan_pushable_sas_files / get_commit_identity）外加
               get_push_credential_username 的 `git credential fill`
               （timeout 8s）。网络盘(SMB Z:)上每次 git spawn 都慢，叠加即
               卡死主线程、窗口假死。
             - 新增 GitlabPushPrepareRunner(QThread)：把上述全部"非交互式"
               git 采集挪到子线程，完成后 emit 结果 dict；所有对话框/弹窗仍
               在主线程，由 gitlab_push_after_prepare() 接管。
             - start_gitlab_push 改为：秒级 base_path 校验 → 进忙碌态 → 起
               准备子线程即返回；点击后窗口立即可响应，按钮显示"⏳ 推送中..."。
             - 采集期出错 / dubious_ownership / detached 等分支全部在主线程
               处理；dubious_ownership 信任后重新起子线程采集（不在主线程跑
               git）。需配合 tfls_init_pgm.py 同版（新增 _on_gitlab_prepare_done
               槽 + _gitlab_prepare_runner 状态 + import）。

职责：
  - 把 <base>/06_programs/、<base>/09_validation/、<repo_root>/utility/macros/
    三个目录下的 *.sas 文件，按用户树形勾选 + commit message → push 到对应 GitLab。
  - 仓库 URL 不需要用户填，从 <repo_root>/.git/config 的 [remote "origin"] 段自动读。
  - 先做 add+commit，再 fetch+检测领先 → 如远端领先，弹窗让用户一键 Pull；
    pull 冲突自动 abort 回滚，本地的 commit 保留不丢；push 失败时同样保留 commit。
  - 推送过程独立于 91/61 SAS 任务线程，互斥但不阻塞。

================================================================================
SPAhub 项目目录结构 memory（参考 HRS9821_102 仓库的真实骨架）：
  <repo_root>/                        ← git 仓库根（含 .git/、.gitignore、README）
  ├── .git/                           Git 仓库元数据
  ├── csr_01/                         ← <base> (SPAhub 内部 base_path)
  │   ├── 00_source_data/             EDC 原始数据
  │   ├── 01_sdtm/  02_adam/          SDTM / ADaM 数据集
  │   ├── 03_reports/                 TFLs 报表输出
  │   ├── 04_crt/  05_pkpd/
  │   ├── 06_programs/                ★ 推送目标 1：SAS 派生程序
  │   │   ├── 061_data/               (SDTM 派生程序)
  │   │   ├── 062_safety/             (ADaM safety)
  │   │   ├── 063_efficacy/           (ADaM efficacy)
  │   │   ├── 064_pkpd/               (ADaM PK/PD)
  │   │   └── 065_stats/              (ADaM stats)
  │   ├── 07_logs/                    运行日志
  │   ├── 08_formats/
  │   └── 09_validation/              ★ 推送目标 2：QC 验证程序
  ├── utility/                        ★ 与 csr_NN 平级（不在 base 下！）
  │   ├── tools/                      跑批脚本
  │   ├── macros/                     ★ 推送目标 3：SAS 宏库
  │   ├── metadata/
  │   └── documentation/
  ├── .gitignore
  └── README

关键点：
  - utility/ 与 csr_NN/ 是 **兄弟** 目录，不是 csr_NN/utility/（SPAhub 内部
    很多代码沿用 <base>/utility/... 的写法是基于另一种结构；本模块改为
    向上找 .git 定位仓库根，然后 <repo_root>/utility/macros/ 兼容两种布局）。
  - 这三个目录的 *.sas 不一定都 tracked，需要用 `git ls-files --others
    --exclude-standard` 同时拿"未被 .gitignore 忽略的 untracked"。

================================================================================
模块结构：
  ┌─ 工具函数（顶层）
  │  ├─ find_repo_root           向上找 .git
  │  ├─ parse_git_remote_url     解析 .git/config 的 origin url
  │  ├─ run_git                  同步执行 git，返回 (rc, stdout, stderr)
  │  ├─ git_current_branch
  │  ├─ git_status_porcelain     拿仓库脏度（status 元组列表）
  │  ├─ git_ahead_behind         fetch 后看本地与 origin/HEAD 的领先/落后数
  │  ├─ git_unpushed_log         git log origin/<br>..HEAD --oneline
  │  └─ scan_pushable_sas_files  扫描三目录 *.sas，与 git status 合并
  ├─ SasFilesTreeDialog          树形勾选 + commit msg 输入
  ├─ PullConfirmDialog           远端领先时的"是否自动 pull"弹窗
  ├─ OutOfScopeDirtyDialog       范围外脏文件的处理选项
  ├─ GitlabPushRunner (QThread)  整个 push 流程编排（fetch → add → commit → pull → push）
  └─ GitStashPanel (QFrame)      右侧 Tab 2 的暂存面板（推送失败/未推送 commit 状态展示）

外部入口（被 tfls_init_pgm.InitPgmForm 调用）：
  start_gitlab_push(parent_form, base_path, repo_root) → 弹对话框 → 启动 Runner
"""
import os
import re
import shutil
import subprocess
import time
from typing import List, Tuple, Optional

from PySide6.QtWidgets import (QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                               QLineEdit, QFrame, QDialog, QTreeWidget,
                               QTreeWidgetItem, QPlainTextEdit, QTextEdit,
                               QCheckBox, QMessageBox, QSizePolicy, QFileDialog,
                               QWidget, QProgressBar, QSpacerItem)
from PySide6.QtCore import Qt, QThread, Signal


# =============================================================================
# 工具函数：git 仓库定位 / 命令执行
# =============================================================================

def find_repo_root(start_path: str) -> str:
    """
    从 start_path 向上递归找包含 .git 目录的祖先；找到返回绝对路径，否则返回 ""。

    v12.10.32 修复（网络盘场景）：
      实测某些 SMB 共享盘上 `os.path.exists(...\\.git)` 会返回 False，即使该
      目录实际可见（可能与隐藏属性 / 列举权限 / SMB 元数据缓存有关）。
      因此先调 `git rev-parse --show-toplevel` 由 git CLI 自己定位仓库根 —
      这条路径在 git 内部已被各种姿势调优过，对 worktree / submodule /
      网络盘都更稳健。失败时再回退到手动向上搜索作为兜底。

    设计：
      - 接受 .git 是目录（普通仓库）或文件（worktree / submodule 引用）。
      - 手动搜索限定向上爬最多 10 层，避免在网络盘上无限上溯导致卡顿。
      - 所有 OS / git 调用都包了 try/except，最差情况只是返回 ""，不抛异常。
    """
    if not start_path:
        return ""
    if not os.path.isdir(start_path):
        # base_path 本身不存在（典型：网络盘断开 / typo），后续都无意义
        return ""
    cur = os.path.abspath(start_path)

    # === 方案 A：让 git CLI 自己定位（权威，绕过 SMB 上 exists 的怪异） ===
    try:
        rc, out, _ = run_git(cur, "rev-parse", "--show-toplevel", timeout=10)
        if rc == 0:
            top = out.strip()
            if top:
                # git 在 Windows 上返回 POSIX 斜杠（如 "Z:/projects/..."），
                # normpath 转回平台原生分隔符以便后续 os.path.join 一致
                return os.path.normpath(top)
    except Exception:
        # run_git 内部已 catch FileNotFoundError 等；这里再兜一层超防御性兜底
        pass

    # === 方案 B：手动向上搜索 .git（fallback） ===
    for _ in range(10):
        try:
            if os.path.exists(os.path.join(cur, ".git")):
                return cur
        except OSError:
            # 网络盘上偶发的 PermissionError / OSError 单层跳过，继续向上
            pass
        parent = os.path.dirname(cur)
        if parent == cur:  # 已到磁盘根
            return ""
        cur = parent
    return ""


def parse_git_remote_url(repo_root: str, remote_name: str = "origin") -> str:
    """
    解析 <repo_root>/.git/config 中 [remote "<remote_name>"] 段的 url。

    与 git config 命令的差异：
      - 我们手工读 .git/config（无需 git CLI）— 因为这个函数有时在 git
        CLI 尚未确认可用前被调用（如 UI 初始化校验远端 URL 是否存在）。
      - 仅做"行级"解析：节段头 [remote "xxx"] + 段内 url = ... 行；
        足够覆盖 99% 标准 config，不处理 include.path 等高级写法。
    """
    cfg_path = os.path.join(repo_root, ".git", "config")
    if not os.path.isfile(cfg_path):
        return ""
    try:
        with open(cfg_path, encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()
    except Exception:
        return ""

    target_section = f'[remote "{remote_name}"]'
    in_section = False
    for raw in lines:
        line = raw.strip()
        if not line or line.startswith("#") or line.startswith(";"):
            continue
        if line.startswith("[") and line.endswith("]"):
            in_section = (line == target_section)
            continue
        if in_section and "=" in line:
            k, _, v = line.partition("=")
            if k.strip().lower() == "url":
                return v.strip()
    return ""


_GIT_EXE_CACHE = None  # v12.10.59：_resolve_git_exe 的模块级缓存（首次解析后复用）


def _resolve_git_exe() -> str:
    """v12.10.59：定位 git 可执行文件的绝对路径，不再单纯依赖 PATH。

    背景：Git for Windows 选 "current user only" 安装时，只把 cmd 目录写进
    安装账号的用户级 PATH (HKCU\\Environment)；而 SPAhub 进程继承的是
    系统 PATH + 启动账号的用户 PATH 快照。于是换账号 / PATH 快照过旧时，
    裸命令 "git" 在 SPAhub 子进程里解析不到 → FileNotFoundError → 报
    "未找到 git 可执行文件"，即便手开 cmd 能正常跑 git。

    解析优先级（命中即缓存返回）：
      1. 环境变量 SPAHUB_GIT_EXE —— 个别机器路径特殊时无需改代码即可指定；
      2. shutil.which("git") —— 当前进程 PATH 能找到最好；
      3. Git for Windows 标准安装目录（系统级 + 用户级都覆盖）：
           <ProgramFiles>\\Git\\cmd\\git.exe       (系统级安装，HKLM)
           <ProgramW6432>\\Git\\cmd\\git.exe
           <ProgramFiles(x86)>\\Git\\cmd\\git.exe
           %LOCALAPPDATA%\\Programs\\Git\\cmd\\git.exe   (current user only 安装)
           …以及对应的 \\bin\\git.exe，外加 scoop 布局。
      4. 都没有 → 返回 ""（调用方据此给"请安装 Git for Windows"提示）。

    注意：Windows 下 subprocess 对**裸命令名**的查找用的是调用进程自身的
    PATH，往传给 subprocess 的 env['PATH'] 注入对定位 git **无效**，所以这里
    解析出绝对路径后由调用方塞进 cmd[0]，这是唯一可靠的修法。
    """
    global _GIT_EXE_CACHE
    if _GIT_EXE_CACHE:
        return _GIT_EXE_CACHE

    # 1) 环境变量显式覆盖（最高优先级）
    override = (os.environ.get("SPAHUB_GIT_EXE") or "").strip().strip('"')
    if override and os.path.isfile(override):
        _GIT_EXE_CACHE = override
        return override

    # 2) 当前 PATH
    p = shutil.which("git")
    if p and os.path.isfile(p):
        _GIT_EXE_CACHE = p
        return p

    # 3) Git for Windows 标准安装目录探测
    candidates: List[str] = []
    roots = []
    for key in ("ProgramFiles", "ProgramW6432", "ProgramFiles(x86)"):
        v = os.environ.get(key)
        if v:
            roots.append(v)
    # 兜底默认根（环境变量缺失时）
    roots += [r"C:\Program Files", r"C:\Program Files (x86)"]
    for root in roots:
        candidates.append(os.path.join(root, "Git", "cmd", "git.exe"))
        candidates.append(os.path.join(root, "Git", "bin", "git.exe"))
    # current user only 安装
    localapp = os.environ.get("LOCALAPPDATA", "")
    if localapp:
        candidates.append(os.path.join(localapp, "Programs", "Git", "cmd", "git.exe"))
        candidates.append(os.path.join(localapp, "Programs", "Git", "bin", "git.exe"))
    # scoop 布局
    userprofile = os.environ.get("USERPROFILE", "")
    if userprofile:
        candidates.append(os.path.join(userprofile, "scoop", "apps", "git", "current", "cmd", "git.exe"))

    seen = set()
    for c in candidates:
        if not c or c in seen:
            continue
        seen.add(c)
        if os.path.isfile(c):
            _GIT_EXE_CACHE = os.path.abspath(c)
            return _GIT_EXE_CACHE

    return ""  # 真没找到


def run_git(cwd: str, *args: str, timeout: int = 120, env_extra: dict = None) -> Tuple[int, str, str]:
    """
    同步执行 `git <args...>`，返回 (returncode, stdout, stderr) 三元组。

    设计要点：
      - 强制 stdout/stderr 文本模式 + utf-8 解码，errors='replace' 防中文路径乱码崩溃。
      - Windows 下隐藏控制台窗口（CREATE_NO_WINDOW），避免 push 时弹出黑框打扰用户。
      - timeout 默认 120s — push 可能慢（大文件 / 网络抖动），单次操作给足时长。
      - rc == 128 通常是"非 git 仓库"或"凭据 / 网络错误"，调用方据 stderr 判别。
    """
    # v12.10.59：用 _resolve_git_exe() 解析出的绝对路径，避免裸 "git" 在
    # current-user-only 安装 / PATH 快照过旧时解析失败。
    git_exe = _resolve_git_exe() or "git"
    cmd = [git_exe] + list(args)
    creationflags = 0
    if os.name == "nt":
        creationflags = 0x08000000  # CREATE_NO_WINDOW

    env = os.environ.copy()
    # 强制 LC_ALL=C.UTF-8 让 git 输出英文，便于稳定解析（不依赖中文 locale）
    env["LC_ALL"] = "C.UTF-8"
    env["LANG"] = "C.UTF-8"
    # GIT_TERMINAL_PROMPT=0：禁止 git 在凭据缺失时弹交互式终端，直接报错返回，
    # 避免 SPAhub 子进程卡死等用户输入。
    env["GIT_TERMINAL_PROMPT"] = "0"
    if env_extra:
        env.update(env_extra)

    try:
        p = subprocess.run(
            cmd, cwd=cwd or None, capture_output=True, text=True,
            encoding="utf-8", errors="replace",
            timeout=timeout, creationflags=creationflags, env=env,
        )
        return p.returncode, (p.stdout or ""), (p.stderr or "")
    except FileNotFoundError:
        # v12.10.59：_resolve_git_exe 已探测过标准安装目录仍找不到 → 真没装/路径特殊
        return 127, "", (
            "未找到 git 可执行文件。已尝试 PATH 与 Git for Windows 标准安装目录"
            "（系统级 C:\\Program Files\\Git、用户级 %LOCALAPPDATA%\\Programs\\Git）。"
            "请安装 Git for Windows，或设环境变量 SPAHUB_GIT_EXE 指向 git.exe 的完整路径。"
        )
    except subprocess.TimeoutExpired:
        return 124, "", f"git 命令超时（>{timeout}s）：{' '.join(cmd)}"
    except Exception as e:
        return 1, "", f"git 命令异常：{e}"


def git_current_branch(repo_root: str) -> str:
    """返回当前 checkout 的分支名；HEAD 分离时返回 "HEAD"。"""
    rc, out, _ = run_git(repo_root, "rev-parse", "--abbrev-ref", "HEAD", timeout=10)
    if rc == 0:
        return out.strip()
    return ""


# =============================================================================
# v12.10.33：dubious ownership 检测与处理
# =============================================================================
# 背景：网络共享盘（SMB）上 clone 的 git 仓库，其文件所有者通常是当初 clone
# 的那个用户（如 mah6）；之后别的同事（如 liup71）用 SPAhub 打开，git 因为
# "dubious ownership" 拒绝任何操作 — 包括 status / rev-parse / fetch 都 rc != 0。
#
# 之前 v12.10.32 把 git_current_branch 失败一律归为 "detached HEAD or 无法识别
# 分支"，对用户极具误导（明明是权限问题，提示却让他 checkout）。
#
# 修复策略：
#   - check_repo_access() 一次性 probe 仓库是否能正常访问，并区分错误类型；
#   - trust_repo() 把仓库加入 git 的 safe.directory 全局白名单；
#   - 上层 start_gitlab_push 据此弹"信任并继续"对话框，一键解决。

_DUBIOUS_RE_SAFEDIR = re.compile(r"safe\.directory\s+'([^']+)'")
# git 的 dubious-ownership 报错里同时有 SID 单引号串 和 紧跟的 (可读名) 括号；
# 两组都捕获，可读名优先；可读名可能缺失（罕见）时退回 SID 串。
_DUBIOUS_RE_OWNER = re.compile(
    r"is\s+owned\s+by:\s*\n?\s*'([^']+)'(?:\s*\(([^)]+)\))?", re.MULTILINE)
_DUBIOUS_RE_CURRENT = re.compile(
    r"current\s+user\s+is:\s*\n?\s*'([^']+)'(?:\s*\(([^)]+)\))?", re.MULTILINE)


def check_repo_access(repo_root: str) -> Tuple[str, str, str]:
    """
    通过一次 `git status` 探测仓库可访问性，并区分错误类型。

    返回 (status, error_msg, safe_directory_value)：
      status:
        "ok"                 — 仓库正常可访问
        "dubious_ownership"  — 网络盘 / 权限问题，需要加 safe.directory
        "not_a_repo"         — repo_root 下没有 .git
        "other"              — 其它 git 错误（如仓库损坏）
      error_msg:             stderr 完整内容（"ok" 时为空）
      safe_directory_value:  仅 "dubious_ownership" 时有值，是 git 自己推荐
                             的 safe.directory 参数（如 "%(prefix)//10.10.5.56/..."）

    为什么用 `git status` 而不是 `git rev-parse`：
      status 是个"重"操作 — 会读 index、读 HEAD、做 ownership 检查；几乎所有
      git 错误都会在这里暴露。rev-parse 只解析 ref，dubious ownership 时也
      失败但错误信息有时不够清晰。
    """
    rc, out, err = run_git(repo_root, "status", "--porcelain", "-uno", timeout=15)
    if rc == 0:
        return ("ok", "", "")

    err_low = err.lower()

    # dubious ownership：错误信息里同时出现 "dubious ownership" 关键词 +
    # 含 "safe.directory" 的建议命令
    if "dubious ownership" in err_low or "safe.directory" in err_low:
        m = _DUBIOUS_RE_SAFEDIR.search(err)
        # 兜底：git 没给出建议（罕见）— 用 repo_root 本身
        suggested = m.group(1) if m else repo_root
        return ("dubious_ownership", err, suggested)

    if "not a git repository" in err_low:
        return ("not_a_repo", err, "")

    return ("other", err, "")


def parse_dubious_ownership_info(err: str) -> Tuple[str, str]:
    """
    从 git dubious ownership 的 stderr 中提取 (owner, current_user) 可读名。

    git 报错形如：
        ...is owned by:
                'S-1-5-21-...' (HENGRUI\\mah6)
        but the current user is:
                'S-1-5-21-...' (HENGRUI\\liup71)

    优先返回括号里的可读名（如 HENGRUI\\liup71）；
    若 git 输出里缺失括号，退回 SID 串；都提取不到返回 ("", "")。
    """
    def _pick(m) -> str:
        if not m:
            return ""
        # group(2) = 括号内可读名（可选）；group(1) = SID 串
        readable = m.group(2) if m.lastindex and m.lastindex >= 2 else None
        return (readable or m.group(1) or "").strip()

    owner = _pick(_DUBIOUS_RE_OWNER.search(err))
    cur_user = _pick(_DUBIOUS_RE_CURRENT.search(err))
    return owner, cur_user


def trust_repo(safe_directory_value: str) -> Tuple[bool, str]:
    """
    执行 `git config --global --add safe.directory <value>` 把仓库加入信任白名单。

    返回 (success, error_msg)。
    - safe_directory_value 一般是 git 自己推荐的 "%(prefix)//server/share/path" 格式,
      也可直接传 UNC 路径。

    注意：这是 --global 配置，写入用户的 ~/.gitconfig，对该用户**所有 git 操作**
    都生效；这是个权衡 — 用户只针对单个仓库信任会更安全，但 git 的 safe.directory
    本来就是 per-directory 白名单，所以无副作用。
    """
    # cwd 用用户 home 而不是空字符串：空字符串走 None，subprocess 用当前进程 cwd，
    # 若该 cwd 本身是网络盘上有 dubious ownership 的目录，git config 命令本身可能
    # 也会失败。用 home 目录就完全规避。
    home = os.path.expanduser("~") or None
    rc, _, err = run_git(
        home or "",
        "config", "--global", "--add", "safe.directory", safe_directory_value,
        timeout=10,
    )
    if rc == 0:
        return True, ""
    return False, err.strip() or "未知错误"


# =============================================================================
# v12.10.35：凭据 / 身份相关工具（认证错误识别 + commit author + push 端用户名）
# =============================================================================

# git 认证类错误的特征关键词（小写匹配，覆盖 GitLab / GCM / OpenSSH 各种姿势）
_AUTH_ERROR_PATTERNS = (
    "authentication failed",
    "http basic: access denied",
    "401 unauthorized",
    "could not read username",
    "could not read password",
    "terminal prompts disabled",
    "invalid credentials",
    "permission denied (publickey",
    "support for password authentication was removed",
    "incorrect username or password",
)

_NETWORK_ERROR_PATTERNS = (
    "could not resolve host",
    "connection refused",
    "connection timed out",
    "operation timed out",
    "ssl_error",
    "couldn't connect to server",
    "failed to connect to",
    "no route to host",
    "network is unreachable",
)


def classify_git_error(stderr: str) -> str:
    """
    根据 stderr 内容分类 git 错误类型。

    返回："auth" / "network" / "other"
      - auth    : 认证失败（token 过期 / 撤销 / 凭据缺失）
      - network : 网络层故障（DNS / 连接 / 超时）
      - other   : 其它（仓库错误、ref 错误、合并冲突、等等）

    不返回 "dubious_ownership" — 那个用 check_repo_access 单独处理，
    本函数关注的是已经过 access check 之后的"运行中"错误。
    """
    if not stderr:
        return "other"
    low = stderr.lower()
    for p in _AUTH_ERROR_PATTERNS:
        if p in low:
            return "auth"
    for p in _NETWORK_ERROR_PATTERNS:
        if p in low:
            return "network"
    return "other"


def get_commit_identity(repo_root: str) -> Tuple[str, str]:
    """
    读 git config 的 user.name / user.email（commit 时的署名身份）。

    优先级（git 自己的合并顺序）：repo-local > global > system。
    任一字段读取失败返回空串，由调用方决定如何处理（通常显示 "(未配置)"）。

    与 push 时的远端验证身份是**两套独立的东西** — 见
    get_push_credential_username 注释。
    """
    rc, out, _ = run_git(repo_root, "config", "user.name", timeout=5)
    name = out.strip() if rc == 0 else ""
    rc, out, _ = run_git(repo_root, "config", "user.email", timeout=5)
    email = out.strip() if rc == 0 else ""
    return name, email


def get_push_credential_username(remote_url: str) -> str:
    """
    通过 `git credential fill` 询问 credential helper（一般是 GCM）
    拿 push 端预期使用的 username（不返回 password / token）。

    流程：
      stdin 写入  protocol=<...>\\nhost=<...>\\n\\n  → git credential fill
      stdout 读出  protocol=...\\nhost=...\\nusername=...\\npassword=...

    场景说明：
      - 凭据管理器里有缓存 → 返回 username（如 liup71），password 我们直接丢弃
      - 凭据管理器里没缓存 → GCM 会弹 GUI 让用户登录 — 我们**不希望**这种情况发生
        （UI 探测阶段不该弹登录窗），所以用短 timeout 兜底
      - URL 不是 http/https → 返回空（SSH 走密钥，无 username 概念）

    返回空字符串表示无法获取（不应作为 fatal 错误）。
    """
    if not remote_url:
        return ""
    # 解析 protocol + host（不引第三方库，简单 split 够用）
    m = re.match(r"^([a-zA-Z]+)://([^/]+)", remote_url)
    if not m:
        return ""
    protocol = m.group(1).lower()
    if protocol not in ("http", "https"):
        return ""
    host_full = m.group(2)
    # 去掉 user:pass@（如 http://user@host/...）和端口（host:port）
    host = host_full.split("@", 1)[-1].split(":", 1)[0]

    # 直接调 subprocess（不走 run_git，因为需要 stdin）
    stdin_data = f"protocol={protocol}\nhost={host}\n\n"
    creationflags = 0x08000000 if os.name == "nt" else 0
    env = os.environ.copy()
    env["LC_ALL"] = "C.UTF-8"
    env["GIT_TERMINAL_PROMPT"] = "0"  # 防止凭据管理器缺失时弹 terminal
    # v12.10.59：与 run_git 一致，用绝对路径避免裸 "git" 解析失败
    git_exe = _resolve_git_exe() or "git"
    try:
        p = subprocess.run(
            [git_exe, "credential", "fill"],
            input=stdin_data, capture_output=True, text=True,
            encoding="utf-8", errors="replace",
            timeout=8, creationflags=creationflags, env=env,
        )
        if p.returncode != 0:
            return ""
        for line in p.stdout.splitlines():
            if line.startswith("username="):
                return line[len("username="):].strip()
        return ""
    except Exception:
        return ""


def open_windows_credential_manager() -> bool:
    """
    Windows: 打开"凭据管理器"控制面板。非 Windows 返回 False（无操作）。
    用于 CredentialErrorDialog 的"打开凭据管理器"按钮。
    """
    if os.name != "nt":
        return False
    try:
        subprocess.Popen(
            ["control.exe", "/name", "Microsoft.CredentialManager"],
            creationflags=0x08000000,
        )
        return True
    except Exception:
        return False


def gitlab_pat_settings_url(remote_url: str) -> str:
    """
    根据 remote URL 推导 GitLab 个人 Token 管理页面 URL。
    例：http://10.10.5.52/g/r.git → http://10.10.5.52/-/user_settings/personal_access_tokens
    """
    if not remote_url:
        return ""
    m = re.match(r"^(https?://[^/]+)", remote_url)
    if not m:
        return ""
    return m.group(1) + "/-/user_settings/personal_access_tokens"


def git_status_porcelain(repo_root: str) -> List[Tuple[str, str]]:
    """
    返回 `git status --porcelain` 解析后的 [(status_code, rel_path), ...] 列表。

    status_code 是两字符（XY）：
      - 'M ' / ' M' = 已 tracked 修改（staged / unstaged）
      - 'A ' = 新增 staged
      - '??' = untracked（未 ignore）
      - 'D ' / ' D' = 删除
      - 'R ' = 重命名（路径形如 "old -> new"，本函数仅返回 new）

    用 -z 分隔可解决路径含空格 / 中文的边缘情况，但解析复杂；这里用普通
    模式 + 简单分隔，配合 `core.quotepath=false` 让 git 不要把非 ASCII
    路径转 \\xxx 转义形式输出。
    """
    rc, out, err = run_git(
        repo_root, "-c", "core.quotepath=false", "status", "--porcelain", timeout=30,
    )
    if rc != 0:
        return []
    items: List[Tuple[str, str]] = []
    for line in out.splitlines():
        if not line:
            continue
        # 前 2 字符是状态码，第 3 字符是空格，后面是路径
        if len(line) < 4:
            continue
        code = line[:2]
        path = line[3:]
        # 处理重命名 "R  old -> new"：仅取 new 端做路径匹配
        if " -> " in path:
            path = path.split(" -> ", 1)[1]
        items.append((code, path))
    return items


def git_ahead_behind(repo_root: str, branch: str) -> Tuple[int, int]:
    """
    返回 (ahead, behind)：本地相对 origin/<branch> 的领先和落后 commit 数。

    需要先 fetch 才有意义（git fetch 不在本函数里做，留给调用方编排）。
    若 origin/<branch> 不存在（首次 push）则返回 (ahead=本地 commit 数, behind=0)。
    """
    rc, out, _ = run_git(
        repo_root, "rev-list", "--left-right", "--count",
        f"HEAD...origin/{branch}", timeout=20,
    )
    if rc == 0:
        parts = out.strip().split()
        if len(parts) == 2:
            try:
                # 左：本地 HEAD 独有（ahead），右：origin/<branch> 独有（behind）
                return int(parts[0]), int(parts[1])
            except ValueError:
                return 0, 0
    # rev-list 失败通常是 origin/<branch> 不存在 — 首次 push 场景
    rc2, out2, _ = run_git(repo_root, "rev-list", "--count", "HEAD", timeout=10)
    if rc2 == 0:
        try:
            return int(out2.strip()), 0
        except ValueError:
            pass
    return 0, 0


def git_unpushed_log(repo_root: str, branch: str, limit: int = 50) -> List[str]:
    """
    列出本地相对 origin/<branch> 领先的 commit（最近 limit 个）。
    每个元素形如 "abc1234 commit subject"。
    """
    rc, out, _ = run_git(
        repo_root, "log", f"origin/{branch}..HEAD", "--oneline",
        f"-n{limit}", "--no-decorate", timeout=15,
    )
    if rc == 0:
        return [l for l in out.splitlines() if l.strip()]
    # 若 origin/<branch> 不存在（首次 push），改用 HEAD 全量
    rc2, out2, _ = run_git(repo_root, "log", "HEAD", "--oneline",
                           f"-n{limit}", "--no-decorate", timeout=15)
    if rc2 == 0:
        return [l for l in out2.splitlines() if l.strip()]
    return []


# =============================================================================
# 工具函数：扫描三个目录下的可推送 *.sas
# =============================================================================

# 推送目标目录定义（相对 repo_root）：
#   - "06_programs"     → 实际路径 = <base>/06_programs
#   - "09_validation"   → 实际路径 = <base>/09_validation
#   - "utility/macros"  → 实际路径 = <repo_root>/utility/macros
#
# 用 _DirSpec 三元组描述：(显示名, 相对 repo_root 的子路径, 默认是否展开)
_PUSH_DIR_SPECS = [
    ("06_programs", "csr_REPLACE/06_programs", True),
    ("09_validation", "csr_REPLACE/09_validation", True),
    ("utility/macros", "utility/macros", True),
]


def resolve_push_dirs(base_path: str, repo_root: str) -> List[Tuple[str, str, str]]:
    """
    解析三个推送目录的绝对路径 + 相对仓库根的相对路径。

    返回 [(display_name, abs_path, rel_to_repo), ...]。
    rel_to_repo 用 POSIX 风格（"/" 分隔）— 这是 git 内部统一格式，便于后续
    与 ls-files / status 的输出做字符串匹配。

    若某目录不存在（罕见，但理论可能：某些项目可能没建 09_validation），
    在返回列表里仍占位（abs_path 给出，调用方自行判断 isdir）。
    """
    repo_root_abs = os.path.abspath(repo_root)
    base_path_abs = os.path.abspath(base_path)
    # csr_NN 相对 repo_root 的路径段（如 "csr_01"）
    try:
        csr_rel = os.path.relpath(base_path_abs, repo_root_abs).replace("\\", "/")
    except ValueError:
        # 极端：base_path 与 repo_root 在不同盘符 — 不应发生
        csr_rel = os.path.basename(base_path_abs)

    out = []
    out.append(("06_programs",
                os.path.join(base_path_abs, "06_programs"),
                f"{csr_rel}/06_programs"))
    out.append(("09_validation",
                os.path.join(base_path_abs, "09_validation"),
                f"{csr_rel}/09_validation"))
    out.append(("utility/macros",
                os.path.join(repo_root_abs, "utility", "macros"),
                "utility/macros"))
    return out


def scan_pushable_sas_files(repo_root: str, push_dirs: List[Tuple[str, str, str]]
                            ) -> List[Tuple[str, str, str, str]]:
    """
    扫描三个推送目录里 **状态为 modified 或 untracked** 的 *.sas 文件。

    返回 [(display_name, rel_to_repo, file_basename, status), ...]：
      - display_name : "06_programs" / "09_validation" / "utility/macros"
      - rel_to_repo  : 相对 repo_root 的路径（POSIX，带前缀如 "csr_01/06_programs/..."）
      - file_basename: 仅文件名（用于 UI 展示）
      - status       : "modified" / "untracked"

    实现：
      1. 一次性调 `git status --porcelain` 拿全仓库的脏度 — 比对每个推送目录前缀。
      2. 仅保留 .sas 后缀（大小写不敏感）。
      3. 仅返回 modified / untracked 两类（Q7=A：clean 文件不在树形对话框里）。

    为什么不分别对每个目录调 `git ls-files`：
      - status 一次出全部，O(N)；ls-files 要 ×3，且还要再合并去重；
      - status 直接告诉我们 modified / untracked / clean，方便分类。
    """
    if not repo_root:
        return []
    status_items = git_status_porcelain(repo_root)
    if not status_items:
        return []

    # 把 push_dirs 的 rel_to_repo 做前缀映射 — 注意末尾加 "/" 防止子串误匹配
    prefix_map = []  # [(prefix, display_name), ...]
    for display, _abs, rel in push_dirs:
        prefix_map.append((rel.rstrip("/") + "/", display))

    out: List[Tuple[str, str, str, str]] = []
    for code, path in status_items:
        # 仅 .sas
        if not path.lower().endswith(".sas"):
            continue
        # 状态分类
        if code == "??":
            status = "untracked"
        elif "D" in code:
            # 删除的文件 — 一般不推（git add 会把它从索引移除），先跳过
            continue
        else:
            status = "modified"

        # 看属于哪个推送目录
        path_norm = path.replace("\\", "/")
        match_display = None
        for prefix, display in prefix_map:
            if path_norm.startswith(prefix):
                match_display = display
                break
        if not match_display:
            continue

        basename = path_norm.rsplit("/", 1)[-1]
        out.append((match_display, path_norm, basename, status))

    # 稳定排序：先按目录名分组（按 _PUSH_DIR_SPECS 顺序），再按相对路径字典序
    order = {display: i for i, (display, *_rest) in enumerate(push_dirs)}
    out.sort(key=lambda r: (order.get(r[0], 99), r[1]))
    return out


# =============================================================================
# SasFilesTreeDialog —— 树形勾选 + commit message 输入
# =============================================================================
class SasFilesTreeDialog(QDialog):
    """
    推送前的"文件选择 + commit message"入口对话框。

    UI 自顶向下：
      1. 仓库信息区（只读）：远端 URL / 当前分支
      2. 文件树（QTreeWidget）：
         - 根节点 = 推送目录（如 06_programs），其旁显示"X / Y 项"
         - 子节点 = 单文件（带状态图标）
         - 三态 checkbox 联动：根 ↔ 子（Qt.PartiallyChecked 兼容父节点部分选中）
      3. commit message 输入（QPlainTextEdit），默认"auto push by SPAhub @ <ts>"
      4. 按钮区：[取消] [▶ 开始推送]

    Q7=A 决策：只展示 modified + untracked，默认全勾选（调用方传入的 file_rows 已过滤）。
    """
    # v12.10.34：自定义 done code — 用户点了"🔄 仅 Pull 更新"按钮
    # （需与 QDialog.Accepted=1, QDialog.Rejected=0 区分开）
    PULL_REQUESTED = 100

    def __init__(self, parent, repo_root: str, remote_url: str, branch: str,
                 file_rows: List[Tuple[str, str, str, str]],
                 commit_author_name: str = "", commit_author_email: str = "",
                 push_username: str = ""):
        """
        v12.10.35: 增加身份相关参数（show in 信息区，不参与 push 逻辑）。
          - commit_author_name / email: 来自 `git config user.name/email`，
            是 commit 时显示的作者
          - push_username: 来自 `git credential fill`，是 GCM 里缓存的、
            push 时实际用来 HTTP 认证的账号（与 commit author 可能不一致！）
        """
        super().__init__(parent)
        self.setWindowTitle("🚀 推送 SAS 程序至 GitLab")
        self.setMinimumSize(720, 600)
        self._repo_root = repo_root
        self._remote_url = remote_url
        self._branch = branch
        self._file_rows = file_rows
        self._commit_author_name = commit_author_name
        self._commit_author_email = commit_author_email
        self._push_username = push_username

        # 输出：调用方拿到选中文件相对路径列表 + commit_msg
        self.selected_files: List[str] = []
        self.commit_msg: str = ""

        self._build_ui()

    # ------------------- UI 构造 -------------------
    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(16, 16, 16, 16)
        root.setSpacing(10)

        # === 1. 仓库信息区 ===
        info_frame = QFrame()
        info_frame.setStyleSheet(
            "QFrame { background-color: #F5F7FA; border: 1px solid #E4E7ED; border-radius: 4px; }")
        info_l = QVBoxLayout(info_frame)
        info_l.setContentsMargins(12, 10, 12, 10)
        info_l.setSpacing(4)

        def _info_row(key: str, value: str, value_bold: bool = False,
                      value_color: str = "#303133",
                      tooltip: str = "") -> QHBoxLayout:
            row = QHBoxLayout()
            lk = QLabel(key)
            lk.setStyleSheet(
                "color: #909399; font-size: 12px; border: none; min-width: 90px;")
            row.addWidget(lk)
            lv = QLabel(value or "(未配置)")
            weight = "bold" if value_bold else "normal"
            lv.setStyleSheet(
                f"color: {value_color}; font-family: Consolas; "
                f"font-size: 12px; font-weight: {weight}; border: none;")
            lv.setTextInteractionFlags(Qt.TextSelectableByMouse)
            lv.setWordWrap(True)
            if tooltip:
                lv.setToolTip(tooltip)
            row.addWidget(lv, 1)
            return row

        info_l.addLayout(_info_row("远端 URL：", self._remote_url or "(未配置 origin remote)"))
        info_l.addLayout(_info_row("当前分支：", self._branch or "(未知)", value_bold=True))

        # v12.10.35: commit 作者 + push 端账号
        author_display = ""
        if self._commit_author_name or self._commit_author_email:
            if self._commit_author_name and self._commit_author_email:
                author_display = f"{self._commit_author_name} <{self._commit_author_email}>"
            else:
                author_display = self._commit_author_name or self._commit_author_email
        else:
            author_display = "(未配置 — 建议先 git config user.name / user.email)"
        info_l.addLayout(_info_row(
            "Commit 作者：", author_display,
            value_color="#67C23A" if author_display and "未配置" not in author_display else "#E6A23C",
            tooltip="git config user.name / user.email — 决定 commit 的署名"))

        # push 用户：如果获取不到（GCM 不存在 / 凭据缺失），显示提示
        if self._push_username:
            push_display = self._push_username
            push_color = "#67C23A"
            # 警告：commit author 与 push username 不一致
            if (self._commit_author_name
                    and self._push_username.lower() not in self._commit_author_name.lower()
                    and self._commit_author_name.lower() not in self._push_username.lower()
                    and (self._commit_author_email
                         and self._push_username.lower() not in self._commit_author_email.lower())):
                push_display += "   ⚠️ 与 commit 作者不一致"
                push_color = "#E6A23C"
        else:
            push_display = "(凭据管理器中无缓存 — 首次 push 时 GCM 会弹登录)"
            push_color = "#909399"

        info_l.addLayout(_info_row(
            "Push 凭据：", push_display, value_color=push_color,
            tooltip="git credential fill — Windows 凭据管理器中缓存的 HTTP 认证用户名"))

        root.addWidget(info_frame)

        # === 2. 文件树标题 ===
        tip = QLabel(
            f"勾选要推送的 SAS 文件（默认全选，共 {len(self._file_rows)} 个）："
            f"<span style='color:#909399;font-size:11px;'>"
            f"   🟢 已修改  🆕 新文件</span>")
        tip.setStyleSheet("color: #606266; font-size: 13px; border: none;")
        tip.setTextFormat(Qt.RichText)
        root.addWidget(tip)

        # === 文件树 ===
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["文件 / 路径", "状态"])
        self.tree.setColumnWidth(0, 480)
        self.tree.setColumnWidth(1, 100)
        self.tree.setStyleSheet(
            "QTreeWidget { border: 1px solid #E4E7ED; border-radius: 4px; background: #FFFFFF; }"
            "QTreeWidget::item { padding: 3px 0; }"
            "QTreeWidget::item:hover { background-color: #ECF5FF; }"
        )
        # 三态联动：自己处理（itemChanged → 同步父/子）
        self._suppress_item_change = False
        self.tree.itemChanged.connect(self._on_item_changed)

        # 分组写入
        groups: dict = {}  # display_name → [rows]
        for r in self._file_rows:
            groups.setdefault(r[0], []).append(r)

        for display, rows in groups.items():
            parent = QTreeWidgetItem(self.tree)
            parent.setText(0, f"📂 {display}/   ({len(rows)} 个文件)")
            parent.setFlags(parent.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsAutoTristate)
            parent.setCheckState(0, Qt.Checked)
            parent.setExpanded(True)
            font = parent.font(0)
            font.setBold(True)
            parent.setFont(0, font)

            for _disp, rel_path, basename, status in rows:
                child = QTreeWidgetItem(parent)
                icon = "🟢" if status == "modified" else "🆕"
                child.setText(0, f"{icon}  {basename}")
                child.setText(1, status)
                child.setToolTip(0, rel_path)
                # 第二列颜色：modified=橙，untracked=绿
                if status == "modified":
                    child.setForeground(1, Qt.darkYellow)
                else:
                    child.setForeground(1, Qt.darkGreen)
                child.setFlags(child.flags() | Qt.ItemIsUserCheckable)
                child.setCheckState(0, Qt.Checked)
                # 把相对路径塞 UserRole，提交时取
                child.setData(0, Qt.UserRole, rel_path)

        root.addWidget(self.tree, 1)

        # === 3. commit message ===
        msg_lbl = QLabel("Commit message：")
        msg_lbl.setStyleSheet("color: #606266; font-size: 13px; border: none;")
        root.addWidget(msg_lbl)

        self.msg_edit = QPlainTextEdit()
        default_msg = f"auto push by SPAhub @ {time.strftime('%Y-%m-%d %H:%M:%S')}"
        self.msg_edit.setPlainText(default_msg)
        self.msg_edit.setMaximumHeight(70)
        self.msg_edit.setStyleSheet(
            "QPlainTextEdit { border: 1px solid #DCDFE6; border-radius: 4px; "
            "padding: 6px 8px; font-family: Consolas; font-size: 12px; }"
            "QPlainTextEdit:focus { border-color: #409EFF; }"
        )
        root.addWidget(self.msg_edit)

        # === 4. 按钮区 ===
        btn_row = QHBoxLayout()

        # v12.10.34：仅 Pull 更新 — 左侧次要操作，不关闭整个 push 流程
        # 用 done(PULL_REQUESTED) 返回特殊码，让 start_gitlab_push 转交给
        # PullOnlyRunner 处理；pull 结束后再决定是否重开 push 对话框。
        self.btn_pull_only = QPushButton("🔄 仅 Pull 更新")
        self.btn_pull_only.setStyleSheet(
            "QPushButton { background-color: #FFFFFF; color: #409EFF; "
            "border: 1px solid #409EFF; padding: 8px 18px; border-radius: 4px; }"
            "QPushButton:hover { background-color: #ECF5FF; }"
            "QPushButton:pressed { background-color: #D9ECFF; }")
        self.btn_pull_only.setCursor(Qt.PointingHandCursor)
        self.btn_pull_only.setToolTip(
            "执行 git pull --ff-only origin <分支>\n"
            "仅在能 fast-forward 时拉取（最安全，不产生 merge commit）。\n"
            "本地有未推送 commit 时会拒绝 — 那种情况请走【▶ 开始推送】。")
        self.btn_pull_only.clicked.connect(lambda: self.done(self.PULL_REQUESTED))
        btn_row.addWidget(self.btn_pull_only)

        btn_row.addStretch()

        self.btn_cancel = QPushButton("取消")
        self.btn_cancel.setStyleSheet(
            "QPushButton { background-color: #F5F7FA; color: #606266; "
            "border: 1px solid #DCDFE6; padding: 8px 22px; border-radius: 4px; }"
            "QPushButton:hover { background-color: #E4E7ED; }")
        self.btn_cancel.setCursor(Qt.PointingHandCursor)
        self.btn_cancel.clicked.connect(self.reject)
        btn_row.addWidget(self.btn_cancel)

        self.btn_ok = QPushButton("▶ 开始推送")
        self.btn_ok.setStyleSheet(
            "QPushButton { background-color: #67C23A; color: white; "
            "border: none; padding: 8px 22px; border-radius: 4px; font-weight: bold; }"
            "QPushButton:hover { background-color: #85CE61; }"
            "QPushButton:pressed { background-color: #5DAF34; }"
            "QPushButton:disabled { background-color: #B3E19D; }")
        self.btn_ok.setCursor(Qt.PointingHandCursor)
        self.btn_ok.clicked.connect(self._on_ok)
        btn_row.addWidget(self.btn_ok)
        root.addLayout(btn_row)

        # 没有可推送文件时禁用 OK（但 Pull 按钮仍可用 — 用户可能就是想先 pull 看看）
        if not self._file_rows:
            self.btn_ok.setEnabled(False)
            self.btn_ok.setText("无可推送文件")

    # ------------------- 三态联动 -------------------
    def _on_item_changed(self, item: QTreeWidgetItem, col: int):
        """checkState 变化时，父子联动。用 _suppress_item_change 防递归。"""
        if col != 0 or self._suppress_item_change:
            return
        self._suppress_item_change = True
        try:
            # 父 → 子：根节点切换时把所有子勾上 / 取消
            if item.parent() is None and item.childCount() > 0:
                state = item.checkState(0)
                if state in (Qt.Checked, Qt.Unchecked):
                    for i in range(item.childCount()):
                        item.child(i).setCheckState(0, state)
            # 子 → 父：用 ItemIsAutoTristate 自动处理（Qt 内置）
            # 但我们仍然手动更新一次，防止 Qt 版本差异
            else:
                p = item.parent()
                if p is not None:
                    n = p.childCount()
                    checked = sum(1 for i in range(n)
                                  if p.child(i).checkState(0) == Qt.Checked)
                    if checked == 0:
                        p.setCheckState(0, Qt.Unchecked)
                    elif checked == n:
                        p.setCheckState(0, Qt.Checked)
                    else:
                        p.setCheckState(0, Qt.PartiallyChecked)
        finally:
            self._suppress_item_change = False

    # ------------------- 确认 -------------------
    def _on_ok(self):
        # 收集所有勾选的子节点
        selected: List[str] = []
        for i in range(self.tree.topLevelItemCount()):
            top = self.tree.topLevelItem(i)
            for j in range(top.childCount()):
                child = top.child(j)
                if child.checkState(0) == Qt.Checked:
                    rel = child.data(0, Qt.UserRole)
                    if rel:
                        selected.append(rel)

        if not selected:
            QMessageBox.warning(self, "提示", "未选择任何文件，无可推送内容。")
            return

        msg = self.msg_edit.toPlainText().strip()
        if not msg:
            QMessageBox.warning(self, "提示", "Commit message 不能为空。")
            return

        self.selected_files = selected
        self.commit_msg = msg
        self.accept()


# =============================================================================
# PullConfirmDialog —— 远端 origin/<branch> 领先时的"是否自动 pull"弹窗
# =============================================================================
class PullConfirmDialog(QDialog):
    """
    fetch 完后检测到 origin/<branch> 领先时弹出。

    呈现：领先 commit 数 + 近若干条 oneline 历史；
    按钮：[取消推送] / [🔀 自动 Pull 后继续 Push]。
    """
    def __init__(self, parent, branch: str, behind_count: int,
                 recent_log: List[str]):
        super().__init__(parent)
        self.setWindowTitle("⚠️ 远端有新提交，需要先合并")
        self.setMinimumSize(560, 360)
        self._build_ui(branch, behind_count, recent_log)

    def _build_ui(self, branch: str, behind: int, log_lines: List[str]):
        root = QVBoxLayout(self)
        root.setContentsMargins(16, 16, 16, 16)
        root.setSpacing(10)

        # 警告标题
        lbl_title = QLabel(
            f"<span style='color:#E6A23C; font-size:14px; font-weight:bold;'>"
            f"⚠️ 远端 origin/{branch} 领先本地 {behind} 个 commit</span>")
        lbl_title.setTextFormat(Qt.RichText)
        lbl_title.setStyleSheet("border: none;")
        root.addWidget(lbl_title)

        # 说明
        desc = QLabel(
            "继续 push 会被远端拒绝。建议先把远端新提交合并到本地（git pull --no-rebase）<br>"
            "再 push。<b>本地待推送 commit 已固化保护</b>，合并冲突时会自动 abort 回滚，<br>"
            "不会污染你的修改。"
        )
        desc.setTextFormat(Qt.RichText)
        desc.setWordWrap(True)
        desc.setStyleSheet("color: #606266; font-size: 12px; border: none;")
        root.addWidget(desc)

        # 远端最近 commit
        lbl_log = QLabel(f"远端最近 {min(len(log_lines), 10)} 个 commit：")
        lbl_log.setStyleSheet("color: #909399; font-size: 12px; border: none;")
        root.addWidget(lbl_log)

        log_view = QTextEdit()
        log_view.setReadOnly(True)
        log_view.setStyleSheet(
            "QTextEdit { background: #F5F7FA; color: #303133; "
            "font-family: Consolas; font-size: 12px; border: 1px solid #E4E7ED; "
            "border-radius: 4px; padding: 8px; }")
        if log_lines:
            log_view.setPlainText("\n".join(log_lines[:10]))
        else:
            log_view.setPlainText("(无法获取 commit 列表)")
        log_view.setMaximumHeight(180)
        root.addWidget(log_view)

        # 按钮
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        btn_cancel = QPushButton("取消推送")
        btn_cancel.setStyleSheet(
            "QPushButton { background-color: #F5F7FA; color: #606266; "
            "border: 1px solid #DCDFE6; padding: 8px 18px; border-radius: 4px; }"
            "QPushButton:hover { background-color: #E4E7ED; }")
        btn_cancel.setCursor(Qt.PointingHandCursor)
        btn_cancel.clicked.connect(self.reject)
        btn_row.addWidget(btn_cancel)

        btn_pull = QPushButton("🔀 自动 Pull 后继续 Push")
        btn_pull.setStyleSheet(
            "QPushButton { background-color: #409EFF; color: white; "
            "border: none; padding: 8px 18px; border-radius: 4px; font-weight: bold; }"
            "QPushButton:hover { background-color: #66B1FF; }"
            "QPushButton:pressed { background-color: #3A8EE6; }")
        btn_pull.setCursor(Qt.PointingHandCursor)
        btn_pull.clicked.connect(self.accept)
        btn_row.addWidget(btn_pull)
        root.addLayout(btn_row)


# =============================================================================
# OutOfScopeDirtyDialog —— 仓库内勾选范围外的脏文件警告
# =============================================================================
class OutOfScopeDirtyDialog(QDialog):
    """
    用户的待推内容已确定，但仓库内还有"非勾选范围"的未提交修改时弹出。

    三选项：
      - 取消推送（returns "cancel"）
      - 自动 stash → push → pop 回来（returns "stash"，推荐）
      - 继续推送，仓库其它修改保持不变（returns "continue"）
    """
    CHOICE_CANCEL = "cancel"
    CHOICE_STASH = "stash"
    CHOICE_CONTINUE = "continue"

    def __init__(self, parent, dirty_files: List[Tuple[str, str]]):
        """dirty_files: [(status_code, rel_path), ...]"""
        super().__init__(parent)
        self.setWindowTitle("⚠️ 仓库内存在其它未提交修改")
        self.setMinimumSize(620, 420)
        self.choice = self.CHOICE_CANCEL
        self._build_ui(dirty_files)

    def _build_ui(self, dirty_files: List[Tuple[str, str]]):
        root = QVBoxLayout(self)
        root.setContentsMargins(16, 16, 16, 16)
        root.setSpacing(10)

        lbl_title = QLabel(
            f"<span style='color:#E6A23C; font-size:14px; font-weight:bold;'>"
            f"⚠️ 仓库内还有 {len(dirty_files)} 个未提交的其它修改（不在本次推送范围）</span>")
        lbl_title.setTextFormat(Qt.RichText)
        lbl_title.setStyleSheet("border: none;")
        root.addWidget(lbl_title)

        desc = QLabel(
            "这些文件可能在 pull 合并阶段与远端冲突，导致 pull 失败。<br>"
            "请选择如何处理："
        )
        desc.setTextFormat(Qt.RichText)
        desc.setWordWrap(True)
        desc.setStyleSheet("color: #606266; font-size: 12px; border: none;")
        root.addWidget(desc)

        # 文件列表
        files_view = QTextEdit()
        files_view.setReadOnly(True)
        files_view.setStyleSheet(
            "QTextEdit { background: #F5F7FA; color: #303133; "
            "font-family: Consolas; font-size: 12px; border: 1px solid #E4E7ED; "
            "border-radius: 4px; padding: 8px; }")
        rows = []
        for code, path in dirty_files[:200]:
            icon = "🟢" if "M" in code else "🆕" if code == "??" else "🟡"
            rows.append(f"  {icon}  [{code}] {path}")
        if len(dirty_files) > 200:
            rows.append(f"  ... 另有 {len(dirty_files) - 200} 个文件未显示")
        files_view.setPlainText("\n".join(rows))
        files_view.setMaximumHeight(180)
        root.addWidget(files_view)

        # 三个选项按钮（纵向排，每个都有说明）
        def _make_choice_btn(emoji: str, label: str, hint: str,
                             color_main: str, color_hover: str, choice_val: str,
                             recommended: bool = False) -> QPushButton:
            btn = QPushButton()
            tag = "  【推荐】" if recommended else ""
            btn.setText(f"{emoji}  {label}{tag}\n    {hint}")
            btn.setStyleSheet(
                f"QPushButton {{ background-color: {color_main}; color: white; "
                f"border: none; padding: 10px 16px; border-radius: 4px; "
                f"text-align: left; font-size: 12px; }}"
                f"QPushButton:hover {{ background-color: {color_hover}; }}"
            )
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda: self._choose(choice_val))
            return btn

        btn_stash = _make_choice_btn(
            "🔄", "自动 stash → push → pop",
            "推送前临时收起这些修改，推完自动恢复 — 状态完全一致，不留痕迹",
            "#67C23A", "#85CE61", self.CHOICE_STASH, recommended=True,
        )
        root.addWidget(btn_stash)

        btn_continue = _make_choice_btn(
            "▶", "继续推送，保留其它脏文件",
            "若这些文件与远端无冲突可行；有冲突时 pull 会失败（自动 abort 回滚）",
            "#E6A23C", "#EBB563", self.CHOICE_CONTINUE,
        )
        root.addWidget(btn_continue)

        btn_cancel = _make_choice_btn(
            "✖", "取消推送",
            "退出本次推送，不做任何 git 操作",
            "#909399", "#A6A9AD", self.CHOICE_CANCEL,
        )
        root.addWidget(btn_cancel)

    def _choose(self, val: str):
        self.choice = val
        self.accept()


# =============================================================================
# SafeDirectoryDialog —— v12.10.33: dubious ownership 时的"信任仓库"对话框
# =============================================================================
class SafeDirectoryDialog(QDialog):
    """
    检测到 git "dubious ownership" 错误时弹出，让用户一键把仓库加入
    `git config --global safe.directory` 白名单。

    背景见 check_repo_access 注释。

    UI 设计：
      - 标题：⚠️ Git 仓库可疑所有权
      - 信息：仓库路径 / 所有者 / 当前用户（从 git stderr 提取）
      - 解释：为什么 git 拒绝；做什么能解决
      - 命令预览（只读 + 可选中复制）：要执行的 git config 命令
      - 按钮：[取消] / [✓ 信任并继续推送]
    """
    def __init__(self, parent, repo_root: str, safe_dir_value: str,
                 owner: str, current_user: str):
        super().__init__(parent)
        self.setWindowTitle("⚠️ Git 仓库可疑所有权")
        self.setMinimumSize(640, 460)
        self._build_ui(repo_root, safe_dir_value, owner, current_user)

    def _build_ui(self, repo_root: str, safe_dir_value: str,
                  owner: str, current_user: str):
        root = QVBoxLayout(self)
        root.setContentsMargins(16, 16, 16, 16)
        root.setSpacing(10)

        # 标题
        lbl_title = QLabel(
            "<span style='color:#E6A23C; font-size:14px; font-weight:bold;'>"
            "⚠️ Git 检测到仓库可疑所有权（dubious ownership）</span>")
        lbl_title.setTextFormat(Qt.RichText)
        lbl_title.setStyleSheet("border: none;")
        root.addWidget(lbl_title)

        # 描述
        desc = QLabel(
            "该 git 仓库位于网络共享盘，文件所有者与当前 Windows 用户不一致。"
            "Git 出于安全考虑会拒绝在这种仓库上做任何操作（status / fetch / "
            "commit / push 全部 fail）。<br><br>"
            "解决方案：把该仓库加入 git 全局信任目录白名单（<code>safe.directory</code>）。"
            "本操作只影响当前 Windows 用户，对仓库本身和其他人无任何影响。"
        )
        desc.setTextFormat(Qt.RichText)
        desc.setWordWrap(True)
        desc.setStyleSheet("color: #606266; font-size: 12px; border: none;")
        root.addWidget(desc)

        # 信息表
        info = QFrame()
        info.setStyleSheet(
            "QFrame { background-color: #F5F7FA; border: 1px solid #E4E7ED; "
            "border-radius: 4px; }")
        info_l = QVBoxLayout(info)
        info_l.setContentsMargins(12, 10, 12, 10)
        info_l.setSpacing(4)

        def _kv_row(k: str, v: str):
            row = QHBoxLayout()
            lk = QLabel(k)
            lk.setStyleSheet("color: #909399; font-size: 12px; border: none; min-width: 90px;")
            row.addWidget(lk)
            lv = QLabel(v or "(未知)")
            lv.setStyleSheet(
                "color: #303133; font-family: Consolas; font-size: 12px; border: none;")
            lv.setTextInteractionFlags(Qt.TextSelectableByMouse)
            lv.setWordWrap(True)
            row.addWidget(lv, 1)
            return row

        info_l.addLayout(_kv_row("仓库路径：", repo_root))
        info_l.addLayout(_kv_row("仓库所有者：", owner))
        info_l.addLayout(_kv_row("当前用户：", current_user))
        root.addWidget(info)

        # 命令预览
        lbl_cmd = QLabel("将执行的命令（已根据 git 的推荐生成）：")
        lbl_cmd.setStyleSheet("color: #606266; font-size: 12px; border: none;")
        root.addWidget(lbl_cmd)

        cmd_view = QTextEdit()
        cmd_view.setReadOnly(True)
        cmd_view.setStyleSheet(
            "QTextEdit { background: #F0F2F5; color: #303133; "
            "font-family: Consolas; font-size: 12px; border: 1px solid #E4E7ED; "
            "border-radius: 4px; padding: 8px; }")
        cmd_view.setPlainText(
            f"git config --global --add safe.directory '{safe_dir_value}'")
        cmd_view.setMaximumHeight(60)
        root.addWidget(cmd_view)

        # 按钮
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        btn_cancel = QPushButton("取消")
        btn_cancel.setStyleSheet(
            "QPushButton { background-color: #F5F7FA; color: #606266; "
            "border: 1px solid #DCDFE6; padding: 8px 18px; border-radius: 4px; }"
            "QPushButton:hover { background-color: #E4E7ED; }")
        btn_cancel.setCursor(Qt.PointingHandCursor)
        btn_cancel.clicked.connect(self.reject)
        btn_row.addWidget(btn_cancel)

        btn_trust = QPushButton("✓ 信任并继续推送")
        btn_trust.setStyleSheet(
            "QPushButton { background-color: #67C23A; color: white; "
            "border: none; padding: 8px 18px; border-radius: 4px; font-weight: bold; }"
            "QPushButton:hover { background-color: #85CE61; }"
            "QPushButton:pressed { background-color: #5DAF34; }")
        btn_trust.setCursor(Qt.PointingHandCursor)
        btn_trust.setDefault(True)
        btn_trust.clicked.connect(self.accept)
        btn_row.addWidget(btn_trust)
        root.addLayout(btn_row)


# =============================================================================
# CredentialErrorDialog —— v12.10.35: token 过期 / 撤销 / 凭据缺失的友好弹窗
# =============================================================================
class CredentialErrorDialog(QDialog):
    """
    在 fetch / push / ls-remote 失败且 classify_git_error 返回 "auth" 时弹出。

    三个一键操作按钮：
      - 📂 打开 Windows 凭据管理器：用户可手工删除过期的 git:http://... 条目
      - 🌐 打开 GitLab PAT 页：用户可生成新 token
      - 🔁 测试连接：再跑一次 ls-remote，触发 GCM 弹窗重新登录
        （测试结果通过 sig_test_result 信号告诉调用方）

    本对话框只是"展示 + 触发动作"，不直接执行 push 重试 — 重试由调用方决定。
    """
    sig_test_result = Signal(bool, str)  # (success, message)

    def __init__(self, parent, repo_root: str, remote_url: str, branch: str,
                 stderr_excerpt: str):
        super().__init__(parent)
        self.setWindowTitle("⚠️ Git 认证失败")
        self.setMinimumSize(620, 480)
        self._repo_root = repo_root
        self._remote_url = remote_url
        self._branch = branch
        self._build_ui(stderr_excerpt)

    def _build_ui(self, stderr_excerpt: str):
        root = QVBoxLayout(self)
        root.setContentsMargins(16, 16, 16, 16)
        root.setSpacing(10)

        # 标题
        lbl_title = QLabel(
            "<span style='color:#F56C6C; font-size:14px; font-weight:bold;'>"
            "⚠️ Git 认证失败 — 可能是 GitLab Token 过期或被撤销</span>")
        lbl_title.setTextFormat(Qt.RichText)
        lbl_title.setStyleSheet("border: none;")
        root.addWidget(lbl_title)

        # 描述
        desc = QLabel(
            "Git 在与远端通信时被服务器拒绝。常见原因：<br>"
            "&nbsp;&nbsp;· Personal Access Token (PAT) 已过期（GitLab 默认 90 天 / 1 年）<br>"
            "&nbsp;&nbsp;· Token 被管理员撤销 / 权限范围不足<br>"
            "&nbsp;&nbsp;· 账号密码改了但 Windows 凭据管理器还存着旧凭据<br><br>"
            "选择下面其中一个操作来解决："
        )
        desc.setTextFormat(Qt.RichText)
        desc.setWordWrap(True)
        desc.setStyleSheet("color: #606266; font-size: 12px; border: none;")
        root.addWidget(desc)

        # git stderr 摘要
        if stderr_excerpt:
            err_view = QTextEdit()
            err_view.setReadOnly(True)
            err_view.setStyleSheet(
                "QTextEdit { background: #FEF0F0; color: #5A2828; "
                "font-family: Consolas; font-size: 11px; "
                "border: 1px solid #FBC4C4; border-radius: 4px; padding: 6px; }")
            err_view.setPlainText(stderr_excerpt.strip()[:1000])
            err_view.setMaximumHeight(100)
            root.addWidget(err_view)

        # 一键操作按钮（纵向，每个都有说明）
        def _make_action_btn(emoji: str, label: str, hint: str,
                             color: str, color_hover: str, on_click):
            btn = QPushButton()
            btn.setText(f"{emoji}  {label}\n    {hint}")
            btn.setStyleSheet(
                f"QPushButton {{ background-color: {color}; color: white; "
                f"border: none; padding: 10px 16px; border-radius: 4px; "
                f"text-align: left; font-size: 12px; }}"
                f"QPushButton:hover {{ background-color: {color_hover}; }}"
            )
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(on_click)
            return btn

        btn_cred_mgr = _make_action_btn(
            "📂", "打开 Windows 凭据管理器",
            "查找并删除条目 git:" + (self._remote_url or "<host>") +
            "，然后下次推送时 GCM 会重新让你登录",
            "#409EFF", "#66B1FF", self._on_open_cred_mgr,
        )
        root.addWidget(btn_cred_mgr)

        pat_url = gitlab_pat_settings_url(self._remote_url)
        btn_pat = _make_action_btn(
            "🌐", "打开 GitLab 生成新 Token",
            (pat_url or "(无法解析 URL)"),
            "#67C23A", "#85CE61", self._on_open_pat_page,
        )
        if not pat_url:
            btn_pat.setEnabled(False)
        root.addWidget(btn_pat)

        btn_test = _make_action_btn(
            "🔁", "测试连接（再次尝试，会触发 GCM 弹窗）",
            "重新跑 git ls-remote，凭据缺失时 GCM 会弹登录",
            "#E6A23C", "#EBB563", self._on_test_connection,
        )
        root.addWidget(btn_test)

        # 关闭
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        btn_close = QPushButton("关闭")
        btn_close.setStyleSheet(
            "QPushButton { background-color: #F5F7FA; color: #606266; "
            "border: 1px solid #DCDFE6; padding: 8px 18px; border-radius: 4px; }"
            "QPushButton:hover { background-color: #E4E7ED; }")
        btn_close.setCursor(Qt.PointingHandCursor)
        btn_close.clicked.connect(self.accept)
        btn_row.addWidget(btn_close)
        root.addLayout(btn_row)

    # ------------------- 按钮回调 -------------------
    def _on_open_cred_mgr(self):
        if not open_windows_credential_manager():
            QMessageBox.warning(
                self, "操作失败",
                "无法打开 Windows 凭据管理器，请手工运行：\n"
                "  control.exe /name Microsoft.CredentialManager")

    def _on_open_pat_page(self):
        url = gitlab_pat_settings_url(self._remote_url)
        if url:
            try:
                from PySide6.QtGui import QDesktopServices
                from PySide6.QtCore import QUrl
                QDesktopServices.openUrl(QUrl(url))
            except Exception:
                pass

    def _on_test_connection(self):
        """在对话框内同步跑一次 ls-remote，把结果显示在对话框内并 emit 信号。"""
        rc, _, err = run_git(
            self._repo_root, "ls-remote", "--heads", "origin", self._branch,
            timeout=30,
        )
        if rc == 0:
            QMessageBox.information(
                self, "测试连接",
                "✅ 连接成功，凭据有效。\n关闭本对话框后可重试推送。")
            self.sig_test_result.emit(True, "ok")
        else:
            err_type = classify_git_error(err)
            if err_type == "auth":
                QMessageBox.warning(
                    self, "测试连接",
                    f"❌ 仍是认证错误。请尝试先删除凭据管理器条目，"
                    f"再点本按钮 — GCM 应该会弹登录窗。\n\n{err.strip()[:400]}")
            else:
                QMessageBox.warning(
                    self, "测试连接",
                    f"❌ 失败：{err.strip()[:400]}")
            self.sig_test_result.emit(False, err.strip())


# =============================================================================
# GitlabPushProbeRunner —— Stage 1：探测（git status + git fetch + ahead/behind）
# =============================================================================
class GitlabPushProbeRunner(QThread):
    """
    Stage 1 后台线程：

    职责：
      - git status --porcelain  → 拿全仓库脏度，分类出 "勾选范围外的脏文件"
      - git fetch origin        → 同步远端 ref（push 前必做）
      - git rev-list 计 ahead/behind 数
      - 若 behind > 0，拉 origin/<branch> 上的最近 commit oneline 供 UI 展示

    设计：
      不要在线程里弹任何 UI；探测完毕后通过 sig_done 把 dict 抛给 UI 线程，
      由 UI 决定弹哪些对话框，然后再启动 Stage 2 Runner。
      这样规避了 QThread ↔ UI 之间的同步原语，简单稳定。
    """
    sig_log = Signal(str)            # 日志（HTML）
    sig_done = Signal(dict)          # 探测完毕，dict 字段见 _empty_result()

    def __init__(self, repo_root: str, branch: str, selected_files: List[str]):
        super().__init__()
        self.repo_root = repo_root
        self.branch = branch
        self.selected_files = list(selected_files or [])

    @staticmethod
    def _empty_result() -> dict:
        return {
            "ok": False,
            "error": "",
            "error_type": "",              # v12.10.35: "auth" / "network" / "other"
            "error_stderr": "",            # v12.10.35: 原始 stderr 供 CredentialErrorDialog 展示
            "dirty_outside_scope": [],      # [(code, path), ...]
            "ahead": 0,
            "behind": 0,
            "recent_log": [],               # origin/<br> 上比 HEAD 新的 commit oneline
            "selected_still_present": [],   # 探测时仍存在的勾选文件
        }

    def run(self):
        res = self._empty_result()
        try:
            # 1. status 拿全仓库脏度
            self.sig_log.emit("<span style='color:#909399;'>> 检查仓库工作区状态...</span>")
            all_dirty = git_status_porcelain(self.repo_root)

            sel_set = set(self.selected_files)
            outside = [(code, p) for (code, p) in all_dirty if p not in sel_set]
            res["dirty_outside_scope"] = outside

            # 顺便确认勾选文件仍在 status 里（边缘：用户在对话框开着时改了文件）
            present = [p for (_c, p) in all_dirty if p in sel_set]
            res["selected_still_present"] = present
            if len(present) < len(sel_set):
                missing = sel_set - set(present)
                self.sig_log.emit(
                    f"<span style='color:#E6A23C;'>  ⚠️ {len(missing)} 个勾选文件已不在变更列表中（可能在外部已清理）：</span>")
                for p in list(missing)[:5]:
                    self.sig_log.emit(f"<span style='color:#909399;'>     · {p}</span>")

            # 2. fetch
            self.sig_log.emit("<span style='color:#409EFF;'>> git fetch origin（同步远端，本地无修改）...</span>")
            rc, out, err = run_git(self.repo_root, "fetch", "origin", timeout=120)
            if rc != 0:
                # v12.10.35: 分类错误，供 UI 决定弹哪种对话框
                res["error_type"] = classify_git_error(err)
                res["error_stderr"] = err
                res["error"] = f"git fetch 失败：\n{err.strip() or out.strip()}"
                self.sig_log.emit(
                    f"<span style='color:#F56C6C;'>  ❌ {res['error']}</span>")
                self.sig_done.emit(res)
                return
            self.sig_log.emit("<span style='color:#67C23A;'>  ✅ fetch 完成</span>")

            # 3. ahead / behind
            ahead, behind = git_ahead_behind(self.repo_root, self.branch)
            res["ahead"] = ahead
            res["behind"] = behind
            self.sig_log.emit(
                f"<span style='color:#909399;'>  本地 vs origin/{self.branch}："
                f"领先 {ahead} 个，落后 {behind} 个</span>")

            # 4. 若 behind > 0，拉 origin 的最近 commit oneline 供 UI 展示
            if behind > 0:
                rc2, out2, _ = run_git(
                    self.repo_root, "log",
                    f"HEAD..origin/{self.branch}",
                    "--oneline", "-n10", "--no-decorate", timeout=15,
                )
                if rc2 == 0:
                    res["recent_log"] = [l for l in out2.splitlines() if l.strip()]

            res["ok"] = True

        except Exception as e:
            res["error"] = f"探测异常：{e}"
            self.sig_log.emit(
                f"<span style='color:#F56C6C;'>  ❌ {res['error']}</span>")

        self.sig_done.emit(res)


# =============================================================================
# GitlabPushExecuteRunner —— Stage 2：执行（add + commit + [pull] + push）
# =============================================================================
class GitlabPushExecuteRunner(QThread):
    """
    Stage 2 后台线程：完成真正的 git 写操作。

    决策由 UI 已经做完，传进来：
      - selected_files: 用户勾选的相对路径
      - commit_msg:     commit message
      - do_stash:       True = stash 收起范围外脏文件再推
      - do_pull:        True = push 前自动 git pull --no-rebase
      - branch:         当前分支名（push origin HEAD 等价于 push origin <branch>，
                        但 HEAD 写法对 detached HEAD 更稳健）

    完成方式：
      - 成功 → sig_done.emit(True, "✅ 推送完成", {...status_dict})
      - 失败 → sig_done.emit(False, error_msg, {...status_dict})
        status_dict 给 Stash Panel 展示用，包含：
          {
            'committed': True/False,
            'has_local_commit': True/False,
            'unpushed_commits': [...],
            'stash_pop_failed': True/False,
            'merge_conflict': True/False,
          }
    """
    sig_log = Signal(str)
    sig_progress = Signal(int, str)
    sig_done = Signal(bool, str, dict)

    def __init__(self, repo_root: str, branch: str, selected_files: List[str],
                 commit_msg: str, do_stash: bool, do_pull: bool):
        super().__init__()
        self.repo_root = repo_root
        self.branch = branch
        self.selected_files = list(selected_files or [])
        self.commit_msg = commit_msg
        self.do_stash = do_stash
        self.do_pull = do_pull
        self.is_cancelled = False

    # ------------------- 辅助 -------------------
    def _log(self, text: str, color: str = "#606266"):
        self.sig_log.emit(f"<span style='color:{color};'>{text}</span>")

    def _log_cmd(self, cmd_str: str):
        self.sig_log.emit(f"<span style='color:#409EFF;'>$ {cmd_str}</span>")

    def _git(self, *args: str, timeout: int = 60) -> Tuple[int, str, str]:
        """run_git 简化包装，记入日志。"""
        self._log_cmd("git " + " ".join(args))
        rc, out, err = run_git(self.repo_root, *args, timeout=timeout)
        if out.strip():
            for ln in out.strip().splitlines()[:20]:
                self._log(f"  {ln}", "#909399")
        if err.strip():
            color = "#F56C6C" if rc != 0 else "#E6A23C"
            for ln in err.strip().splitlines()[:20]:
                self._log(f"  {ln}", color)
        return rc, out, err

    def _make_status_dict(self, **kw) -> dict:
        # 始终包含未推送 commit 列表（供 Tab 2 暂存面板展示）
        unpushed = git_unpushed_log(self.repo_root, self.branch, limit=20)
        d = {
            "committed": kw.get("committed", False),
            "has_local_commit": bool(unpushed),
            "unpushed_commits": unpushed,
            "stash_pop_failed": kw.get("stash_pop_failed", False),
            "merge_conflict": kw.get("merge_conflict", False),
            # v12.10.35: 错误分类供 UI 决定弹哪种对话框
            "error_type": kw.get("error_type", ""),
            "error_stderr": kw.get("error_stderr", ""),
            "branch": self.branch,
            "repo_root": self.repo_root,
        }
        d.update({k: v for k, v in kw.items() if k not in d})
        return d

    # ------------------- 主流程 -------------------
    def run(self):
        stashed = False
        committed = False
        merge_conflict = False
        stash_pop_failed = False
        last_err_type = ""
        last_err_stderr = ""
        try:
            # ============================================================
            # v12.10.35: 0/N - PUSH 前凭据预检（避免生成 commit 后才发现 push 失败）
            # ============================================================
            self.sig_progress.emit(5, "预检凭据...")
            self._log("┌─ 预检：验证 GitLab 凭据", "#303133")
            rc, _, err = self._git(
                "ls-remote", "--heads", "origin", self.branch, timeout=15,
            )
            if rc != 0:
                err_type = classify_git_error(err)
                last_err_type = err_type
                last_err_stderr = err
                if err_type == "auth":
                    raise RuntimeError(
                        "Git 认证失败（token 可能过期）— 已在生成 commit 前拦截，"
                        "本地无任何变化。请按提示更新凭据后重试。")
                # 其它失败也提前停（避免后续白干）
                raise RuntimeError(f"凭据预检失败：{err.strip() or '未知错误'}")
            self._log("  ✅ 凭据有效", "#67C23A")
            # ============================================================
            # 1. 如果需要 stash：先 stage 要 commit 的文件，再 --keep-index stash
            #    其余 working tree 修改
            # ============================================================
            if self.do_stash:
                self.sig_progress.emit(10, "临时收起范围外脏文件...")
                self._log("┌─ 1/5：stash 范围外脏文件", "#303133")

                # 先 stage 要 commit 的文件（注意：路径要用 POSIX 风格，git 都接受）
                rc, _, err = self._git("add", "--", *self.selected_files, timeout=60)
                if rc != 0:
                    raise RuntimeError(f"git add 失败（pre-stash 阶段）：{err.strip()}")

                # stash 未 stage 的修改（含 untracked）
                stash_msg = f"SPAhub-auto-stash-{int(time.time())}"
                rc, _, err = self._git(
                    "stash", "push", "--keep-index", "--include-untracked",
                    "-m", stash_msg, timeout=120,
                )
                if rc != 0:
                    raise RuntimeError(f"git stash 失败：{err.strip()}")
                stashed = True
                self._log("  ✅ 范围外修改已临时收起", "#67C23A")
            else:
                # 不 stash 时：直接 add 勾选文件
                self.sig_progress.emit(15, "添加勾选文件到 git index...")
                self._log("┌─ 1/5：添加勾选文件", "#303133")
                rc, _, err = self._git("add", "--", *self.selected_files, timeout=60)
                if rc != 0:
                    raise RuntimeError(f"git add 失败：{err.strip()}")
                self._log(f"  ✅ 已添加 {len(self.selected_files)} 个文件", "#67C23A")

            # ============================================================
            # 2. commit
            # ============================================================
            self.sig_progress.emit(30, "本地 commit...")
            self._log("├─ 2/5：commit", "#303133")
            rc, out, err = self._git("commit", "-m", self.commit_msg, timeout=30)
            if rc != 0:
                combined = (out + "\n" + err).lower()
                if "nothing to commit" in combined or "no changes added" in combined:
                    # 罕见：探测时还有修改，到 commit 时已经没了
                    raise RuntimeError(
                        "nothing to commit — 文件可能在探测后被外部还原")
                raise RuntimeError(f"git commit 失败：{err.strip() or out.strip()}")
            committed = True
            self._log("  ✅ 本地 commit 已生成", "#67C23A")

            # ============================================================
            # 3. （可选）pull
            # ============================================================
            if self.do_pull:
                self.sig_progress.emit(50, "合并远端变更...")
                self._log("├─ 3/5：pull --no-rebase（自动合并）", "#303133")
                rc, out, err = self._git(
                    "pull", "--no-rebase", "origin", self.branch, timeout=180,
                )
                if rc != 0:
                    # 检查是否陷入 MERGING 状态 — 如是则 abort 自动回滚
                    merge_head = os.path.join(self.repo_root, ".git", "MERGE_HEAD")
                    if os.path.exists(merge_head):
                        merge_conflict = True
                        self._log("  ⚠️ 检测到 MERGE_HEAD，自动执行 merge --abort 回滚...",
                                  "#E6A23C")
                        self._git("merge", "--abort", timeout=30)
                        raise RuntimeError(
                            "git pull 自动合并冲突，已 abort 回滚。"
                            "本地 commit 保留，远端变更未合并。"
                            "请在本地手动 pull 解决冲突后再 push。")
                    raise RuntimeError(
                        f"git pull 失败（非合并冲突）：{err.strip() or out.strip()}")
                self._log("  ✅ 远端变更已合并", "#67C23A")
            else:
                self.sig_progress.emit(50, "跳过 pull（远端未领先）...")
                self._log("├─ 3/5：跳过 pull（远端未领先）", "#909399")

            # ============================================================
            # 4. push
            # ============================================================
            self.sig_progress.emit(75, "推送至 GitLab...")
            self._log("├─ 4/5：push origin HEAD", "#303133")
            rc, out, err = self._git("push", "origin", "HEAD", timeout=180)
            if rc != 0:
                # v12.10.35: push 阶段的认证失败（罕见但可能 — 比如 token 在
                # 预检和 push 之间被撤销）— 仍要分类好 error_type 让 UI 引导
                last_err_type = classify_git_error(err)
                last_err_stderr = err
                raise RuntimeError(
                    f"git push 失败：{err.strip() or out.strip()}\n"
                    "（本地 commit 已保留，可在 Git 暂存 tab 重试）")
            self._log("  ✅ push 成功，远端已同步", "#67C23A")

            # ============================================================
            # 5. （可选）stash pop
            # ============================================================
            if stashed:
                self.sig_progress.emit(90, "恢复 stash（范围外修改）...")
                self._log("└─ 5/5：stash pop（恢复范围外修改）", "#303133")
                rc, out, err = self._git("stash", "pop", timeout=30)
                if rc != 0:
                    # pop 冲突 — 推送本身成功，但用户的范围外修改没自动恢复
                    stash_pop_failed = True
                    self._log(
                        "  ⚠️ stash pop 失败（可能与远端 incoming 文件冲突）",
                        "#E6A23C")
                    self._log(
                        "  您的范围外修改安全保留在 git stash 中。"
                        "查看：git stash list  恢复：git stash pop  → 手工解决冲突",
                        "#E6A23C")
                else:
                    stashed = False
                    self._log("  ✅ 范围外修改已恢复", "#67C23A")
            else:
                self._log("└─ 5/5：无 stash，跳过", "#909399")

            self.sig_progress.emit(100, "推送完成")
            summary = "✅ 推送完成"
            if stash_pop_failed:
                summary = "⚠️ 推送成功，但 stash pop 失败 — 您的范围外修改保留在 git stash 中"
            self.sig_done.emit(True, summary,
                               self._make_status_dict(committed=committed,
                                                      stash_pop_failed=stash_pop_failed,
                                                      merge_conflict=merge_conflict))

        except Exception as e:
            # ============================================================
            # 失败兜底：若有 stash，尝试 pop 恢复（让用户回到 push 前状态）
            # ============================================================
            err_msg = str(e)
            if stashed:
                self._log("⚙ 失败兜底：尝试 git stash pop 恢复...", "#E6A23C")
                rc, _, err = self._git("stash", "pop", timeout=30)
                if rc != 0:
                    stash_pop_failed = True
                    self._log(
                        "  ⚠️ pop 也失败，stash 保留：git stash list 查看",
                        "#F56C6C")

            self.sig_progress.emit(100, "推送失败")
            self.sig_done.emit(False, err_msg,
                               self._make_status_dict(committed=committed,
                                                      stash_pop_failed=stash_pop_failed,
                                                      merge_conflict=merge_conflict,
                                                      error_type=last_err_type,
                                                      error_stderr=last_err_stderr))


# =============================================================================
# PullOnlyRunner —— v12.10.34：单纯 pull 后台线程（不 commit、不 push）
# =============================================================================
class PullOnlyRunner(QThread):
    """
    "仅 Pull 更新" 按钮的后台线程。用 `git pull --ff-only` 安全更新本地。

    为什么用 --ff-only：
      - 只在能 fast-forward 时拉取（远端纯领先、本地干净）；
      - 任何其他情况（本地领先、本地有脏文件与 incoming 冲突）— git 自己拒绝，
        不做任何修改、不留 MERGE_HEAD，永远不会污染本地历史；
      - 这是"我只想看看远端有没有新东西"语义最贴切的实现。

    流程（每一步都让 git CLI 自己挡风险）：
      1. git fetch origin                 — 同步远端 ref（本地工作区零变化）
      2. git merge --ff-only origin/<br>  — 仅 ff，不能 ff 就拒绝

    可能的结果：
      - 已最新 (Already up to date)              → sig_done(True, "✅ 已是最新", {...})
      - fast-forward 成功                         → sig_done(True, "✅ 已更新 N 个 commit", {...})
      - 本地有未推送 commit 导致 diverged          → sig_done(False, "diverged", {...})
      - 工作区脏文件与 incoming 冲突              → sig_done(False, "uncommitted_changes", {...})
      - 网络 / 认证 / 其它 git 错误               → sig_done(False, err_msg, {...})
    """
    sig_log = Signal(str)
    sig_done = Signal(bool, str, dict)
    # status_dict 字段：
    #   'reason': 'ok' / 'diverged' / 'dirty_tree' / 'network' / 'other'
    #   'before_commit': pull 前 HEAD 的 SHA（用于显示"更新了 X 个 commit"）
    #   'after_commit': pull 后 HEAD 的 SHA
    #   'updated_count': fast-forward 推进了几个 commit
    #   'stderr': 原始 stderr（失败时供诊断）

    def __init__(self, repo_root: str, branch: str):
        super().__init__()
        self.repo_root = repo_root
        self.branch = branch

    def _log(self, text: str, color: str = "#606266"):
        self.sig_log.emit(f"<span style='color:{color};'>{text}</span>")

    def _log_cmd(self, cmd_str: str):
        self.sig_log.emit(f"<span style='color:#409EFF;'>$ {cmd_str}</span>")

    def _git(self, *args: str, timeout: int = 60) -> Tuple[int, str, str]:
        self._log_cmd("git " + " ".join(args))
        rc, out, err = run_git(self.repo_root, *args, timeout=timeout)
        if out.strip():
            for ln in out.strip().splitlines()[:15]:
                self._log(f"  {ln}", "#909399")
        if err.strip():
            color = "#F56C6C" if rc != 0 else "#E6A23C"
            for ln in err.strip().splitlines()[:15]:
                self._log(f"  {ln}", color)
        return rc, out, err

    def run(self):
        status_dict = {
            "reason": "other",
            "before_commit": "",
            "after_commit": "",
            "updated_count": 0,
            "stderr": "",
            # v12.10.35: 统一 error_type 字段（push 与 pull 共享 CredentialErrorDialog 路由）
            "error_type": "",
        }
        try:
            # 记录 pull 前 HEAD
            rc, out, _ = run_git(self.repo_root, "rev-parse", "HEAD", timeout=10)
            if rc == 0:
                status_dict["before_commit"] = out.strip()[:12]

            self._log("┌─ 1/2：fetch 远端 ref", "#303133")
            rc, _, err = self._git("fetch", "origin", timeout=120)
            if rc != 0:
                # v12.10.35: 分类 auth / network，UI 据此决定是否弹 CredentialErrorDialog
                err_type = classify_git_error(err)
                # reason 字段保留原语义（给 _on_gitlab_pull_only_done 的引导文案用），
                # error_type 字段同 push 流程统一（给 CredentialErrorDialog 用）
                status_dict["reason"] = "auth" if err_type == "auth" else "network"
                status_dict["error_type"] = err_type
                status_dict["stderr"] = err.strip()
                self.sig_done.emit(False, f"git fetch 失败：{err.strip()}", status_dict)
                return
            self._log("  ✅ fetch 完成", "#67C23A")

            # 检查 ahead/behind — 决定下一步走向 + 给好的提示
            ahead, behind = git_ahead_behind(self.repo_root, self.branch)
            self._log(
                f"  本地 vs origin/{self.branch}："
                f"领先 {ahead} 个，落后 {behind} 个", "#909399")

            if behind == 0:
                self._log("└─ 2/2：远端无新 commit，跳过 merge", "#909399")
                msg = "✅ 已是最新（远端无新 commit）"
                if ahead > 0:
                    msg += f"（注意：本地领先 {ahead} 个未推送 commit）"
                status_dict["reason"] = "ok"
                self.sig_done.emit(True, msg, status_dict)
                return

            if ahead > 0:
                # 本地与远端 diverged — ff-only 必然失败，提前给好提示
                self._log(
                    "└─ 2/2：本地与远端分叉（ahead 且 behind），ff-only 无法处理",
                    "#E6A23C")
                status_dict["reason"] = "diverged"
                self.sig_done.emit(
                    False,
                    f"本地有 {ahead} 个未推送 commit，且远端领先 {behind} 个。\n"
                    "ff-only 模式无法合并分叉历史。请走 [🚀 推送至 GitLab] 流程 — \n"
                    "它会自动 pull (--no-rebase 含 merge commit) 再 push。",
                    status_dict)
                return

            # behind > 0 且 ahead == 0：纯远端领先，可以 fast-forward
            self._log("├─ 2/2：fast-forward merge", "#303133")
            rc, _, err = self._git(
                "merge", "--ff-only", f"origin/{self.branch}", timeout=60)
            if rc != 0:
                err_low = err.lower()
                if "would be overwritten" in err_low or "uncommitted" in err_low \
                        or "local changes" in err_low:
                    status_dict["reason"] = "dirty_tree"
                    status_dict["stderr"] = err.strip()
                    self.sig_done.emit(
                        False,
                        "工作区有未提交的修改会被远端覆盖。\n"
                        "请先 commit 或 stash，再尝试 Pull。",
                        status_dict)
                    return
                if "not possible to fast-forward" in err_low \
                        or "non-fast-forward" in err_low:
                    # 上面 ahead 检查已挡住，但兜底
                    status_dict["reason"] = "diverged"
                    status_dict["stderr"] = err.strip()
                    self.sig_done.emit(
                        False,
                        "无法 fast-forward（本地与远端历史已分叉）。\n"
                        "请走 [🚀 推送至 GitLab] 流程做完整 pull+push。",
                        status_dict)
                    return
                status_dict["stderr"] = err.strip()
                self.sig_done.emit(False, f"git merge 失败：{err.strip()}", status_dict)
                return

            # 成功 — 记录 pull 后 HEAD
            rc, out, _ = run_git(self.repo_root, "rev-parse", "HEAD", timeout=10)
            if rc == 0:
                status_dict["after_commit"] = out.strip()[:12]
            status_dict["updated_count"] = behind
            status_dict["reason"] = "ok"
            self._log(f"  ✅ 已 fast-forward {behind} 个 commit", "#67C23A")
            self.sig_done.emit(
                True,
                f"✅ 已更新 {behind} 个 commit 到本地",
                status_dict)

        except Exception as e:
            status_dict["stderr"] = str(e)
            self.sig_done.emit(False, f"Pull 异常：{e}", status_dict)


# =============================================================================
# GitStashPanel —— 右侧 Tab 2：Git 暂存面板
# =============================================================================
class GitStashPanel(QFrame):
    """
    Initial PGM 右侧"Git 暂存"Tab 的内容面板。

    展示 / 操作：
      - 仓库根目录、当前分支、远端 URL（顶部信息条）
      - 未推送的本地 commit 列表（git log origin/<br>..HEAD --oneline）
      - 推送状态摘要（最近一次 push 结果）
      - 操作按钮：
          🔄 刷新状态        重新跑 git status / ahead-behind
          🔁 重试推送        重新弹出主推送对话框
          📂 打开仓库根
          📋 复制 git 命令   将"手动恢复"用的 git 命令复制到剪贴板

    数据来源：
      - 由 InitPgmForm 通过 update_repo_info(repo_root, branch, remote_url) 推送
        基础信息；
      - 由 GitlabPushExecuteRunner 完成时通过 update_after_push(status_dict)
        刷新 commit 列表 + 状态摘要。
    """
    # 信号：用户点"🔁 重试推送"时通知 InitPgmForm
    sig_retry_push = Signal()

    def __init__(self):
        super().__init__()
        self._repo_root = ""
        self._branch = ""
        self._remote_url = ""
        self._build_ui()

    def _build_ui(self):
        self.setStyleSheet("QFrame { background: transparent; border: none; }")
        root = QVBoxLayout(self)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(8)

        # === 顶部信息条 ===
        info = QFrame()
        info.setStyleSheet(
            "QFrame { background-color: #F5F7FA; border: 1px solid #E4E7ED; "
            "border-radius: 4px; }")
        info_l = QVBoxLayout(info)
        info_l.setContentsMargins(10, 8, 10, 8)
        info_l.setSpacing(2)

        self.lbl_repo = QLabel("仓库根：(未识别)")
        self.lbl_branch = QLabel("分支：(未识别)")
        self.lbl_remote = QLabel("远端：(未识别)")
        for lbl in (self.lbl_repo, self.lbl_branch, self.lbl_remote):
            lbl.setStyleSheet(
                "color: #606266; font-size: 11px; font-family: Consolas; border: none;")
            lbl.setTextInteractionFlags(Qt.TextSelectableByMouse)
            lbl.setWordWrap(True)
            info_l.addWidget(lbl)
        root.addWidget(info)

        # === 状态摘要 ===
        self.lbl_status = QLabel("📭 暂无推送活动")
        self.lbl_status.setStyleSheet(
            "color: #909399; font-size: 13px; font-weight: bold; border: none; padding: 4px 0;")
        self.lbl_status.setWordWrap(True)
        root.addWidget(self.lbl_status)

        # === 未推送 commit 列表 ===
        lbl_unpushed = QLabel("📋 未推送 commit：")
        lbl_unpushed.setStyleSheet(
            "color: #606266; font-size: 12px; font-weight: bold; border: none;")
        root.addWidget(lbl_unpushed)

        self.commits_view = QTextEdit()
        self.commits_view.setReadOnly(True)
        self.commits_view.setStyleSheet(
            "QTextEdit { background-color: #FFFFFF; color: #303133; "
            "font-family: Consolas; font-size: 12px; border: 1px solid #E4E7ED; "
            "border-radius: 4px; padding: 8px; }")
        self.commits_view.setPlainText("(无)")
        root.addWidget(self.commits_view, 1)

        # === 操作按钮 ===
        btn_row = QHBoxLayout()
        btn_row.setSpacing(8)

        self.btn_refresh = QPushButton("🔄 刷新状态")
        self.btn_refresh.setStyleSheet(self._light_btn_style())
        self.btn_refresh.setCursor(Qt.PointingHandCursor)
        self.btn_refresh.clicked.connect(self.refresh_from_repo)
        btn_row.addWidget(self.btn_refresh)

        self.btn_retry = QPushButton("🔁 重试推送")
        self.btn_retry.setStyleSheet(
            "QPushButton { background-color: #409EFF; color: white; "
            "border: none; padding: 6px 14px; border-radius: 4px; "
            "font-size: 12px; font-weight: bold; }"
            "QPushButton:hover { background-color: #66B1FF; }"
            "QPushButton:pressed { background-color: #3A8EE6; }"
            "QPushButton:disabled { background-color: #A0CFFF; }")
        self.btn_retry.setCursor(Qt.PointingHandCursor)
        self.btn_retry.clicked.connect(self.sig_retry_push.emit)
        btn_row.addWidget(self.btn_retry)

        self.btn_open = QPushButton("📂 打开仓库根")
        self.btn_open.setStyleSheet(self._light_btn_style())
        self.btn_open.setCursor(Qt.PointingHandCursor)
        self.btn_open.clicked.connect(self._open_repo)
        btn_row.addWidget(self.btn_open)

        self.btn_copy = QPushButton("📋 复制恢复命令")
        self.btn_copy.setStyleSheet(self._light_btn_style())
        self.btn_copy.setCursor(Qt.PointingHandCursor)
        self.btn_copy.setToolTip("把手动 push 用的 git 命令复制到剪贴板")
        self.btn_copy.clicked.connect(self._copy_cmd)
        btn_row.addWidget(self.btn_copy)

        btn_row.addStretch()
        root.addLayout(btn_row)

    @staticmethod
    def _light_btn_style() -> str:
        return ("QPushButton { background-color: #F0F2F5; color: #606266; "
                "border: 1px solid #DCDFE6; padding: 6px 12px; "
                "border-radius: 4px; font-size: 12px; }"
                "QPushButton:hover { background-color: #E4E7ED; }")

    # ------------------- 对外 API -------------------
    def update_repo_info(self, repo_root: str, branch: str, remote_url: str):
        """由 InitPgmForm 在 update_paths 时调用，把基础信息推过来。"""
        self._repo_root = repo_root or ""
        self._branch = branch or ""
        self._remote_url = remote_url or ""

        self.lbl_repo.setText(f"仓库根：{self._repo_root or '(未识别)'}")
        self.lbl_branch.setText(f"分支：  {self._branch or '(未识别)'}")
        self.lbl_remote.setText(f"远端：  {self._remote_url or '(未识别)'}")

        # 信息齐备时刷新 commit 列表
        if self._repo_root and self._branch:
            self.refresh_from_repo()
        else:
            self.commits_view.setPlainText("(仓库未识别)")
            self.btn_retry.setEnabled(False)

    def refresh_from_repo(self):
        """重读 git 状态：未推送 commit 列表 + ahead 数。"""
        if not self._repo_root or not self._branch:
            return
        commits = git_unpushed_log(self._repo_root, self._branch, limit=30)
        if commits:
            self.commits_view.setPlainText("\n".join(commits))
            self.lbl_status.setText(
                f"📦 本地有 {len(commits)} 个未推送 commit — 可点 [🔁 重试推送]")
            self.lbl_status.setStyleSheet(
                "color: #E6A23C; font-size: 13px; font-weight: bold; border: none; padding: 4px 0;")
            self.btn_retry.setEnabled(True)
        else:
            self.commits_view.setPlainText("(无未推送 commit)")
            self.lbl_status.setText("✅ 本地与远端同步")
            self.lbl_status.setStyleSheet(
                "color: #67C23A; font-size: 13px; font-weight: bold; border: none; padding: 4px 0;")
            self.btn_retry.setEnabled(True)

    def update_after_push(self, success: bool, summary: str, status_dict: dict):
        """Stage 2 Runner 完成时调用，刷新摘要 + commit 列表。"""
        if success:
            self.lbl_status.setText(f"✅ 最近推送：{summary}")
            color = "#67C23A"
            if status_dict.get("stash_pop_failed"):
                self.lbl_status.setText(
                    "⚠️ 推送成功，但 stash pop 失败：执行 `git stash pop` 手动恢复")
                color = "#E6A23C"
        else:
            txt = f"❌ 最近推送失败：{summary}"
            if status_dict.get("merge_conflict"):
                txt += "（自动合并冲突，已 abort 回滚）"
            self.lbl_status.setText(txt)
            color = "#F56C6C"

        self.lbl_status.setStyleSheet(
            f"color: {color}; font-size: 13px; font-weight: bold; border: none; padding: 4px 0;")

        # 刷新 commit 列表
        commits = status_dict.get("unpushed_commits") or []
        if commits:
            self.commits_view.setPlainText("\n".join(commits))
        else:
            self.commits_view.setPlainText("(无未推送 commit)")

    # ------------------- 按钮回调 -------------------
    def _open_repo(self):
        if not self._repo_root:
            return
        try:
            if os.name == "nt":
                os.startfile(self._repo_root)
            else:
                subprocess.Popen(["xdg-open", self._repo_root])
        except Exception:
            pass

    def _copy_cmd(self):
        """复制手动 push 的 git 命令到剪贴板。"""
        if not self._repo_root or not self._branch:
            return
        cmd = (f"cd \"{self._repo_root}\" && "
               f"git pull --no-rebase origin {self._branch} && "
               f"git push origin {self._branch}")
        try:
            from PySide6.QtGui import QGuiApplication
            QGuiApplication.clipboard().setText(cmd)
            old_text = self.btn_copy.text()
            self.btn_copy.setText("✓ 已复制")
            from PySide6.QtCore import QTimer
            QTimer.singleShot(1500, lambda: self.btn_copy.setText(old_text))
        except Exception:
            pass


# =============================================================================
# 主入口 —— 给 InitPgmForm 调用
# =============================================================================
class GitlabPushPrepareRunner(QThread):
    """v12.10.60：点击「🚀 推送至 GitLab」后、弹文件树对话框之前的全部 git 采集子线程。

    背景：原 start_gitlab_push 在主线程同步串跑 find_repo_root /
    check_repo_access / git_current_branch / scan_pushable_sas_files /
    get_commit_identity 等 6~7 次 git 子进程，外加 get_push_credential_username
    的 `git credential fill`（timeout 8s）。网络盘上每次 git spawn 都慢，叠加
    起来主线程卡死 ≥5s、窗口假死。本线程把这些**非交互式**采集挪到后台，
    完成后 emit 结果 dict；所有对话框/弹窗仍由主线程的 gitlab_push_after_prepare
    处理（Qt 规定 UI 只能在主线程）。

    sig_done 的 dict 一定含 "kind"，取值：
      ok / no_repo / no_remote / dubious_ownership / not_a_repo /
      access_other / no_branch / detached / exception
    其余字段随 kind 而定（见各分支注释）。
    """
    sig_log = Signal(str)
    sig_done = Signal(dict)

    def __init__(self, base_path: str):
        super().__init__()
        self.base_path = base_path

    def run(self):
        try:
            self.sig_log.emit(
                "🚀 正在准备推送（读取仓库状态 / 扫描待推 .sas / 校验凭据）…"
            )
            base_path = self.base_path
            repo_root = find_repo_root(base_path)
            if not repo_root:
                self.sig_done.emit({"kind": "no_repo", "base_path": base_path})
                return

            remote_url = parse_git_remote_url(repo_root, "origin")
            if not remote_url:
                self.sig_done.emit({"kind": "no_remote", "repo_root": repo_root})
                return

            # 网络共享盘上 git 的 "dubious ownership" 是最常见的踩坑点：用户 A
            # clone 的仓库、用户 B 用 SPAhub 打开，所有 git 命令一律 fail。
            access_status, access_err, safe_dir_value = check_repo_access(repo_root)
            if access_status == "dubious_ownership":
                self.sig_done.emit({
                    "kind": "dubious_ownership", "repo_root": repo_root,
                    "remote_url": remote_url, "access_err": access_err,
                    "safe_dir_value": safe_dir_value,
                })
                return
            if access_status == "not_a_repo":
                self.sig_done.emit({"kind": "not_a_repo", "repo_root": repo_root,
                                    "access_err": access_err})
                return
            if access_status == "other":
                self.sig_done.emit({"kind": "access_other", "repo_root": repo_root,
                                    "access_err": access_err})
                return

            branch = git_current_branch(repo_root)
            if not branch:
                self.sig_done.emit({"kind": "no_branch", "repo_root": repo_root})
                return
            if branch == "HEAD":
                self.sig_done.emit({"kind": "detached", "repo_root": repo_root})
                return

            push_dirs = resolve_push_dirs(base_path, repo_root)
            file_rows = scan_pushable_sas_files(repo_root, push_dirs)
            commit_name, commit_email = get_commit_identity(repo_root)
            push_username = get_push_credential_username(remote_url)

            # list(...) 给 receiver 一份新拷贝（红线：不 emit 可被改的 mutable 引用）
            self.sig_done.emit({
                "kind": "ok",
                "repo_root": repo_root, "remote_url": remote_url, "branch": branch,
                "file_rows": list(file_rows),
                "commit_name": commit_name, "commit_email": commit_email,
                "push_username": push_username,
            })
        except Exception as e:
            self.sig_done.emit({"kind": "exception", "msg": str(e)})


def start_gitlab_push(form, base_path: str) -> bool:
    """
    InitPgmForm 的「🚀 推送至 GitLab」按钮回调入口。

    v12.10.60：仅做秒级 base_path 校验，随后把全部 git 采集交给
    GitlabPushPrepareRunner 子线程（避免点击后主界面卡死 ≥5s），立即返回。
    采集完成后由 form._on_gitlab_prepare_done → gitlab_push_after_prepare 接管
    对话框流程。dubious_ownership 信任成功后会再次调用本函数重新起子线程采集。

    返回：
      - True  表示已启动准备子线程
      - False 表示秒级前置校验失败（路径不存在），未启动线程
    """
    from ui_utils import show_dialog  # 局部 import 防循环依赖

    if not base_path or not os.path.isdir(base_path):
        show_dialog(form, "GitLab 推送",
                    f"路径不存在或不是目录：\n{base_path}", "error")
        return False

    # 进忙碌态（按钮变「⏳ 推送中...」并禁用 91/61/push）→ 起准备子线程
    form._gitlab_set_buttons_busy(True)
    runner = GitlabPushPrepareRunner(base_path)
    form._gitlab_prepare_runner = runner  # 持有引用防 GC
    runner.sig_log.connect(form.sig_log.emit)
    runner.sig_done.connect(form._on_gitlab_prepare_done)
    runner.start()
    return True


def gitlab_push_after_prepare(form, result: dict) -> None:
    """v12.10.60：准备子线程采集完成后，在主线程接管的对话框流程。

    覆盖原 start_gitlab_push 里 git 采集之后的全部分支（错误弹窗 / 信任流程 /
    文件树对话框 / 启动 Stage 1）。所有 git 采集已在子线程做完，这里只剩 UI。

    任意"未进入 Stage 1 / Pull"的提前返回路径都会把忙碌态复位
    （form._gitlab_set_buttons_busy(False)）；进入 Stage 1 / Pull 的路径不复位，
    由对应 runner 的 done 回调负责复位，使忙碌态从点击起连续到推送结束。
    """
    from ui_utils import show_dialog  # 局部 import 防循环依赖

    kind = result.get("kind", "")

    if kind == "exception":
        show_dialog(form, "GitLab 推送",
                    f"准备推送时出错：\n{result.get('msg', '')}", "error")
        form._gitlab_set_buttons_busy(False)
        return

    if kind == "no_repo":
        base_path = result.get("base_path", "") or getattr(form, "base_path", "")
        if base_path and os.path.isdir(base_path):
            cur = os.path.abspath(base_path)
            tried = []
            for _ in range(10):
                tried.append(cur)
                parent = os.path.dirname(cur)
                if parent == cur:
                    break
                cur = parent
            tried_lines = "\n".join(f"  · {p}\\.git" for p in tried[:8])
            show_dialog(
                form, "GitLab 推送",
                f"未找到 git 仓库根。已尝试以下路径但都不存在 .git：\n\n"
                f"{tried_lines}\n\n"
                f"请确认仓库已 clone 好，且 .git 目录可访问。\n"
                f"若 .git 确实存在但仍报错，可能是网络盘权限问题，"
                f"请在仓库根手动执行 `git status` 验证。",
                "error",
            )
        else:
            show_dialog(form, "GitLab 推送",
                        f"路径不存在或不是目录：\n{base_path}", "error")
        form._gitlab_set_buttons_busy(False)
        return

    if kind == "no_remote":
        repo_root = result.get("repo_root", "")
        show_dialog(form, "GitLab 推送",
                    f"仓库 {repo_root} 的 .git/config 没有 origin remote。\n"
                    "请先 git remote add origin <gitlab-url>。", "error")
        form._gitlab_set_buttons_busy(False)
        return

    if kind == "dubious_ownership":
        repo_root = result.get("repo_root", "")
        safe_dir_value = result.get("safe_dir_value", "")
        owner, cur_user = parse_dubious_ownership_info(result.get("access_err", ""))
        dlg_trust = SafeDirectoryDialog(form, repo_root, safe_dir_value, owner, cur_user)
        if dlg_trust.exec() != QDialog.Accepted:
            form._gitlab_set_buttons_busy(False)  # 用户拒绝信任 → 中止
            return
        ok, trust_err = trust_repo(safe_dir_value)
        if not ok:
            show_dialog(
                form, "GitLab 推送",
                f"添加 git safe.directory 信任失败：\n{trust_err}\n\n"
                f"可在命令行手动执行：\n"
                f"  git config --global --add safe.directory '{safe_dir_value}'",
                "error")
            form._gitlab_set_buttons_busy(False)
            return
        # 信任已加 → 重新起子线程跑一遍采集（不在主线程做 git；忙碌态保持）
        start_gitlab_push(form, getattr(form, "base_path", "") or repo_root)
        return

    if kind == "not_a_repo":
        repo_root = result.get("repo_root", "")
        show_dialog(form, "GitLab 推送",
                    f"路径 {repo_root} 不是合法 git 仓库：\n"
                    f"{result.get('access_err', '').strip()}", "error")
        form._gitlab_set_buttons_busy(False)
        return

    if kind == "access_other":
        show_dialog(form, "GitLab 推送",
                    f"git 仓库访问错误：\n{result.get('access_err', '').strip()}", "error")
        form._gitlab_set_buttons_busy(False)
        return

    if kind == "no_branch":
        show_dialog(form, "GitLab 推送",
                    "无法识别当前分支（仓库可访问但 git rev-parse HEAD 失败）。"
                    "请在仓库根手动执行 `git status` 排查。", "error")
        form._gitlab_set_buttons_busy(False)
        return

    if kind == "detached":
        show_dialog(form, "GitLab 推送",
                    "当前处于 detached HEAD 状态（HEAD 直接指向某 commit，不在任何分支上）。\n\n"
                    "请先 checkout 一个分支，例如：\n"
                    "  git checkout main\n\n"
                    "然后再尝试推送。", "warning")
        form._gitlab_set_buttons_busy(False)
        return

    if kind != "ok":
        # 兜底：未知 kind，复位忙碌态
        form._gitlab_set_buttons_busy(False)
        return

    # ---- kind == "ok"：弹文件树对话框（采集结果均已就绪，构造与 exec 都很快）----
    repo_root = result["repo_root"]
    remote_url = result["remote_url"]
    branch = result["branch"]
    file_rows = result.get("file_rows") or []

    dlg = SasFilesTreeDialog(form, repo_root, remote_url, branch, file_rows,
                             commit_author_name=result.get("commit_name", ""),
                             commit_author_email=result.get("commit_email", ""),
                             push_username=result.get("push_username", ""))
    res = dlg.exec()

    # 用户点了「🔄 仅 Pull 更新」— 转交 form 启动 PullOnlyRunner（其内部自管忙碌态）
    if res == SasFilesTreeDialog.PULL_REQUESTED:
        form._gitlab_start_pull_only(repo_root, branch, remote_url)
        return

    if res != QDialog.Accepted:
        form._gitlab_set_buttons_busy(False)
        return

    selected_files = dlg.selected_files
    commit_msg = dlg.commit_msg

    # 启动 Stage 1（form 负责把信号连好；忙碌态从点击起连续保持）
    form._gitlab_start_probe(repo_root, branch, remote_url, selected_files, commit_msg)
