# -*- coding: utf-8 -*-
"""
modules/acrf_annotation_update_runner.py
========================================
aCRF 模块「05 aCRF Update」独立子进程脚本（v12.10.118 新增）。

设计目的（同 m5_pds_runner / pdt_post_process_runner）：
  引擎 run_acrf_update 内部会拉起 autoanno（pdfminer 抽坐标）+ PyPDF2 读书签 +
  合并 xfdf，全是持 GIL 的重活。放 QThread 会饿死 UI，所以整段搬独立子进程：
  子进程有自己的 GIL，父进程只在另一线程阻塞读 stdout（I/O 等待释放 GIL）→ UI 流畅。

调用约定：
  父进程：subprocess.Popen([python, "-u", "-m", "modules.acrf_annotation_update_runner"],
                          stdin=PIPE, stdout=PIPE)
  父进程把参数 JSON 写入子进程 stdin（一行）：
      {
        "old_crf_pdf":     "...",
        "new_crf_pdf":     "...",
        "old_xfdf":        "...",
        "out_xfdf":        "...",
        "base_path":       "<csr_NN 目录>",
        "annodraft_parent":"<可选，autoanno_draft 包父目录；空则引擎按磁盘约定探测>",
        "annomap_name":    "annomap4update.xlsx"
      }
  子进程 stdout：逐行 JSON：
      {"level": "info"|"ok"|"warn"|"err", "msg": "<text>"}                普通日志
      {"level": "result", "ok": <bool>, "msg": "",                        最终结果（仅一条）
       "out_xfdf": "...", "annomap_path": "...",
       "page_map": {...}, "new_form_origin": {...},
       "covered_new_pages": [...], "blank_new_pages": [...],
       "added_forms": [...], "removed_forms": [...],
       "warnings": [...], "stats": {...}}
  exit code：0 成功 / 1 失败。

引擎为外部 sibling 包 acrf_update_spahub（v12.10.125 从 SPAhub 移出）：
部署在 Z:/projects/Z_PYTHON/aCRF/acrf_update_spahub（与 autoanno_draft 平级）。
本脚本在磁盘定位其父目录后 `from acrf_update_spahub.engine import run_acrf_update`。
（autoanno_draft 也是外部部门包，由引擎在磁盘按需定位。）
"""
import sys
import os
import json

# 装 no-window-popen patch：本子进程内任何后续 subprocess.Popen 默认带 CREATE_NO_WINDOW。
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    from _no_window_popen import install as _install_no_window_popen
    _install_no_window_popen()
except Exception:
    pass

# v12.10.121：兜底把 stdin/stdout 强制 UTF-8 —— 防 Windows 中文 locale 下 sys.stdin 默认
# cp936 读父进程写的 UTF-8 JSON，导致中文路径乱码。父进程已设 PYTHONIOENCODING，这里再保一道。
for _s in (sys.stdin, sys.stdout):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

_REAL_STDOUT = sys.stdout


def emit(level, msg="", **extra):
    obj = {"level": level, "msg": msg}
    if extra:
        obj.update(extra)
    try:
        _REAL_STDOUT.write(json.dumps(obj, ensure_ascii=False) + "\n")
        _REAL_STDOUT.flush()
    except Exception:
        pass


def main():
    try:
        raw = sys.stdin.readline()
        args = json.loads(raw) if raw.strip() else {}
    except Exception as e:  # noqa: BLE001
        emit("err", f"❌ 参数解析失败：{e}")
        emit("result", ok=False, msg=str(e))
        return 1

    # v12.10.125：引擎移出 SPAhub，作为外部 sibling 包 acrf_update_spahub（部署在
    #   Z:\projects\Z_PYTHON\aCRF\acrf_update_spahub，与 autoanno_draft 平级）。这里在磁盘
    #   定位其父目录、加入 sys.path 后按包导入引擎；可用 args["acrf_update_parent"] 覆盖父目录。
    _ACRF_UPDATE_PARENT_CANDIDATES = (
        r"Z:\projects\Z_PYTHON\aCRF",
        "/u01/app/sas/sas9.4/DocumentRepository/DDT/projects/Z_PYTHON/aCRF",
    )
    _explicit_parent = (args.get("acrf_update_parent") or "").strip()
    _cands = ([_explicit_parent] if _explicit_parent else []) + list(_ACRF_UPDATE_PARENT_CANDIDATES)
    _parent = ""
    for _p in _cands:
        try:
            if os.path.isfile(os.path.join(_p, "acrf_update_spahub", "__init__.py")):
                _parent = _p
                break
        except OSError:
            continue
    if not _parent:
        msg = ("❌ 找不到 acrf_update_spahub 包（需含 acrf_update_spahub/__init__.py）。"
               f"已探测：{_cands}")
        emit("err", msg)
        emit("result", ok=False, msg=msg)
        return 1
    if _parent not in sys.path:
        sys.path.insert(0, _parent)
    try:
        from acrf_update_spahub.engine import run_acrf_update as _run_acrf_update
        from acrf_update_spahub import engine as E  # 兼容 AcrfUpdateImportError 等属性引用
    except Exception as e:  # noqa: BLE001
        emit("err", f"❌ 导入 acrf_update_spahub.engine 失败（{_parent}）：{e}")
        import traceback
        for ln in traceback.format_exc().splitlines():
            emit("err", ln)
        emit("result", ok=False, msg=str(e))
        return 1

    _AUTOANNO_TAGS = ("[annomap_io]", "[anno_layout]", "[xfdf_writer]", "[autoanno]")

    def _log(*a):
        line = " ".join(str(x) for x in a)
        # v12.10.121：不展示 autoanno 的「表单未自动 map」提示（噪音，用户不需要）
        if "表单未自动" in line and "map" in line:
            return
        # v12.10.123：autoanno 内部标签行的 WARNING 降级为普通 log（黑），只有引擎自己 put 的
        #             两条 summary warning 才作为 ⚠（在结尾统一展示）。ERROR 仍照报。
        is_autoanno_internal = any(t in line for t in _AUTOANNO_TAGS)
        up = line.upper()
        if "ERROR" in up or "❌" in line or "🟥" in line:
            lvl = "err"
        elif ("WARNING" in up or "⚠" in line) and not is_autoanno_internal:
            lvl = "warn"
        elif "✅" in line:
            lvl = "ok"
        else:
            lvl = "info"
        emit(lvl, line)

    try:
        res = _run_acrf_update(
            old_crf_pdf=args["old_crf_pdf"],
            new_crf_pdf=args["new_crf_pdf"],
            old_xfdf=args["old_xfdf"],
            out_xfdf=args["out_xfdf"],
            run_autoanno=True,
            base_path=args.get("base_path", ""),
            prot=args.get("prot", ""),
            edc_path=args.get("edc_path", ""),
            annomap_name=args.get("annomap_name", "annomap4update.xlsx"),
            translate="none",   # 05 只做 update，不翻译
            override_pages=args.get("override_pages", []),   # #2：灰行覆盖 → 丢弃迁移、autoanno 重 map
            annodraft_parent=args.get("annodraft_parent", ""),  # autoanno_draft 仍外部定位
            log=_log,
        )
    except Exception as e:  # noqa: BLE001
        import traceback
        emit("err", f"❌ aCRF Update 运行异常：{e}")
        for ln in traceback.format_exc().splitlines():
            emit("err", ln)
        emit("result", ok=False, msg=str(e))
        return 1

    emit(
        "result", ok=True, msg="",
        out_xfdf=res.out_xfdf,
        annomap_path=res.annomap_path,
        page_map={str(k): v for k, v in res.page_map.items()},   # JSON key 需 str
        new_form_origin=res.new_form_origin,
        covered_new_pages=res.covered_new_pages,
        blank_new_pages=res.blank_new_pages,
        added_forms=res.added_forms,
        removed_forms=res.removed_forms,
        warnings=res.warnings,
        stats=res.stats,
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
