# -*- coding: utf-8 -*-
"""
modules/acrf_edc_recode.py
==========================
aCRF 模块 - 02 EDC Data Recode

职责：
  - 在 00_source_data 下自动定位最新解压目录（同 01 Unzip 的关键字优先策略）
  - 读取 utility/documentation/setup.xlsx 中宏变量 FILEPATH 的当前值
  - 用户点击 ▶ 运行：
      * 比较"用户所选目录名" vs "setup 中 FILEPATH"；
      * 不一致时弹窗：使用所选（重写 setup）/ 使用 setup 已有值 / 取消；
      * 然后调度 SingleBatchRunner 运行 21_edc_data_recode_call.sas
        （脚本本身用 %edc_data_recode(filepath=&filepath.); 直接读 setup 宏变量，无需改写 SAS）

v12.10.33（本次改动）：把 setup.FILEPATH 状态标签从只读 → 可点击补行（与 sdtm_import_edcdef
中 EDCSTD/EDCDEF 同款落地）：
  - 行不存在（红）/ 值为空（橙）时 cursor 变手形，点击 → 弹 question 弹窗确认（默认焦点
    主蓝"确认"按钮，回车快路）→ 立即写 setup → 切到绿色"已补行"态。
  - 已有合法值（灰白）/ setup.xlsx 缺失（红+不可点）/ 已补行（绿+不可点）→ Arrow cursor。
  - 运行时兜底：用户未点红框直接点运行且 FILEPATH 行不存在 → 弹 question 确认补行，
    确认后追加 setup 行并自动继续走"使用所选目录"分支（不再 return）。
  - 新增 _ClickableLabel（独立副本，避免跨模块依赖）+ _append_filepath_macro_row（本模块
    专属，模仿 sdtm_common.append_setup_macro_row 风格）+ _get_filepath_template_row（Z 盘
    template 优先 + hardcode 兜底）。
  - 抽 _apply_filepath_label_state — 5 态切换样式 + cursor 联动。
  - "点红框补行"与"点运行 SAS"完全分离：补行后不自动跑 SAS，用户须再点 ▶。

关键设计：
  - 写回 setup.xlsx 时：openpyxl load_workbook(data_only=False, keep_vba=保留)，仅改命中行的 C 列；
    保留其它单元格的样式/公式/格式串，避免破坏其他模块（TOC / Metadata）的读取。
  - FILEPATH 行的定位：B 列（下标 1）值不区分大小写匹配 "FILEPATH"，并跳过表头 Macro_Variable_Name。
    若多个 sheet 都有该列，仅改第一个命中（与 _read_filepath 行为对称）。
"""
import os
import re
import time
from datetime import datetime

from PySide6.QtWidgets import (QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                               QLineEdit, QFileDialog, QFrame, QProgressBar)
from PySide6.QtCore import Qt, Signal, QThread

from modules.tfls_batch_run import SingleBatchRunner
from modules.acrf_unzip import pick_latest_in_dir
from ui_utils import (show_dialog, show_choice_dialog, primary_outline_btn_style, scan_status_lbl_style,
                      primary_btn_style, danger_btn_style, success_btn_style, light_btn_style)


# v12.10.33: setup_template 路径 + FILEPATH 行缺失场景的兜底（与 sdtm_import_edcdef 同款）
# 含义：当 Z 盘 template 不可达时, 按这里的 description 给 setup.xlsx 补行。
# 实际写入的 value 始终来自 UI 上方所选目录（chosen_dir），不直接用这里的 macro_value。
_TEMPLATE_PATH = r"Z:\projects\utility\template\setup_template.xlsx"
_FILEPATH_HARDCODE = {
    "description": "EDC原始数据路径",
    "macro_name": "FILEPATH",
    "macro_value": "",
}


def _get_filepath_template_row():
    """v12.10.33: 取 FILEPATH 行的 description 默认值（用于补行）。

    与 sdtm_import_edcdef._get_edcdef_template_row 同款：
      Z 盘 setup_template.xlsx → 命中返回 template 来源
      不可达 → _FILEPATH_HARDCODE 兜底

    实际写入 value 由调用方传 chosen_dir，本函数仅供 description。
    """
    try:
        if os.path.isfile(_TEMPLATE_PATH):
            from openpyxl import load_workbook
            wb = load_workbook(_TEMPLATE_PATH, data_only=True, read_only=True)
            try:
                ws = wb["Macro Variables"] if "Macro Variables" in wb.sheetnames else wb.worksheets[0]
                for r in ws.iter_rows(min_row=2, values_only=True):
                    if len(r) >= 2 and r[1] and str(r[1]).strip().upper() == "FILEPATH":
                        desc = r[0] if r[0] is not None else ""
                        val = r[2] if len(r) > 2 and r[2] is not None else ""
                        return {
                            "description": str(desc),
                            "macro_name": "FILEPATH",
                            "macro_value": str(val),
                            "source": "template",
                        }
            finally:
                wb.close()
    except Exception:
        pass
    return {**_FILEPATH_HARDCODE, "source": "hardcode"}


# v12.10.97: FILEPATH 补行专用 —— 按 setup_template 相对位置插入的本地工具
# （独立副本，不跨模块依赖 sdtm_common；逻辑与 sdtm_common 的同名工具一致）
def _fp_template_macro_order():
    """读 _TEMPLATE_PATH 的 Macro Variables sheet → 有序宏名列表（大写）。任意失败 → []。"""
    order = []
    try:
        if not _TEMPLATE_PATH or not os.path.isfile(_TEMPLATE_PATH):
            return order
        import openpyxl
        wb = openpyxl.load_workbook(_TEMPLATE_PATH, data_only=True, read_only=True)
        try:
            ws = wb["Macro Variables"] if "Macro Variables" in wb.sheetnames else wb.worksheets[0]
            for r in ws.iter_rows(min_row=2, values_only=True):
                name = r[1] if len(r) > 1 else None
                if name and str(name).strip():
                    order.append(str(name).strip().upper())
        finally:
            wb.close()
    except Exception:
        return []
    return order


def _fp_compute_insert_idx(ws, macro_name):
    """按 template 顺序锚定最近的已存在邻居算插入行号；算不出 → None（退化为末尾追加）。"""
    target = (macro_name or "").strip().upper()
    order = _fp_template_macro_order()
    if target not in order:
        return None
    pos = order.index(target)
    setup_map = {}
    for ridx, r in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
        nm = r[1] if len(r) > 1 else None
        if nm and str(nm).strip():
            setup_map.setdefault(str(nm).strip().upper(), ridx)
    for prev in reversed(order[:pos]):
        if prev in setup_map:
            return setup_map[prev] + 1
    for nxt in order[pos + 1:]:
        if nxt in setup_map:
            return setup_map[nxt]
    return None


def _fp_shift_data_validations_down(ws, insert_idx, amount=1):
    """insert_rows 后把 >= insert_idx 的 data validation sqref 整体下移（单元格粒度重建）。"""
    try:
        from openpyxl.utils import get_column_letter
        dvs = ws.data_validations.dataValidation
    except Exception:
        return
    for dv in dvs:
        coords = []
        try:
            for rng in dv.sqref.ranges:
                for row in range(rng.min_row, rng.max_row + 1):
                    for col in range(rng.min_col, rng.max_col + 1):
                        nr = row + amount if row >= insert_idx else row
                        coords.append(f"{get_column_letter(col)}{nr}")
        except Exception:
            continue
        if coords:
            dv.sqref = " ".join(coords)


def _append_filepath_macro_row(setup_path: str, macro_value: str, description: str = ""):
    """v12.10.97: 在 setup.xlsx 的"Macro Variables"sheet 补 FILEPATH 行。

    行为变更（原 v12.10.33 为末尾追加）：按 setup_template 的相对位置插入
    （锚定最近的已存在邻居），并同步下移 data validation 下拉引用。
    _TEMPLATE_PATH 不可读 / FILEPATH 不在模板 / 前后邻居都不在 setup → 退化为末尾追加。

    与 sdtm_common.append_setup_macro_row 同款风格（不跨模块依赖，避免 acrf → sdtm 耦合）。
    调用方需先用 _read_filepath_macro 确认 row == 0 再调本函数。

    返回 (ok, msg, sheet_name, row_idx)。
    """
    if not os.path.isfile(setup_path):
        return False, f"找不到 setup.xlsx：{setup_path}", "", 0
    try:
        import openpyxl
        wb = openpyxl.load_workbook(setup_path, data_only=False)
    except Exception as e:
        return False, f"加载 setup.xlsx 失败：{e}", "", 0

    target_sheet = "Macro Variables"
    try:
        ws = wb[target_sheet] if target_sheet in wb.sheetnames else wb.worksheets[0]

        insert_idx = _fp_compute_insert_idx(ws, "FILEPATH")
        appended = insert_idx is None
        if appended:
            insert_idx = ws.max_row + 1
        else:
            ws.insert_rows(insert_idx)
            _fp_shift_data_validations_down(ws, insert_idx, 1)

        ws.cell(row=insert_idx, column=1).value = description
        ws.cell(row=insert_idx, column=2).value = "FILEPATH"
        ws.cell(row=insert_idx, column=3).value = macro_value
        wb.save(setup_path)
        sheet_title = ws.title
    except Exception as e:
        try:
            wb.close()
        except Exception:
            pass
        return False, f"写回 setup.xlsx 失败：{e}", "", 0
    finally:
        try:
            wb.close()
        except Exception:
            pass
    if appended:
        return True, f"已在 setup.xlsx[{sheet_title}] 末尾追加 FILEPATH = {macro_value}（未匹配到模板位置）", sheet_title, insert_idx
    return True, f"已在 setup.xlsx[{sheet_title}] 第 {insert_idx} 行按模板位置插入 FILEPATH = {macro_value}", sheet_title, insert_idx


# v12.10.33: 红色"行不存在/值为空"提示框 → 可点击 → 弹窗确认 → 立即补/写 setup
# 与 sdtm_import_edcdef._ClickableLabel 同款实现（独立副本，避免跨模块依赖）。
class _ClickableLabel(QLabel):
    """QLabel 子类：cursor 为 PointingHandCursor 时左键 click emit sig_clicked。"""
    sig_clicked = Signal()

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton and self.cursor().shape() == Qt.PointingHandCursor:
            self.sig_clicked.emit()
            event.accept()
            return
        super().mousePressEvent(event)



def _read_filepath_macro(setup_path: str):
    """
    读取 setup.xlsx 中 FILEPATH 的值。

    返回 (val: str, sheet_name: str, row_idx: int)。语义说明：
      - row_idx > 0  → 在 setup 里找到了 FILEPATH 行（val 可能为空字符串，表示 value 单元格未填）
      - row_idx == 0 → 连 FILEPATH 行都没找到（极端兜底；setup 模板恒含此行，常规不会触发）
    row_idx 为 1-based（openpyxl 习惯）。

    v12.4：调用方靠 (val, row) 二元组区分"值为空"与"找不到行"两种状态。
    """
    if not os.path.isfile(setup_path):
        return "", "", 0
    try:
        import openpyxl
        wb = openpyxl.load_workbook(setup_path, data_only=True, read_only=True)
        try:
            for ws in wb.worksheets:
                for r_idx, row in enumerate(ws.iter_rows(values_only=True), start=1):
                    if len(row) < 3:
                        continue
                    key = row[1]
                    if key is None:
                        continue
                    if str(key).strip().upper() == "FILEPATH":
                        val = row[2]
                        return ("" if val is None else str(val).strip()), ws.title, r_idx
        finally:
            wb.close()
    except Exception:
        pass
    return "", "", 0


def _write_filepath_macro(setup_path: str, new_value: str) -> tuple:
    """
    将 setup.xlsx 中 FILEPATH 的 C 列值改为 new_value。

    返回 (ok: bool, msg: str)。仅改命中行的 C 列单元格，保留其它单元格属性。
    """
    if not os.path.isfile(setup_path):
        return False, f"找不到 setup.xlsx：{setup_path}"
    try:
        import openpyxl
        # 关键：data_only=False + 不开 read_only，写回后保留公式/样式
        wb = openpyxl.load_workbook(setup_path, data_only=False)
    except Exception as e:
        return False, f"加载 setup.xlsx 失败：{e}"

    target_ws = None
    target_row = 0
    try:
        for ws in wb.worksheets:
            for r_idx in range(1, ws.max_row + 1):
                key_cell = ws.cell(row=r_idx, column=2).value
                if key_cell is None:
                    continue
                if str(key_cell).strip().upper() == "FILEPATH":
                    target_ws = ws
                    target_row = r_idx
                    break
            if target_ws is not None:
                break

        if target_ws is None:
            return False, "未在 setup.xlsx 中找到 FILEPATH 行"

        # v12.4 关键修复：openpyxl 的 ws.cell(row, col, value=v) 仅在"新建 cell"时初始化 value，
        # 对已存在的 cell 不会改写。已存 cell 必须显式 `.value = v` 赋值，否则旧版逻辑会
        # 静默不修改 setup.xlsx 还告知用户"已更新"。
        target_ws.cell(row=target_row, column=3).value = new_value
        wb.save(setup_path)
    except Exception as e:
        return False, f"写回 setup.xlsx 失败：{e}"
    finally:
        try:
            wb.close()
        except Exception:
            pass
    return True, f"已更新 setup.xlsx[{target_ws.title}] 的 FILEPATH = {new_value}"


# =============================================================================
# 后台路径扫描线程（v12.10.2 加入）
# 目的：消除 update_paths 在 Z:\ 网络盘上 listdir + openpyxl.load_workbook(setup.xlsx)
#       阻塞主线程的卡顿（openpyxl 读 setup.xlsx 一般 500ms-1.5s，叠加 listdir）。
# =============================================================================
class _RecodePathScanThread(QThread):
    """扫描 SAS 脚本 / setup.xlsx / 00_source_data 最新子目录 / FILEPATH 宏值"""
    finished_signal = Signal(int, dict)
    # results 字段：sas_exists/sas_path/setup_exists/setup_path/latest_dir/src_dir_exists/
    #              filepath_val/filepath_sheet/filepath_row

    def __init__(self, base_path: str, token: int, parent=None):
        super().__init__(parent)
        self.base_path = base_path or ""
        self.token = token

    def run(self):
        result = {
            "sas_exists": False, "sas_path": "",
            "setup_exists": False, "setup_path": "",
            "latest_dir": "",
            "src_dir_exists": False,
            "filepath_val": "", "filepath_sheet": "", "filepath_row": 0,
        }
        try:
            sas_path = os.path.join(self.base_path, "utility", "tools", "21_edc_data_recode_call.sas")
            result["sas_path"] = sas_path
            result["sas_exists"] = os.path.isfile(sas_path)

            setup_path = os.path.join(self.base_path, "utility", "documentation", "setup.xlsx")
            result["setup_path"] = setup_path
            setup_ok = os.path.isfile(setup_path)
            result["setup_exists"] = setup_ok

            # 扫 00_source_data 最新子目录
            src_dir = os.path.join(self.base_path, "00_source_data")
            result["src_dir_exists"] = os.path.isdir(src_dir)
            result["latest_dir"] = pick_latest_in_dir(src_dir, want_zip=False)

            # 读 setup.FILEPATH（这是大头：openpyxl.load_workbook 网络盘上 0.5-1.5s）
            if setup_ok:
                val, sheet, row = _read_filepath_macro(setup_path)
                result["filepath_val"] = val or ""
                result["filepath_sheet"] = sheet or ""
                result["filepath_row"] = int(row or 0)
        except Exception:
            pass
        self.finished_signal.emit(self.token, result)


# =============================================================================
# 左侧表单组件 EdcRecodeForm
# =============================================================================
class EdcRecodeForm(QFrame):
    """aCRF / 02 EDC Data Recode 的左侧业务表单"""

    sig_log = Signal(str)
    sig_status = Signal(str, str)
    sig_step_update = Signal(str)
    sig_run_started = Signal()
    sig_run_finished = Signal()

    def __init__(self):
        super().__init__()
        self.base_path = ""
        self._step_name = "EDC Data Recode"
        self._runner = None
        self._cancelled = False  # v12.10.17：用户主动中止标志，让 _on_runner_finished 检测后跳过常规处理
        # v12.10.2：后台路径扫描
        self._path_scan_token = 0
        self._retired_path_threads = []
        self._setup_ui()

    # ------------------------- UI -------------------------
    def _setup_ui(self):
        self.setObjectName("LeftPanel")
        self.setStyleSheet("#LeftPanel { background-color: #FFFFFF; border: 1px solid #E4E7ED; border-radius: 6px; }")
        form = QVBoxLayout(self)
        form.setAlignment(Qt.AlignTop)
        form.setContentsMargins(25, 25, 25, 25)
        form.setSpacing(15)

        # 顶部刷新栏
        top_bar = QHBoxLayout()
        self.refresh_btn = QPushButton("🔄 刷新源文件")
        # v12.10.65：统一改用 home"📁 系统文件复制"同款蓝色外框样式
        self.refresh_btn.setStyleSheet(primary_outline_btn_style())
        self.refresh_btn.setCursor(Qt.PointingHandCursor)
        top_bar.addWidget(self.refresh_btn)
        self.scan_lbl = QLabel("")
        self.scan_lbl.setStyleSheet(scan_status_lbl_style())
        top_bar.addWidget(self.scan_lbl)
        top_bar.addStretch()
        form.addLayout(top_bar)

        title = QLabel("调用 21_edc_data_recode_call.sas，对 EDC 数据做 format / 重编码处理。")
        title.setStyleSheet("color: #303133; font-weight: bold; font-size: 14px; border: none;")
        title.setWordWrap(True)
        form.addWidget(title)

        # 行 1：00_source_data 下的目录（filepath）
        row_dir = QHBoxLayout()
        lbl_dir = QLabel("EDC 数据目录：")
        lbl_dir.setStyleSheet("border: none; color: #606266; min-width: 130px;")
        row_dir.addWidget(lbl_dir)
        self.dir_entry = QLineEdit()
        self.dir_entry.setStyleSheet("padding: 6px; border: 1px solid #DCDFE6; border-radius: 4px;")
        self.dir_entry.setPlaceholderText("等待 4 级路径填全后自动定位…")
        row_dir.addWidget(self.dir_entry, 1)
        self.btn_browse_dir = QPushButton("浏览")
        # v12.10.68：统一改用 helper（与 TOC ▶初版TOC/🟥中止/📂打开TOC 视觉一致）
        self.btn_browse_dir.setStyleSheet(light_btn_style())
        self.btn_browse_dir.setCursor(Qt.PointingHandCursor)
        self.btn_browse_dir.clicked.connect(self._on_browse_dir)
        row_dir.addWidget(self.btn_browse_dir)
        form.addLayout(row_dir)

        # 行 2：setup.xlsx
        row_setup = QHBoxLayout()
        lbl_setup = QLabel("setup.xlsx：")
        lbl_setup.setStyleSheet("border: none; color: #606266; min-width: 130px;")
        row_setup.addWidget(lbl_setup)
        self.setup_entry = QLineEdit()
        self.setup_entry.setReadOnly(True)
        self.setup_entry.setStyleSheet(
            "padding: 6px; border: 1px solid #DCDFE6; border-radius: 4px; background: #F5F7FA; color: #606266;")
        row_setup.addWidget(self.setup_entry, 1)
        self.btn_open_setup = QPushButton("📂 打开")
        # v12.10.68：统一改用 helper（与 TOC ▶初版TOC/🟥中止/📂打开TOC 视觉一致）
        self.btn_open_setup.setStyleSheet(light_btn_style())
        self.btn_open_setup.setCursor(Qt.PointingHandCursor)
        self.btn_open_setup.clicked.connect(self._open_setup_file)
        row_setup.addWidget(self.btn_open_setup)
        form.addLayout(row_setup)

        # 行 2-补充：setup 中 FILEPATH 当前值（可点击补行/覆盖）
        # v12.10.33: 从 QLabel → _ClickableLabel — 红/橙态 cursor 变手形, 点击 → 弹窗 → 立即写 setup
        row_macro = QHBoxLayout()
        lbl_macro = QLabel("setup.FILEPATH：")
        lbl_macro.setStyleSheet("border: none; color: #606266; min-width: 130px;")
        row_macro.addWidget(lbl_macro)
        self.macro_lbl = _ClickableLabel("(尚未读取)")
        self.macro_lbl.setStyleSheet(
            "border: 1px solid #E4E7ED; background: #F8F9FA; color: #606266; padding: 6px 10px; border-radius: 4px;")
        self.macro_lbl.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.macro_lbl.sig_clicked.connect(self._on_click_filepath_macro)
        row_macro.addWidget(self.macro_lbl, 1)
        form.addLayout(row_macro)

        # 行 3：21_edc_data_recode_call.sas
        row_sas = QHBoxLayout()
        lbl_sas = QLabel("调用脚本：")
        lbl_sas.setStyleSheet("border: none; color: #606266; min-width: 130px;")
        row_sas.addWidget(lbl_sas)
        self.sas_entry = QLineEdit()
        self.sas_entry.setReadOnly(True)
        self.sas_entry.setStyleSheet(
            "padding: 6px; border: 1px solid #DCDFE6; border-radius: 4px; background: #F5F7FA; color: #606266;")
        row_sas.addWidget(self.sas_entry, 1)
        self.btn_open_sas = QPushButton("📂 打开")
        # v12.10.68：统一改用 helper（与 TOC ▶初版TOC/🟥中止/📂打开TOC 视觉一致）
        self.btn_open_sas.setStyleSheet(light_btn_style())
        self.btn_open_sas.setCursor(Qt.PointingHandCursor)
        self.btn_open_sas.clicked.connect(self._open_sas_file)
        row_sas.addWidget(self.btn_open_sas)
        form.addLayout(row_sas)

        # 进度条
        self.prog = QProgressBar()
        self.prog.setVisible(False)
        self.prog.setFixedHeight(4)
        self.prog.setTextVisible(False)  # v12.10.13：4px 太矮装不下文字，关闭百分比显示避免和上方 label 重叠
        form.addWidget(self.prog)

        # 运行按钮 + 中止按钮（运行中互斥显示）
        btn_row = QHBoxLayout()
        self.btn_run = QPushButton("▶ 运行 EDC Recode")
        # v12.10.68：统一改用 helper（与 TOC ▶初版TOC/🟥中止/📂打开TOC 视觉一致）
        self.btn_run.setStyleSheet(primary_btn_style())
        self.btn_run.setCursor(Qt.PointingHandCursor)
        self.btn_run.clicked.connect(self.run_edc_recode)
        btn_row.addWidget(self.btn_run)

        # v12.6：中止按钮（与 acrf_unzip 一致策略）
        self.btn_cancel = QPushButton("🟥 中止")
        # v12.10.68：统一改用 helper（与 TOC ▶初版TOC/🟥中止/📂打开TOC 视觉一致）
        self.btn_cancel.setStyleSheet(danger_btn_style())
        self.btn_cancel.setCursor(Qt.PointingHandCursor)
        self.btn_cancel.setVisible(False)
        self.btn_cancel.clicked.connect(self._on_cancel_run)
        btn_row.addWidget(self.btn_cancel)

        self.btn_open_src = QPushButton("📂 打开 00_source_data")
        # v12.10.68：统一改用 helper（与 TOC ▶初版TOC/🟥中止/📂打开TOC 视觉一致）
        self.btn_open_src.setStyleSheet(success_btn_style())
        self.btn_open_src.setCursor(Qt.PointingHandCursor)
        self.btn_open_src.clicked.connect(self._open_src_dir)
        btn_row.addWidget(self.btn_open_src)
        btn_row.addStretch()
        form.addLayout(btn_row)
        form.addStretch()

    # ------------------------- 路径推送 / 自动探测 -------------------------
    def update_paths(self, base_path):
        """
        由主控推送路径；自动定位最新解压目录、setup.xlsx、调用脚本，并读取宏变量。

        v12.10.2：IO（pick_latest_in_dir + openpyxl 读 setup.xlsx）拆到后台线程。
        主线程立即清空 + 显示 ⏳ 占位，IO 完成后回主线程更新。
        """
        self.base_path = base_path or ""

        # 主线程立即清空 + 占位，避免显示旧值
        self.sas_entry.setText("")
        self.setup_entry.setText("")
        self.dir_entry.clear()
        self.dir_entry.setPlaceholderText("⏳ 扫描 00_source_data 中…")
        self.macro_lbl.setText("⏳ 加载 setup.xlsx 中…")
        self.macro_lbl.setStyleSheet(
            "border: 1px solid #C0CAE1; background: #EEF2FB; color: #409EFF; padding: 6px 10px; border-radius: 4px;")
        self._set_scanning_hint(True)

        # 启动后台扫描
        self._path_scan_token += 1
        token = self._path_scan_token
        thread = _RecodePathScanThread(self.base_path, token, parent=self)
        thread.finished_signal.connect(self._on_path_scan_done)
        self._retired_path_threads.append(thread)
        thread.start()

    def _set_scanning_hint(self, on: bool):
        if on:
            self.scan_lbl.setText("⏳ 扫描中…")
            self.scan_lbl.setStyleSheet(scan_status_lbl_style("#409EFF"))
        else:
            self.scan_lbl.setText("")

    def _on_path_scan_done(self, token: int, result: dict):
        """后台扫描完成 → 主线程更新控件。"""
        if token != self._path_scan_token:
            return  # 过期结果丢弃

        # 1. SAS 脚本
        if result.get("sas_exists"):
            self.sas_entry.setText(result.get("sas_path", ""))

        # 2. setup.xlsx
        setup_path = result.get("setup_path", "")
        setup_ok = result.get("setup_exists", False)
        if setup_ok:
            self.setup_entry.setText(setup_path)

        # 3. 00_source_data 最新子目录
        latest_dir = result.get("latest_dir", "")
        src_ok = result.get("src_dir_exists", False)
        if latest_dir:
            self.dir_entry.setText(latest_dir)
        else:
            self.dir_entry.clear()
            if src_ok:
                self.dir_entry.setPlaceholderText("00_source_data 下未找到子目录")
            else:
                self.dir_entry.setPlaceholderText("00_source_data 目录不存在")

        # 4. FILEPATH 宏 — 四态着色 + 可点击补行（v12.10.33）
        if not setup_ok:
            self._apply_filepath_label_state("noFile", text="(setup.xlsx 不存在)")
        else:
            val = result.get("filepath_val", "")
            sheet = result.get("filepath_sheet", "")
            row = int(result.get("filepath_row", 0))
            if val:
                self._apply_filepath_label_state("ok", text=f"{val}  [{sheet} 行 {row}]")
            elif row > 0:
                self._apply_filepath_label_state(
                    "empty", text=f"(值为空，点击写入上方所选目录)  [{sheet} 行 {row}]"
                )
            else:
                self._apply_filepath_label_state(
                    "noRow", text="(setup.xlsx 中未找到 FILEPATH 行，点击补行)"
                )

        self._set_scanning_hint(False)

        sender = self.sender()
        if sender is not None:
            try:
                sender.finished.connect(sender.deleteLater)
            except Exception:
                pass

    # ------------------------- v12.10.33: 状态切换 + 点击补行 -------------------------
    # 与 sdtm_import_edcdef 中 EDCSTD/EDCDEF 同款落地：
    #   红框（行不存在）/ 橙框（值为空）→ cursor=PointingHand, click 触发补/写
    #   灰白（已有值）/ 绿（已补行）/ 红+noFile → cursor=Arrow, 不响应
    #   写完后切到 "filled" 绿态，不再可点（须改 setup.xlsx 重启）
    _FILEPATH_STATE_STYLES = {
        "ok":     ("border: 1px solid #E4E7ED; background: #F8F9FA; color: #303133;", Qt.ArrowCursor,        False),
        "empty":  ("border: 1px solid #F5DAB1; background: #FDF6EC; color: #E6A23C;", Qt.PointingHandCursor, True),
        "noRow":  ("border: 1px solid #FBC4C4; background: #FEF0F0; color: #F56C6C;", Qt.PointingHandCursor, True),
        "noFile": ("border: 1px solid #FBC4C4; background: #FEF0F0; color: #F56C6C;", Qt.ArrowCursor,        False),
        "filled": ("border: 1px solid #B3E19D; background: #F0F9EB; color: #67C23A;", Qt.ArrowCursor,        False),
    }
    _LABEL_BASE = " padding: 6px 10px; border-radius: 4px;"

    def _apply_filepath_label_state(self, state: str, text: str):
        style_core, cursor, clickable = self._FILEPATH_STATE_STYLES.get(
            state, self._FILEPATH_STATE_STYLES["ok"]
        )
        self.macro_lbl.setText(text)
        self.macro_lbl.setStyleSheet(style_core + self._LABEL_BASE)
        self.macro_lbl.setCursor(cursor)
        self.macro_lbl.setToolTip("点击：把上方所选目录写入 setup.xlsx" if clickable else "")

    def _on_click_filepath_macro(self):
        """v12.10.33: setup.FILEPATH 红/橙框点击 → 弹窗确认 → 写 setup。

        与 sdtm_import_edcdef 中 EDCSTD/EDCDEF 同款交互模式：
          - noRow:  行不存在 → 按 template 补行（含 description）+ value=dir_entry 文本
          - empty:  行存在 value 空 / 不一致 → write_setup_macro 覆盖

        前置约束：dir_entry 必须有值（用户应已选好 00_source_data 子目录）。
        本功能仅"补 setup"，不会触发 SAS 运行 — 用户后续要点 ▶ 才跑（与 EDCSTD/EDCDEF 一致）。
        """
        setup_path = self.setup_entry.text().strip()
        if not setup_path or not os.path.isfile(setup_path):
            show_dialog(self, "提示", "setup.xlsx 不可用，无法操作。", "warning")
            return

        chosen_dir = self.dir_entry.text().strip()
        if not chosen_dir:
            show_dialog(
                self, "目录未选择",
                "上方目录输入框为空，无法写入 setup。\n"
                "请先在 00_source_data 下选择/输入解压目录名。",
                "warning"
            )
            return

        cur_val, sheet, row = _read_filepath_macro(setup_path)

        if row == 0:
            # 行不存在 → 弹窗确认 → 按 template 补行
            confirm = show_dialog(
                self, "补 FILEPATH 行",
                f"setup.xlsx 中未找到 FILEPATH 行。\n\n"
                f"将增加一行：\n"
                f"  • Macro_Variable_Name = FILEPATH\n"
                f"  • Macro_Variable_Value = {chosen_dir}（来自上方目录输入框）\n\n"
                f"确认继续？",
                "question"
            )
            if not confirm:
                self.sig_log.emit("<span style='color:#909399;'>已取消补 FILEPATH 行。</span>")
                return
            tpl = _get_filepath_template_row()
            ok, msg, sheet_n, row_n = _append_filepath_macro_row(
                setup_path, macro_value=chosen_dir, description=tpl["description"]
            )
            if not ok:
                show_dialog(self, "补 FILEPATH 行失败", msg, "error")
                self.sig_log.emit(f"<span style='color:#F56C6C;'>❌ {msg}</span>")
                return
            src_tag = "template" if tpl["source"] == "template" else "hardcode 兜底"
            self.sig_log.emit(f"<span style='color:#67C23A;'>➕ {msg}（描述来自 {src_tag}）</span>")
            self._apply_filepath_label_state(
                "filled", text=f"✅ 已补行 FILEPATH = {chosen_dir}  [{sheet_n} 行 {row_n}]"
            )
        else:
            # row > 0: 值为空 / 不一致 → 弹窗确认覆盖
            old_disp = cur_val if cur_val else "(空)"
            confirm = show_dialog(
                self, "覆盖 setup.FILEPATH",
                f"setup.xlsx（{sheet} 行 {row}）当前 FILEPATH = {old_disp}\n\n"
                f"将覆盖为：{chosen_dir}（来自上方目录输入框）\n\n"
                f"确认继续？",
                "question"
            )
            if not confirm:
                self.sig_log.emit("<span style='color:#909399;'>已取消覆盖 setup.FILEPATH。</span>")
                return
            ok, msg = _write_filepath_macro(setup_path, chosen_dir)
            if not ok:
                show_dialog(self, "更新 setup 失败", msg, "error")
                self.sig_log.emit(f"<span style='color:#F56C6C;'>❌ {msg}</span>")
                return
            self.sig_log.emit(f"<span style='color:#67C23A;'>✏️ {msg}</span>")
            self._apply_filepath_label_state(
                "filled", text=f"✅ 已写入 FILEPATH = {chosen_dir}  [{sheet} 行 {row}]"
            )

    def set_wait_hint(self, show):
        if show:
            self.scan_lbl.setText("⏳ 等待填写完整路径...")
            self.scan_lbl.setStyleSheet(scan_status_lbl_style())
        else:
            self.scan_lbl.setText("")

    # ------------------------- 浏览 / 打开 -------------------------
    def _on_browse_dir(self):
        """浏览选择 00_source_data 下的解压目录（QFileDialog 的目录模式）"""
        start_dir = ""
        if self.base_path:
            cand = os.path.join(self.base_path, "00_source_data")
            start_dir = cand if os.path.isdir(cand) else self.base_path
        path = QFileDialog.getExistingDirectory(self, "选择 EDC 数据目录", start_dir)
        if path:
            # 通常只需要目录名（与 setup.FILEPATH 的语义一致：相对 00_source_data 的目录名）
            self.dir_entry.setText(os.path.basename(path.rstrip("\\/")))

    def _open_setup_file(self):
        p = self.setup_entry.text().strip()
        if p and os.path.isfile(p):
            os.startfile(p)
        else:
            show_dialog(self, "提示", "找不到 setup.xlsx 文件。", "warning")

    def _open_sas_file(self):
        p = self.sas_entry.text().strip()
        if p and os.path.isfile(p):
            os.startfile(p)
        else:
            show_dialog(self, "提示", "找不到 21_edc_data_recode_call.sas 文件。", "warning")

    def _open_src_dir(self):
        if not self.base_path:
            return
        src = os.path.join(self.base_path, "00_source_data")
        if os.path.isdir(src):
            os.startfile(src)

    # ------------------------- 全局快捷键钩子 -------------------------
    def action_refresh(self):
        btn = getattr(self, "refresh_btn", None)
        if btn is not None and btn.isEnabled():
            btn.click()

    def action_run(self):
        if self.btn_run.isEnabled():
            self.btn_run.click()

    # ------------------------- 运行入口 -------------------------
    def run_edc_recode(self):
        """点击 ▶ 运行：交叉核查 setup vs 用户值 → 决定是否改 setup → 跑 SAS"""
        chosen_dir = self.dir_entry.text().strip()
        # 用户可能输入完整路径，也可能只输入目录名 — 一律取 basename
        if chosen_dir:
            chosen_dir = os.path.basename(chosen_dir.rstrip("\\/"))
        if not chosen_dir:
            show_dialog(self, "提示", "EDC 数据目录不能为空，请填写或浏览选择。", "warning")
            return

        # 校验该目录在 00_source_data 下确实存在（与 SAS 宏读 &filepath. 后的拼接一致）
        if self.base_path:
            full = os.path.join(self.base_path, "00_source_data", chosen_dir)
            if not os.path.isdir(full):
                ok = show_dialog(
                    self, "目录不存在",
                    f"00_source_data 下未找到子目录：{chosen_dir}\n仍要继续运行 SAS 吗？",
                    "question"
                )
                if not ok:
                    return

        sas_path = self.sas_entry.text().strip()
        if not sas_path or not os.path.isfile(sas_path):
            show_dialog(self, "错误", f"找不到 SAS 调用脚本：\n{sas_path}", "error")
            return

        setup_path = self.setup_entry.text().strip()
        if not setup_path or not os.path.isfile(setup_path):
            show_dialog(self, "错误", f"找不到 setup.xlsx：\n{setup_path}", "error")
            return

        # 防重入
        if self._runner is not None and self._runner.isRunning():
            self.sig_log.emit("<span style='color:#E6A23C;'>⏳ 上一次 EDC Recode 仍在运行中，请稍候…</span>")
            return

        # 读取 setup.FILEPATH 并比较
        cur_val, sheet, row = _read_filepath_macro(setup_path)
        if row == 0:
            # v12.10.33: 行不存在 → 不再弹错 return，改为弹窗征询补行
            # （正常路径下用户应已先点红框补行；这里是"未点红框直接点运行"的兜底）
            confirm = show_dialog(
                self, "EDC Recode — setup.xlsx 中无 FILEPATH 行",
                "setup.xlsx 中未找到 FILEPATH 宏变量行，无法直接运行 SAS。\n\n"
                "将在 setup 中增加一行：\n"
                f"  • Macro_Variable_Name = FILEPATH\n"
                f"  • Macro_Variable_Value = {chosen_dir}（来自上方所选目录）\n\n"
                "确认补行后继续运行？",
                "question"
            )
            if not confirm:
                self.sig_log.emit("<span style='color:#909399;'>已取消 EDC Recode。</span>")
                return
            tpl = _get_filepath_template_row()
            ok, msg, sheet, row = _append_filepath_macro_row(
                setup_path, macro_value=chosen_dir, description=tpl["description"]
            )
            if not ok:
                show_dialog(self, "补 FILEPATH 行失败", msg, "error")
                self.sig_log.emit(f"<span style='color:#F56C6C;'>❌ {msg}</span>")
                return
            src_tag = "template" if tpl["source"] == "template" else "hardcode 兜底"
            self.sig_log.emit(f"<span style='color:#67C23A;'>➕ {msg}（描述来自 {src_tag}）</span>")
            self._apply_filepath_label_state(
                "filled", text=f"✅ 已补行 FILEPATH = {chosen_dir}  [{sheet} 行 {row}]"
            )
            cur_val = chosen_dir  # 让下方"已一致"分支跳过弹窗，直接运行

        if cur_val and cur_val == chosen_dir:
            # 已是目标值 — 直接运行
            self.sig_log.emit(
                f"<span style='color:#909399;'>&nbsp;&nbsp;ℹ️ setup.FILEPATH 已是 {cur_val}，无需更新。</span>"
            )
        elif not cur_val:
            # v12.4：FILEPATH 行存在但 value 为空 — 弹窗征询是否写入所选目录
            choice = show_choice_dialog(
                self,
                title="EDC Recode — setup.FILEPATH 值为空",
                text=(
                    f"setup.xlsx（{sheet} 行 {row}）中 FILEPATH 的 value 为空，SAS 会因此 ERROR 退出。\n\n"
                    f"  • 所选目录：{chosen_dir}\n\n"
                    f"请选择要使用哪一个，并继续运行："
                ),
                options=[
                    ("✅ 写入所选目录到 setup", "use_chosen"),
                ],
                cancellable=True,
            )
            if choice is None:
                self.sig_log.emit("<span style='color:#909399;'>已取消 EDC Recode。</span>")
                return
            ok, msg = _write_filepath_macro(setup_path, chosen_dir)
            if not ok:
                show_dialog(self, "更新 setup 失败", msg, "error")
                self.sig_log.emit(f"<span style='color:#F56C6C;'>❌ {msg}</span>")
                return
            self.sig_log.emit(f"<span style='color:#67C23A;'>✏️ {msg}</span>")
            # 同步 UI 显示
            self.macro_lbl.setText(f"{chosen_dir}  [{sheet} 行 {row}]")
            self.macro_lbl.setStyleSheet(
                "border: 1px solid #E4E7ED; background: #F8F9FA; color: #303133; padding: 6px 10px; border-radius: 4px;")
        else:
            # 不一致 — 弹窗征询（保留原"使用 setup 已有值"选项）
            choice = show_choice_dialog(
                self,
                title="EDC Recode — 目录与 setup.FILEPATH 不一致",
                text=(
                    f"当前所选目录与 setup.xlsx 的 FILEPATH 不一致：\n\n"
                    f"  • 所选目录：{chosen_dir}\n"
                    f"  • setup.FILEPATH（{sheet} 行 {row}）：{cur_val}\n\n"
                    f"请选择要使用哪一个，并继续运行："
                ),
                options=[
                    ("✅ 使用所选目录（更新 setup）", "use_chosen"),
                    ("ℹ️ 使用 setup 已有值", "use_setup"),
                ],
                cancellable=True,
            )
            if choice is None:
                self.sig_log.emit("<span style='color:#909399;'>已取消 EDC Recode。</span>")
                return

            if choice == "use_chosen":
                ok, msg = _write_filepath_macro(setup_path, chosen_dir)
                if not ok:
                    show_dialog(self, "更新 setup 失败", msg, "error")
                    self.sig_log.emit(f"<span style='color:#F56C6C;'>❌ {msg}</span>")
                    return
                self.sig_log.emit(f"<span style='color:#67C23A;'>✏️ {msg}</span>")
                # 同步 UI 显示
                self.macro_lbl.setText(f"{chosen_dir}  [{sheet} 行 {row}]")
                self.macro_lbl.setStyleSheet(
                    "border: 1px solid #E4E7ED; background: #F8F9FA; color: #303133; padding: 6px 10px; border-radius: 4px;")
            else:
                # use_setup：把 entry 同步成 setup 的值（让用户看到实际生效项），但不改 setup
                self.dir_entry.setText(cur_val)
                chosen_dir = cur_val
                self.sig_log.emit(
                    f"<span style='color:#909399;'>ℹ️ 沿用 setup.FILEPATH = {cur_val}，未修改 setup.xlsx。</span>"
                )

        # 进入运行态
        self.sig_run_started.emit()
        self.sig_status.emit("⏳ 正在执行 EDC Recode…", "#409EFF")
        self.sig_log.emit(
            f"<span style='color:#409EFF; font-weight:bold;'>🚀 准备执行 21_edc_data_recode_call.sas</span>"
        )
        self.sig_log.emit(f"<span style='color:#909399;'>&nbsp;&nbsp;filepath：{chosen_dir}</span>")
        self.sig_log.emit(f"<span style='color:#909399;'>&nbsp;&nbsp;脚本：{sas_path}</span>")

        self.btn_run.setVisible(False)
        self.btn_cancel.setVisible(True)
        self.prog.setRange(0, 0)
        self.prog.setVisible(True)

        # 复用 SingleBatchRunner（脚本本身用 &filepath. 读 setup，无需改 SAS）
        self._runner = SingleBatchRunner(sas_path)
        self._runner.finished_signal.connect(self._on_runner_finished)
        self._t_start = time.time()
        self._runner.start()

    def _on_cancel_run(self):
        """v12.6：中止 EDC Recode 运行（同 acrf_unzip 策略）

        v12.10.17 修复闪退根因：
          原本流程是：
            1. 用户点中止 → kill 子进程 + self._runner = None
            2. 子进程被 kill → SingleBatchRunner emit finished_signal
            3. _on_runner_finished 回调读 self._runner.script_path → NoneType.attr → 闪退
          修复：
            - 加 _cancelled 标志区分"用户主动中止"
            - 不在 cancel 内立即清 self._runner（让 finished 回调能正常工作）
            - _on_runner_finished 检测 _cancelled → 直接 return（不读 script_path）
        """
        runner = self._runner
        if runner is None or not runner.isRunning():
            self._reset_ui_after_run()
            return
        self._cancelled = True   # v12.10.17：让 _on_runner_finished 检测此标志直接 return
        runner.is_cancelled = True
        try:
            if runner.proc and runner.proc.poll() is None:
                runner.proc.kill()
        except Exception:
            pass
        self.sig_status.emit("🛑 已中止 EDC Recode", "#F56C6C")
        self.sig_step_update.emit("02 EDC Data Recode 🟥")
        self.sig_log.emit("<span style='color:#F56C6C; font-weight:bold;'>🛑 用户已中止 EDC Recode 运行。</span>")
        self._reset_ui_after_run()
        # v12.10.17：不再立即 self._runner = None，留给 _on_runner_finished 内清理
        # （之前在这里清 None 导致 finished 回调读 script_path 报 NoneType.attr 闪退）

    def _reset_ui_after_run(self):
        self.prog.setVisible(False)
        self.btn_run.setVisible(True)
        self.btn_cancel.setVisible(False)

    def _on_runner_finished(self, has_issue, summary, log_text):
        # v12.10.17：用户主动中止 → 已经在 _on_cancel_run 内 emit 状态 + 复位 UI，
        # 这里直接清理 runner 引用并 return，避免重复 emit + 避免读 self._runner.attr
        # 时如果 runner 已被 GC 触发的属性访问报错（之前闪退根因）
        if getattr(self, "_cancelled", False):
            self._cancelled = False
            thread_ref = self._runner
            self._runner = None
            if thread_ref is not None:
                try:
                    thread_ref.finished.connect(thread_ref.deleteLater)
                except Exception:
                    pass
            return

        self._reset_ui_after_run()
        elapsed = time.time() - getattr(self, "_t_start", time.time())

        if has_issue:
            self.sig_status.emit("❌ EDC Recode 完成（含警告/错误）", "#F56C6C")
            self.sig_step_update.emit("02 EDC Data Recode ⚠️")
            self.sig_log.emit(
                f"<span style='color:#F56C6C; font-weight:bold;'>❌ EDC Recode 执行存在 ERROR/WARNING — {summary}</span>"
            )
            self.sig_log.emit(self._extract_issue_lines(log_text))
        else:
            self.sig_status.emit(f"✅ EDC Recode 完成（{elapsed:.1f}s）", "#67C23A")
            self.sig_step_update.emit("02 EDC Data Recode ✅")
            self.sig_log.emit(
                f"<span style='color:#67C23A; font-weight:bold;'>✅ EDC Recode 执行完毕 — {summary}</span>"
            )
        # v12.10.17：安全读 script_path（兜底 None）
        try:
            if self._runner is not None and getattr(self._runner, "script_path", None):
                log_path = os.path.splitext(self._runner.script_path)[0] + ".log"
                if os.path.exists(log_path):
                    self.sig_log.emit(f"<span style='color:#909399;'>&nbsp;&nbsp;详细日志：{log_path}</span>")
        except Exception:
            pass

        thread_ref = self._runner
        self._runner = None
        if thread_ref is not None:
            try:
                thread_ref.finished.connect(thread_ref.deleteLater)
            except Exception:
                pass

    @staticmethod
    def _extract_issue_lines(log_text: str) -> str:
        if not log_text:
            return "<i style='color:#909399;'>(SAS 未返回日志内容)</i>"
        out = []
        for line in log_text.splitlines():
            s = line.strip()
            up = s.upper()
            if up.startswith("ERROR:") or up.startswith("WARNING:"):
                color = "#F56C6C" if up.startswith("ERROR:") else "#E6A23C"
                safe = (s.replace("&", "&amp;")
                         .replace("<", "&lt;")
                         .replace(">", "&gt;"))
                out.append(f"<span style='color:{color};'>&nbsp;&nbsp;{safe}</span>")
                if len(out) >= 8:
                    out.append("<i style='color:#909399;'>&nbsp;&nbsp;… 更多详见日志文件 …</i>")
                    break
        if not out:
            return "<i style='color:#909399;'>(未匹配到标准 ERROR/WARNING 行)</i>"
        return "<br>".join(out)
