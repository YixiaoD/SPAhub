# -*- coding: utf-8 -*-
"""
modules/sdtm_batch_run.py
=========================
SDTM 模块 - 03 Batch Run（与 tfls 04 完全同名同样式）（v12.10.34 起：原 04，顺移到 03）

完全复用 TFLs / 04 BatchRunForm 的逻辑，仅锁定 force_type="sdtm"：
  - PDT 中各 OUTTYPE 程序数统计（BatchGenRunner 已对 SDTM/ADAM/TABLE/LISTING/FIGURE 全分类）
  - v12.10.31 起：force_type="sdtm" → 仅保留 type=%str(sdtm) 独占段，跳过
    type=%str(adam|sdtm|...) 这种"通用 batch_script_generator"段，最终只生成
    sdtm_dev / sdtm_qc 两个脚本（对齐 ADaM 模块的锁定模式）。
    日志中将打印「锁定 type 限制：TYPE=%str(sdtm)（仅限本模块）」。

子类化只做最小差异：
  - 构造时传 force_type="sdtm" 给 BatchRunForm
  - _step_name = "Batch Run"（与 tfls 完全一致，**不带 SDTM 前缀**）
"""
from modules.tfls_batch_run import BatchRunForm


class SdtmBatchRunForm(BatchRunForm):
    """
    SDTM / 03 Batch Run 表单。

    v12.10.31：与 ADaM 模块 BatchRunForm(force_type="adam") 同款机制 —
      锁定 force_type="sdtm"，BatchGenRunner 扫 92_batch_call.sas 时只保留
      type=%str(sdtm) 独占段。
    """

    def __init__(self):
        # v12.10.31：锁定 force_type="sdtm"（修 Issue 7）
        super().__init__(force_type="sdtm")
        # 与 tfls 一致：_step_name = "Batch Run"
        self._step_name = "Batch Run"
