# -*- coding: utf-8 -*-
"""
modules/m5_convert2xpt.py
=========================
M5 模块 - 01 Convert2XPT

把 SDTM / ADaM 数据集转成符合 NMPA 递交要求的 .xpt，业务落在 SAS 宏
`%submdata_nmpa(inlib=, outlib=, format=)`（宏本体已部署到 <repo_root>/utility/macros/，
autorun 加载后即可直接调用）。

调用方式（与 01 PDT Gen 的 %gen_pdt 同源）：
  - 在 <base>/utility/tools/ 下建一个**临时** .sas（用 sdtm_common.write_temp_sas，与 BatchRun
    同源）。run_sas() 提交时会 `%include autorun.sas`（**只定义** %autorun 宏），因此临时脚本
    必须在宏调用前**显式执行** %autorun 来真正 setup 环境（assign libref + 编译宏库）：
        data _null_; if libref('adam') then call execute('%nrstr(%autorun)'); run;
        %submdata_nmpa(inlib=SDTM, outlib=crtSDTM, format=V8);
    write_temp_sas 已内建上面的 autorun 执行块，故本模块只传宏调用即可。跑完删除 .sas 及 .log。
  - 临时脚本必须落在真实项目树（utility/tools）下——autorun 靠 `_sasprogramfile`
    路径推断项目根来 assign crtSDTM / crtADaM 等 libref，放到别处会导致 libref 找不到。

三个参数均为下拉框：
  inlib  ∈ {SDTM, ADaM}    默认 SDTM
  outlib ∈ {crtSDTM, crtADaM} 默认 crtSDTM
  format ∈ {V5, V8}        默认 V8

执行走独立子进程（app_paths.child_command_run_sas），与 PDTRunner 同款脚手架——
每次新建干净 saspy 会话，跑完进程退出，无状态污染。

信号：sig_log / sig_status / sig_step_update / sig_run_started / sig_run_finished

v12.10.116：新增 M5-01 Convert2XPT。
v12.10.118：按钮「▶ 生成 .xpt」→「▶ 生成XPT」；「📂 打开 tools 目录」→「📂 打开XPT目录」，
            指向 <base>/04_crt/tabulations/sdtm（crtSDTM 输出目录）。
v12.10.119：「打开XPT目录」随 outlib 下拉联动 —— crtSDTM→04_crt/tabulations/sdtm、
            crtADaM→04_crt/analysis/adam/datasets（映射沿用 crt_vars Config 派生约定）。
v12.10.120：① 修 bug —— 临时脚本改用 write_temp_sas 生成，宏调用前先执行 %autorun 才 setup
            环境，否则报「没有解析宏 SUBMDATA_NMPA / ERROR 180-322」；② 顶部增加「刷新源文件」
            按钮，复检输入库数据集数量 + 输出 XPT 目录。
v12.10.122：inlib→outlib 联动 —— 只选 inlib，outlib 自动置为 crtSDTM/crtADaM 并设为只读。
v12.10.123：outlib 标签去掉"随 inlib 联动"描述、hint 去掉联动句（仅灰色锁定，不重写）。
v12.10.124：outlib 显式灰底灰字（只读锁定视觉）；hint 去掉 libref-assign 一句，只留 V5/V8 提醒。
"""
import os
import time
import pickle
import subprocess
import html

from PySide6.QtWidgets import (QFrame, QVBoxLayout, QHBoxLayout, QLabel,
                               QPushButton, QComboBox, QProgressBar, QWidget)
from PySide6.QtCore import Qt, QThread, Signal

from ui_utils import show_dialog, scan_status_lbl_style, primary_outline_btn_style
from modules.sdtm_common import write_temp_sas, cleanup_temp_sas


# ------------------------- 下拉选项 / 样式 -------------------------
_INLIB_OPTIONS = ["SDTM", "ADaM"]
_OUTLIB_OPTIONS = ["crtSDTM", "crtADaM"]
_FORMAT_OPTIONS = ["V8", "V5"]   # 默认 V8 置首

_COMBO_STYLE = ("padding: 6px 10px; border: 1px solid #DCDFE6; border-radius: 4px; "
                "background-color: #FFFFFF; color: #303133;")


class _NoWheelComboBox(QComboBox):
    """禁用滚轮改值（避免用户滚动面板时误改下拉选项）。"""
    def wheelEvent(self, event):
        event.ignore()


# =============================================================================
# 子进程执行器（照搬 PDTRunner：独立 Python 子进程 + pickle IPC 回传 4 元组）
# =============================================================================
class Convert2XptRunner(QThread):
    """后台执行 %submdata_nmpa 的临时脚本。

    与 tfls_pdt.PDTRunner 同款子进程脚手架：通过 app_paths.child_command_run_sas
    拉新进程跑 run_sas(return_details=True)，pickle 文件回传 4 元组
    (has_issue, summary, log_text, source_label)。
    """
    log_signal = Signal(str)
    finished_signal = Signal(bool, str, str, str)  # has_issue, summary, log_text, source_label

    def __init__(self, sas_script):
        super().__init__()
        self.sas_script = sas_script
        self.is_cancelled = False
        self.proc = None

    def run(self):
        res_path = self.sas_script + ".res"
        if os.path.exists(res_path):
            try:
                os.remove(res_path)
            except Exception:
                pass

        from app_paths import child_command_run_sas
        cmd = child_command_run_sas(self.sas_script, res_path)

        try:
            self.proc = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=0x08000000,  # CREATE_NO_WINDOW
            )
        except Exception as e:
            if not self.is_cancelled:
                self.log_signal.emit(f"ERROR: 启动子进程失败：{e}")
                self.finished_signal.emit(True, f"异常: {e}", "", "")
            return

        while self.proc.poll() is None:
            if self.is_cancelled:
                try:
                    self.proc.kill()
                except Exception:
                    pass
                return
            time.sleep(0.5)

        if self.is_cancelled:
            return

        res_tuple = (False, "✅ 运行成功", "", "")
        if os.path.exists(res_path):
            try:
                with open(res_path, 'rb') as f:
                    res = pickle.load(f)
                if isinstance(res, tuple) and len(res) >= 4:
                    res_tuple = (bool(res[0]), str(res[1]), str(res[2]), str(res[3]))
                elif isinstance(res, tuple) and len(res) == 3:
                    res_tuple = (bool(res[0]), str(res[1]), str(res[2]), "")
            except Exception as e:
                self.log_signal.emit(f"ERROR: 读取子进程结果失败：{e}")
            try:
                os.remove(res_path)
            except Exception:
                pass
        else:
            self.log_signal.emit(
                "ERROR: Convert2XPT 子进程未产出结果文件，可能 saspy 启动失败。"
                "请检查 sascfg.py 配置或 SAS IOM 服务连通性。"
            )
            res_tuple = (True, "子进程未返回结果（saspy 启动可能失败）", "", "")

        self.finished_signal.emit(*res_tuple)


# =============================================================================
# 左侧业务表单
# =============================================================================
class Convert2XptForm(QFrame):
    """M5 / 01 Convert2XPT 的左侧业务表单。"""
    sig_log = Signal(str)
    sig_status = Signal(str, str)
    sig_step_update = Signal(str)
    sig_run_started = Signal()
    sig_run_finished = Signal()

    def __init__(self):
        super().__init__()
        self.base_path = ""       # 四级 csr 目录
        self._tmp_script = ""     # 本次跑用的临时脚本路径（用于跑完删除）
        self._setup_ui()

    def _show_msg(self, title, text, msg_type="info"):
        return show_dialog(self, title, text, msg_type)

    # ------------------------- UI -------------------------
    def _setup_ui(self):
        self.setObjectName("LeftPanel")
        self.setStyleSheet("#LeftPanel { background-color: #FFFFFF; border: 1px solid #E4E7ED; border-radius: 6px; }")
        form_layout = QVBoxLayout(self)
        form_layout.setAlignment(Qt.AlignTop)
        form_layout.setContentsMargins(25, 25, 25, 25)
        form_layout.setSpacing(16)

        self._step_name = "Convert2XPT"

        top_bar = QHBoxLayout()
        # v12.10.120：与其它模块一致，增加「🔄 刷新源文件」按钮（蓝色外框），
        # 复检输入库数据集 + 输出 XPT 目录，状态写到右侧 scan_lbl。
        self.refresh_btn = QPushButton("🔄 刷新源文件")
        self.refresh_btn.setStyleSheet(primary_outline_btn_style())
        self.refresh_btn.setCursor(Qt.PointingHandCursor)
        self.refresh_btn.clicked.connect(self._on_refresh_clicked)
        top_bar.addWidget(self.refresh_btn)
        self.scan_lbl = QLabel("")
        self.scan_lbl.setStyleSheet(scan_status_lbl_style())
        top_bar.addWidget(self.scan_lbl)
        top_bar.addStretch()
        form_layout.addLayout(top_bar)

        title = QLabel("调用 %submdata_nmpa 把 SDTM / ADaM 数据集转为符合 NMPA 递交要求的 .xpt。")
        title.setStyleSheet("color: #303133; font-weight: bold; font-size: 14px; border: none;")
        title.setWordWrap(True)
        form_layout.addWidget(title)

        self.prog = QProgressBar()
        self.prog.setVisible(False)
        self.prog.setFixedHeight(4)
        form_layout.addWidget(self.prog)

        # ---------- 三个参数下拉 ----------
        # v12.10.131：combo_row 改为整行包一层 QWidget 容器，便于按行整体隐藏。
        def combo_row(label_text, options):
            row = QHBoxLayout()
            row.setContentsMargins(0, 0, 0, 0)
            lbl = QLabel(label_text)
            lbl.setStyleSheet("border: none; color: #606266; min-width: 150px;")
            row.addWidget(lbl)
            combo = _NoWheelComboBox()
            combo.setStyleSheet(_COMBO_STYLE)
            combo.addItems(options)
            row.addWidget(combo, 1)
            wrap = QWidget()
            wrap.setLayout(row)
            form_layout.addWidget(wrap)
            return combo, wrap

        self.inlib_combo, self._inlib_row = combo_row("输入库（inlib）：", _INLIB_OPTIONS)
        self.outlib_combo, _ = combo_row("输出库（outlib）：", _OUTLIB_OPTIONS)
        self.format_combo, _ = combo_row("XPT 版本（format）：", _FORMAT_OPTIONS)

        # v12.10.131：inlib 现由 M5 顶部「数据类型」总开关驱动，隐藏本行（仍作状态容器 +
        # 保留 inlib→outlib/XPT 目录/源扫描 联动逻辑）。outlib 行保留（只读锁定，展示当前输出库）。
        self._inlib_row.setVisible(False)

        # v12.10.122：只选 inlib，outlib 联动置 crtSDTM/crtADaM 并灰色锁定（禁手选）。
        self.outlib_combo.setEnabled(False)
        # v12.10.124：显式灰底灰字（disabled 时 stylesheet 会盖过 palette，若不设仍是白底），
        # 明确"只读锁定"视觉。
        self.outlib_combo.setStyleSheet(
            "padding: 6px 10px; border: 1px solid #DCDFE6; border-radius: 4px; "
            "background-color: #F5F7FA; color: #909399;")
        self.inlib_combo.currentTextChanged.connect(self._sync_outlib_from_inlib)
        self._sync_outlib_from_inlib(self.inlib_combo.currentText())

        # v12.10.124：去掉"outlib 对应的 libref … 需已在 autorun 中 assign；"一句，只留 V5/V8 提醒。
        hint = QLabel("提示：V5 变量名 ≤ 8 字符、字符长度 ≤ 200，否则宏会 abort，请改用 V8。")
        hint.setStyleSheet("color: #909399; font-size: 12px; border: none;")
        hint.setWordWrap(True)
        form_layout.addWidget(hint)

        # ---------- 运行按钮区 ----------
        bl = QHBoxLayout()
        self.run_btn = QPushButton("▶ 生成XPT")
        self.run_btn.setStyleSheet(
            "background-color: #4A6FA5; color: white; border: none; padding: 8px 20px; border-radius: 4px; font-weight: bold;")
        self.run_btn.clicked.connect(self.execute_run)
        bl.addWidget(self.run_btn)

        self.cancel_btn = QPushButton("🟥 中止")
        self.cancel_btn.setStyleSheet(
            "background-color: #FEF0F0; color: #F56C6C; border: 1px solid #FBC4C4; padding: 8px 20px; border-radius: 4px; font-weight: bold;")
        self.cancel_btn.setVisible(False)
        self.cancel_btn.clicked.connect(self.cancel_run)
        bl.addWidget(self.cancel_btn)

        self.open_btn = QPushButton("📂 打开XPT目录")
        self.open_btn.setStyleSheet(
            "background-color: #3F9A6E; color: white; border: none; padding: 8px 20px; border-radius: 4px; font-weight: bold;")
        self.open_btn.clicked.connect(self._open_xpt_dir)
        bl.addWidget(self.open_btn)
        # v12.10.119：目录随 outlib 联动 —— 切换下拉即更新按钮 tooltip 提示当前将打开哪个目录
        self.outlib_combo.currentTextChanged.connect(self._refresh_open_btn_tooltip)
        self._refresh_open_btn_tooltip(self.outlib_combo.currentText())
        bl.addStretch()
        form_layout.addLayout(bl)

    # ------------------------- 数据类型总开关 -------------------------
    def set_data_type(self, data_type):
        """v12.10.131：由 M5Widget 顶部「数据类型」总开关驱动。
        设置 inlib（自动联动 outlib / XPT 目录 / 源扫描），SDTM↔ADaM。
        canonical: "sdtm" / "adam"（大小写不敏感）→ 映射到 inlib 的 "SDTM"/"ADaM"。"""
        t = (data_type or "").strip().lower()
        target = "ADaM" if t == "adam" else "SDTM"
        if self.inlib_combo.currentText() != target:
            self.inlib_combo.setCurrentText(target)   # 触发 _sync_outlib_from_inlib
        else:
            self._sync_outlib_from_inlib(target)       # 值未变不发信号，显式同步一次
        self.action_refresh()

    # ------------------------- 路径 / 提示 / 快捷键 -------------------------
    def update_paths(self, base_path):
        self.base_path = base_path
        # v12.10.120：切项目后自动复检一次源文件状态
        self.action_refresh()

    def set_wait_hint(self, show):
        if show:
            self.scan_lbl.setText("⏳ 等待填写完整路径...")
            self.scan_lbl.setStyleSheet(scan_status_lbl_style())
        else:
            self.scan_lbl.setText("")

    def _on_refresh_clicked(self):
        self.action_refresh()

    def action_refresh(self):
        # v12.10.120：复检输入库（inlib→01_sdtm/02_adam）数据集数量 + 输出 XPT 目录是否存在，
        # 状态写到 scan_lbl。单目录 listdir，量小，主线程内即可（不涉及 pandas 重活）。
        if not self.base_path or not os.path.isdir(self.base_path):
            self.scan_lbl.setText("⏳ 请先选择完整项目路径")
            self.scan_lbl.setStyleSheet(scan_status_lbl_style())
            return
        inlib = (self.inlib_combo.currentText().strip() or "SDTM").lower()
        in_dir = os.path.join(self.base_path, "01_sdtm" if inlib == "sdtm" else "02_adam")
        outlib = (self.outlib_combo.currentText().strip() or "crtSDTM").lower()
        out_rel = self._XPT_DIR_BY_OUTLIB.get(outlib, ("04_crt", "tabulations", "sdtm"))
        out_dir = os.path.join(self.base_path, *out_rel)
        try:
            n_in = (len([f for f in os.listdir(in_dir) if f.lower().endswith(".sas7bdat")])
                    if os.path.isdir(in_dir) else -1)
        except Exception:
            n_in = -1
        if n_in < 0:
            self.scan_lbl.setText(f"⚠ 输入库目录不存在：{os.path.basename(in_dir)}")
            self.scan_lbl.setStyleSheet(scan_status_lbl_style(color="#E6A23C"))
        elif n_in == 0:
            self.scan_lbl.setText(f"⚠ {os.path.basename(in_dir)} 下无 .sas7bdat")
            self.scan_lbl.setStyleSheet(scan_status_lbl_style(color="#E6A23C"))
        else:
            exists = "已存在" if os.path.isdir(out_dir) else "尚未创建"
            self.scan_lbl.setText(
                f"✅ 输入库 {os.path.basename(in_dir)}：{n_in} 个数据集；输出目录{exists}")
            self.scan_lbl.setStyleSheet(scan_status_lbl_style(color="#67C23A"))

    def action_run(self):
        btn = getattr(self, "run_btn", None)
        if btn is not None and btn.isEnabled() and btn.isVisible():
            btn.click()

    # v12.10.118：XPT 输出目录（相对 base_path 计算，未硬编码绝对路径）。
    # v12.10.119：随 outlib 下拉联动 —— 映射沿用 crt_vars 的 Config 派生约定
    #   （见 m5_pds_codelist.py _derive_paths）：
    #     crtSDTM → 04_crt/tabulations/sdtm
    #     crtADaM → 04_crt/analysis/adam/datasets
    _XPT_DIR_BY_OUTLIB = {
        "crtsdtm": ("04_crt", "tabulations", "sdtm"),
        "crtadam": ("04_crt", "analysis", "adam", "datasets"),
    }

    def _sync_outlib_from_inlib(self, inlib_text=None):
        # v12.10.122：inlib→outlib 联动。SDTM→crtSDTM，ADaM→crtADaM。
        inlib = (inlib_text or self.inlib_combo.currentText() or "SDTM").strip().lower()
        target = "crtADaM" if inlib == "adam" else "crtSDTM"
        if self.outlib_combo.currentText() != target:
            self.outlib_combo.setCurrentText(target)
        self._refresh_open_btn_tooltip(target)

    def _refresh_open_btn_tooltip(self, outlib_text=None):
        if not hasattr(self, "open_btn"):   # 初始联动可能早于 open_btn 创建
            return
        outlib = (outlib_text or self.outlib_combo.currentText() or "crtSDTM").strip().lower()
        rel = self._XPT_DIR_BY_OUTLIB.get(outlib, ("04_crt", "tabulations", "sdtm"))
        self.open_btn.setToolTip("打开当前 outlib 的 XPT 输出目录：\n<项目>\\" + "\\".join(rel))

    def _open_xpt_dir(self):
        outlib = (self.outlib_combo.currentText().strip() or "crtSDTM").lower()
        rel = self._XPT_DIR_BY_OUTLIB.get(outlib, ("04_crt", "tabulations", "sdtm"))
        d = os.path.join(self.base_path or "", *rel)
        if d and os.path.isdir(d):
            try:
                os.startfile(d)  # type: ignore[attr-defined]
            except Exception:
                pass
        else:
            self._show_msg("提示", f"XPT 目录不存在：\n{d or '(未知)'}", "info")

    # ------------------------- 执行 -------------------------
    def execute_run(self):
        if not self.base_path or not os.path.isdir(self.base_path):
            self._show_msg("错误", "项目路径（四级目录）无效，请先在顶部选择完整 csr 路径！", "error")
            return

        tools_dir = os.path.join(self.base_path, "utility", "tools")
        if not os.path.isdir(tools_dir):
            self._show_msg("错误", f"找不到 tools 目录，无法建临时脚本：\n{tools_dir}", "error")
            return

        inlib = self.inlib_combo.currentText().strip() or "SDTM"
        outlib = self.outlib_combo.currentText().strip() or "crtSDTM"
        fmt = self.format_combo.currentText().strip() or "V8"

        # v12.10.120：改用 sdtm_common.write_temp_sas 生成临时脚本——它会在宏调用前自动插入
        # 「执行 autorun」块：data _null_; if libref('adam') then call execute('%nrstr(%autorun)'); run;
        # （与 BatchRun 同源）。此前脚本只有 %submdata_nmpa(...)：run_sas 虽 %include autorun.sas
        # 定义了 %autorun 宏，却从未执行它 → libref/宏库未 setup → %submdata_nmpa 未编译，
        # 报「没有解析宏 SUBMDATA_NMPA 的调用 / ERROR 180-322」。执行 %autorun 后环境齐备即正常。
        macro_call = f"%submdata_nmpa(inlib={inlib}, outlib={outlib}, format={fmt});"
        try:
            tmp_script = write_temp_sas(self.base_path, macro_call, prefix="temp_convert2xpt")
        except PermissionError:
            self._show_msg("权限拒绝", "临时脚本写入失败（文件被占用或目录只读），请重试！", "error")
            return
        except Exception as e:
            self._show_msg("错误", f"临时脚本写入失败：{e}", "error")
            return

        self._tmp_script = tmp_script

        self.sig_run_started.emit()
        self.run_btn.hide()
        self.cancel_btn.show()
        self.prog.setRange(0, 0)
        self.prog.setVisible(True)
        self.prog.setValue(0)

        self.sig_log.emit(
            f"<span style='color:#409EFF;'>> 提交 %submdata_nmpa(inlib={inlib}, "
            f"outlib={outlib}, format={fmt}) 到 SAS 服务器...</span>")
        self.sig_status.emit("⏳ 正在执行中...", "#409EFF")

        self.runner = Convert2XptRunner(tmp_script)
        self.runner.log_signal.connect(
            lambda msg: self.sig_log.emit(
                f"<span style='color:#F56C6C; font-weight:bold;'>{html.escape(str(msg))}</span>"))
        self.runner.finished_signal.connect(self._on_finished)
        self.runner.start()

    def _cleanup_tmp(self):
        """删除临时 .sas 及其 .log（复用 sdtm_common.cleanup_temp_sas）。"""
        cleanup_temp_sas(self._tmp_script)
        self._tmp_script = ""

    def _on_finished(self, has_issue, summary, log_text, source_label):
        if hasattr(self, "runner") and self.runner.is_cancelled:
            self._cleanup_tmp()
            return

        self.cancel_btn.hide()
        self.run_btn.show()
        self.prog.setVisible(False)

        if log_text:
            self.sig_log.emit(f"<pre style='white-space:pre-wrap; color:#606266;'>{html.escape(log_text)}</pre>")

        if not has_issue:
            self.sig_status.emit("✅ .xpt 生成成功！", "#67C23A")
            self.sig_step_update.emit("01 Convert2XPT ✅")
            if summary:
                self.sig_log.emit(
                    f"<span style='color:#67C23A; font-weight:bold;'>{html.escape(summary)}</span>")
        else:
            self.sig_status.emit("❌ 生成失败！", "#F56C6C")
            self.sig_step_update.emit("01 Convert2XPT ❌")
            self.sig_log.emit(
                f"<span style='color:#F56C6C; font-weight:bold;'>{html.escape(summary or '执行失败，详见日志。')}</span>")

        self._cleanup_tmp()
        self.sig_run_finished.emit()

    def cancel_run(self):
        if hasattr(self, "runner") and self.runner.isRunning():
            self.runner.is_cancelled = True
            self.runner.wait(5000)
        self.cancel_btn.hide()
        self.run_btn.show()
        self.prog.setVisible(False)
        self._cleanup_tmp()

        self.sig_status.emit("🛑 已中止", "#F56C6C")
        self.sig_step_update.emit("01 Convert2XPT 🟥")
        self.sig_log.emit("<span style='color:#F56C6C; font-weight:bold;'>[已中止] 🛑 用户手动取消了执行。</span>")
        self.sig_run_finished.emit()
