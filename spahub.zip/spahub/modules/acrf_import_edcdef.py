# -*- coding: utf-8 -*-
"""
modules/acrf_import_edcdef.py
=============================
aCRF 模块 - 03 Import EDC Definition

职责：
  - 调用 24_import_edcdef_call.sas（脚本本身只是 autorun + %import_edcdef，无显式入参）
  - 真正的入参由 setup.xlsx 中的宏变量 EDCSTD 控制（HRTAU / RAVE 二选一）
  - UI 提供 EDCSTD 下拉框：默认读 setup 当前值；用户切到另一项 → 弹窗征询
    "覆盖 setup → 重新运行"或"沿用 setup 已有值"，确认后再调度 SAS 执行

v12.10.104：修复切换项目后 EDCDEF 输入框沿用上个项目残留值的 bug。
  - 现象：A 项目自动检测到 EDC 定义文件并填入 EDCDEF；切到 B 项目（其 00_source_data
    下无任何符合条件的文件）时，旧逻辑因「检测不到就跳过回填」而保留了 A 的文件名残留。
  - 修复：update_paths 中按「是否切换项目」+「当前值是否自动填」决定是否重置 EDCDEF：
    · 切换项目 → 一律以本项目检测结果为准（检到→填，没检到→置空，绝不沿用旧值）。
    · 同项目刷新且值为自动填 → 跟随源文件存在性（文件没了→清空）。
    · 用户手改 / 📁 浏览选过的值 → 保留不动（textEdited / 浏览回写时标记 _edcdef_autofilled=False）。

v12.10.103：EDCDEF 自动检测兼容英文项目。
  - _detect_latest_edcdef 的文件名匹配从硬编码中文子串「数据库定义」改为正则
    _EDCDEF_NAME_RE，新增识别英文 "DB Definition"（及 "Database Definition"），
    大小写不敏感，DB 与 Definition 间允许 空格/下划线/连字符 0~N 个分隔符。
  - EDCDEF 输入框 placeholder 改为中英双语提示。
  - 仅影响自动检测/回填；用户仍可手改或用 📁 浏览 手选任意 .xlsx。

v12.10.34（本次架构调整）：从 SDTM-01 转移到 aCRF-03 位置：
  - 原 modules/sdtm_import_edcdef.py 重命名为 modules/acrf_import_edcdef.py
  - step_name "01 Import EDC Definition" → "03 Import EDC Definition"
  - 所有 sig_step_update emit 字串同步改前缀号
  - 类名 ImportEdcdefForm 保持不变（仅文件 + step 号变）
  - 转移原因：TOC 生成需要 EDCDEF 文件，把 EDC 定义导入归到 aCRF 后段更合理；
    SDTM 模块后续步骤 02/03/04 顺移到 01/02/03。

v12.10.33：把 setup.EDCSTD / setup.EDCDEF 的状态标签从只读 → 可点击：
  - 行不存在（红框）/ 值为空（橙框）时 cursor 变手形，点击 → 弹 question 弹窗
    确认（默认焦点蓝色"确认"按钮，回车快路）→ 立即写 setup → 切到绿色"已补行"态。
  - 已有合法值（灰白）/ setup.xlsx 缺失（红+不可点）/ 已补行（绿+不可点）→ Arrow cursor，
    不响应点击。"已补行"绿态后须改 setup.xlsx 才能再次激活点击。
  - "运行 Import EDC Definition" 按钮原有三/四分支兜底保留：若用户未点红框直接点运行，
    EDCSTD 行不存在改为弹三选项（使用 UI 选择 / 使用 template 默认 / 取消），不再 return。
  - 新增 _ClickableLabel（QLabel 子类）— cursor=PointingHand 时左键 emit sig_clicked。
  - 新增 _get_edcstd_template_row()（对称 _get_edcdef_template_row）+ _EDCSTD_HARDCODE 兜底。
  - 抽 _apply_edcstd_label_state / _apply_edcdef_label_state — 5 态切换样式 + cursor 联动。

UI 设计参考 acrf_edc_recode（同款 setup 一致性弹窗模式 + 同款红框可点击范式）。
"""
import os
import re
import time

from PySide6.QtWidgets import (QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                               QLineEdit, QFrame, QProgressBar, QComboBox, QFileDialog)
from PySide6.QtCore import Qt, Signal


# v12.10.33: 红色"行不存在/值为空"提示框需要变成可点击 → click 后弹窗确认 → 直接补/写 setup。
# 单独抽一个 ClickableLabel 子类（替代 QLabel）—— 拦截 mousePressEvent emit click 信号。
# 设计取舍：
#   - 不用 QPushButton 改外观：原状态 (灰底/橙底/绿底/红底) 文案多变, QPushButton 套样式
#     会被 Qt button style 干扰; QLabel 加边框/背景更自由可控。
#   - 仅左键触发: 右键留给 setTextInteractionFlags 的"复制"菜单 (TextSelectableByMouse)。
#   - 'enabled' 状态由调用方控制: setProperty("clickable", True/False) + setCursor。
class _ClickableLabel(QLabel):
    """QLabel 子类，点击时 emit click() 信号。"""
    sig_clicked = Signal()

    def mousePressEvent(self, event):
        # 仅左键触发，且 cursor 是 PointingHandCursor 时才认为是"可点击态"
        if event.button() == Qt.LeftButton and self.cursor().shape() == Qt.PointingHandCursor:
            self.sig_clicked.emit()
            event.accept()
            return
        super().mousePressEvent(event)


from modules.tfls_batch_run import SingleBatchRunner
from modules.sdtm_common import (read_setup_macro, write_setup_macro, append_setup_macro_row,
                                 classify_log_severity, extract_issue_lines_html,
                                 severity_finished_html)
from ui_utils import (show_dialog, show_choice_dialog, primary_outline_btn_style, scan_status_lbl_style,
                      primary_btn_style, danger_btn_style, success_btn_style, light_btn_style)


# 合法 EDCSTD 取值
_EDCSTD_OPTIONS = ["HRTAU", "RAVE"]
_EDCSTD_DEFAULT = "HRTAU"

# v12.10.19: EDCDEF 相关 — setup_template 路径 + hardcode 兜底
# 用法见 _get_edcdef_template_row():
#   1) 优先读 Z 盘 template（唯一真相源；SAS 团队后续更新模板时无需改代码即生效）
#   2) Z 盘不可达 → 兜底 hardcode（保证补行能力，离线/网络故障也能跑）
_TEMPLATE_PATH = r"Z:\projects\utility\template\setup_template.xlsx"
_EDCDEF_HARDCODE = {
    "description": "数据库定义文件",
    "macro_name": "EDCDEF",
    "macro_value": "",
}
# v12.10.103: EDCDEF 文件名匹配规则 — 兼容中文项目「数据库定义」与英文项目「DB Definition」。
# 匹配（re.IGNORECASE，对 fn 做 search）：
#   - 中文子串「数据库定义」
#   - 英文 "DB Definition"：DB 与 Definition 之间允许 0~N 个 空格 / 下划线 / 连字符，
#     覆盖 "DB Definition" / "DB_Definition" / "DB-Definition" / "DBDefinition"
#   - 同时兼容英文全称 "Database Definition"（「数据库定义」直译，部分英文项目这样命名）
# 正则注意点：
#   - 英文分支不加单词边界 \b —— 文件名里分隔符（- _ 空格）已构成天然边界，强加 \b
#     反而会漏掉 "XXX-DBDefinition.xlsx" 这类紧贴写法。
#   - "definition" 必须紧跟在 db/database(+分隔符) 之后 → 天然规避 "feedback definition"
#     这类把 "db" 嵌在别的词里的误匹配（"...dback definition" 中 db 后不是分隔符+definition）。
#   - 用 re.search（非 match）以匹配文件名任意位置，如 "HRS9821-DB Definition-V1.0.xlsx"。
_EDCDEF_NAME_RE = re.compile(r"数据库定义|(?:database|db)[\s_\-]*definition", re.IGNORECASE)
# v12.10.33: EDCSTD 缺失行场景的兜底模板（与 _EDCDEF_HARDCODE 对称）
# 含义：当 Z 盘 template 不可达时，按这里的字段补 setup.xlsx 行。
# description 是从真实 setup_template.xlsx row 3 抄的（含 HRTAU/RAVE 说明）。
_EDCSTD_HARDCODE = {
    "description": "EDC系统( HRTAU = 百奥知系统, RAVE= Rave 系统）",
    "macro_name": "EDCSTD",
    "macro_value": "HRTAU",  # 仅用作 description 兜底，实际写入的 value 始终来自 UI 选择
}


def _get_edcstd_template_row():
    """v12.10.33: 取 EDCSTD 行的 description 默认值（用于补行）。

    与 _get_edcdef_template_row() 对称：
      主路径：Z 盘 setup_template.xlsx 的 Macro Variables sheet 扫 EDCSTD 行
      兜底：Z 盘不可达 → _EDCSTD_HARDCODE

    注意：本函数返回的 macro_value 仅用于兜底场景；append 时实际写入的 value
    始终是 UI 当前选择（HRTAU/RAVE），由调用方决定，不直接用本函数返回的 value。

    返回 dict: {description, macro_name, macro_value, source}
    """
    try:
        if os.path.isfile(_TEMPLATE_PATH):
            from openpyxl import load_workbook
            wb = load_workbook(_TEMPLATE_PATH, data_only=True, read_only=True)
            try:
                ws = wb["Macro Variables"] if "Macro Variables" in wb.sheetnames else wb.worksheets[0]
                for r in ws.iter_rows(min_row=2, values_only=True):
                    if len(r) >= 2 and r[1] and str(r[1]).strip().upper() == "EDCSTD":
                        desc = r[0] if r[0] is not None else ""
                        val = r[2] if len(r) > 2 and r[2] is not None else ""
                        return {
                            "description": str(desc),
                            "macro_name": "EDCSTD",
                            "macro_value": str(val),
                            "source": "template",
                        }
            finally:
                wb.close()
    except Exception:
        pass
    return {**_EDCSTD_HARDCODE, "source": "hardcode"}


def _detect_latest_edcdef(source_dir: str):
    """v12.10.19: 扫 source_dir 下时间戳最晚的"数据库定义".xlsx 文件名（不递归）。

    v12.10.103: 兼容英文项目 — 匹配从硬编码中文子串改为正则 _EDCDEF_NAME_RE，
    同时识别「数据库定义」(中) 与 "DB Definition" / "Database Definition" (英)。

    匹配规则：
      - 文件名命中 _EDCDEF_NAME_RE（中文「数据库定义」或英文 DB/Database Definition，
        大小写不敏感，分隔符 空格/_/- 容错）
      - 后缀 .xlsx（小写不敏感）
      - 排除 Excel 临时锁文件（"~$" 开头）

    业务约定：EDC 数据库定义文件直接放 00_source_data 根目录。如发现项目把它埋
    在子目录里，用户可用浏览按钮手选 — 不在此函数做递归（避免 walk 大目录拖慢 UI）。

    返回文件名（basename）；找不到 → None。
    """
    if not source_dir or not os.path.isdir(source_dir):
        return None
    candidates = []
    try:
        for fn in os.listdir(source_dir):
            if not _EDCDEF_NAME_RE.search(fn):
                continue
            if not fn.lower().endswith(".xlsx"):
                continue
            if fn.startswith("~$"):
                continue
            full = os.path.join(source_dir, fn)
            try:
                candidates.append((os.path.getmtime(full), fn))
            except OSError:
                continue
    except OSError:
        return None
    if not candidates:
        return None
    candidates.sort(reverse=True)  # 最新在前
    return candidates[0][1]


def _get_edcdef_template_row():
    """v12.10.19: 取 EDCDEF 行的 description / value 默认值（用于补行）。

    主路径：读 Z:\\projects\\utility\\template\\setup_template.xlsx
            的 "Macro Variables" sheet，扫名为 EDCDEF 的行。
    兜底：Z 盘不可达（离线/网络故障/文件被删）→ 落回 _EDCDEF_HARDCODE。

    实测耗时：openpyxl read_only=True ~16ms（应用已加载 openpyxl，无冷启动开销）。

    返回 dict: {description, macro_name, macro_value, source}  source ∈ {template, hardcode}
    """
    try:
        if os.path.isfile(_TEMPLATE_PATH):
            from openpyxl import load_workbook
            wb = load_workbook(_TEMPLATE_PATH, data_only=True, read_only=True)
            try:
                ws = wb["Macro Variables"] if "Macro Variables" in wb.sheetnames else wb.worksheets[0]
                for r in ws.iter_rows(min_row=2, values_only=True):
                    if len(r) >= 2 and r[1] and str(r[1]).strip().upper() == "EDCDEF":
                        desc = r[0] if r[0] is not None else ""
                        val = r[2] if len(r) > 2 and r[2] is not None else ""
                        return {
                            "description": str(desc),
                            "macro_name": "EDCDEF",
                            "macro_value": str(val),
                            "source": "template",
                        }
            finally:
                wb.close()
    except Exception:
        pass  # 任意失败 → 兜底
    return {**_EDCDEF_HARDCODE, "source": "hardcode"}


# =============================================================================
# 左侧表单组件 ImportEdcdefForm
# =============================================================================
class ImportEdcdefForm(QFrame):
    """aCRF / 03 Import EDC Definition 的左侧业务表单"""

    sig_log = Signal(str)
    sig_status = Signal(str, str)
    sig_step_update = Signal(str)
    sig_run_started = Signal()
    sig_run_finished = Signal()

    def __init__(self):
        super().__init__()
        self.base_path = ""
        self._step_name = "Import EDC Definition"
        self._runner = None
        self._cancelled = False  # v12.10.20: 用户主动中止标志，让 _on_runner_finished 检测后跳过常规处理
        # v12.10.104: EDCDEF 输入框重置追踪
        #   _edcdef_last_base : 上一次 update_paths 的 base_path（normcase 归一化）→ 判断是否切换了项目
        #   _edcdef_autofilled: 当前 LineEdit 的值是否由「自动检测」填入（未被用户手改/浏览过）
        # 用途：切换项目时，绝不沿用上个项目残留的 EDCDEF 值（检测到→填，检测不到→置空）；
        #       同项目刷新时，自动填的值随源文件存在性更新，但用户手改/浏览过的值保留不动。
        self._edcdef_last_base = None
        self._edcdef_autofilled = False
        self._setup_ui()

    # ------------------------- UI -------------------------
    def _setup_ui(self):
        self.setObjectName("LeftPanel")
        self.setStyleSheet("#LeftPanel { background-color: #FFFFFF; border: 1px solid #E4E7ED; border-radius: 6px; }")
        form = QVBoxLayout(self)
        form.setAlignment(Qt.AlignTop)
        form.setContentsMargins(25, 25, 25, 25)
        form.setSpacing(15)

        # 顶部刷新栏
        top_bar = QHBoxLayout()
        self.refresh_btn = QPushButton("🔄 刷新源文件")
        # v12.10.65：统一改用 home"📁 系统文件复制"同款蓝色外框样式
        self.refresh_btn.setStyleSheet(primary_outline_btn_style())
        self.refresh_btn.setCursor(Qt.PointingHandCursor)
        top_bar.addWidget(self.refresh_btn)
        self.scan_lbl = QLabel("")
        self.scan_lbl.setStyleSheet(scan_status_lbl_style())
        top_bar.addWidget(self.scan_lbl)
        top_bar.addStretch()
        form.addLayout(top_bar)

        title = QLabel("调用 24_import_edcdef_call.sas，导入 EDC 定义文件。")
        title.setStyleSheet("color: #303133; font-weight: bold; font-size: 14px; border: none;")
        title.setWordWrap(True)
        form.addWidget(title)

        # 行 1：EDCSTD 选择
        row_std = QHBoxLayout()
        lbl_std = QLabel("EDCSTD：")
        lbl_std.setStyleSheet("border: none; color: #606266; min-width: 130px;")
        row_std.addWidget(lbl_std)
        self.edcstd_combo = QComboBox()
        self.edcstd_combo.addItems(_EDCSTD_OPTIONS)
        self.edcstd_combo.setStyleSheet(
            "padding: 6px 10px; border: 1px solid #DCDFE6; border-radius: 4px; background: #FFFFFF; color: #606266;")
        row_std.addWidget(self.edcstd_combo, 1)
        form.addLayout(row_std)

        # 行 1-补充：setup 当前 EDCSTD 值（只读展示，可点击补行/覆盖）
        # v12.10.33: 从 QLabel → _ClickableLabel —— 当 EDCSTD 行缺失或值为空时，
        # 控件 cursor 变手形, 点击 → 弹窗确认 → 立即写 setup (回车快路, 默认蓝按钮)
        row_macro = QHBoxLayout()
        lbl_macro = QLabel("setup.EDCSTD：")
        lbl_macro.setStyleSheet("border: none; color: #606266; min-width: 130px;")
        row_macro.addWidget(lbl_macro)
        self.macro_lbl = _ClickableLabel("(尚未读取)")
        self.macro_lbl.setStyleSheet(
            "border: 1px solid #E4E7ED; background: #F8F9FA; color: #606266; padding: 6px 10px; border-radius: 4px;")
        self.macro_lbl.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.macro_lbl.sig_clicked.connect(self._on_click_edcstd_macro)
        row_macro.addWidget(self.macro_lbl, 1)
        form.addLayout(row_macro)

        # v12.10.19: 行 1.5 — EDCDEF 输入口（数据库定义文件名）
        # 设计取舍：
        #   - 用 QLineEdit（可编辑）+ 浏览按钮 — 不用下拉，因为 EDCDEF 的 value 是
        #     文件名（变化的），EDCSTD 的固定 2 选 1 模式不适用。
        #   - update_paths() 会自动检测 00_source_data 下时间戳最晚的"数据库定义".xlsx
        #     回填这个 LineEdit；用户也可手改或用浏览按钮选别的文件。
        #   - 浏览按钮默认目录为 00_source_data；选择后只取 basename（与 setup.xlsx
        #     里其它文件类宏变量的写法一致：SDTMSPEC / AECODE 都只写文件名不带路径）。
        row_edcdef = QHBoxLayout()
        lbl_edcdef = QLabel("EDCDEF：")
        lbl_edcdef.setStyleSheet("border: none; color: #606266; min-width: 130px;")
        row_edcdef.addWidget(lbl_edcdef)
        self.edcdef_edit = QLineEdit()
        self.edcdef_edit.setPlaceholderText("XXX-数据库定义 / DB Definition-Vx.x.xlsx（自动检测，可手改）")
        self.edcdef_edit.setStyleSheet(
            "padding: 6px 10px; border: 1px solid #DCDFE6; border-radius: 4px; background: #FFFFFF; color: #303133;")
        row_edcdef.addWidget(self.edcdef_edit, 1)
        # v12.10.104: 用户手动键入即视为「用户已接管」→ 后续刷新不再被自动检测覆盖/清空。
        # textEdited 只在用户编辑时触发，setText() 程序填值不会触发，正好用于区分。
        self.edcdef_edit.textEdited.connect(lambda _t: setattr(self, "_edcdef_autofilled", False))
        self.btn_browse_edcdef = QPushButton("📁 浏览")
        # v12.10.68：统一改用 helper（与 TOC ▶初版TOC/🟥中止/📂打开TOC 视觉一致）
        self.btn_browse_edcdef.setStyleSheet(light_btn_style())
        self.btn_browse_edcdef.setCursor(Qt.PointingHandCursor)
        self.btn_browse_edcdef.setToolTip("默认定位到 00_source_data，选 *.xlsx 文件")
        self.btn_browse_edcdef.clicked.connect(self._browse_edcdef)
        row_edcdef.addWidget(self.btn_browse_edcdef)
        form.addLayout(row_edcdef)

        # 行 1.5-补充：setup 当前 EDCDEF 值（可点击补行/覆盖，与 setup.EDCSTD 行对称）
        # v12.10.33: _ClickableLabel — 行缺失/值为空时手形 + 弹窗确认 + 立即写 setup
        row_edcdef_macro = QHBoxLayout()
        lbl_edcdef_macro = QLabel("setup.EDCDEF：")
        lbl_edcdef_macro.setStyleSheet("border: none; color: #606266; min-width: 130px;")
        row_edcdef_macro.addWidget(lbl_edcdef_macro)
        self.edcdef_macro_lbl = _ClickableLabel("(尚未读取)")
        self.edcdef_macro_lbl.setStyleSheet(
            "border: 1px solid #E4E7ED; background: #F8F9FA; color: #606266; padding: 6px 10px; border-radius: 4px;")
        self.edcdef_macro_lbl.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.edcdef_macro_lbl.sig_clicked.connect(self._on_click_edcdef_macro)
        row_edcdef_macro.addWidget(self.edcdef_macro_lbl, 1)
        form.addLayout(row_edcdef_macro)

        # 行 2：setup.xlsx
        row_setup = QHBoxLayout()
        lbl_setup = QLabel("setup.xlsx：")
        lbl_setup.setStyleSheet("border: none; color: #606266; min-width: 130px;")
        row_setup.addWidget(lbl_setup)
        self.setup_entry = QLineEdit()
        self.setup_entry.setReadOnly(True)
        self.setup_entry.setStyleSheet(
            "padding: 6px; border: 1px solid #DCDFE6; border-radius: 4px; background: #F5F7FA; color: #606266;")
        row_setup.addWidget(self.setup_entry, 1)
        self.btn_open_setup = QPushButton("📂 打开")
        # v12.10.68：统一改用 helper（与 TOC ▶初版TOC/🟥中止/📂打开TOC 视觉一致）
        self.btn_open_setup.setStyleSheet(light_btn_style())
        self.btn_open_setup.setCursor(Qt.PointingHandCursor)
        self.btn_open_setup.clicked.connect(self._open_setup_file)
        row_setup.addWidget(self.btn_open_setup)
        form.addLayout(row_setup)

        # 行 3：调用脚本
        row_sas = QHBoxLayout()
        lbl_sas = QLabel("调用脚本：")
        lbl_sas.setStyleSheet("border: none; color: #606266; min-width: 130px;")
        row_sas.addWidget(lbl_sas)
        self.sas_entry = QLineEdit()
        self.sas_entry.setReadOnly(True)
        self.sas_entry.setStyleSheet(
            "padding: 6px; border: 1px solid #DCDFE6; border-radius: 4px; background: #F5F7FA; color: #606266;")
        row_sas.addWidget(self.sas_entry, 1)
        self.btn_open_sas = QPushButton("📂 打开")
        # v12.10.68：统一改用 helper（与 TOC ▶初版TOC/🟥中止/📂打开TOC 视觉一致）
        self.btn_open_sas.setStyleSheet(light_btn_style())
        self.btn_open_sas.setCursor(Qt.PointingHandCursor)
        self.btn_open_sas.clicked.connect(self._open_sas_file)
        row_sas.addWidget(self.btn_open_sas)
        form.addLayout(row_sas)

        # 进度条
        self.prog = QProgressBar()
        self.prog.setVisible(False)
        self.prog.setFixedHeight(4)
        self.prog.setTextVisible(False)  # v12.10.13：4px 太矮装不下文字，关闭百分比显示避免和上方 label 重叠
        form.addWidget(self.prog)

        # 运行按钮 + 中止按钮
        btn_row = QHBoxLayout()
        self.btn_run = QPushButton("▶ 运行 Import EDC Definition")
        # v12.10.68：统一改用 helper（与 TOC ▶初版TOC/🟥中止/📂打开TOC 视觉一致）
        self.btn_run.setStyleSheet(primary_btn_style())
        self.btn_run.setCursor(Qt.PointingHandCursor)
        self.btn_run.clicked.connect(self.run_import_edcdef)
        btn_row.addWidget(self.btn_run)

        self.btn_cancel = QPushButton("🟥 中止")
        # v12.10.68：统一改用 helper（与 TOC ▶初版TOC/🟥中止/📂打开TOC 视觉一致）
        self.btn_cancel.setStyleSheet(danger_btn_style())
        self.btn_cancel.setCursor(Qt.PointingHandCursor)
        self.btn_cancel.setVisible(False)
        self.btn_cancel.clicked.connect(self._on_cancel_run)
        btn_row.addWidget(self.btn_cancel)

        # v12.10.20: "打开 metadata 文件夹" — 绿色按钮，紧挨运行按钮（与 tfls_init_pgm
        # 的"📂 打开 06_programs/09_validation"风格一致：动作按钮区色彩 = 蓝运行 / 红中止 / 绿导航）
        self.btn_open_metadata = QPushButton("📂 打开 metadata")
        # v12.10.68：统一改用 helper（与 TOC ▶初版TOC/🟥中止/📂打开TOC 视觉一致）
        self.btn_open_metadata.setStyleSheet(success_btn_style())
        self.btn_open_metadata.setCursor(Qt.PointingHandCursor)
        self.btn_open_metadata.setToolTip("打开 utility/metadata（EDC 定义导入结果存放处）")
        self.btn_open_metadata.clicked.connect(self._open_metadata_folder)
        btn_row.addWidget(self.btn_open_metadata)

        btn_row.addStretch()

        form.addLayout(btn_row)
        form.addStretch()

    # ------------------------- 路径推送 -------------------------
    def update_paths(self, base_path):
        """由主控推送路径；自动定位 setup.xlsx 与调用脚本，并读取 EDCSTD"""
        self.base_path = base_path or ""

        sas_path = os.path.join(self.base_path, "utility", "tools", "24_import_edcdef_call.sas")
        self.sas_entry.setText(sas_path if os.path.isfile(sas_path) else "")

        setup_path = os.path.join(self.base_path, "utility", "documentation", "setup.xlsx")
        self.setup_entry.setText(setup_path if os.path.isfile(setup_path) else "")

        # 读 setup.EDCSTD → 同步 macro_lbl + 下拉框默认选中
        # v12.10.33: 状态切换抽到 _apply_edcstd_label_state() — 四态:
        #   ok    (已有合法值)  灰白底, 不可点击
        #   empty (值为空)       橙底, 可点击 → 弹窗补值
        #   noRow (行不存在)     红底, 可点击 → 弹窗补行
        #   noFile/异常          红底, 不可点击 (setup.xlsx 都没了, 点也没意义)
        if os.path.isfile(setup_path):
            val, sheet, row = read_setup_macro(setup_path, "EDCSTD")
            if val:
                disp = val.upper()
                if disp in _EDCSTD_OPTIONS:
                    self.edcstd_combo.setCurrentText(disp)
                    self._apply_edcstd_label_state("ok", text=f"{disp}  [{sheet} 行 {row}]")
                else:
                    self.edcstd_combo.setCurrentText(_EDCSTD_DEFAULT)
                    self._apply_edcstd_label_state(
                        "empty",  # 非标准值视同需要确认（运行时会沿用，但视觉与"值为空"同款橙色提醒）
                        text=f"{val}  [{sheet} 行 {row}] ⚠ 非标准值，运行时将沿用此值",
                    )
            elif row > 0:
                self.edcstd_combo.setCurrentText(_EDCSTD_DEFAULT)
                self._apply_edcstd_label_state(
                    "empty", text=f"(值为空，点击写入 UI 当前选择)  [{sheet} 行 {row}]"
                )
            else:
                self.edcstd_combo.setCurrentText(_EDCSTD_DEFAULT)
                self._apply_edcstd_label_state(
                    "noRow", text="(setup.xlsx 中未找到 EDCSTD 行，点击补行)"
                )
        else:
            self.edcstd_combo.setCurrentText(_EDCSTD_DEFAULT)
            self._apply_edcstd_label_state("noFile", text="(setup.xlsx 不存在)")

        # v12.10.19: EDCDEF 双向同步 ——
        #   1) 自动检测 00_source_data 下的 EDC 定义文件（中文「数据库定义」/ 英文 DB Definition）→ 填 LineEdit
        #   2) 读 setup.EDCDEF → 填只读 macro_lbl
        #   两者由 run_import_edcdef() 在 ▶ 时做交叉核查（参照 EDCSTD 现有模式）
        source_dir = os.path.join(self.base_path, "00_source_data")
        detected = _detect_latest_edcdef(source_dir)

        # v12.10.104: 修复「切换项目后沿用上个项目残留 EDCDEF 值」的 bug。
        #   场景：A 项目检测到文件 → 填入；切到 B 项目（其 00_source_data 无任何符合文件），
        #         旧逻辑因 detected=None 而跳过 setText，LineEdit 仍残留 A 项目的文件名。
        #   规则：
        #     · 切换了项目（base 变） → 一律以本项目检测结果为准：检测到→填；检测不到→置空。
        #       （绝不沿用上个项目的残留值）
        #     · 同项目刷新且当前值是自动填的（未被用户手改/浏览）→ 同样跟随检测结果：
        #       文件还在→刷新为最新；文件没了→清空。
        #     · 用户手改 / 浏览选过（_edcdef_autofilled=False 且非切换项目）→ 保留现值不动。
        base_norm = os.path.normcase(os.path.normpath(self.base_path)) if self.base_path else ""
        base_changed = (base_norm != self._edcdef_last_base)
        self._edcdef_last_base = base_norm

        if base_changed or self._edcdef_autofilled:
            if detected:
                self.edcdef_edit.setText(detected)
                self._edcdef_autofilled = True
            else:
                self.edcdef_edit.clear()
                self._edcdef_autofilled = False
        # else: 同项目 + 用户手改过 → 保留 LineEdit 现值（不覆盖手改/浏览结果）

        if os.path.isfile(setup_path):
            val_d, sheet_d, row_d = read_setup_macro(setup_path, "EDCDEF")
            if val_d:
                self._apply_edcdef_label_state("ok", text=f"{val_d}  [{sheet_d} 行 {row_d}]")
            elif row_d > 0:
                self._apply_edcdef_label_state(
                    "empty", text=f"(值为空，点击写入 UI 当前输入)  [{sheet_d} 行 {row_d}]"
                )
            else:
                self._apply_edcdef_label_state(
                    "noRow", text="(setup.xlsx 中未找到 EDCDEF 行，点击补行)"
                )
        else:
            self._apply_edcdef_label_state("noFile", text="(setup.xlsx 不存在)")

    # ------------------------- v12.10.33: 状态切换 + 点击补行 -------------------------
    # 设计要点（与 acrf_edc_recode 中 FILEPATH 同款落地）：
    #   - 红框（行不存在）/ 橙框（值为空）→ cursor=PointingHand, 点击触发补行/写值
    #   - 灰白框（已有合法值）/ 绿框（已补行）→ cursor=Arrow, 点击不响应
    #   - 弹窗用 show_dialog(msg_type="question")：默认焦点在主蓝"确认"按钮，回车快路
    #   - 点击 → 立即写 setup → 切到绿色"已补行"态，不再可点（再点击需手改 setup.xlsx 重启）
    _EDCSTD_STATE_STYLES = {
        # text 由调用方传；这里只规定 (border/bg/color, cursor, clickable)
        "ok":     ("border: 1px solid #E4E7ED; background: #F8F9FA; color: #303133;", Qt.ArrowCursor,        False),
        "empty":  ("border: 1px solid #F5DAB1; background: #FDF6EC; color: #E6A23C;", Qt.PointingHandCursor, True),
        "noRow":  ("border: 1px solid #FBC4C4; background: #FEF0F0; color: #F56C6C;", Qt.PointingHandCursor, True),
        "noFile": ("border: 1px solid #FBC4C4; background: #FEF0F0; color: #F56C6C;", Qt.ArrowCursor,        False),
        # filled = 用户刚点击完成补行，绿色 + 不可点击
        "filled": ("border: 1px solid #B3E19D; background: #F0F9EB; color: #67C23A;", Qt.ArrowCursor,        False),
    }
    _LABEL_BASE = " padding: 6px 10px; border-radius: 4px;"

    def _apply_edcstd_label_state(self, state: str, text: str):
        style_core, cursor, clickable = self._EDCSTD_STATE_STYLES.get(
            state, self._EDCSTD_STATE_STYLES["ok"]
        )
        self.macro_lbl.setText(text)
        self.macro_lbl.setStyleSheet(style_core + self._LABEL_BASE)
        self.macro_lbl.setCursor(cursor)
        self.macro_lbl.setToolTip("点击：把 UI 当前选择写入 setup.xlsx" if clickable else "")

    def _apply_edcdef_label_state(self, state: str, text: str):
        style_core, cursor, clickable = self._EDCSTD_STATE_STYLES.get(
            state, self._EDCSTD_STATE_STYLES["ok"]
        )
        self.edcdef_macro_lbl.setText(text)
        self.edcdef_macro_lbl.setStyleSheet(style_core + self._LABEL_BASE)
        self.edcdef_macro_lbl.setCursor(cursor)
        self.edcdef_macro_lbl.setToolTip("点击：把上方 EDCDEF 输入框的文件名写入 setup.xlsx" if clickable else "")

    def _on_click_edcstd_macro(self):
        """v12.10.33: setup.EDCSTD 红/橙框点击 → 弹窗确认 → 写 setup。

        三种触发情形（与 update_paths 的状态映射一致）：
          - noRow:  行不存在 → 按 template 补行（含 description）+ value=UI 当前选择
          - empty:  行存在 value 空 → 仅 write_setup_macro 写 value
          - empty:  非标准值（不在 HRTAU/RAVE 白名单）→ 同上，覆盖为 UI 选择
        其它情形（ok/noFile/filled）不应触发本函数（cursor 已不是手形），保险兜底直接 return。
        """
        setup_path = self.setup_entry.text().strip()
        if not setup_path or not os.path.isfile(setup_path):
            show_dialog(self, "提示", "setup.xlsx 不可用，无法操作。", "warning")
            return

        chosen = self.edcstd_combo.currentText().strip().upper()
        if chosen not in _EDCSTD_OPTIONS:
            show_dialog(self, "提示",
                        f"上方 EDCSTD 下拉框取值不合法：{chosen}\n仅允许 {' / '.join(_EDCSTD_OPTIONS)}。",
                        "warning")
            return

        # 重新读一遍 setup（避免外部刚改 + 我们已 cache 的不一致）
        cur_val, sheet, row = read_setup_macro(setup_path, "EDCSTD")

        if row == 0:
            # 行不存在 → 弹窗确认 → 按 template 补行
            confirm = show_dialog(
                self, "补 EDCSTD 行",
                f"setup.xlsx 中未找到 EDCSTD 行。\n\n"
                f"将增加一行：\n"
                f"  • Macro_Variable_Name = EDCSTD\n"
                f"  • Macro_Variable_Value = {chosen}（来自上方 UI 下拉框）\n\n"
                f"确认继续？",
                "question"
            )
            if not confirm:
                self.sig_log.emit("<span style='color:#909399;'>已取消补 EDCSTD 行。</span>")
                return
            tpl = _get_edcstd_template_row()
            ok, msg, sheet_n, row_n = append_setup_macro_row(
                setup_path, macro_name="EDCSTD",
                macro_value=chosen, description=tpl["description"],
                template_path=_TEMPLATE_PATH,  # v12.10.97: 按模板位置插入
            )
            if not ok:
                show_dialog(self, "补 EDCSTD 行失败", msg, "error")
                self.sig_log.emit(f"<span style='color:#F56C6C;'>❌ {msg}</span>")
                return
            src_tag = "template" if tpl["source"] == "template" else "hardcode 兜底"
            self.sig_log.emit(f"<span style='color:#67C23A;'>➕ {msg}（描述来自 {src_tag}）</span>")
            self._apply_edcstd_label_state(
                "filled", text=f"✅ 已补行 EDCSTD = {chosen}  [{sheet_n} 行 {row_n}]"
            )
        else:
            # row > 0：值为空 / 非标准值 → 弹窗确认覆盖
            old_disp = cur_val if cur_val else "(空)"
            confirm = show_dialog(
                self, "覆盖 setup.EDCSTD",
                f"setup.xlsx（{sheet} 行 {row}）当前 EDCSTD = {old_disp}\n\n"
                f"将覆盖为：{chosen}（来自上方 UI 下拉框）\n\n"
                f"确认继续？",
                "question"
            )
            if not confirm:
                self.sig_log.emit("<span style='color:#909399;'>已取消覆盖 setup.EDCSTD。</span>")
                return
            ok, msg = write_setup_macro(setup_path, "EDCSTD", chosen)
            if not ok:
                show_dialog(self, "更新 setup 失败", msg, "error")
                self.sig_log.emit(f"<span style='color:#F56C6C;'>❌ {msg}</span>")
                return
            self.sig_log.emit(f"<span style='color:#67C23A;'>✏️ {msg}</span>")
            self._apply_edcstd_label_state(
                "filled", text=f"✅ 已写入 EDCSTD = {chosen}  [{sheet} 行 {row}]"
            )

    def _on_click_edcdef_macro(self):
        """v12.10.33: setup.EDCDEF 红/橙框点击 → 弹窗确认 → 写 setup。

        与 _on_click_edcstd_macro 完全对称，区别：
          - 取值源是 self.edcdef_edit（文本框）而非下拉框
          - 文本框为空 → 弹 warning 提示用户先填，不进 setup 写入
          - 补行/覆盖 description 来自 _get_edcdef_template_row()（已存在 v12.10.19）
        """
        setup_path = self.setup_entry.text().strip()
        if not setup_path or not os.path.isfile(setup_path):
            show_dialog(self, "提示", "setup.xlsx 不可用，无法操作。", "warning")
            return

        chosen_edcdef = self.edcdef_edit.text().strip()
        if not chosen_edcdef:
            show_dialog(
                self, "EDCDEF 为空",
                "上方 EDCDEF 输入框为空，无法写入 setup。\n"
                "请先填入数据库定义文件名，或点 📁 浏览 选择 00_source_data 下的 .xlsx 文件。",
                "warning"
            )
            return

        cur_def, sheet_d, row_d = read_setup_macro(setup_path, "EDCDEF")

        if row_d == 0:
            confirm = show_dialog(
                self, "补 EDCDEF 行",
                f"setup.xlsx 中未找到 EDCDEF 行。\n\n"
                f"将增加一行：\n"
                f"  • Macro_Variable_Name = EDCDEF\n"
                f"  • Macro_Variable_Value = {chosen_edcdef}（来自上方 UI 输入框）\n\n"
                f"确认继续？",
                "question"
            )
            if not confirm:
                self.sig_log.emit("<span style='color:#909399;'>已取消补 EDCDEF 行。</span>")
                return
            tpl = _get_edcdef_template_row()
            ok, msg, sheet_n, row_n = append_setup_macro_row(
                setup_path, macro_name="EDCDEF",
                macro_value=chosen_edcdef, description=tpl["description"],
                template_path=_TEMPLATE_PATH,  # v12.10.97: 按模板位置插入
            )
            if not ok:
                show_dialog(self, "补 EDCDEF 行失败", msg, "error")
                self.sig_log.emit(f"<span style='color:#F56C6C;'>❌ {msg}</span>")
                return
            src_tag = "template" if tpl["source"] == "template" else "hardcode 兜底"
            self.sig_log.emit(f"<span style='color:#67C23A;'>➕ {msg}（描述来自 {src_tag}）</span>")
            self._apply_edcdef_label_state(
                "filled", text=f"✅ 已补行 EDCDEF = {chosen_edcdef}  [{sheet_n} 行 {row_n}]"
            )
        else:
            old_disp = cur_def if cur_def else "(空)"
            confirm = show_dialog(
                self, "覆盖 setup.EDCDEF",
                f"setup.xlsx（{sheet_d} 行 {row_d}）当前 EDCDEF = {old_disp}\n\n"
                f"将覆盖为：{chosen_edcdef}（来自上方 UI 输入框）\n\n"
                f"确认继续？",
                "question"
            )
            if not confirm:
                self.sig_log.emit("<span style='color:#909399;'>已取消覆盖 setup.EDCDEF。</span>")
                return
            ok, msg = write_setup_macro(setup_path, "EDCDEF", chosen_edcdef)
            if not ok:
                show_dialog(self, "更新 setup 失败", msg, "error")
                self.sig_log.emit(f"<span style='color:#F56C6C;'>❌ {msg}</span>")
                return
            self.sig_log.emit(f"<span style='color:#67C23A;'>✏️ {msg}</span>")
            self._apply_edcdef_label_state(
                "filled", text=f"✅ 已写入 EDCDEF = {chosen_edcdef}  [{sheet_d} 行 {row_d}]"
            )

    def set_wait_hint(self, show):
        if show:
            self.scan_lbl.setText("⏳ 等待填写完整路径...")
            self.scan_lbl.setStyleSheet(scan_status_lbl_style())
        else:
            self.scan_lbl.setText("")

    # ------------------------- 浏览 / 打开 -------------------------
    def _open_setup_file(self):
        p = self.setup_entry.text().strip()
        if p and os.path.isfile(p):
            os.startfile(p)
        else:
            show_dialog(self, "提示", "找不到 setup.xlsx 文件。", "warning")

    def _open_sas_file(self):
        p = self.sas_entry.text().strip()
        if p and os.path.isfile(p):
            os.startfile(p)
        else:
            show_dialog(self, "提示", "找不到 24_import_edcdef_call.sas 文件。", "warning")

    def _browse_edcdef(self):
        """v12.10.19: 浏览选择数据库定义文件，默认定位 00_source_data。

        只取 basename 写回 LineEdit —— setup.EDCDEF 与同类宏变量（SDTMSPEC/AECODE）
        约定只存文件名，由 SAS 端按 &source. 路径解析。
        """
        source_dir = os.path.join(self.base_path, "00_source_data") if self.base_path else ""
        start_dir = source_dir if os.path.isdir(source_dir) else (self.base_path or "")
        fp, _ = QFileDialog.getOpenFileName(
            self, "选择数据库定义文件", start_dir,
            "Excel 文件 (*.xlsx);;所有文件 (*)"
        )
        if fp:
            self.edcdef_edit.setText(os.path.basename(fp))
            # v12.10.104: 浏览选择 = 用户主动指定 → 标记为「非自动填」，后续刷新不被检测覆盖/清空。
            self._edcdef_autofilled = False

    def _open_metadata_folder(self):
        """v12.10.20: 打开当前项目的 utility/metadata 文件夹。

        EDC 定义导入步骤的 SAS 输出落点 — 跑完后用户常需要查看
        _edcdef_ecrf_99 / _edcdef_visit_99 等元数据集，提供一键打开。
        路径不存在时给 warning（不静默失败，便于排查项目目录是否完整）。
        """
        if not self.base_path:
            show_dialog(self, "提示", "尚未选择项目路径。", "warning")
            return
        meta_dir = os.path.join(self.base_path, "utility", "metadata")
        if not os.path.isdir(meta_dir):
            show_dialog(
                self, "找不到 metadata 目录",
                f"路径不存在：\n{meta_dir}\n\n"
                f"通常 ▶ 运行 Import EDC Definition 成功后会自动生成此目录。",
                "warning"
            )
            return
        try:
            os.startfile(meta_dir)
        except Exception as e:
            show_dialog(self, "打开失败", f"无法打开：{meta_dir}\n\n{e}", "error")

    # ------------------------- 全局快捷键钩子 -------------------------
    def action_refresh(self):
        btn = getattr(self, "refresh_btn", None)
        if btn is not None and btn.isEnabled():
            btn.click()

    def action_run(self):
        if self.btn_run.isEnabled() and self.btn_run.isVisible():
            self.btn_run.click()

    # ------------------------- 运行入口 -------------------------
    def run_import_edcdef(self):
        """点击 ▶ 运行：交叉核查 setup.EDCSTD vs UI 选择 → 决定是否改 setup → 跑 SAS"""
        chosen = self.edcstd_combo.currentText().strip().upper()
        if chosen not in _EDCSTD_OPTIONS:
            show_dialog(self, "提示", f"EDCSTD 取值不合法：{chosen}\n仅允许 {' / '.join(_EDCSTD_OPTIONS)}。", "warning")
            return

        sas_path = self.sas_entry.text().strip()
        if not sas_path or not os.path.isfile(sas_path):
            show_dialog(self, "错误", f"找不到 SAS 调用脚本：\n{sas_path}", "error")
            return

        setup_path = self.setup_entry.text().strip()
        if not setup_path or not os.path.isfile(setup_path):
            show_dialog(self, "错误", f"找不到 setup.xlsx：\n{setup_path}", "error")
            return

        # 防重入
        if self._runner is not None and self._runner.isRunning():
            self.sig_log.emit("<span style='color:#E6A23C;'>⏳ 上一次 Import 仍在运行中，请稍候…</span>")
            return

        # 读 setup.EDCSTD
        cur_val, sheet, row = read_setup_macro(setup_path, "EDCSTD")
        cur_upper = cur_val.upper() if cur_val else ""

        if row == 0:
            # v12.10.33: 行不存在 → 不再弹错 return，改为三选项征询：
            #   - use_ui:    按 UI 选择补行
            #   - use_tpl:   按 template 默认值（通常是 HRTAU）补行
            #   - 取消
            # （正常路径下用户应该已经先点红框补行，这里是"用户没点红框直接点运行"的兜底）
            tpl = _get_edcstd_template_row()
            tpl_val = (tpl.get("macro_value") or "").strip().upper() or _EDCSTD_DEFAULT
            if tpl_val not in _EDCSTD_OPTIONS:
                tpl_val = _EDCSTD_DEFAULT
            choice = show_choice_dialog(
                self,
                title="Import EDC Definition — setup.xlsx 中无 EDCSTD 行",
                text=(
                    "setup.xlsx 中未找到 EDCSTD 宏变量行，无法直接运行 SAS。\n\n"
                    "可在 setup 中追加一行 EDCSTD，请选择写入的值：\n\n"
                    f"  • UI 下拉框当前选择：{chosen}\n"
                    f"  • setup_template 默认值：{tpl_val}\n"
                ),
                options=[
                    (f"✅ 使用 UI 选择 ({chosen})", "use_ui"),
                    (f"📋 使用 template 默认 ({tpl_val})", "use_tpl"),
                ],
                cancellable=True,
            )
            if choice is None:
                self.sig_log.emit("<span style='color:#909399;'>已取消 Import EDC Definition。</span>")
                return
            write_val = chosen if choice == "use_ui" else tpl_val
            ok, msg, sheet, row = append_setup_macro_row(
                setup_path, macro_name="EDCSTD",
                macro_value=write_val, description=tpl["description"],
                template_path=_TEMPLATE_PATH,  # v12.10.97: 按模板位置插入
            )
            if not ok:
                show_dialog(self, "补 EDCSTD 行失败", msg, "error")
                self.sig_log.emit(f"<span style='color:#F56C6C;'>❌ {msg}</span>")
                return
            src_tag = "template" if tpl["source"] == "template" else "hardcode 兜底"
            self.sig_log.emit(f"<span style='color:#67C23A;'>➕ {msg}（描述来自 {src_tag}）</span>")
            self._apply_edcstd_label_state(
                "filled", text=f"✅ 已补行 EDCSTD = {write_val}  [{sheet} 行 {row}]"
            )
            # 同步 UI 下拉框 + chosen 给下方逻辑用
            if write_val in _EDCSTD_OPTIONS:
                self.edcstd_combo.setCurrentText(write_val)
            chosen = write_val
            cur_val = write_val  # 让下方"已一致"分支走通
            cur_upper = write_val.upper()

        if cur_upper == chosen:
            # 已是目标值，直接运行
            self.sig_log.emit(
                f"<span style='color:#909399;'>&nbsp;&nbsp;ℹ️ setup.EDCSTD 已是 {chosen}，无需更新。</span>"
            )
        elif not cur_val:
            # value 为空 → 弹窗征询写入
            choice = show_choice_dialog(
                self,
                title="Import EDC Definition — setup.EDCSTD 值为空",
                text=(
                    f"setup.xlsx（{sheet} 行 {row}）中 EDCSTD 的 value 为空，SAS 会因此 ERROR 退出。\n\n"
                    f"  • 你选择的 EDCSTD：{chosen}\n\n"
                    f"是否将其写入 setup 后继续运行？"
                ),
                options=[
                    ("✅ 写入所选值到 setup", "use_chosen"),
                ],
                cancellable=True,
            )
            if choice is None:
                self.sig_log.emit("<span style='color:#909399;'>已取消 Import EDC Definition。</span>")
                return
            ok, msg = write_setup_macro(setup_path, "EDCSTD", chosen)
            if not ok:
                show_dialog(self, "更新 setup 失败", msg, "error")
                self.sig_log.emit(f"<span style='color:#F56C6C;'>❌ {msg}</span>")
                return
            self.sig_log.emit(f"<span style='color:#67C23A;'>✏️ {msg}</span>")
            self.macro_lbl.setText(f"{chosen}  [{sheet} 行 {row}]")
            self.macro_lbl.setStyleSheet(
                "border: 1px solid #E4E7ED; background: #F8F9FA; color: #303133; padding: 6px 10px; border-radius: 4px;")
        else:
            # 不一致 → 弹"覆盖重新 setup"或"沿用 setup 已有值"
            choice = show_choice_dialog(
                self,
                title="Import EDC Definition — UI 选择与 setup.EDCSTD 不一致",
                text=(
                    f"当前 UI 选择与 setup.xlsx 的 EDCSTD 不一致：\n\n"
                    f"  • UI 选择：{chosen}\n"
                    f"  • setup.EDCSTD（{sheet} 行 {row}）：{cur_val}\n\n"
                    f"请选择要使用哪一个，并继续运行："
                ),
                options=[
                    ("✅ 使用 UI 选择（覆盖重新 setup）", "use_chosen"),
                    ("ℹ️ 沿用 setup 已有值", "use_setup"),
                ],
                cancellable=True,
            )
            if choice is None:
                self.sig_log.emit("<span style='color:#909399;'>已取消 Import EDC Definition。</span>")
                return

            if choice == "use_chosen":
                ok, msg = write_setup_macro(setup_path, "EDCSTD", chosen)
                if not ok:
                    show_dialog(self, "更新 setup 失败", msg, "error")
                    self.sig_log.emit(f"<span style='color:#F56C6C;'>❌ {msg}</span>")
                    return
                self.sig_log.emit(f"<span style='color:#67C23A;'>✏️ {msg}</span>")
                self.macro_lbl.setText(f"{chosen}  [{sheet} 行 {row}]")
                self.macro_lbl.setStyleSheet(
                    "border: 1px solid #E4E7ED; background: #F8F9FA; color: #303133; padding: 6px 10px; border-radius: 4px;")
            else:
                # 沿用 setup：UI 同步成 setup 的值
                self.edcstd_combo.setCurrentText(cur_upper if cur_upper in _EDCSTD_OPTIONS else _EDCSTD_DEFAULT)
                chosen = cur_upper
                self.sig_log.emit(
                    f"<span style='color:#909399;'>ℹ️ 沿用 setup.EDCSTD = {cur_val}，未修改 setup.xlsx。</span>"
                )

        # ===========================================================================
        # v12.10.19: EDCDEF 交叉核查（独立于 EDCSTD 三分支，串行处理）
        # ---------------------------------------------------------------------------
        # 与 EDCSTD 同款"读 setup → 三分支"逻辑，但多一个"行不存在 → 补行"分支
        # （EDCSTD 找不到行直接报错让用户手补；EDCDEF 行确认是用户场景下常见缺失项，
        # 主动按 template 补一行更友好）。
        # ---------------------------------------------------------------------------
        chosen_edcdef = self.edcdef_edit.text().strip()
        if not chosen_edcdef:
            show_dialog(
                self, "EDCDEF 为空",
                "EDCDEF 输入框为空。\n"
                "请填入数据库定义文件名，或点 📁 浏览 选择 00_source_data 下的 .xlsx 文件。",
                "warning"
            )
            return

        cur_def, sheet_d, row_d = read_setup_macro(setup_path, "EDCDEF")

        if row_d == 0:
            # 行完全不存在 → 按 template 补一行（核心新逻辑）
            tpl = _get_edcdef_template_row()
            ok, msg, sheet_d, row_d = append_setup_macro_row(
                setup_path,
                macro_name="EDCDEF",
                macro_value=chosen_edcdef,
                description=tpl["description"],
                template_path=_TEMPLATE_PATH,  # v12.10.97: 按模板位置插入
            )
            if not ok:
                show_dialog(self, "补 EDCDEF 行失败", msg, "error")
                self.sig_log.emit(f"<span style='color:#F56C6C;'>❌ {msg}</span>")
                return
            src_tag = "template" if tpl["source"] == "template" else "hardcode 兜底"
            self.sig_log.emit(
                f"<span style='color:#67C23A;'>➕ {msg}（描述来自 {src_tag}）</span>"
            )
            self.edcdef_macro_lbl.setText(f"{chosen_edcdef}  [{sheet_d} 行 {row_d}]")
            self.edcdef_macro_lbl.setStyleSheet(
                "border: 1px solid #E4E7ED; background: #F8F9FA; color: #303133; padding: 6px 10px; border-radius: 4px;")
        elif cur_def == chosen_edcdef:
            # 一致 → 静默
            self.sig_log.emit(
                f"<span style='color:#909399;'>&nbsp;&nbsp;ℹ️ setup.EDCDEF 已是 {chosen_edcdef}，无需更新。</span>"
            )
        elif not cur_def:
            # 行存在但 value 为空 → 弹窗征询写入
            choice_d = show_choice_dialog(
                self,
                title="Import EDC Definition — setup.EDCDEF 值为空",
                text=(
                    f"setup.xlsx（{sheet_d} 行 {row_d}）中 EDCDEF 的 value 为空，SAS 会因此 ERROR 退出。\n\n"
                    f"  • 你输入的 EDCDEF：{chosen_edcdef}\n\n"
                    f"是否将其写入 setup 后继续运行？"
                ),
                options=[("✅ 写入所选值到 setup", "use_chosen")],
                cancellable=True,
            )
            if choice_d is None:
                self.sig_log.emit("<span style='color:#909399;'>已取消 Import EDC Definition。</span>")
                return
            ok, msg = write_setup_macro(setup_path, "EDCDEF", chosen_edcdef)
            if not ok:
                show_dialog(self, "更新 setup 失败", msg, "error")
                self.sig_log.emit(f"<span style='color:#F56C6C;'>❌ {msg}</span>")
                return
            self.sig_log.emit(f"<span style='color:#67C23A;'>✏️ {msg}</span>")
            self.edcdef_macro_lbl.setText(f"{chosen_edcdef}  [{sheet_d} 行 {row_d}]")
            self.edcdef_macro_lbl.setStyleSheet(
                "border: 1px solid #E4E7ED; background: #F8F9FA; color: #303133; padding: 6px 10px; border-radius: 4px;")
        else:
            # 不一致 → 弹"覆盖"或"沿用 setup 已有值"
            choice_d = show_choice_dialog(
                self,
                title="Import EDC Definition — UI 输入与 setup.EDCDEF 不一致",
                text=(
                    f"当前 UI 输入与 setup.xlsx 的 EDCDEF 不一致：\n\n"
                    f"  • UI 输入：{chosen_edcdef}\n"
                    f"  • setup.EDCDEF（{sheet_d} 行 {row_d}）：{cur_def}\n\n"
                    f"请选择要使用哪一个，并继续运行："
                ),
                options=[
                    ("✅ 使用 UI 输入（覆盖重新 setup）", "use_chosen"),
                    ("ℹ️ 沿用 setup 已有值", "use_setup"),
                ],
                cancellable=True,
            )
            if choice_d is None:
                self.sig_log.emit("<span style='color:#909399;'>已取消 Import EDC Definition。</span>")
                return
            if choice_d == "use_chosen":
                ok, msg = write_setup_macro(setup_path, "EDCDEF", chosen_edcdef)
                if not ok:
                    show_dialog(self, "更新 setup 失败", msg, "error")
                    self.sig_log.emit(f"<span style='color:#F56C6C;'>❌ {msg}</span>")
                    return
                self.sig_log.emit(f"<span style='color:#67C23A;'>✏️ {msg}</span>")
                self.edcdef_macro_lbl.setText(f"{chosen_edcdef}  [{sheet_d} 行 {row_d}]")
                self.edcdef_macro_lbl.setStyleSheet(
                    "border: 1px solid #E4E7ED; background: #F8F9FA; color: #303133; padding: 6px 10px; border-radius: 4px;")
            else:
                # 沿用 setup：UI 回填成 setup 当前值
                self.edcdef_edit.setText(cur_def)
                chosen_edcdef = cur_def
                self.sig_log.emit(
                    f"<span style='color:#909399;'>ℹ️ 沿用 setup.EDCDEF = {cur_def}，未修改 setup.xlsx。</span>"
                )

        # 进入运行态
        self.sig_run_started.emit()
        self.sig_status.emit("⏳ 正在执行 Import EDC Definition…", "#409EFF")
        self.sig_log.emit(
            f"<span style='color:#409EFF; font-weight:bold;'>🚀 准备执行 24_import_edcdef_call.sas</span>"
        )
        self.sig_log.emit(f"<span style='color:#909399;'>&nbsp;&nbsp;EDCSTD：{chosen}</span>")
        self.sig_log.emit(f"<span style='color:#909399;'>&nbsp;&nbsp;EDCDEF：{chosen_edcdef}</span>")
        self.sig_log.emit(f"<span style='color:#909399;'>&nbsp;&nbsp;脚本：{sas_path}</span>")

        self.btn_run.setVisible(False)
        self.btn_cancel.setVisible(True)
        self.prog.setRange(0, 0)
        self.prog.setVisible(True)

        # SAS 脚本本身用 &edcstd. 读 setup，无需改写脚本
        self._runner = SingleBatchRunner(sas_path)
        self._runner.finished_signal.connect(self._on_runner_finished)
        self._t_start = time.time()
        self._runner.start()

    def _on_cancel_run(self):
        """v12.10.20: 修复"中止时无痕闪退"，与 acrf_edc_recode v12.10.17 / acrf_unzip 同模式。

        闪退根因（race window）：
          T0  SingleBatchRunner.run() 走过 line 87 的 is_cancelled 检查（此刻仍 False）
          T1  用户点中止 → 旧逻辑设 self._runner = None
          T2  run() 在 line 103 emit finished_signal（SAS 子进程恰好正常退出）
          T3  main thread 触发 _on_runner_finished
          T4  访问 self._runner.script_path → NoneType.attr → Qt 槽未捕获异常 → 闪退
        修法：
          - 加 self._cancelled 标志区分"用户主动中止"
          - 不在 cancel 内立即清 self._runner（让可能仍触发的 finished 回调能进入分支）
          - _on_runner_finished 检测 _cancelled → 直接 return（不读 script_path）
        """
        runner = self._runner
        if runner is None or not runner.isRunning():
            self._reset_ui_after_run()
            return
        self._cancelled = True   # v12.10.20: 让 _on_runner_finished 检测后直接 return
        runner.is_cancelled = True
        try:
            if runner.proc and runner.proc.poll() is None:
                runner.proc.kill()
        except Exception:
            pass
        self.sig_status.emit("🛑 已中止 Import EDC Definition", "#F56C6C")
        self.sig_step_update.emit("03 Import EDC Definition 🟥")
        self.sig_log.emit("<span style='color:#F56C6C; font-weight:bold;'>🛑 用户已中止 Import EDC Definition 运行。</span>")
        self._reset_ui_after_run()
        # v12.10.20: 不再立即 self._runner = None — race window 内 finished 回调可能仍触发，
        # 留给 _on_runner_finished 内统一清理。

    def _reset_ui_after_run(self):
        self.prog.setVisible(False)
        self.btn_run.setVisible(True)
        self.btn_cancel.setVisible(False)

    def _on_runner_finished(self, has_issue, summary, log_text):
        # v12.10.20: 用户主动中止 → cancel 内已 emit 状态 + 复位 UI，这里直接清理 runner 引用并 return，
        # 避免重复 emit + 避免 self._runner.attr 访问报错（原闪退根因）
        if getattr(self, "_cancelled", False):
            self._cancelled = False
            thread_ref = self._runner
            self._runner = None
            if thread_ref is not None:
                try:
                    thread_ref.finished.connect(thread_ref.deleteLater)
                except Exception:
                    pass
            return

        self._reset_ui_after_run()
        elapsed = time.time() - getattr(self, "_t_start", time.time())

        # 严格按日志严重程度分级（不依赖 has_issue 二值，避免 WARNING 也用红色）
        sev = classify_log_severity(log_text)
        severity = sev["severity"]
        step_label = "Import EDC Definition"

        if severity == "error":
            self.sig_status.emit(f"❌ {step_label} 完成（含 ERROR）", "#F56C6C")
            self.sig_step_update.emit("03 Import EDC Definition ❌")
            self.sig_log.emit(severity_finished_html(step_label, severity, summary))
            self.sig_log.emit(extract_issue_lines_html(log_text))
        elif severity == "warning":
            self.sig_status.emit(f"⚠️ {step_label} 完成（含 WARNING）", "#E6A23C")
            self.sig_step_update.emit("03 Import EDC Definition ⚠️")
            self.sig_log.emit(severity_finished_html(step_label, severity, summary))
            self.sig_log.emit(extract_issue_lines_html(log_text))
        else:
            self.sig_status.emit(f"✅ {step_label} 完成（{elapsed:.1f}s）", "#67C23A")
            self.sig_step_update.emit("03 Import EDC Definition ✅")
            self.sig_log.emit(severity_finished_html(step_label, severity, summary, elapsed))

        # v12.10.20: 安全读 script_path（兜底 None），即便走到这里 runner 仍可能在极限 race 下被释放
        try:
            if self._runner is not None and getattr(self._runner, "script_path", None):
                log_path = os.path.splitext(self._runner.script_path)[0] + ".log"
                if os.path.exists(log_path):
                    self.sig_log.emit(f"<span style='color:#909399;'>&nbsp;&nbsp;详细日志：{log_path}</span>")
        except Exception:
            pass

        thread_ref = self._runner
        self._runner = None
        if thread_ref is not None:
            try:
                thread_ref.finished.connect(thread_ref.deleteLater)
            except Exception:
                pass

    @staticmethod
    def _extract_issue_lines(log_text: str) -> str:
        # 已迁移到 sdtm_common.extract_issue_lines_html；保留一个 thin wrapper 以防外部调用
        return extract_issue_lines_html(log_text)
