# -*- coding: utf-8 -*-
"""
modules/acrf_annotation_update.py
=================================
aCRF 模块「05 aCRF Update」左侧业务表单 + 自带右侧面板（…；129 文案;130 图例独立成行防遮挡）。

职责（只做 update，不做翻译）：
  左侧参数面板：
    · 新版 eCRF PDF（在 062_acrf 下浏览手选）
    · 旧版 eCRF PDF（在 062_acrf 下浏览手选）
    · 旧版 xfdf（在 062_acrf/final 下自动选最新的一份，标签显示选中项，可手动改选）
    · ▶ 运行 aCRF Update
  右侧面板（本表单自带 create_right_panel，不复用 04 的共享编辑器 → 04 零影响）：
    Tab1 运行日志 / Tab2 annomap4update 编辑器（PAGE|ORIGIN|STANDARD）
      - 自动从旧 CRF 匹配（迁移）的表单行 → 灰底、STANDARD 锁定不可改（#3）
      - autoanno 自动补白的表单行 → 浅青蓝底(#C9E9F5)，STANDARD 可改；改后转蓝(#D6E8FF+边框+加粗)
      - 三个按钮（💾 保存并重跑 / 📝 批量赋值 / 📋 导入 xfdf）+ STANDARD 表头 ▽ 筛选，与 04 一致
      - 「保存并重跑」= 保存非灰色行的 STANDARD 到 annomap4update → 重跑整个 update
        （迁移人工注释不动，只按新 STANDARD 重生成空白页的 autoanno 补白，再合并）

重活隔离：run_acrf_update 内部拉 autoanno（pdfminer）+ PyPDF2 + 合并，全持 GIL。
  按 SPAhub 红线走独立子进程 modules/acrf_annotation_update_runner.py，父进程另起线程
  逐行读 stdout（JSON）→ emit sig_log / 状态。annomap 读/写沿用 04 的子线程模式。

依赖：引擎为外部 sibling 包 acrf_update_spahub（部署 Z:/projects/Z_PYTHON/aCRF/acrf_update_spahub，
  与 autoanno_draft 平级）；由 runner 磁盘定位后导入。autoanno_draft 亦外部（引擎磁盘定位）。
"""
import os
import json
import subprocess

from PySide6.QtWidgets import (QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                               QLineEdit, QFileDialog, QFrame, QTabWidget,
                               QTextEdit, QTableWidget, QTableWidgetItem,
                               QComboBox, QCompleter, QAbstractScrollArea,
                               QSizePolicy, QHeaderView, QStyledItemDelegate,
                               QLineEdit as _QLineEdit, QStyleOptionViewItem,
                               QStyle, QApplication, QDialog, QMenu,
                               QListWidget, QListWidgetItem, QAbstractItemView)
from PySide6.QtCore import Qt, Signal, QThread, QRect, QPoint
from PySide6.QtGui import (QTextOption, QColor, QPainter, QPolygon, QPalette)

from ui_utils import (show_dialog, show_choice_dialog, primary_btn_style,
                      danger_btn_style, success_btn_style, light_btn_style,
                      primary_outline_btn_style, scan_status_lbl_style,
                      log_textedit_style)
try:
    from gui.log_search import attach_log_search
except Exception:  # 容错：日志搜索是可选增强
    def attach_log_search(_w):  # type: ignore
        return None

try:
    from app_paths import child_command_acrf_update
except Exception:
    child_command_acrf_update = None  # 由 _build_child_cmd 兜底

import sys as _sys

# aCRF 目录相对 base_path 的层级
_ACRF_REL = ("utility", "documentation", "06_crt_preparation", "062_acrf")
_FINAL_REL = _ACRF_REL + ("final",)
_DRAFT_REL = _ACRF_REL + ("draft",)
# 迁移覆盖行的灰底
_GREY_RGB = (238, 240, 243)          # #EEF0F3（自动对齐/迁移行 —— 中性灰）
# v12.10.128：autoanno 新增(补白)行底色 —— 浅青蓝 #C9E9F5。刻意选偏青的色相，
#   与「自动对齐灰 #EEF0F3(中性)」和「STANDARD 改后蓝 #D6E8FF(偏紫天蓝)+#409EFF 边框」
#   都拉开距离，低分屏也能区分（原白底在低分屏与灰底难辨）。
_NEW_RGB = (201, 233, 245)           # #C9E9F5
_BLUE_EDIT_STYLE = "background-color:#ECF5FF;"   # 改动透蓝（同普通 annomap 修改）


# ============================================================================
# 复用 04 已验证的 annomap 编辑器基础设施（原样复制，隔离 04）
# ============================================================================
class _NoWheelComboBox(QComboBox):
    """禁滚轮改值 + 禁右键菜单（三重防线），防表格滚动时误改 STANDARD。"""
    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self.setContextMenuPolicy(Qt.NoContextMenu)

    def setEditable(self, editable):
        super().setEditable(editable)
        le = self.lineEdit()
        if le is not None:
            le.setContextMenuPolicy(Qt.NoContextMenu)

    def wheelEvent(self, event):
        event.ignore()

    def contextMenuEvent(self, event):
        event.ignore()


class _FilterHeaderView(QHeaderView):
    """STANDARD 列表头右侧的 ▽ Excel 式筛选按钮。"""
    filter_clicked = Signal(int)

    def __init__(self, orientation, parent=None):
        super().__init__(orientation, parent)
        self._filter_col = -1
        self._filter_active = False
        self.setSectionsClickable(True)

    def set_filter_column(self, col):
        if col != self._filter_col:
            self._filter_col = col
            self.viewport().update()

    def set_filter_active(self, active):
        active = bool(active)
        if active != self._filter_active:
            self._filter_active = active
            self.viewport().update()

    @staticmethod
    def _glyph_rect(section_rect):
        sz = 16
        x = section_rect.right() - sz - 5
        y = section_rect.center().y() - sz // 2
        return QRect(x, y, sz, sz)

    def paintSection(self, painter, rect, logicalIndex):
        super().paintSection(painter, rect, logicalIndex)
        if logicalIndex != self._filter_col or rect.width() < 60:
            return
        gr = self._glyph_rect(rect)
        painter.save()
        painter.setRenderHint(QPainter.Antialiasing, True)
        active = self._filter_active
        painter.setBrush(QColor("#409EFF") if active else QColor("#FFFFFF"))
        painter.setPen(QColor("#409EFF") if active else QColor("#C0C4CC"))
        painter.drawRoundedRect(gr, 3, 3)
        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor("#FFFFFF") if active else QColor("#606266"))
        cx, cy = gr.center().x(), gr.center().y()
        tri = QPolygon([QPoint(cx - 4, cy - 2), QPoint(cx + 4, cy - 2), QPoint(cx, cy + 3)])
        painter.drawPolygon(tri)
        painter.restore()

    def mousePressEvent(self, event):
        if self._filter_col >= 0:
            try:
                pos = event.position().toPoint()
            except AttributeError:
                pos = event.pos()
            logical = self.logicalIndexAt(pos.x())
            if logical == self._filter_col:
                x = self.sectionViewportPosition(logical)
                w = self.sectionSize(logical)
                section_rect = QRect(x, 0, w, self.height())
                if self._glyph_rect(section_rect).contains(pos):
                    self.filter_clicked.emit(logical)
                    return
        super().mousePressEvent(event)


class _ReadOnlyEditDelegate(QStyledItemDelegate):
    """PAGE / ORIGIN 双击进只读编辑态（可选字符复制），并接管 paint 修 hover 字消失。"""
    def createEditor(self, parent, option, index):
        editor = _QLineEdit(parent)
        editor.setReadOnly(True)
        editor.setStyleSheet("QLineEdit { border:1px solid #409EFF; background:#FFFFFF; "
                             "padding:2px 4px; color:#303133; }")
        return editor

    def setEditorData(self, editor, index):
        editor.setText(index.data(Qt.DisplayRole) or "")
        editor.selectAll()

    def setModelData(self, editor, model, index):
        pass

    def paint(self, painter, option, index):
        opt = QStyleOptionViewItem(option)
        self.initStyleOption(opt, index)
        is_hover = bool(option.state & QStyle.State_MouseOver)
        is_selected = bool(option.state & QStyle.State_Selected)
        opt.state &= ~QStyle.State_MouseOver
        for grp in (QPalette.Active, QPalette.Inactive, QPalette.Disabled):
            opt.palette.setColor(grp, QPalette.HighlightedText, QColor("#303133"))
        widget = opt.widget
        style = widget.style() if widget else QApplication.style()
        style.drawControl(QStyle.CE_ItemViewItem, opt, painter, widget)
        if is_hover and not is_selected:
            painter.save()
            painter.fillRect(option.rect, QColor(64, 158, 255, 25))
            painter.restore()


class _AnnomapLoadThread(QThread):
    """openpyxl 读 annomap（data + style）到子线程，主线程只做渲染。"""
    finished_signal = Signal(bool, object)

    def __init__(self, path, parent=None):
        super().__init__(parent)
        self.path = path

    def run(self):
        import logging
        try:
            import openpyxl
            wb_data = openpyxl.load_workbook(self.path, data_only=True, read_only=True)
            ws = wb_data.active
            rows_data = [list(r) for r in ws.iter_rows(values_only=True)]
            wb_data.close()
            if not rows_data or len(rows_data) < 2:
                self.finished_signal.emit(True, {"empty": True})
                return
            max_col = max(len(r) for r in rows_data)
            max_row = len(rows_data)
            headers = ["" if (j >= len(rows_data[0]) or rows_data[0][j] is None)
                       else str(rows_data[0][j]) for j in range(max_col)]
            hl = [h.lower() for h in headers]
            page_col = hl.index("page") if "page" in hl else -1
            std_col = hl.index("standard") if "standard" in hl else -1
            origin_col = hl.index("origin") if "origin" in hl else -1

            std_uniques = set()
            if std_col >= 0:
                for i in range(1, max_row):
                    row = rows_data[i]
                    if std_col < len(row) and row[std_col] is not None:
                        s = str(row[std_col]).strip()
                        if s:
                            std_uniques.add(s)
            std_options = [""] + sorted(std_uniques)

            visible_rows = []
            for i in range(1, max_row):
                row = rows_data[i]
                if page_col >= 0:
                    pv = row[page_col] if page_col < len(row) else None
                    if pv is None or not str(pv).strip():
                        continue
                visible_rows.append((i, i + 1))

            cell_bgs = {}
            try:
                wb_style = openpyxl.load_workbook(self.path, data_only=True, read_only=False)
                wss = wb_style.active
                for tr, (data_idx, src_row) in enumerate(visible_rows):
                    for j in range(max_col):
                        if j == std_col:
                            continue
                        try:
                            rgb = self._extract_cell_bg_rgb(wss.cell(row=src_row, column=j + 1))
                            if rgb is not None:
                                cell_bgs[(tr, j)] = rgb
                        except Exception:
                            pass
                wb_style.close()
            except Exception as e:
                logging.error(f"[update]annomap 样式读失败：{e}")

            self.finished_signal.emit(True, {
                "empty": False, "headers": headers, "rows_data": rows_data,
                "max_col": max_col, "max_row": max_row, "std_col": std_col,
                "page_col": page_col, "origin_col": origin_col,
                "std_options": std_options, "visible_rows": visible_rows,
                "cell_bgs": cell_bgs,
            })
        except Exception as e:
            logging.error(f"[update]annomap 加载失败：{e}", exc_info=True)
            self.finished_signal.emit(False, str(e))

    @staticmethod
    def _extract_cell_bg_rgb(cell):
        try:
            fill = cell.fill
            if fill is None or fill.fill_type not in ("solid",):
                return None
            color = fill.start_color
            if color is None or color.type != "rgb" or not color.rgb:
                return None
            s = str(color.rgb)
            if len(s) == 8:
                s = s[2:]
            if len(s) != 6:
                return None
            r, g, b = int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16)
            if r >= 240 and g >= 240 and b >= 240:
                return None
            return (r, g, b)
        except Exception:
            return None


class _AnnomapSaveThread(QThread):
    """把 STANDARD 列写回 annomap4update.xlsx（子线程，避免 openpyxl 写盘卡 UI）。"""
    finished_signal = Signal(bool, str)

    def __init__(self, path, col_1based, updates, parent=None):
        super().__init__(parent)
        self.path = path
        self.col = col_1based
        self.updates = updates

    def run(self):
        try:
            import openpyxl
            wb = openpyxl.load_workbook(self.path)
            ws = wb.active
            for src_row, new_val in self.updates:
                ws.cell(row=src_row, column=self.col).value = (new_val or None)
            wb.save(self.path)
            wb.close()
        except Exception as e:
            self.finished_signal.emit(False, str(e))
            return
        self.finished_signal.emit(True, "")


# ============================================================================
# runner 子进程 stdout 逐行读取线程
# ============================================================================
class _UpdateRunnerThread(QThread):
    """起 acrf_annotation_update_runner 子进程，逐行读 JSON。"""
    sig_line = Signal(str, str)        # level, msg
    sig_result = Signal(bool, object)  # ok, payload(dict)

    def __init__(self, cmd, args_json, parent=None):
        super().__init__(parent)
        self._cmd = cmd
        self._args_json = args_json
        self._proc = None
        self._cancelled = False

    def run(self):
        # v12.10.121：按 SPAhub 约定设 UTF-8 环境 —— 否则 Windows 中文 locale 下子进程
        # sys.stdin 默认按 cp936/GBK 读，父进程写的 UTF-8 JSON 里的中文路径被解码成乱码，
        # 导致 os.path.isfile 找不到文件（用户报「旧 CRF PDF 不存在」的真正根因）。
        env = os.environ.copy()
        env["PYTHONIOENCODING"] = "utf-8"
        env["PYTHONUTF8"] = "1"
        try:
            from app_paths import app_root as _app_root
            _cwd = _app_root()
        except Exception:
            _cwd = None
        _flags = 0x08000000 if os.name == "nt" else 0  # CREATE_NO_WINDOW（Windows 防黑框）
        try:
            self._proc = subprocess.Popen(
                self._cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT, text=True, encoding="utf-8",
                errors="replace", bufsize=1, env=env, cwd=_cwd,
                creationflags=_flags,
            )
        except Exception as e:
            self.sig_result.emit(False, {"msg": f"子进程启动失败：{e}"})
            return
        try:
            self._proc.stdin.write(self._args_json + "\n")
            self._proc.stdin.flush()
            self._proc.stdin.close()
        except Exception as e:
            self.sig_result.emit(False, {"msg": f"写子进程参数失败：{e}"})
            return

        result_payload = None
        for line in self._proc.stdout:
            if self._cancelled:
                break
            line = line.rstrip("\r\n")
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
            except Exception:
                self.sig_line.emit("info", line)  # 非 JSON 行也照显
                continue
            if obj.get("level") == "result":
                result_payload = obj
            else:
                self.sig_line.emit(obj.get("level", "info"), obj.get("msg", ""))
        try:
            self._proc.wait(timeout=5)
        except Exception:
            pass
        if self._cancelled:
            self.sig_result.emit(False, {"msg": "已中止"})
        elif result_payload is not None:
            self.sig_result.emit(bool(result_payload.get("ok")), result_payload)
        else:
            self.sig_result.emit(False, {"msg": "子进程未返回结果"})

    def cancel(self):
        self._cancelled = True
        try:
            if self._proc and self._proc.poll() is None:
                self._proc.terminate()
        except Exception:
            pass


# ============================================================================
# 05 aCRF Update 主表单
# ============================================================================
class AcrfUpdateForm(QFrame):
    """aCRF / 05 aCRF Update：左参数面板 + 自带右面板（日志 + 灰锁 annomap 编辑器）。"""

    sig_log = Signal(str)
    sig_status = Signal(str, str)
    sig_step_update = Signal(str)
    sig_run_started = Signal()
    sig_run_finished = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.base_path = ""
        self._runner = None
        self._save_thread = None
        self._load_thread = None
        self._annomap_loading_path = None
        # 灰锁判定数据（来自引擎 result）
        self._locked_origins = set()     # 归一化 ORIGIN → 迁移(灰锁)
        self._covered_pages = set()
        self._blank_pages = set()
        self._last_result = None
        # 编辑器运行态
        self._annomap_std_col = -1
        self._annomap_page_col = -1
        self._annomap_origin_col = -1
        self._annomap_row_map = []
        self._annomap_combo_widgets = {}
        self._annomap_original_values = {}
        self._annomap_migrated_rows = set()
        self._std_filter_mode = "all"
        self._annomap_loaded_path = None
        # 运行日志 WARNING/ERROR 筛选（与 tfls-01 同款）
        self._log_entries = []                 # [(level, html), ...] level: NOTE/WARNING/ERROR
        self._log_filter = {"WARNING": False, "ERROR": False}
        self._log_filter_chks = {}
        # #2：迁移(灰)行覆盖 —— 用户改动灰行 → 该页丢弃迁移人工注释、autoanno 重 map
        self._overridden_pages = set()         # 引擎逻辑页(= annomap PAGE) 集合；跨"保存并重跑"持久
        self._row_page = {}                    # tr -> int(page)
        self._build_left()

    # ---------------- 左侧参数面板 ----------------
    def _build_left(self):
        # v12.10.123：与其它步骤一致的白底卡片
        self.setObjectName("LeftPanel")
        self.setStyleSheet("#LeftPanel { background-color: #FFFFFF; border: 1px solid #E4E7ED; border-radius: 6px; }")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 14, 14, 14)
        lay.setSpacing(10)

        title = QLabel("05 aCRF Update")
        title.setStyleSheet("font-size:15px; font-weight:bold; color:#303133; border:none;")
        lay.addWidget(title)

        desc = QLabel("把上一版 CRF 的人工 xfdf 注释迁移到新版 CRF 页码，仍空白的表单由 autoanno 自动补注释，"
                      "合并产出新版 draft.xfdf（导入 Adobe 人工复核）。")
        desc.setWordWrap(True)
        desc.setStyleSheet("color:#909399; font-size:12px; border:none;")
        lay.addWidget(desc)

        # v12.10.129：完成后续操作提示 —— aCRF 注释定稿后需回 04 生成 anno study 数据集
        tip = QLabel("💡 完成 aCRF 注释后，请到「04 CRF Annotation」的「23 Final Anno」更新 anno study 数据集。")
        tip.setWordWrap(True)
        tip.setStyleSheet("color:#409EFF; font-size:12px; border:none;")
        lay.addWidget(tip)

        self.new_crf_entry = self._add_file_row(lay, "新版 eCRF PDF", self._browse_new_crf)
        self.old_crf_entry = self._add_file_row(lay, "旧版 eCRF PDF", self._browse_old_crf)
        self.old_xfdf_entry = self._add_file_row(lay, "旧版 xfdf（final 下最新）", self._browse_old_xfdf)

        lay.addSpacing(6)
        # v12.10.123：全局同款运行条（4px 不确定进度，运行时滚动）
        from PySide6.QtWidgets import QProgressBar
        self.prog_bar = QProgressBar()
        self.prog_bar.setVisible(False)
        self.prog_bar.setFixedHeight(4)
        self.prog_bar.setTextVisible(False)
        lay.addWidget(self.prog_bar)

        self.btn_run = QPushButton("▶ 运行 aCRF Update")
        self.btn_run.setStyleSheet(primary_btn_style())
        self.btn_run.setCursor(Qt.PointingHandCursor)
        self.btn_run.clicked.connect(self._on_run_clicked)
        lay.addWidget(self.btn_run)

        self.btn_cancel = QPushButton("🟥 中止")
        self.btn_cancel.setStyleSheet(danger_btn_style())
        self.btn_cancel.setVisible(False)
        self.btn_cancel.clicked.connect(self._on_cancel)
        lay.addWidget(self.btn_cancel)

        lay.addStretch()

    def _add_file_row(self, parent_lay, label, browse_cb):
        row_lbl = QLabel(label)
        row_lbl.setStyleSheet("color:#606266; font-size:12px; font-weight:bold; border:none;")
        parent_lay.addWidget(row_lbl)
        h = QHBoxLayout()
        entry = QLineEdit()
        entry.setReadOnly(True)
        entry.setPlaceholderText("(未选择)")
        entry.setStyleSheet("QLineEdit{border:1px solid #DCDFE6; border-radius:4px; padding:5px; "
                            "background:#FFFFFF; color:#303133;}")
        h.addWidget(entry, 1)
        btn = QPushButton("📂 浏览")
        btn.setStyleSheet(light_btn_style())
        btn.setCursor(Qt.PointingHandCursor)
        btn.clicked.connect(browse_cb)
        h.addWidget(btn)
        parent_lay.addLayout(h)
        return entry

    # ---------------- 路径 ----------------
    def update_paths(self, base_path):
        self.base_path = base_path or ""
        # 自动预选 final 下最新 xfdf
        self._autopick_old_xfdf()
        # 若已有 annomap4update，加载到编辑器
        if hasattr(self, "annomap_table"):
            ap = self._annomap_update_path()
            if ap and os.path.isfile(ap):
                self._load_annomap_into_table(ap)

    def _acrf_dir(self):
        return os.path.join(self.base_path, *_ACRF_REL) if self.base_path else ""

    def _final_dir(self):
        return os.path.join(self.base_path, *_FINAL_REL) if self.base_path else ""

    def _annomap_update_path(self):
        d = self._acrf_dir()
        return os.path.join(d, "annomap4update.xlsx") if d else ""

    def _out_xfdf_path(self):
        d = os.path.join(self.base_path, *_DRAFT_REL) if self.base_path else ""
        return os.path.join(d, "draft4update.xfdf") if d else ""

    def _autopick_old_xfdf(self):
        fd = self._final_dir()
        if not fd or not os.path.isdir(fd):
            return
        best, best_m = "", -1.0
        try:
            for name in os.listdir(fd):
                if not name.lower().endswith(".xfdf") or name.startswith("~$"):
                    continue
                full = os.path.join(fd, name)
                try:
                    m = os.path.getmtime(full)
                except OSError:
                    continue
                if os.path.isfile(full) and m > best_m:
                    best, best_m = full, m
        except OSError:
            return
        if best:
            self.old_xfdf_entry.setText(best)

    # ---------------- 浏览 ----------------
    def _browse_pdf(self, entry, start_dir, caption):
        d = start_dir if (start_dir and os.path.isdir(start_dir)) else (self.base_path or "")
        path, _ = QFileDialog.getOpenFileName(self, caption, d, "PDF 文件 (*.pdf)")
        if path:
            entry.setText(path)

    def _browse_new_crf(self):
        self._browse_pdf(self.new_crf_entry, self._acrf_dir(), "选择新版 eCRF PDF")

    def _browse_old_crf(self):
        self._browse_pdf(self.old_crf_entry, self._acrf_dir(), "选择旧版 eCRF PDF")

    def _browse_old_xfdf(self):
        d = self._final_dir()
        d = d if (d and os.path.isdir(d)) else (self.base_path or "")
        path, _ = QFileDialog.getOpenFileName(self, "选择旧版 xfdf", d, "XFDF 文件 (*.xfdf)")
        if path:
            self.old_xfdf_entry.setText(path)

    # ---------------- 运行 ----------------
    def _build_child_cmd(self):
        if callable(child_command_acrf_update):
            return child_command_acrf_update()
        # 兜底：直接用当前解释器
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        return [_sys.executable, "-u", "-m", "modules.acrf_annotation_update_runner"]

    def _gather_args(self):
        new_crf = self.new_crf_entry.text().strip()
        old_crf = self.old_crf_entry.text().strip()
        old_xfdf = self.old_xfdf_entry.text().strip()
        for label, p in (("新版 eCRF PDF", new_crf), ("旧版 eCRF PDF", old_crf), ("旧版 xfdf", old_xfdf)):
            if not p or not os.path.isfile(p):
                show_dialog(self, "参数不完整", f"请先选择有效的{label}。", "warning")
                return None
        if not self.base_path:
            show_dialog(self, "未选择项目", "请先在上方选择项目路径（csr_NN）。", "warning")
            return None
        return {
            "old_crf_pdf": old_crf, "new_crf_pdf": new_crf, "old_xfdf": old_xfdf,
            "out_xfdf": self._out_xfdf_path(), "base_path": self.base_path,
            "annomap_name": "annomap4update.xlsx",
        }

    def _on_run_clicked(self):
        if self._runner is not None and self._runner.isRunning():
            show_dialog(self, "任务进行中", "aCRF Update 正在运行，请等待或中止。", "warning")
            return
        self._overridden_pages = set()   # v12.10.123：全新运行 → 清空覆盖集（保存并重跑则保留）
        args = self._gather_args()
        if args is None:
            return
        self._start_run(args)

    def _start_run(self, args):
        args = dict(args)
        args["override_pages"] = sorted(self._overridden_pages)   # #2：累积的灰行覆盖页
        self.sig_run_started.emit()
        self.sig_log.emit("<span style='color:#409EFF'>🚀 开始 aCRF Update ...</span>")
        self.btn_run.setEnabled(False)
        self.btn_cancel.setVisible(True)
        self.prog_bar.setRange(0, 0)   # 不确定进度→滚动
        self.prog_bar.setVisible(True)
        self._runner = _UpdateRunnerThread(self._build_child_cmd(),
                                           json.dumps(args, ensure_ascii=False), parent=self)
        self._runner.sig_line.connect(self._on_runner_line)
        self._runner.sig_result.connect(self._on_runner_result)
        self._runner.start()

    def _on_cancel(self):
        if self._runner is not None and self._runner.isRunning():
            self._runner.cancel()
            self.sig_log.emit("<span style='color:#F56C6C'>🟥 已请求中止 ...</span>")

    _LEVEL_COLOR = {"info": "#303133", "ok": "#67C23A", "warn": "#E6A23C", "err": "#F56C6C"}
    # 动作类前缀（🚀▶🔄🔁📂📋）用蓝色，其余 info 用黑色
    _ACTION_MARKS = ("🚀", "▶", "🔄", "🔁", "📂", "📋")

    def _on_runner_line(self, level, msg):
        color = self._LEVEL_COLOR.get(level, "#303133")
        if level == "info" and any(m in (msg or "") for m in self._ACTION_MARKS):
            color = "#409EFF"  # 动作类 info → 蓝
        # 转义尖括号，防注入
        safe = (msg or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        self.sig_log.emit(f"<span style='color:{color}'>{safe}</span>")

    def _on_runner_result(self, ok, payload):
        self.btn_run.setEnabled(True)
        self.btn_cancel.setVisible(False)
        self.prog_bar.setVisible(False)
        payload = payload or {}
        if not ok:
            self.sig_status.emit("aCRF Update 失败", "#F56C6C")
            self.sig_log.emit(f"<span style='color:#F56C6C'>❌ {payload.get('msg','运行失败')}</span>")
            self.sig_run_finished.emit()
            return
        self._last_result = payload
        # 提取灰锁数据
        origin_map = payload.get("new_form_origin", {}) or {}
        self._locked_origins = {self._norm(k) for k, v in origin_map.items() if v == "migrated"}
        self._covered_pages = set(payload.get("covered_new_pages", []) or [])
        self._blank_pages = set(payload.get("blank_new_pages", []) or [])
        warns = payload.get("warnings", []) or []
        for w in warns:
            # v12.10.121：不展示 autoanno 的告警（表单未自动 map 等噪音，用户不需要）
            if str(w).startswith("[autoanno]"):
                continue
            self._on_runner_line("warn", w)
        out = payload.get("out_xfdf", "")
        self.sig_status.emit(f"aCRF Update 完成 → {os.path.basename(out)}", "#67C23A")
        self.sig_log.emit(f"<span style='color:#67C23A'>✅ 完成：{out}</span>")
        # 加载 annomap4update 到编辑器（带灰锁）
        ap = payload.get("annomap_path", "") or self._annomap_update_path()
        if ap and os.path.isfile(ap) and hasattr(self, "annomap_table"):
            self._load_annomap_into_table(ap)
        self.sig_run_finished.emit()

    @staticmethod
    def _norm(s):
        return " ".join(str(s or "").split()).strip().casefold()

    # ========================================================================
    # 右侧面板：Tab1 日志 / Tab2 annomap4update 编辑器
    # ========================================================================
    def create_right_panel(self):
        rw = QFrame()
        rl = QVBoxLayout(rw)
        rl.setContentsMargins(10, 10, 10, 10)
        rl.setSpacing(8)
        tabs = QTabWidget()
        tabs.setStyleSheet(
            "QTabWidget::pane{border:1px solid #E4E7ED; border-radius:4px;}"
            "QTabBar::tab{background:#F5F7FA; color:#606266; padding:6px 14px; border:1px solid #E4E7ED; "
            "border-bottom:none; border-top-left-radius:4px; border-top-right-radius:4px;}"
            "QTabBar::tab:selected{background:#FFFFFF; color:#409EFF; font-weight:bold;}"
        )
        # ---- Tab1 日志 ----
        tab_log = QFrame()
        tlay = QVBoxLayout(tab_log)
        tlay.setContentsMargins(8, 8, 8, 8)
        hdr = QHBoxLayout()
        lbl = QLabel("📄 aCRF Update 运行日志")
        lbl.setStyleSheet("font-size:13px; font-weight:bold; color:#606266; border:none;")
        hdr.addWidget(lbl)
        hdr.addStretch()
        # WARNING / ERROR 正向筛选（与 tfls-01 PDT Gen 同款：不勾=全展示；勾了只看勾的级别）
        from PySide6.QtWidgets import QCheckBox
        for level, label, color in [("WARNING", "⚠ WARNING", "#E6A23C"), ("ERROR", "❌ ERROR", "#F56C6C")]:
            chk = QCheckBox(label)
            chk.setChecked(False)
            chk.setStyleSheet(
                f"QCheckBox {{ color: {color}; font-size: 11px; border: none; spacing: 4px; }}"
                f"QCheckBox::indicator {{ width: 12px; height: 12px; border: 1px solid #DCDFE6; border-radius: 2px; background-color: #FFFFFF; }}"
                f"QCheckBox::indicator:hover {{ border: 1px solid {color}; }}"
                f"QCheckBox::indicator:checked {{ background-color: {color}; border: 1px solid {color}; }}"
            )
            chk.toggled.connect(lambda checked, lv=level: self._on_log_filter_toggled(lv, checked))
            self._log_filter_chks[level] = chk
            hdr.addWidget(chk)
        tlay.addLayout(hdr)
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        attach_log_search(self.log_text)
        self.log_text.setLineWrapMode(QTextEdit.WidgetWidth)
        self.log_text.setWordWrapMode(QTextOption.WrapAnywhere)
        self.log_text.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.log_text.setStyleSheet(log_textedit_style(with_padding=True))
        tlay.addWidget(self.log_text)
        self.right_status = QLabel("就绪")
        self.right_status.setAlignment(Qt.AlignCenter)
        self.right_status.setStyleSheet("font-size:13px; font-weight:bold; color:#909399; padding-top:5px;")
        tlay.addWidget(self.right_status)
        tabs.addTab(tab_log, "📄 运行日志")

        # 表单自连日志/状态到自己的右面板（不依赖 stepper 路由）
        self.sig_log.connect(self._append_log)
        self.sig_status.connect(lambda m, c: self.right_status.setText(m))
        self.sig_run_started.connect(self._clear_log)

        # ---- Tab2 annomap4update 编辑器 ----
        tab_map = QFrame()
        mlay = QVBoxLayout(tab_map)
        mlay.setContentsMargins(8, 8, 8, 8)
        # 第 1 行：标题 + 路径 + 💾 保存并重跑
        top = QHBoxLayout()
        mt = QLabel("📊 annomap4update.xlsx 编辑")
        mt.setStyleSheet("font-size:13px; font-weight:bold; color:#606266; border:none;")
        top.addWidget(mt)
        top.addStretch()
        self.btn_save_rerun = QPushButton("💾 保存并重跑")
        self.btn_save_rerun.setStyleSheet(
            "QPushButton { background-color: #67C23A; color: white; border: none; padding: 4px 14px; border-radius: 4px; font-size:12px; font-weight:bold;}"
            "QPushButton:hover { background-color: #85CE61; }"
            "QPushButton:disabled { background-color: #C8E5BB; }"
        )
        self.btn_save_rerun.setToolTip("把非灰色行的 STANDARD 写回 annomap4update，然后重跑整个 update：\n"
                                       "迁移来的人工注释不动，只按新 STANDARD 重生成空白页的 autoanno 补白后合并。")
        self.btn_save_rerun.clicked.connect(self._save_and_rerun)
        top.addWidget(self.btn_save_rerun)
        mlay.addLayout(top)
        # v12.10.130：图例(灰=旧版对齐/蓝=新版增加)单独占一整行 —— 原来夹在标题与「保存并重跑」
        #   按钮之间同排，文字一长就被右侧按钮遮挡；移到下方整行 + wordWrap 兜底。
        self.annomap_path_lbl = QLabel("")
        self.annomap_path_lbl.setStyleSheet("color:#909399; font-size:11px; border:none;")
        self.annomap_path_lbl.setWordWrap(True)
        mlay.addWidget(self.annomap_path_lbl)
        # 第 2 行：📝 批量赋值 / 📋 导入 xfdf（样式与 04 一致）
        _outline_style = (
            "QPushButton { background-color: #ECF5FF; color: #409EFF; border: 1px solid #B3D8FF; padding: 4px 12px; border-radius: 4px; font-size:12px; font-weight:bold;}"
            "QPushButton:hover { background-color: #409EFF; color: #FFFFFF; }"
            "QPushButton:disabled { background-color: #F5F7FA; color: #C0C4CC; }"
        )
        bot = QHBoxLayout()
        self.btn_batch = QPushButton("📝 批量赋值")
        self.btn_batch.setStyleSheet(_outline_style)
        self.btn_batch.setToolTip("为选中的多行统一赋同一个 STANDARD。仅改内存，需再点保存并重跑。")
        self.btn_batch.clicked.connect(self._batch_assign)
        bot.addWidget(self.btn_batch)
        bot.addStretch()
        self.btn_import_xfdf = QPushButton("📋 导入 xfdf")
        self.btn_import_xfdf.setStyleSheet(_outline_style)
        self.btn_import_xfdf.setToolTip("用 Adobe 打开新版 CRF，引导导入 draft4update.xfdf 复核。")
        self.btn_import_xfdf.clicked.connect(self._import_xfdf)
        bot.addWidget(self.btn_import_xfdf)
        mlay.addLayout(bot)

        self.annomap_table = QTableWidget()
        self.annomap_table.setStyleSheet(
            "QTableWidget{background:#FFFFFF; border:1px solid #E4E7ED; border-radius:4px; gridline-color:#E4E7ED;}"
            "QHeaderView::section{background:#F5F7FA; padding:4px; border:1px solid #E4E7ED; font-weight:bold;}"
            "QTableWidget::item{color:#303133;}"
            "QTableWidget::item:hover{background:#F0F7FF; color:#303133;}"
            "QTableWidget::item:selected{background:#C6E2FF; color:#303133;}"
        )
        self.annomap_table.setAlternatingRowColors(False)
        self.annomap_table.setSizeAdjustPolicy(QAbstractScrollArea.AdjustIgnored)
        self.annomap_table.setHorizontalScrollMode(QTableWidget.ScrollPerPixel)
        self.annomap_table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.annomap_table.setEditTriggers(QTableWidget.DoubleClicked)
        self._ro_delegate = _ReadOnlyEditDelegate(self.annomap_table)
        self.annomap_table.setItemDelegate(self._ro_delegate)
        # Excel 式筛选表头
        self._filter_header = _FilterHeaderView(Qt.Horizontal, self.annomap_table)
        self._filter_header.setStretchLastSection(True)
        self._filter_header.filter_clicked.connect(self._on_filter_clicked)
        self.annomap_table.setHorizontalHeader(self._filter_header)
        mlay.addWidget(self.annomap_table)

        # 批量赋值 / 筛选的反馈状态行（对齐 04）
        self.annomap_status_lbl = QLabel("")
        self.annomap_status_lbl.setStyleSheet("QLabel{padding:6px 10px; font-size:13px; color:#909399;}")
        self.annomap_status_lbl.hide()
        mlay.addWidget(self.annomap_status_lbl)

        tabs.addTab(tab_map, "📊 annomap4update")
        rl.addWidget(tabs)
        return rw

    @staticmethod
    def _classify_log_level(html):
        """按颜色/emoji/关键词把一条日志分级 NOTE/WARNING/ERROR（与 tfls 一致）。"""
        up = (html or "").upper()
        if "#F56C6C" in (html or "") or "❌" in (html or "") or "🟥" in (html or "") or "ERROR" in up:
            return "ERROR"
        if "#E6A23C" in (html or "") or "⚠" in (html or "") or "WARNING" in up:
            return "WARNING"
        return "NOTE"

    def _should_show_log(self, level):
        active = [lv for lv in ("WARNING", "ERROR") if self._log_filter.get(lv)]
        if not active:
            return True
        return level in active

    def _append_log(self, html):
        if not hasattr(self, "log_text"):
            return
        level = self._classify_log_level(html)
        self._log_entries.append((level, html))
        if not self._should_show_log(level):
            return
        self.log_text.append(html)
        sb = self.log_text.verticalScrollBar()
        sb.setValue(sb.maximum())

    def _clear_log(self):
        self._log_entries = []
        if hasattr(self, "log_text"):
            self.log_text.clear()

    def _on_log_filter_toggled(self, level, checked):
        self._log_filter[level] = checked
        self._rerender_log()

    def _rerender_log(self):
        if not hasattr(self, "log_text"):
            return
        self.log_text.clear()
        for lvl, html in self._log_entries:
            if self._should_show_log(lvl):
                self.log_text.append(html)
        sb = self.log_text.verticalScrollBar()
        sb.setValue(sb.maximum())

    # ---------------- annomap 加载 + 灰锁着色 ----------------
    def _load_annomap_into_table(self, path):
        if not path or not os.path.isfile(path):
            self.annomap_path_lbl.setText("(未找到 annomap4update.xlsx — 请先运行 aCRF Update)")
            self.annomap_path_lbl.setStyleSheet("color:#E6A23C; font-size:11px; border:none;")
            self.annomap_table.setRowCount(0)
            self.annomap_table.setColumnCount(0)
            return
        if self._annomap_loading_path == path:
            return
        self._annomap_loading_path = path
        self.annomap_path_lbl.setText("⏳ 正在加载 annomap4update.xlsx ...")
        self.annomap_path_lbl.setStyleSheet("color:#909399; font-size:11px; border:none;")
        th = _AnnomapLoadThread(path, parent=self)
        th.finished_signal.connect(lambda ok, pl, p=path, t=th: self._on_annomap_loaded(ok, pl, p, t))
        th.start()
        self._load_thread = th

    def _on_annomap_loaded(self, ok, payload, path, thread_ref):
        if self._annomap_loading_path != path:
            return
        self._annomap_loading_path = None
        if not ok or not isinstance(payload, dict):
            self.annomap_path_lbl.setText("(annomap4update 加载失败)")
            self.annomap_path_lbl.setStyleSheet("color:#F56C6C; font-size:11px; border:none;")
            self.annomap_table.setRowCount(0)
            self.annomap_table.setColumnCount(0)
            return
        if payload.get("empty"):
            self.annomap_table.setRowCount(0)
            self.annomap_table.setColumnCount(0)
            self.annomap_path_lbl.setText("(annomap4update 为空)")
            self.annomap_path_lbl.setStyleSheet("color:#E6A23C; font-size:11px; border:none;")
            return

        headers = payload["headers"]
        rows_data = payload["rows_data"]
        max_col = payload["max_col"]
        std_col = payload["std_col"]
        page_col = payload["page_col"]
        origin_col = payload["origin_col"]
        std_options = payload["std_options"]
        visible_rows = payload["visible_rows"]
        cell_bgs = payload["cell_bgs"]

        self._annomap_row_map = [src_row for _, src_row in visible_rows]
        self._annomap_std_col = std_col
        self._annomap_page_col = page_col
        self._annomap_origin_col = origin_col
        self._annomap_std_options = std_options
        self._annomap_combo_widgets = {}
        self._annomap_original_values = {}
        self._annomap_migrated_rows = set()
        self._row_page = {}   # 每次加载重建 tr→page；_overridden_pages 不在此清（跨重跑持久）

        self.annomap_table.setUpdatesEnabled(False)
        was_sort = self.annomap_table.isSortingEnabled()
        self.annomap_table.setSortingEnabled(False)
        try:
            self.annomap_table.clear()
            self.annomap_table.setColumnCount(max_col)
            self.annomap_table.setHorizontalHeaderLabels(headers)
            self.annomap_table.setRowCount(len(visible_rows))
            self.annomap_table.verticalHeader().setDefaultSectionSize(30)

            for tr, (data_idx, src_row) in enumerate(visible_rows):
                row = rows_data[data_idx]
                # 判定该行是否为「自动对齐(迁移)」行 —— 灰底作视觉提示，但仍可双击编辑（带覆盖告警）
                migrated = self._is_row_migrated(row, origin_col, page_col)
                if migrated:
                    self._annomap_migrated_rows.add(tr)
                # 记录该行的引擎逻辑页（= annomap PAGE），供覆盖(override)定位
                if 0 <= page_col < len(row):
                    try:
                        self._row_page[tr] = int(str(row[page_col]).strip())
                    except (ValueError, TypeError):
                        pass

                for j in range(max_col):
                    val = row[j] if j < len(row) else None
                    txt = "" if val is None else str(val)
                    if j == std_col:
                        self._annomap_original_values[tr] = txt
                        combo = self._make_combo(tr, txt, std_options, migrated)
                        self.annomap_table.setCellWidget(tr, j, combo)
                        item = QTableWidgetItem("")
                        item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                        self.annomap_table.setItem(tr, j, item)
                    else:
                        item = QTableWidgetItem(txt)
                        # 迁移行的 PAGE/ORIGIN 灰底提示（不加斜体）；新增(补白)行浅青蓝底提示
                        if migrated:
                            item.setBackground(QColor(*_GREY_RGB))
                        else:
                            # v12.10.128：新增行统一浅青蓝底（原白底在低分屏与灰难辨）
                            item.setBackground(QColor(*_NEW_RGB))
                        self.annomap_table.setItem(tr, j, item)
        finally:
            self.annomap_table.setSortingEnabled(was_sort)
            self.annomap_table.setUpdatesEnabled(True)

        # 列宽
        try:
            h = self.annomap_table.horizontalHeader()
            for j in range(max_col):
                h.setSectionResizeMode(j, QHeaderView.Interactive)
            if page_col >= 0:
                self.annomap_table.setColumnWidth(page_col, 60)
            if origin_col >= 0:
                self.annomap_table.setColumnWidth(origin_col, 320)
        except Exception:
            pass
        # 筛选表头指到 STANDARD
        try:
            self._filter_header.set_filter_column(std_col)
            self._filter_header.set_filter_active(False)
            self._std_filter_mode = "all"
            for tr in range(self.annomap_table.rowCount()):
                self.annomap_table.setRowHidden(tr, False)
        except Exception:
            pass
        try:
            self.annomap_table.clearSelection()
            self.annomap_table.setCurrentCell(-1, -1)
        except Exception:
            pass

        n_mig = len(self._annomap_migrated_rows)
        self.annomap_path_lbl.setText(f"共 {len(visible_rows)} 行　灰色：旧版自动对齐页面 {n_mig}（可双击改）；蓝色：新版增加页面 {len(visible_rows)-n_mig}")
        self.annomap_path_lbl.setStyleSheet("color:#67C23A; font-size:11px; border:none;")
        self._annomap_loaded_path = path

    def _is_row_migrated(self, row, origin_col, page_col):
        """行是否为迁移覆盖行（灰锁）：ORIGIN 命中 locked_origins；或 PAGE 被覆盖且非空白。"""
        if origin_col >= 0 and origin_col < len(row):
            o = self._norm(row[origin_col])
            if o and o in self._locked_origins:
                return True
        if page_col >= 0 and page_col < len(row):
            pv = row[page_col]
            try:
                p = int(str(pv).strip())
                if p in self._covered_pages and p not in self._blank_pages:
                    return True
            except (ValueError, TypeError):
                pass
        return False

    def _make_combo(self, tr, current, options, migrated):
        """与 04 一致的 STANDARD combo：即时标蓝 + 覆盖确认 + 程序化赋值入口。
        迁移(自动对齐)行：灰底作视觉提示，仍可双击编辑；首次改动弹「此表单可能已有对应人工
        注释，确定覆盖」告警，确认后按最新覆盖。"""
        combo = _NoWheelComboBox()
        combo.setEditable(True)
        combo.setInsertPolicy(QComboBox.NoInsert)
        if combo.lineEdit() is not None:
            combo.lineEdit().setContextMenuPolicy(Qt.NoContextMenu)
        opts = [o for o in (options or []) if o]
        combo.addItems([""] + opts)
        if current:
            idx = combo.findText(current)
            if idx >= 0:
                combo.setCurrentIndex(idx)
            else:
                combo.setEditText(current)
        completer = QCompleter(combo.model(), combo)
        completer.setFilterMode(Qt.MatchContains)
        completer.setCaseSensitivity(Qt.CaseInsensitive)
        completer.setCompletionMode(QCompleter.PopupCompletion)
        combo.setCompleter(completer)

        # 迁移行默认灰底（提示是自动对齐来的），新增行浅青蓝底；改动后都转蓝（#D6E8FF+边框+加粗）
        if migrated:
            default_style = ("QComboBox { background:#EEF0F3; border:1px solid #E4E7ED; "
                             "border-radius:3px; padding:1px 4px; font-size:12px; min-height:24px; color:#606266; }")
        else:
            # v12.10.128：新增行 combo 默认浅青蓝，与灰底/改后蓝(#D6E8FF)区分
            default_style = ("QComboBox { background:#C9E9F5; border:1px solid #B5D8E6; "
                             "border-radius:3px; padding:1px 4px; font-size:12px; min-height:24px; }")
        combo.setStyleSheet(default_style)
        combo._sty_default = default_style
        combo._sty_dirty = ("QComboBox { background:#D6E8FF; border:1px solid #409EFF; "
                            "border-radius:3px; padding:1px 4px; font-size:12px; min-height:24px; "
                            "color:#1F4E8F; font-weight:bold; }")
        original = (current or "").strip()
        state = {"confirmed": original, "rolling_back": False, "migrated_warned": False,
                 "forced_dirty": False}   # forced_dirty：人工修改(含灰行覆盖/批量赋值同值) → 强制蓝

        def on_text_changed(new_text):
            cur = (new_text or "").strip()
            dirty = state.get("forced_dirty") or (cur != original)
            combo.setStyleSheet(combo._sty_dirty if dirty else combo._sty_default)
        combo.currentTextChanged.connect(on_text_changed)

        def _revert():
            state["rolling_back"] = True
            try:
                if state["confirmed"] in opts:
                    combo.setCurrentText(state["confirmed"])
                elif combo.lineEdit() is not None:
                    combo.lineEdit().setText(state["confirmed"])
                combo.setStyleSheet(combo._sty_dirty if state["confirmed"] != original
                                    else combo._sty_default)
            finally:
                state["rolling_back"] = False

        def maybe_confirm_change():
            if state["rolling_back"]:
                return
            import time
            now = time.time()
            if now - state.get("last_confirm_at", 0.0) < 0.5:
                return
            state["last_confirm_at"] = now
            new_val = (combo.currentText() or "").strip()
            if new_val == state["confirmed"]:
                return
            # 迁移(自动对齐)行：首次改动弹「可能已有人工注释」告警
            if migrated and not state["migrated_warned"]:
                ok = show_dialog(
                    self, "覆盖自动对齐的 STANDARD",
                    "此表单是从旧版 CRF 自动对齐迁移来的，可能已有对应的人工注释。\n\n"
                    f"要改为：\n  {new_val or '(空)'}\n\n"
                    "确定覆盖吗？确认后将丢弃该表单原有的人工注释，按标准库用 autoanno 重新 map\n"
                    "（保存并重跑后生效）。", "question")
                if ok:
                    state["migrated_warned"] = True
                    state["confirmed"] = new_val
                    state["forced_dirty"] = True     # 人工覆盖 → 蓝（即使值与原相同）
                    self._register_override(tr)
                    combo.setStyleSheet(combo._sty_dirty)
                else:
                    _revert()
                return
            # 非迁移行、原值非空：改动弹普通覆盖确认（原值为空→首次填入不弹）
            if not original:
                state["confirmed"] = new_val
                return
            ok = show_dialog(
                self, "确认修改 STANDARD",
                f"该单元格已有值：\n  {original}\n\n修改为：\n  {new_val or '(空)'}\n\n"
                f"保存并重跑后生效。确定要修改吗？", "question")
            if ok:
                state["confirmed"] = new_val
            else:
                _revert()

        combo.activated.connect(lambda _i: maybe_confirm_change())
        if combo.lineEdit() is not None:
            combo.lineEdit().editingFinished.connect(maybe_confirm_change)

        def _apply_value_programmatic(value):
            v = (value or "").strip()
            state["forced_dirty"] = True    # 批量赋值=显式人工修改 → 蓝（即使值不变）
            combo.setCurrentText(v)
            state["confirmed"] = v
            if migrated:
                state["migrated_warned"] = True  # 批量赋值已是显式操作，不再逐格弹迁移告警
                self._register_override(tr)       # 批量赋值灰行 → 登记覆盖（即使值相同）
            combo.setStyleSheet(combo._sty_dirty)  # 保险：强制蓝
        combo._apply_value_programmatic = _apply_value_programmatic

        self._annomap_combo_widgets[tr] = combo
        return combo

    def _register_override(self, tr):
        """登记某灰(迁移)行为覆盖：其页在重跑时丢弃迁移人工注释、改用 autoanno 重 map。
        即使 STANDARD 值不变也登记（用户意图是"该表单位置微调，重新 map"）。"""
        p = self._row_page.get(tr)
        if p is not None:
            self._overridden_pages.add(int(p))

    # ---------------- 保存并重跑 ----------------
    def _collect_std_updates(self):
        """收集所有被改动的 STANDARD → [(src_row_1based, new_value), ...]。
        迁移(自动对齐)行现在也可编辑，改动后同样收集写回。"""
        updates = []
        std_col = self._annomap_std_col
        if std_col < 0:
            return updates
        for tr, combo in self._annomap_combo_widgets.items():
            new_val = combo.currentText().strip()
            orig = (self._annomap_original_values.get(tr, "") or "").strip()
            if new_val != orig:
                src_row = self._annomap_row_map[tr] if tr < len(self._annomap_row_map) else None
                if src_row:
                    updates.append((src_row, new_val))
        return updates

    def _save_and_rerun(self):
        if self._runner is not None and self._runner.isRunning():
            show_dialog(self, "任务进行中", "请等待当前 update 结束。", "warning")
            return
        ap = self._annomap_loaded_path or self._annomap_update_path()
        if not ap or not os.path.isfile(ap):
            show_dialog(self, "尚未加载", "annomap4update.xlsx 未加载，请先运行一次 aCRF Update。", "warning")
            return
        # 校验运行参数仍完整（沿用上次左侧选择）
        args = self._gather_args()
        if args is None:
            return
        updates = self._collect_std_updates()
        self.btn_save_rerun.setEnabled(False)
        self.btn_save_rerun.setText("⏳ 保存中 ...")
        col_1based = self._annomap_std_col + 1
        self._save_thread = _AnnomapSaveThread(ap, col_1based, updates, parent=self)
        self._save_thread.finished_signal.connect(lambda ok, err: self._on_saved(ok, err, args))
        self._save_thread.start()

    def _on_saved(self, ok, err, args):
        self.btn_save_rerun.setEnabled(True)
        self.btn_save_rerun.setText("💾 保存并重跑")
        if not ok:
            show_dialog(self, "保存失败", f"写回 annomap4update 失败：{err}", "error")
            return
        self.sig_log.emit("<span style='color:#67C23A'>✅ 已保存 STANDARD 编辑，重跑 update ...</span>")
        # 重跑整个 update（引擎会喂回 annomap4update → autoanno 复用新 STANDARD）
        self._start_run(args)

    # ---------------- 批量赋值（对齐 04：预览弹窗 + 覆盖确认）----------------
    def _batch_assign(self):
        if not self._annomap_combo_widgets:
            show_dialog(self, "批量赋值", "annomap 尚未加载完成，无法批量赋值。", "warning")
            return
        std_col = self._annomap_std_col
        # 只认显式选中 PAGE/ORIGIN 单元格的行；跳过灰锁行 + 被筛选隐藏行
        sel = self.annomap_table.selectionModel()
        raw_rows, hidden_hit = set(), False
        if sel is not None:
            for idx in sel.selectedIndexes():
                if idx.column() == std_col:
                    continue
                r = idx.row()
                if self.annomap_table.isRowHidden(r):
                    hidden_hit = True
                    continue
                raw_rows.add(r)
        rows = sorted(raw_rows)
        if not rows:
            if hidden_hit:
                msg = ("当前选中的行已被 STANDARD 筛选隐藏，无法赋值。\n"
                       "请先在可见行中点选 PAGE 或 ORIGIN 单元格（或点 STANDARD 表头 ▽ 改筛选）。")
            else:
                msg = ("请先显式选中要赋值的行 —— 点选该行的 PAGE 或 ORIGIN 单元格：\n"
                       "  · 点 PAGE / ORIGIN 单元格选该行；点左侧行号选整行\n"
                       "  · 按住 Ctrl / Shift 可多选多行")
            show_dialog(self, "批量赋值", msg, "warning")
            return

        preview = self._build_batch_preview(rows)
        opts = [o for o in (self._annomap_std_options or []) if o]
        value = self._prompt_batch_standard_value(opts, preview, len(rows))
        if value is None:
            return
        value = value.strip()

        apply_rows, overwrite, mig_rows = [], [], []
        for tr in rows:
            combo = self._annomap_combo_widgets.get(tr)
            if combo is None:
                continue
            old = (combo.currentText() or "").strip()
            is_mig = tr in self._annomap_migrated_rows
            if old == value and not is_mig:
                continue   # 非灰行且值不变 → 跳过
            apply_rows.append(tr)
            if is_mig:
                mig_rows.append(tr)   # 灰行：即使值相同也登记（用户意图=重新 map）
            elif old:
                overwrite.append(tr)
        if not apply_rows:
            show_dialog(self, "批量赋值", "选中行的 STANDARD 已经是该值，无需修改。", "info")
            return
        confirm_parts = []
        if overwrite:
            confirm_parts.append(f"其中 {len(overwrite)} 行已有非空值，将被覆盖。")
        if mig_rows:
            confirm_parts.append(f"其中 {len(mig_rows)} 行是自动对齐(灰色)行，将丢弃原有人工注释、"
                                 f"按标准库用 autoanno 重新 map。")
        if confirm_parts:
            ok = show_dialog(
                self, "确认批量赋值",
                f"将把选中的 {len(apply_rows)} 行 STANDARD 统一赋值为：\n  {value or '(空)'}\n\n"
                + "\n".join(confirm_parts) + "\n\n保存并重跑后生效。确定要继续吗？",
                "question")
            if not ok:
                return

        self.annomap_table.setUpdatesEnabled(False)
        try:
            for tr in apply_rows:
                combo = self._annomap_combo_widgets.get(tr)
                if combo is not None and hasattr(combo, "_apply_value_programmatic"):
                    combo._apply_value_programmatic(value)
        finally:
            self.annomap_table.setUpdatesEnabled(True)

        if self._std_filter_mode != "all":
            self._apply_standard_filter(self._std_filter_mode, announce=False)
        if sel is not None:
            sel.clearSelection()
        self.annomap_table.setCurrentCell(-1, -1)
        if hasattr(self, "annomap_status_lbl"):
            self.annomap_status_lbl.setText(f"✅ 已批量赋值 {len(apply_rows)} 行 → {value or '(空)'}")
            self.annomap_status_lbl.setStyleSheet("QLabel{padding:6px 10px; font-size:13px; color:#67C23A;}")
            self.annomap_status_lbl.show()

    def _build_batch_preview(self, rows):
        page_col = self._annomap_page_col
        origin_col = self._annomap_origin_col
        std_col = self._annomap_std_col
        col_count = self.annomap_table.columnCount()
        lines = []
        for tr in rows:
            def _cell(c):
                if c is None or c < 0:
                    return ""
                it = self.annomap_table.item(tr, c)
                return (it.text() if it else "") or ""
            if page_col >= 0 or origin_col >= 0:
                left_parts = [t for t in (_cell(page_col), _cell(origin_col)) if t]
            else:
                left_parts = [t for t in (_cell(c) for c in range(col_count) if c != std_col) if t]
            left = " | ".join(left_parts) if left_parts else f"第 {tr + 1} 行"
            combo = self._annomap_combo_widgets.get(tr)
            cur = (combo.currentText() or "").strip() if combo is not None else ""
            lines.append(f"{left}　→　当前: {cur or '(空)'}")
        return lines

    def _prompt_batch_standard_value(self, opts, preview=None, total=0):
        dlg = QDialog(self)
        dlg.setWindowTitle("批量赋值 STANDARD")
        dlg.setMinimumWidth(460)
        lay = QVBoxLayout(dlg)
        lay.setContentsMargins(16, 14, 16, 14)
        lay.setSpacing(10)
        if preview:
            head = QLabel(f"将对以下 {total} 行赋值（请核对）：")
            head.setStyleSheet("font-size:13px; color:#303133; border:none; font-weight:bold;")
            lay.addWidget(head)
            lst = QListWidget()
            lst.setSelectionMode(QAbstractItemView.NoSelection)
            lst.setFocusPolicy(Qt.NoFocus)
            lst.setStyleSheet("QListWidget{background:#F8F9FB; border:1px solid #E4E7ED; border-radius:4px; "
                              "font-size:12px; color:#606266; padding:2px;} QListWidget::item{padding:2px 4px;}")
            MAX_SHOW = 200
            for line in preview[:MAX_SHOW]:
                lst.addItem(QListWidgetItem(line))
            if len(preview) > MAX_SHOW:
                lst.addItem(QListWidgetItem(f"… 还有 {len(preview) - MAX_SHOW} 行（已省略）"))
            lst.setMaximumHeight(190)
            lst.setMinimumHeight(min(190, 24 * max(1, min(len(preview), 6)) + 8))
            lay.addWidget(lst)
        tip = QLabel("为选中行设置统一的 STANDARD（可下拉选择，或输入做模糊联想）：")
        tip.setStyleSheet("font-size:13px; color:#303133; border:none;")
        tip.setWordWrap(True)
        lay.addWidget(tip)
        combo = _NoWheelComboBox(dlg)
        combo.setEditable(True)
        combo.setInsertPolicy(QComboBox.NoInsert)
        if combo.lineEdit() is not None:
            combo.lineEdit().setContextMenuPolicy(Qt.NoContextMenu)
        combo.addItems([""] + list(opts))
        completer = QCompleter(combo.model(), combo)
        completer.setFilterMode(Qt.MatchContains)
        completer.setCaseSensitivity(Qt.CaseInsensitive)
        completer.setCompletionMode(QCompleter.PopupCompletion)
        combo.setCompleter(completer)
        combo.setStyleSheet("QComboBox{background:#FFFFFF; border:1px solid #DCDFE6; border-radius:3px; "
                            "padding:3px 6px; font-size:13px; min-height:26px;}")
        combo.setCurrentIndex(0)
        lay.addWidget(combo)
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        btn_cancel = QPushButton("取消")
        btn_cancel.setStyleSheet("QPushButton{background:#FFFFFF; color:#606266; border:1px solid #DCDFE6; "
                                 "padding:5px 16px; border-radius:4px; font-size:12px;} "
                                 "QPushButton:hover{background:#F5F7FA; border-color:#409EFF; color:#409EFF;}")
        btn_cancel.setCursor(Qt.PointingHandCursor)
        btn_cancel.clicked.connect(dlg.reject)
        btn_ok = QPushButton("✅ 赋值")
        btn_ok.setStyleSheet("QPushButton{background:#409EFF; color:#FFFFFF; border:none; padding:5px 18px; "
                             "border-radius:4px; font-size:12px; font-weight:bold;} "
                             "QPushButton:hover{background:#66B1FF;}")
        btn_ok.setCursor(Qt.PointingHandCursor)
        btn_ok.clicked.connect(dlg.accept)
        btn_row.addWidget(btn_cancel)
        btn_row.addWidget(btn_ok)
        lay.addLayout(btn_row)
        combo.setFocus()
        if dlg.exec() == QDialog.Accepted:
            return combo.currentText()
        return None

    # ---------------- STANDARD 筛选（对齐 04：▽ 弹 QMenu）----------------
    def _on_filter_clicked(self, section):
        cur = self._std_filter_mode
        menu = QMenu(self)
        items = [("显示全部", "all"), ("仅未填 (空白)", "blank"), ("仅已填", "filled")]
        act_map = {}
        for label, mode in items:
            act = menu.addAction(("● " if cur == mode else "○ ") + label)
            act_map[act] = mode
        header = self.annomap_table.horizontalHeader()
        x = header.sectionViewportPosition(section) + header.sectionSize(section) - 24
        gpos = header.mapToGlobal(QPoint(max(0, x), header.height()))
        chosen = menu.exec(gpos)
        if chosen in act_map:
            self._apply_standard_filter(act_map[chosen])

    def _apply_standard_filter(self, mode, announce=True):
        self._std_filter_mode = mode
        combos = self._annomap_combo_widgets or {}
        shown = hidden = 0
        self.annomap_table.setUpdatesEnabled(False)
        try:
            for tr, combo in combos.items():
                val = (combo.currentText() or "").strip()
                if mode == "blank":
                    hide = bool(val)
                elif mode == "filled":
                    hide = not val
                else:
                    hide = False
                self.annomap_table.setRowHidden(tr, hide)
                hidden += 1 if hide else 0
                shown += 0 if hide else 1
        finally:
            self.annomap_table.setUpdatesEnabled(True)
        try:
            self._filter_header.set_filter_active(mode != "all")
        except Exception:
            pass
        if announce and hasattr(self, "annomap_status_lbl"):
            label = {"all": "显示全部", "blank": "仅未填", "filled": "仅已填"}.get(mode, mode)
            txt = (f"🔄 筛选：{label}（共 {shown} 行）" if mode == "all"
                   else f"🔄 筛选：{label} —— 显示 {shown} 行，隐藏 {hidden} 行")
            self.annomap_status_lbl.setText(txt)
            self.annomap_status_lbl.setStyleSheet("QLabel{padding:6px 10px; font-size:13px; color:#409EFF;}")
            self.annomap_status_lbl.show()

    # ---------------- 导入 xfdf（对齐 04：直接用 Adobe 打开）----------------
    @staticmethod
    def _find_adobe_exe():
        """探测 Adobe Acrobat 可执行路径（Windows），与 04 crf_form 一致。"""
        if os.name != "nt":
            return None
        try:
            import winreg
            for key_name in ("Acrobat.exe", "AcroRd32.exe"):
                try:
                    key = winreg.OpenKey(
                        winreg.HKEY_LOCAL_MACHINE,
                        rf"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\{key_name}")
                    val, _ = winreg.QueryValueEx(key, None)
                    winreg.CloseKey(key)
                    if val and os.path.isfile(val):
                        return val
                except OSError:
                    continue
        except Exception:
            pass
        for cand in (
            r"C:\Program Files\Adobe\Acrobat DC\Acrobat\Acrobat.exe",
            r"C:\Program Files (x86)\Adobe\Acrobat DC\Acrobat\Acrobat.exe",
            r"C:\Program Files\Adobe\Acrobat 2020\Acrobat\Acrobat.exe",
            r"C:\Program Files (x86)\Adobe\Acrobat Reader DC\Reader\AcroRd32.exe",
        ):
            if os.path.isfile(cand):
                return cand
        return None

    def _import_xfdf(self):
        """用 Adobe 打开新版 CRF，引导用户在 Adobe 内手动 Import Comments 选 draft4update.xfdf。"""
        new_crf = self.new_crf_entry.text().strip()
        out = self._out_xfdf_path()
        if not new_crf or not os.path.isfile(new_crf):
            show_dialog(self, "缺少新版 CRF", "请先在左侧选择新版 eCRF PDF。", "warning")
            return
        if not out or not os.path.isfile(out):
            show_dialog(self, "缺少 xfdf",
                        f"找不到 draft4update.xfdf：\n{out}\n\n请先运行 ▶ 运行 aCRF Update。", "warning")
            return
        adobe_exe = self._find_adobe_exe()
        try:
            if adobe_exe:
                subprocess.Popen([adobe_exe, new_crf], shell=False, creationflags=0x00000008)
            else:
                os.startfile(new_crf)  # noqa: S606 (Windows only)
        except Exception as e:
            show_dialog(self, "打开失败", f"无法打开 PDF：\n{new_crf}\n\n{e}", "error")
            return
        show_dialog(
            self, "请在 Adobe 中导入 xfdf",
            f"已打开新版 CRF：\n  {new_crf}\n\n"
            f"如 Adobe 弹「AppContainer 在保护模式下不兼容」对话框：\n"
            f"  → 选「在停用保护模式的情况下通过 AppContainer 打开 Acrobat」点确定\n\n"
            f"在 Adobe Acrobat 中：\n"
            f"  1. 右侧 💬（评论）→ ⋮（选项）→「导入数据文件」\n"
            f"  2. 选择文件：{os.path.basename(out)}（位于 062_acrf/draft/）\n"
            f"  3. 校对完成后另存放到 062_acrf/final/\n\n"
            f"如系统未检测到 Adobe Acrobat，可能用默认 PDF 应用打开 —— 请改用 Adobe 重新打开。",
            "info", align="right")

    # ---------------- 清理 ----------------
    def reset_state(self):
        self.new_crf_entry.setText("")
        self.old_crf_entry.setText("")
        self.old_xfdf_entry.setText("")
        self._locked_origins = set()
        self._covered_pages = set()
        self._blank_pages = set()
        self._last_result = None
        if hasattr(self, "annomap_table"):
            self.annomap_table.setRowCount(0)
            self.annomap_table.setColumnCount(0)
