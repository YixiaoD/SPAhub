# -*- coding: utf-8 -*-
"""
modules/sdtm_common.py
======================
SDTM 模块共享工具：
  - domain_list 扫描（Python 复现 26_generate_pds_call.sas / 27_sdtm_template_call.sas
    中的 %domain_list 宏逻辑）
  - setup.xlsx 中按宏变量名读 / 写（参数化，复用给 EDCSTD / 其他宏）
  - SDTM PDS xlsx 解析（Datasets sheet 的 Dataset 列）
  - SAS 日志严重程度分级（严格区分 ERROR / WARNING / OK）
  - SAS EG 启动 + Z:\\ 目录打开（用于"在 EG 中打开 061_data"按钮）

================================================================================
项目目录结构 memory（参考 HRS9821_102 zip 中 csr_01 的真实骨架）：
  <base>/                             ← 4 级路径（projects/<prot>/<prot>_<ra>/csr_NN）
  ├── 00_source_data/                 EDC 原始数据（zip / xlsx / sas7bdat）
  ├── 01_sdtm/                        SDTM 数据集（dev: <dom>.sas7bdat / qc: <dom>_qc.sas7bdat）
  ├── 02_adam/                        ADaM 数据集
  ├── 03_reports/                     TFLs 报表输出
  ├── 04_crt/                         CRT 包（含 anno_study.sas7bdat 等）
  ├── 05_pkpd/                        PK/PD 输出
  ├── 06_programs/                    SAS 派生程序（重要！sdtm_template 输出于此）
  │   ├── 061_data/                   ← SDTM 派生程序：<dom>.sas / <dom>_qc.sas
  │   ├── 062_safety/                 ADaM safety
  │   ├── 063_efficacy/               ADaM efficacy
  │   ├── 064_pkpd/                   ADaM PK/PD
  │   └── 065_stats/                  ADaM stats
  ├── 07_logs/                        运行日志（.log / log_chk*.xml / compare_chk*.xml）
  ├── 08_formats/ / 09_validation/    格式 / 验证
  ├── 91_export/ / 92_import/         导出 / 导入区
  ├── 99_archive/                     归档
  └── utility/
      ├── documentation/              文档区（SDTM_PDS / ADAM_PDS / PDT / PIT / setup.xlsx 都在此）
      │   ├── <prot>_<ra>_PDT.xlsx          PDT 文件（toc=NULL 时仅含 SDTM/ADaM 列）
      │   ├── <prot>_<ra>_SDTM_PDS.xlsx     SDTM PDS（Datasets sheet 列出域名）
      │   ├── <prot>_<ra>_ADAM_PDS.xlsx     ADaM PDS
      │   ├── setup.xlsx                    SAS 全局宏变量配置
      │   └── 06_crt_preparation/
      │       ├── 062_acrf/anno_study.sas7bdat   aCRF 标注 → SDTM domain_list 来源
      │       └── 067_programs/                  CRT 程序
      ├── macros/                     宏库
      ├── metadata/                   元数据
      └── tools/                      调用脚本：21_/24_/25_/26_/27_/91_/92_*.sas

服务器（Linux）↔ Windows 路径：
  Z:\\projects\\<prot>\\<prot>_<ra>\\<csr>      ↔
  /u01/app/sas/sas9.4/DocumentRepository/DDT/projects/<prot>/<prot>_<ra>/<csr>

domain_list 复现规则（以 SAS 宏为准 + 用户新增条件）：
  1. 读 crfpage.anno_study：筛选 lower(strip(substrn(defaultstyle, 1, 16))) eq "font: bold arial"
  2. text 含有 "="
  3. **新增**：text 中 "=" 左侧 strip 后长度恰为 2（domain 名为两位字母）
  4. domain = lower(scan(text, 1, "="))
  5. 排序去重（按 SAS 的 nodupkey by text 语义近似）
  6. **不再排除 pc / rp / yd / dm**（与 26/27 SAS 中默认 where 不同 — 用户明确要求保留）
  7. 最终列表 = ["", "sv", "se"] + 上面排序后的 list（保持空选项放第 0 位以便"清空选择"）

anno_study.sas7bdat 候选位置（参考 acrf_crf_annotation 的 _open_anno_study）：
  - <base>/utility/documentation/06_crt_preparation/062_acrf/anno_study.sas7bdat
  - <base>/utility/documentation/06_crt_preparation/062_acrf/draft/anno_study.sas7bdat
  - <base>/04_crt/anno_study.sas7bdat

读取依赖：优先 pyreadstat（更标准 + 跨平台稳定），回退 sas7bdat（纯 Python）。
两者都装失败时回退 SAS 端动态产出（temp.sas 中嵌 %domain_list 宏，从 log 抽 &domain_list 值）—
这条路径作为最终兜底，避免开发机缺包就完全用不了。
"""
import os
import re
import subprocess
import time



# =============================================================================
# v12.10.5：openpyxl 全局兼容性补丁
# 根因：用户的 SDTM_PDS xlsx 元数据（core.xml）里 modified 字段是 datetime.date 而非
#       datetime.datetime。openpyxl 的 _convert 严格类型检查直接抛 TypeError，
#       导致 load_workbook(...)（任意模式）整个失败 → list_pds_datasets 返回空列表
#       → dom combo 永远空 → 用户感觉"点不出下拉"。
# 修复：monkey-patch openpyxl.descriptors.base._convert，仅当 expected=datetime
#       且 value 是 datetime.date 时做兼容转换；其他情况原样抛回。无副作用。
# 此 patch 在 sdtm_common 首次 import 时安装，全局生效（应用内所有 openpyxl 调用都受益）。
# =============================================================================
def _install_openpyxl_compat_patch():
    try:
        import openpyxl.descriptors.base as _b
        if getattr(_b, "_saseg_patched", False):
            return  # 已 patch，避免重复
        import datetime as _dt
        _orig = _b._convert

        def _patched(expected_type, value):
            try:
                return _orig(expected_type, value)
            except TypeError:
                # 兼容：xlsx 元数据里 datetime.date 自动升级为 datetime.datetime
                if expected_type is _dt.datetime and isinstance(value, _dt.date):
                    return _dt.datetime(value.year, value.month, value.day)
                raise
        _b._convert = _patched
        _b._saseg_patched = True
    except Exception:
        # 如果 openpyxl 内部结构变了 patch 不上 — 静默跳过（list_pds_datasets 内的
        # try-except 仍能捕获后续 load_workbook 异常，不至于让主线程崩溃）
        pass


_install_openpyxl_compat_patch()


# =============================================================================
# 路径常量（与 acrf_crf_annotation 对齐）
# =============================================================================
def candidate_anno_study_paths(base_path: str):
    """返回候选 anno_study.sas7bdat 路径列表（按推荐优先级）"""
    if not base_path:
        return []
    return [
        os.path.join(base_path, "utility", "documentation", "06_crt_preparation",
                     "062_acrf", "anno_study.sas7bdat"),
        os.path.join(base_path, "utility", "documentation", "06_crt_preparation",
                     "062_acrf", "draft", "anno_study.sas7bdat"),
        os.path.join(base_path, "04_crt", "anno_study.sas7bdat"),
    ]


def find_anno_study(base_path: str) -> str:
    """在候选位置中找一个真实存在的 anno_study.sas7bdat；找不到返回 ""。"""
    for p in candidate_anno_study_paths(base_path):
        if p and os.path.isfile(p):
            return p
    return ""


# =============================================================================
# domain_list 扫描器（Python 端复现 SAS %domain_list 宏）
# =============================================================================
def _filter_rows_to_domains(rows):
    """
    输入：rows = [(defaultstyle, text), ...]
    输出：去重排序后的 domain 列表（不含 sv/se/空值，由调用方再拼）。
    """
    out = set()
    for defaultstyle, text in rows:
        if not text:
            continue
        ds = "" if defaultstyle is None else str(defaultstyle).strip()
        # SAS: lower(strip(substrn(defaultstyle, 1, 16))) eq "font: bold arial"
        if ds[:16].lower() != "font: bold arial":
            continue
        t = str(text)
        if "=" not in t:
            continue
        # SAS: domain = lower(scan(text, 1, "="))
        left = t.split("=", 1)[0].strip()
        # 用户新增筛选：domain 名恰为两位字符
        if len(left) != 2:
            continue
        out.add(left.lower())
    return sorted(out)


def scan_domain_list(base_path: str):
    """
    扫描 anno_study.sas7bdat → 产出 domain_list（list[str]）。

    返回 (ok: bool, items: list[str], err: str)：
      ok=True   items 至少包含 ["", "sv", "se"]（即使找不到任何 bold-arial 行也保底）
      ok=False  err 描述失败原因（找不到文件 / 缺包 / 解析异常）。
                items 仍返回 ["", "sv", "se"] 作为最小可用 fallback，让 UI 不至于空。
    """
    fallback = ["", "sv", "se"]

    path = find_anno_study(base_path)
    if not path:
        return False, fallback, "未找到 anno_study.sas7bdat（请先运行 aCRF / 03 Final Annotation）"

    rows = None

    # 优先 pyreadstat
    try:
        import pyreadstat  # type: ignore
        df, _meta = pyreadstat.read_sas7bdat(path)
        cols_lower = {c.lower(): c for c in df.columns}
        if "defaultstyle" not in cols_lower or "text" not in cols_lower:
            return False, fallback, "anno_study 缺 defaultstyle 或 text 列"
        ds_col = cols_lower["defaultstyle"]
        tx_col = cols_lower["text"]
        rows = list(zip(df[ds_col].tolist(), df[tx_col].tolist()))
    except ImportError:
        rows = None
    except Exception as e:
        return False, fallback, f"pyreadstat 解析失败：{e}"

    # 回退 sas7bdat
    if rows is None:
        try:
            from sas7bdat import SAS7BDAT  # type: ignore
            with SAS7BDAT(path) as f:
                cols = [c.name.decode() if isinstance(c.name, (bytes, bytearray)) else c.name
                        for c in f.columns]
                cols_lower = {c.lower(): i for i, c in enumerate(cols)}
                if "defaultstyle" not in cols_lower or "text" not in cols_lower:
                    return False, fallback, "anno_study 缺 defaultstyle 或 text 列"
                ds_idx = cols_lower["defaultstyle"]
                tx_idx = cols_lower["text"]
                tmp = []
                for r in f:
                    ds = r[ds_idx] if ds_idx < len(r) else None
                    tx = r[tx_idx] if tx_idx < len(r) else None
                    tmp.append((ds, tx))
                rows = tmp
        except ImportError:
            return False, fallback, ("缺少 sas7bdat 解析包：请安装 pyreadstat 或 sas7bdat\n"
                                     "  pip install pyreadstat   # 推荐\n"
                                     "  或者: pip install sas7bdat")
        except Exception as e:
            return False, fallback, f"sas7bdat 解析失败：{e}"

    domains = _filter_rows_to_domains(rows or [])
    # 与用户要求一致：sv / se 放在前面，再附扫描出的 domain；空值占位放第 0 位（便于"清空选择"）
    items = [""] + ["sv", "se"] + [d for d in domains if d not in ("sv", "se")]
    # 去重保序
    seen = set()
    uniq = []
    for x in items:
        if x not in seen:
            uniq.append(x)
            seen.add(x)
    return True, uniq, ""


# =============================================================================
# setup.xlsx 中按宏变量名读 / 写（与 acrf_edc_recode 的 FILEPATH 读写策略对称）
# =============================================================================
def read_setup_macro(setup_path: str, macro_name: str):
    """
    读 setup.xlsx 中名为 macro_name 的宏变量值。

    返回 (val: str, sheet_name: str, row_idx: int)
      - row_idx > 0  → 找到了行（val 可能为空字符串）
      - row_idx == 0 → 找不到
    """
    if not os.path.isfile(setup_path):
        return "", "", 0
    target = (macro_name or "").strip().upper()
    if not target:
        return "", "", 0
    try:
        import openpyxl
        wb = openpyxl.load_workbook(setup_path, data_only=True, read_only=True)
        try:
            for ws in wb.worksheets:
                for r_idx, row in enumerate(ws.iter_rows(values_only=True), start=1):
                    if len(row) < 3:
                        continue
                    key = row[1]
                    if key is None:
                        continue
                    if str(key).strip().upper() == target:
                        val = row[2]
                        return ("" if val is None else str(val).strip()), ws.title, r_idx
        finally:
            wb.close()
    except Exception:
        pass
    return "", "", 0


def write_setup_macro(setup_path: str, macro_name: str, new_value: str):
    """
    把 setup.xlsx 中 macro_name 的 C 列值改成 new_value。
    返回 (ok: bool, msg: str)。仅改命中行的 C 列。
    """
    if not os.path.isfile(setup_path):
        return False, f"找不到 setup.xlsx：{setup_path}"
    target = (macro_name or "").strip().upper()
    if not target:
        return False, "未指定 macro_name"
    try:
        import openpyxl
        wb = openpyxl.load_workbook(setup_path, data_only=False)
    except Exception as e:
        return False, f"加载 setup.xlsx 失败：{e}"

    target_ws = None
    target_row = 0
    try:
        for ws in wb.worksheets:
            for r_idx in range(1, ws.max_row + 1):
                key_cell = ws.cell(row=r_idx, column=2).value
                if key_cell is None:
                    continue
                if str(key_cell).strip().upper() == target:
                    target_ws = ws
                    target_row = r_idx
                    break
            if target_ws is not None:
                break

        if target_ws is None:
            return False, f"未在 setup.xlsx 中找到 {macro_name} 行"

        # openpyxl: 已存在 cell 必须显式 .value = v 赋值（参考 acrf_edc_recode 经验）
        target_ws.cell(row=target_row, column=3).value = new_value
        wb.save(setup_path)
    except Exception as e:
        return False, f"写回 setup.xlsx 失败：{e}"
    finally:
        try:
            wb.close()
        except Exception:
            pass
    return True, f"已更新 setup.xlsx[{target_ws.title}] 的 {macro_name} = {new_value}"


# =============================================================================
# v12.10.97: 补行从"末尾追加"改为"按 setup_template 相对位置插入"
# -----------------------------------------------------------------------------
# 背景：原 append_setup_macro_row 把缺失宏行写在 max_row+1（末尾），导致 EDCSTD
# 这种本应在 setup 顶部（必填项段）的宏被补到末尾（如截图里的行149）。用户要求
# 补行位置与 setup_template.xlsx 中的相对顺序一致。
#
# 策略：读 template 的宏顺序 → 锚定"目标宏在 template 中最近的、且在当前 setup
# 已存在的邻居"算出插入行号 → openpyxl insert_rows 插入（会同步下移已有行的值+样式）
# → 再手动下移 data validation 的 sqref（openpyxl 不会自动调整下拉校验引用）。
#
# 向后兼容：template_path 为空 / 不可读 / 目标宏不在 template / 前后邻居都不在
# setup 时，退化为原"末尾追加"。不传 template_path 的调用方行为完全不变。
# =============================================================================
def _template_macro_order(template_path: str):
    """读 setup_template 的 Macro Variables sheet，返回有序宏名列表（全大写）。
    仅取 B 列非空行（跳过 '必填项' 等分节标题行）。任意失败 → []。"""
    order = []
    try:
        if not template_path or not os.path.isfile(template_path):
            return order
        import openpyxl
        wb = openpyxl.load_workbook(template_path, data_only=True, read_only=True)
        try:
            ws = wb["Macro Variables"] if "Macro Variables" in wb.sheetnames else wb.worksheets[0]
            for r in ws.iter_rows(min_row=2, values_only=True):
                name = r[1] if len(r) > 1 else None
                if name and str(name).strip():
                    order.append(str(name).strip().upper())
        finally:
            wb.close()
    except Exception:
        return []
    return order


def _setup_macro_row_map(ws):
    """当前 setup ws 的 宏名(大写) -> 行号。仅 B 列非空，重复名取首次出现。"""
    m = {}
    for ridx, r in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
        name = r[1] if len(r) > 1 else None
        if name and str(name).strip():
            m.setdefault(str(name).strip().upper(), ridx)
    return m


def _compute_template_insert_idx(ws, macro_name, template_path):
    """按 template 顺序锚定"最近的已存在邻居"算插入行号。
    算不出（template 不可读 / 目标不在 template / 前后邻居都不在 setup）→ None，
    调用方据此退化为末尾追加。"""
    target = (macro_name or "").strip().upper()
    order = _template_macro_order(template_path)
    if target not in order:
        return None
    pos = order.index(target)
    setup_map = _setup_macro_row_map(ws)
    # 1) 向前找最近的、在 setup 中已存在的邻居 → 插在它后面
    for prev in reversed(order[:pos]):
        if prev in setup_map:
            return setup_map[prev] + 1
    # 2) 向后找最近的、在 setup 中已存在的邻居 → 插在它前面
    for nxt in order[pos + 1:]:
        if nxt in setup_map:
            return setup_map[nxt]
    return None


def _shift_data_validations_down(ws, insert_idx, amount=1):
    """openpyxl 的 insert_rows 不会调整 data validation 的 sqref；这里把 >= insert_idx
    的引用整体下移（单元格粒度重建 sqref；Macro Variables 无合并单元格，安全）。

    注：自定义校验 formula1 内的绝对引用（如 C76 的 NOT(AND(C3="RAVE",...))) 不在此重写。
    现行补行场景（EDCSTD=模板行3 / EDCDEF=行17 / FILEPATH=行106）均不破坏 C2/C3 引用，
    其中 EDCSTD 补回行3 反而会修复该引用。"""
    try:
        from openpyxl.utils import get_column_letter
        dvs = ws.data_validations.dataValidation
    except Exception:
        return
    for dv in dvs:
        coords = []
        try:
            for rng in dv.sqref.ranges:
                for row in range(rng.min_row, rng.max_row + 1):
                    for col in range(rng.min_col, rng.max_col + 1):
                        nr = row + amount if row >= insert_idx else row
                        coords.append(f"{get_column_letter(col)}{nr}")
        except Exception:
            continue
        if coords:
            dv.sqref = " ".join(coords)


def append_setup_macro_row(setup_path: str, macro_name: str,
                           macro_value: str = "", description: str = "",
                           template_path: str = ""):
    """v12.10.97: 在 setup.xlsx 的"Macro Variables"sheet 补一行宏变量。

    行为：传入可读的 template_path 时，**按 setup_template 的相对位置插入**
    （锚定最近的已存在邻居），并同步下移受影响的 data validation 下拉引用。
    template_path 为空 / Z 盘不可达 / 目标宏不在模板 / 前后邻居都不在 setup
    → 退化为原"末尾追加"（向后兼容，不传该参数的调用方行为不变）。

    使用场景："行不存在"时补行（EDCSTD / EDCDEF / FILEPATH 等在某些项目的 setup 缺失）。
    本函数不查重 — 调用方需先用 read_setup_macro 确认行不存在再调用。

    仅写 A/B/C 三列（描述 / 宏名 / 值），不复制 template 的格式（避免 openpyxl
    跨进程 StyleProxy 引用问题）；insert_rows 会保留被下移行原有的值与样式。

    返回 (ok: bool, msg: str, sheet_name: str, new_row_idx: int)
    """
    if not os.path.isfile(setup_path):
        return False, f"找不到 setup.xlsx：{setup_path}", "", 0
    if not (macro_name or "").strip():
        return False, "未指定 macro_name", "", 0

    try:
        import openpyxl
        wb = openpyxl.load_workbook(setup_path, data_only=False)
    except Exception as e:
        return False, f"加载 setup.xlsx 失败：{e}", "", 0

    try:
        # 优先匹配 "Macro Variables" sheet（与 setup_template 命名一致）；找不到时退到第一个 sheet
        target_ws = None
        for ws in wb.worksheets:
            if (ws.title or "").strip().lower() == "macro variables":
                target_ws = ws
                break
        if target_ws is None:
            target_ws = wb.worksheets[0]

        # v12.10.97: 先按 template 算插入位置；算不出则末尾追加
        insert_idx = _compute_template_insert_idx(target_ws, macro_name, template_path)
        appended = insert_idx is None
        if appended:
            insert_idx = target_ws.max_row + 1
        else:
            target_ws.insert_rows(insert_idx)            # 下移已有行（含值+样式）
            _shift_data_validations_down(target_ws, insert_idx, 1)

        target_ws.cell(row=insert_idx, column=1).value = description or ""
        target_ws.cell(row=insert_idx, column=2).value = macro_name
        target_ws.cell(row=insert_idx, column=3).value = macro_value or ""

        wb.save(setup_path)
    except Exception as e:
        return False, f"补行失败：{e}", "", 0
    finally:
        try:
            wb.close()
        except Exception:
            pass

    if appended:
        return True, f"已在 setup.xlsx[{target_ws.title}] 末尾追加 {macro_name} 行（未匹配到模板位置）", target_ws.title, insert_idx
    return True, f"已在 setup.xlsx[{target_ws.title}] 第 {insert_idx} 行按模板位置插入 {macro_name} 行", target_ws.title, insert_idx


# =============================================================================
# 临时 SAS 脚本生成 / 清理工具
# =============================================================================
def _build_temp_sas_code(macro_call: str) -> str:
    """
    生成"autorun + 用户提交宏调用"的标准 SAS 代码（与 26/27 sas call 同款样板）。

    macro_call 形如：
      "%generate_pds(libname=sdtm, dataset=%str(ta, te), type=replace);"
      "%sdtm_template(dom=%str(ae));"
      "%import_edcdef"
    """
    return (
        "* - . calling autorun to setup the programming environment;\n"
        "data _null_;\n"
        "  if libref('adam') then call execute('%nrstr(%autorun)');\n"
        "run;\n\n"
        f"{macro_call}\n"
    )


def write_temp_sas(base_path: str, macro_call: str, prefix: str):
    """
    把 macro_call 写到 base_path/utility/tools/<prefix>_<uuid>.sas，返回绝对路径。
    调用方在 SingleBatchRunner 完成后用 cleanup_temp_sas 删除（含 .log 同名兄弟）。
    """
    import uuid
    tools_dir = os.path.join(base_path, "utility", "tools")
    if not os.path.isdir(tools_dir):
        os.makedirs(tools_dir, exist_ok=True)
    uid = uuid.uuid4().hex[:8]
    path = os.path.join(tools_dir, f"{prefix}_{uid}.sas")
    with open(path, "w", encoding="utf-8") as f:
        f.write(_build_temp_sas_code(macro_call))
    return path


def cleanup_temp_sas(sas_path: str):
    """清理 temp 脚本及其同名 .log（best-effort，失败不抛）。"""
    if not sas_path:
        return
    base, _ = os.path.splitext(sas_path)
    for p in (sas_path, base + ".log"):
        try:
            if os.path.isfile(p):
                os.remove(p)
        except Exception:
            pass


def append_temp_log_to_permanent(temp_sas_path: str, permanent_log_name: str,
                                  macro_call: str = "", elapsed_sec: float = 0.0) -> str:
    """
    把 temp_<uuid>.log 的内容**追加**到 utility/tools/<permanent_log_name>，
    并加分隔符 + 时间戳 + 本次提交的宏调用，方便多次运行的历史回溯。

    v12.10.8 引入：原来 SDTM 02 SDTM Gen 跑完 cleanup_temp_sas 把 temp.log 删了
    用户在 UI"详见日志文件"链接打不开。改用永久追加文件后：
      - 26_generate_pds_call.log    存 generate_pds 子步全部历史
      - 27_sdtm_template_call.log   存 sdtm_template 子步全部历史

    v12.10.13：永久 log 超过 20MB 自动归档（rename 加日期后缀），新建空文件继续追加。
    避免长期使用后单文件过大（用户跑 100 次 SDTM 03 后可能 50MB+）。

    返回永久 log 文件的绝对路径（Windows / Linux 都可点击打开）。
    若读 temp.log 失败 → 不抛异常，仅返回永久 log 路径（即使是空文件也存在）。
    """
    import datetime
    if not temp_sas_path:
        return ""
    tools_dir = os.path.dirname(temp_sas_path)
    permanent_log = os.path.join(tools_dir, permanent_log_name)
    temp_log_path = os.path.splitext(temp_sas_path)[0] + ".log"

    # v12.10.13：永久 log 超过 20MB 归档
    PERMANENT_LOG_MAX_SIZE = 20 * 1024 * 1024
    try:
        if os.path.isfile(permanent_log) and os.path.getsize(permanent_log) > PERMANENT_LOG_MAX_SIZE:
            stamp = datetime.datetime.now().strftime("%Y-%m-%d_%H%M%S")
            stem, ext = os.path.splitext(permanent_log_name)
            archived = os.path.join(tools_dir, f"{stem}_archived_{stamp}{ext}")
            os.rename(permanent_log, archived)
    except Exception:
        # 归档失败（盘锁定 / 权限）— 静默继续，让追加可能创建新文件或写到旧文件末尾
        pass

    # 读 temp.log 内容（若不存在 / 读失败，写一行 "(无 log 内容)" 占位，仍要写分隔符）
    try:
        if os.path.isfile(temp_log_path):
            with open(temp_log_path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
        else:
            content = "(temp .log 文件不存在 — 可能 SAS 进程在写 log 前就异常退出)"
    except Exception as e:
        content = f"(读 temp .log 失败: {e})"

    # 分隔符 + 元信息头
    ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    header = (
        f"\n{'=' * 100}\n"
        f"=== 提交时间：{ts}    耗时：{elapsed_sec:.1f}s\n"
    )
    if macro_call:
        header += f"=== 宏调用：{macro_call}\n"
    header += "=" * 100 + "\n"

    try:
        with open(permanent_log, "a", encoding="utf-8") as f:
            f.write(header)
            f.write(content)
            if not content.endswith("\n"):
                f.write("\n")
    except Exception:
        # 写永久 log 失败（盘满 / 权限）— 静默，不影响 UI 流程
        pass

    return permanent_log


# =============================================================================
# SAS 日志严重程度分级 + 抽取错误行
# 设计目标：所有从 SAS 抓回的 log 都要严格区分 ERROR / WARNING — 红 vs 黄不混用
# =============================================================================
# ERROR / WARNING 行匹配模式（与 sas_engine/executor.py 的常量保持一致）
_RE_ERROR_LINE = re.compile(r'^\s*ERROR\s*:', re.IGNORECASE)
_RE_WARNING_LINE = re.compile(r'^\s*WARNING\s*:', re.IGNORECASE)


def classify_log_severity(log_text: str):
    """
    扫描 SAS 日志，返回严重程度分类。
    返回 dict：
      {
        "severity":   "error" | "warning" | "ok",   # 严重程度（error 优先级最高）
        "n_error":    int,
        "n_warning":  int,
        "has_error":  bool,
        "has_warning":bool,
      }

    用法：
      sev = classify_log_severity(log_text)
      if sev["severity"] == "error":   → 红色 ❌
      elif sev["severity"] == "warning": → 黄色 ⚠️
      else:                              → 绿色 ✅
    """
    n_err = n_warn = 0
    if log_text:
        for line in log_text.splitlines():
            if _RE_ERROR_LINE.match(line):
                n_err += 1
            elif _RE_WARNING_LINE.match(line):
                n_warn += 1
    if n_err > 0:
        sev = "error"
    elif n_warn > 0:
        sev = "warning"
    else:
        sev = "ok"
    return {
        "severity": sev,
        "n_error": n_err,
        "n_warning": n_warn,
        "has_error": n_err > 0,
        "has_warning": n_warn > 0,
    }


def detect_macro_abort(log_text: str) -> bool:
    """
    检测日志中是否含 SAS 宏 %ABORT 触发的中止。
    匹配："Execution terminated by an %ABORT statement"（不区分大小写）。
    """
    if not log_text:
        return False
    return "%abort" in log_text.lower() and "execution terminated" in log_text.lower()


def extract_abort_context_html(log_text: str, n_before: int = 15) -> str:
    """
    检测到 %ABORT 时，倒扫定位到 "ERROR: Execution terminated by an %ABORT" 行，
    往前抓 n_before 行**所有非空内容**（含 NOTE / WARNING / ERROR 以及宏内 put 输出）
    渲染为 HTML。

    动机：
      SAS 宏 %abort 触发的真实根因（"NOTE: ERROR:: TOC sheet missing column..." /
      "WARNING:[parameter check]:..." 之类）几乎总在 %abort 行之前几行。
      原 extract_issue_lines_html 只过滤行首 ERROR/WARNING — 会把宏内 put 输出
      的 "NOTE: ERROR::" 这种行漏掉，让用户看到一个孤零零的 %abort 完全不知所措。

    着色规则：
      - 行首 ERROR：红色 #F56C6C
      - 行首 WARNING：黄色 #E6A23C
      - 行内含 ERROR:: / ERROR: 关键字（即使 NOTE 前缀）：橙色 #E6A23C 加粗
      - 其他 NOTE / 普通行：灰色 #909399（提供上下文）
    """
    if not log_text:
        return "<i style='color:#909399;'>(SAS 未返回日志内容)</i>"

    lines = log_text.splitlines()
    abort_idx = -1
    # 倒扫找 abort 行
    for i in range(len(lines) - 1, -1, -1):
        ll = lines[i].lower()
        if "execution terminated" in ll and "%abort" in ll:
            abort_idx = i
            break

    if abort_idx < 0:
        return extract_issue_lines_html(log_text)

    # 取 abort 之前 n_before 行 + abort 行本身
    start = max(0, abort_idx - n_before)
    snippet = lines[start:abort_idx + 1]
    out = []
    for line in snippet:
        s = line.rstrip()
        if not s.strip():
            continue
        safe = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        upper = s.upper()
        if _RE_ERROR_LINE.match(line):
            out.append(f"<span style='color:#F56C6C; font-weight:bold;'>&nbsp;&nbsp;{safe}</span>")
        elif _RE_WARNING_LINE.match(line):
            out.append(f"<span style='color:#E6A23C; font-weight:bold;'>&nbsp;&nbsp;{safe}</span>")
        elif "ERROR::" in upper or "ERROR:" in upper:
            # 宏内 put: "NOTE: ERROR:: 某条业务校验失败" — 真实根因
            out.append(f"<span style='color:#E6A23C; font-weight:bold;'>&nbsp;&nbsp;{safe}</span>")
        elif "WARNING::" in upper or "WARNING:" in upper:
            out.append(f"<span style='color:#E6A23C;'>&nbsp;&nbsp;{safe}</span>")
        else:
            # 普通 NOTE / 数据/路径行 — 灰色背景上下文
            out.append(f"<span style='color:#909399;'>&nbsp;&nbsp;{safe}</span>")

    if start > 0:
        out.insert(0, "<i style='color:#909399;'>&nbsp;&nbsp;… (前面省略) …</i>")
    out.append(
        "<i style='color:#909399;'>&nbsp;&nbsp;💡 上面 NOTE/ERROR 行通常是 %ABORT 真实根因；"
        "如仍不清楚，请打开下方 .log 路径查看完整日志。</i>"
    )
    return "<br>".join(out)


def extract_issue_lines_html(log_text: str, max_lines: int = 8) -> str:
    """
    从 SAS 日志抽取 ERROR / WARNING 行 → HTML（红/黄分色）。

    严格区分：
      - ERROR 行：红色 #F56C6C
      - WARNING 行：黄色 #E6A23C
      - 其他行（NOTE / 普通文本）：忽略

    与历史实现的差异：以前 _extract_issue_lines 在外层 emit 时整行用红色 wrap，
    哪怕内部只有 WARNING — 现在拒绝混用。
    """
    if not log_text:
        return "<i style='color:#909399;'>(SAS 未返回日志内容)</i>"
    out = []
    for line in log_text.splitlines():
        s = line.strip()
        if not s:
            continue
        if _RE_ERROR_LINE.match(line):
            color = "#F56C6C"
        elif _RE_WARNING_LINE.match(line):
            color = "#E6A23C"
        else:
            continue
        safe = (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))
        out.append(f"<span style='color:{color};'>&nbsp;&nbsp;{safe}</span>")
        if len(out) >= max_lines:
            out.append("<i style='color:#909399;'>&nbsp;&nbsp;… 更多详见日志文件 …</i>")
            break
    if not out:
        return "<i style='color:#909399;'>(未匹配到标准 ERROR/WARNING 行)</i>"
    return "<br>".join(out)


def severity_finished_html(step_label: str, severity: str, summary: str, elapsed: float = None) -> str:
    """
    根据 severity 产出"运行完成"的整行 HTML（标红 / 标黄 / 标绿，不混用）。

      step_label  显示用步骤名（如 "Import EDC Definition" / "generate_pds"）
      severity    "error" / "warning" / "ok"（来自 classify_log_severity）
      summary     摘要文本（来自 SingleBatchRunner.finished_signal 的第 2 个参数）
      elapsed     可选耗时（秒）— "ok" 分支显示

    示例：
      "<span style='color:#F56C6C; font-weight:bold;'>❌ generate_pds 完成（含 2 个 ERROR）— …</span>"
      "<span style='color:#E6A23C; font-weight:bold;'>⚠️ generate_pds 完成（含 1 个 WARNING，无 ERROR）— …</span>"
      "<span style='color:#67C23A; font-weight:bold;'>✅ generate_pds 完成（3.2s）— …</span>"
    """
    if severity == "error":
        return (f"<span style='color:#F56C6C; font-weight:bold;'>"
                f"❌ {step_label} 完成（含 ERROR）— {summary}</span>")
    elif severity == "warning":
        return (f"<span style='color:#E6A23C; font-weight:bold;'>"
                f"⚠️ {step_label} 完成（含 WARNING，无 ERROR）— {summary}</span>")
    else:
        if elapsed is not None:
            return (f"<span style='color:#67C23A; font-weight:bold;'>"
                    f"✅ {step_label} 完成（{elapsed:.1f}s）— {summary}</span>")
        return (f"<span style='color:#67C23A; font-weight:bold;'>"
                f"✅ {step_label} 完成 — {summary}</span>")


# =============================================================================
# SDTM PDS xlsx：定位 + Datasets sheet 的 Dataset 列读取
# =============================================================================
def find_sdtm_pds_xlsx(base_path: str, sdtmspec_name: str = "") -> str:
    """
    在 utility/documentation 下定位 SDTM PDS xlsx。

    v12.10.3 优化（用户反馈"dom 下拉菜单严重迟滞"）：原 os.walk(doc_root) 会
    递归扫整个 documentation 目录树（含 06_crt_preparation 多层子目录），在 Z:\\
    网络盘上每次调用耗时数百毫秒；watcher 线程每 5s 调一次累积明显。
    新策略：
      1. 若给定 sdtmspec_name → 直接拼 <doc_root>/<name>.xlsx 一次 isfile 判定
      2. 兜底 → 仅扫 doc_root 当前一层（os.listdir，不递归），名字含 sdtm + pds
    返回路径字符串；找不到返回 ""。
    """
    if not base_path:
        return ""
    doc_root = os.path.join(base_path, "utility", "documentation")
    if not os.path.isdir(doc_root):
        return ""

    name = (sdtmspec_name or "").strip()
    if name:
        # 直接拼路径 isfile（最快路径）
        cand = os.path.join(doc_root, name + ".xlsx")
        if os.path.isfile(cand):
            return cand
        # 同名但大小写不同 — 用 listdir 当前层比较一次
        try:
            target_low = (name + ".xlsx").lower()
            for fn in os.listdir(doc_root):
                if fn.lower() == target_low and os.path.isfile(os.path.join(doc_root, fn)):
                    return os.path.join(doc_root, fn)
        except OSError:
            pass

    # 兜底：仅扫 doc_root 当前一层（不递归 — 用户的 PDS 文件就在 documentation 下）
    candidates = []
    try:
        for fn in os.listdir(doc_root):
            low = fn.lower()
            if (low.endswith(".xlsx")
                    and "sdtm" in low and "pds" in low
                    and not fn.startswith("~")):
                full = os.path.join(doc_root, fn)
                if os.path.isfile(full):
                    candidates.append(full)
    except OSError:
        return ""
    if not candidates:
        return ""
    candidates.sort(key=lambda p: os.path.getmtime(p), reverse=True)
    return candidates[0]


def list_pds_datasets(pds_xlsx_path: str):
    """
    从 SDTM PDS xlsx 的 Datasets sheet 拉 Dataset 列。
    返回 (ok: bool, items: list[str], err: str)
      items 已小写 + 去空 + 去重，但**不**注入 sv/se 兜底（与 anno_study 扫描的语义不同 — PDS 通常已有完整列表）

    Datasets sheet 结构（参考用户上传的 SHR9999_test_csr_08_SDTM_PDS.xlsx）：
      | Dataset | Label | Class | SubClass | Structure | Purpose | Key Variables | Standard |
      ... 第 2 行起：实际 domain（如 "SE"）
    """
    if not pds_xlsx_path or not os.path.isfile(pds_xlsx_path):
        return False, [], f"未找到 SDTM PDS：{pds_xlsx_path or '(空)'}"
    try:
        import openpyxl
        wb = openpyxl.load_workbook(pds_xlsx_path, data_only=True, read_only=True)
    except Exception as e:
        return False, [], f"加载 SDTM PDS 失败：{e}"

    try:
        # 找 Datasets sheet（不区分大小写）
        target_ws = None
        for name in wb.sheetnames:
            if name.strip().lower() == "datasets":
                target_ws = wb[name]
                break
        if target_ws is None:
            return False, [], "SDTM PDS 中未找到 'Datasets' sheet"

        rows_iter = target_ws.iter_rows(values_only=True)
        first = next(rows_iter, None)
        if not first:
            return False, [], "Datasets sheet 为空"
        header = [("" if c is None else str(c).strip().lower()) for c in first]
        try:
            ds_col_idx = header.index("dataset")
        except ValueError:
            return False, [], "Datasets sheet 缺 'Dataset' 列"

        seen = set()
        items = []
        for row in rows_iter:
            if not row or len(row) <= ds_col_idx:
                continue
            v = row[ds_col_idx]
            if v is None:
                continue
            s = str(v).strip().lower()
            if not s:
                continue
            if s in seen:
                continue
            seen.add(s)
            items.append(s)
        return True, items, ""
    except Exception as e:
        return False, [], f"解析 SDTM PDS 失败：{e}"
    finally:
        try:
            wb.close()
        except Exception:
            pass


# =============================================================================
# SAS EG 启动 + Z:\ 目录打开（用于"在 EG 中打开 061_data"按钮）
# =============================================================================
def _find_saseg_exe():
    """
    定位 SEGuide.exe。三阶段策略：

    1. 写死候选列表（覆盖 SAS EG 5/6/7/8 的常见安装路径）
    2. 扫 SASHome\\SASEnterpriseGuide\\<ver>\\SEGuide.exe（含 D 盘安装、含定制路径）—
       这一步是关键兜底：SAS EG 9.x 或自定义版本号（如 8.5/8.6）写死候选可能漏
    3. PATH 兜底（where 命令）

    返回找到的最高版本路径；都找不到返回 None。
    """
    # 阶段 1：写死候选
    explicit = [
        # SAS EG 8
        r'C:\Program Files\SaS\SASHome\SASEnterpriseGuide\8\SEGuide.exe',
        r'C:\Program Files\SASHome\SASEnterpriseGuide\8\SEGuide.exe',
        r'C:\Program Files (x86)\SASHome\SASEnterpriseGuide\8\SEGuide.exe',
        # SAS EG 7.1 / 7.15
        r'C:\Program Files\SASHome\SASEnterpriseGuide\7.1\SEGuide.exe',
        r'C:\Program Files (x86)\SASHome\SASEnterpriseGuide\7.1\SEGuide.exe',
        r'C:\Program Files\SASHome\SASEnterpriseGuide\7.15\SEGuide.exe',
        r'C:\Program Files (x86)\SASHome\SASEnterpriseGuide\7.15\SEGuide.exe',
        # SAS EG 6.1
        r'C:\Program Files\SASHome\SASEnterpriseGuide\6.1\SEGuide.exe',
        r'C:\Program Files (x86)\SASHome\SASEnterpriseGuide\6.1\SEGuide.exe',
        # SAS EG 5.1（远古）
        r'C:\Program Files\SASHome\SASEnterpriseGuide\5.1\SEGuide.exe',
        r'C:\Program Files (x86)\SASHome\SASEnterpriseGuide\5.1\SEGuide.exe',
    ]
    for p in explicit:
        if os.path.isfile(p):
            return p

    # 阶段 2：扫 SASHome 下所有版本目录（含 D/E/C 盘 + (x86)）
    # 这一步覆盖：8.5 / 8.6 / 9.0 等候选列表未包括的版本号
    roots = [
        r'C:\Program Files\SASHome\SASEnterpriseGuide',
        r'C:\Program Files (x86)\SASHome\SASEnterpriseGuide',
        r'C:\Program Files\SaS\SASHome\SASEnterpriseGuide',
        r'C:\Program Files (x86)\SaS\SASHome\SASEnterpriseGuide',
        r'D:\Program Files\SASHome\SASEnterpriseGuide',
        r'D:\Program Files (x86)\SASHome\SASEnterpriseGuide',
        r'D:\SASHome\SASEnterpriseGuide',
        r'C:\SASHome\SASEnterpriseGuide',
        r'E:\SASHome\SASEnterpriseGuide',
    ]
    found = []
    for root in roots:
        if not os.path.isdir(root):
            continue
        try:
            for ver in os.listdir(root):
                exe = os.path.join(root, ver, 'SEGuide.exe')
                if os.path.isfile(exe):
                    found.append((ver, exe))
        except Exception:
            continue
    if found:
        # 按版本字符串倒序：'8' > '7.15' > '7.1' > '6.1' > '5.1'
        found.sort(reverse=True)
        return found[0][1]

    # 阶段 3：PATH 兜底
    if os.name == 'nt':
        try:
            out = subprocess.check_output(
                ['where', 'SEGuide.exe'],
                stderr=subprocess.DEVNULL,
                creationflags=0x08000000,  # CREATE_NO_WINDOW
            ).decode('utf-8', 'ignore').strip().splitlines()
            for line in out:
                line = line.strip()
                if line and os.path.exists(line):
                    return line
        except Exception:
            pass
    return None


def _saseg_is_running() -> bool:
    """tasklist 检测 SAS EG 是否已启动（仅 Windows 有效）。"""
    if os.name != 'nt':
        return False
    try:
        out = subprocess.check_output(
            ['tasklist', '/FI', 'IMAGENAME eq SEGuide.exe'],
            stderr=subprocess.DEVNULL,
            creationflags=0x08000000,  # CREATE_NO_WINDOW
        )
        return b"SEGuide.exe" in out
    except Exception:
        return False


def launch_eg_and_open_dir(base_path: str, sub_path: str = "06_programs/061_data"):
    """
    启动 SAS EG（如未运行），并尽量让 EG 自动定位到 061_data 目录。

    设计取舍（v12.10.3 修订）：
      - SAS EG 命令行**不接受**目录作为启动参数（不论是 Z:\\ 路径还是 Linux 路径）；
        但若传入一个 .sas 文件路径作为参数，EG 启动后会自动打开该文件 +
        在内置「服务器文件」面板自动展开到该文件所在目录。
      - 用户反馈 v12.10.2 的"开 explorer 兜底"造成误解（多了不需要的资源管理器窗口）—
        v12.10.3 完全去掉 explorer 弹窗，改为：扫描 061_data 下最新 .sas 文件传给 EG，
        让 EG 自身定位到目录。**EG 主窗口启动后约 5-10s 才会显示**，期间用户能看到
        日志中"已发起启动指令"作为反馈。
      - 若 061_data 下尚无任何 .sas 文件（首次跑 sdtm_template 之前）— 仅启动 EG 主窗口，
        日志提示用户手动在 EG 里导航到 061_data。
      - **不再**做"已运行就跳过 Popen"的短路 —— SAS EG 默认 single-instance 行为：
        新 Popen 进程会激活已有实例并将 .sas 文件推给它打开。

    v12.10.54 修订（撤回 v12.10.53）：
      - v12.10.53 曾把 picked_sas 在传 EG 前转 Linux 路径，意图让 EG 走 SAS
        Server 通道展开服务器面板。**实测无效** —— SEGuide.exe 命令行参数
        无论传 Z:\\ 还是 /u01/.../ 都走 Windows 客户端通道，"服务器文件"
        面板不会真正展开（仅"跳动一下"然后停在最上级）。v12.10.3 注释中
        关于"传 .sas 让 EG 服务器面板展开到该目录"的描述与实测不符。
      - 本版回退至 v12.10.50 的行为：picked_sas 保留 Windows 路径形式直接
        传给 EG。EG 会以 Windows 客户端模式打开该文件（tab 标题 Z:\\...）。
        无法通过命令行让 EG 服务器面板自动定位 — 这是 SAS EG 自己的设计
        限制，用户需要从 EG 内部「服务器→浏览」手工导航。

    返回 (ok: bool, msg: str, details: dict)。
      details:
        exe_path           SEGuide.exe 找到的路径（None 表示未找到）
        was_running        调用前 EG 是否已在跑（信息提示）
        is_running         1.5s 后是否在跑（True = 启动成功）
        target_dir         Windows 端 061_data 目录路径
        target_dir_exists  目录是否存在
        picked_sas         传给 EG 的 .sas 文件路径（Windows 形式;"" 表示没有）
        popen_ok           Popen 调用是否成功（不抛异常）
    """
    details = {
        "exe_path": None,
        "was_running": False,
        "is_running": False,
        "target_dir": "",
        "target_dir_exists": False,
        "picked_sas": "",
        "popen_ok": False,
    }
    full_dir = os.path.join(base_path or "", *sub_path.replace("\\", "/").split("/"))
    full_dir = os.path.normpath(full_dir)
    details["target_dir"] = full_dir
    details["target_dir_exists"] = os.path.isdir(full_dir)

    if os.name != 'nt':
        return False, "❌ 非 Windows 平台，无法启动 SAS EG。", details

    # ====== 决定要传给 EG 的参数：061_data 下最新 .sas（若存在） ======
    picked_sas = ""
    if details["target_dir_exists"]:
        try:
            sas_files = []
            for n in os.listdir(full_dir):
                full = os.path.join(full_dir, n)
                if os.path.isfile(full) and n.lower().endswith(".sas"):
                    try:
                        sas_files.append((full, os.path.getmtime(full)))
                    except OSError:
                        pass
            if sas_files:
                sas_files.sort(key=lambda x: x[1], reverse=True)
                picked_sas = sas_files[0][0]
        except OSError:
            pass
    details["picked_sas"] = picked_sas

    # ====== 启动 EG ======
    was_running = _saseg_is_running()
    details["was_running"] = was_running
    exe = _find_saseg_exe()
    details["exe_path"] = exe

    if not exe:
        details["is_running"] = was_running
        return (
            was_running,
            "❌ 未找到 SEGuide.exe（候选路径都不存在，PATH 中也未注册）。\n"
            "   请检查 SAS Enterprise Guide 安装位置；如果是非标准路径，\n"
            "   请在反馈里告知实际位置以便加入候选列表。",
            details,
        )

    # 强制 Popen（不被 was_running 短路；single-instance 行为由 EG 自己处理：
    # 已有实例时新进程会把文件传给现有实例并自身退出）
    msg_lines = []
    cmd = [exe, picked_sas] if picked_sas else [exe]
    try:
        subprocess.Popen(cmd, shell=False)
        details["popen_ok"] = True
        if was_running:
            head = "🚀 SAS EG 已在后台运行"
            if picked_sas:
                head += f"；已请求现有实例打开 {os.path.basename(picked_sas)}"
                head += "\n   （EG 主窗口会被激活，「服务器文件」面板展开到 061_data）"
            else:
                head += "；已请求激活主窗口"
            msg_lines.append(head)
        else:
            head = "🚀 已发起 SAS EG 启动指令"
            if picked_sas:
                head += f"，并传入：{os.path.basename(picked_sas)}"
                head += "\n   （EG 主窗口约 5-10s 后显示，启动后会自动展开到 061_data）"
            else:
                head += "（无 .sas 参数）"
                head += "\n   061_data 下尚无 .sas 文件 — 请先跑 sdtm_template，或在 EG 启动后手动导航到该目录"
            msg_lines.append(head)
    except Exception as e:
        details["popen_ok"] = False
        msg_lines.append(f"❌ 启动 SAS EG 失败：{e}")

    # 1.5s 复检
    if details["popen_ok"]:
        time.sleep(1.5)
        details["is_running"] = _saseg_is_running()
        if details["is_running"]:
            msg_lines.append("   ✅ 1.5s 后已检测到 SEGuide.exe 进程")
        else:
            msg_lines.append("   ⚠ 1.5s 后尚未检测到 SEGuide.exe 进程（可能仍在加载或被防病毒拦截）")

    ok = bool(details["popen_ok"]) and bool(details["is_running"])
    return ok, "\n".join(msg_lines), details
