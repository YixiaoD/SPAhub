# -*- coding: utf-8 -*-
"""
modules/tfls_combine.py
=======================
05 TFLs Combine 模块。

职责：
  - 调用 31_rtf_combine_call.sas 将 TFLs 输出合并为 RTF
  - 支持 14 个 SAS 宏参数（PDT / OUTFILE / MODE / BYTYPE / BYSEC /
    COVERPAGE / NOTIFY / DEBUG / DOCXYN / TXTLEN / ORDTYPE / OUTLOC / OUTTYPE / SECTION）
  - 运行前根据表单重写 Call 脚本中的 %rtf_combine(...) 调用行
  - 与 01 PDT Gen 同构：QThread + run_sas 直接调用

v12.10.66：高级参数新增 ORDTYPE 下拉框（PDT / ID）。
    ORDTYPE 决定合并 RTF 时的排序依据：
      - PDT：按 PDT 中定义的顺序排序（rtf_combine.sas 文档标注的默认值）
      - ID ：按输出编号排序
    下拉框默认选 PDT（与宏文档一致）。注意 rtf_combine.sas 在参数留空时
    实际 default-fill 的是 'id'；GUI 始终显式下发 ordtype=，因此以下拉框
    选中值为准，不会触发宏内的留空默认。

文件结构：
  ├─ TFLsCombineRunner (QThread)  后台执行
  └─ TFLsCombineForm   (QFrame)   左侧表单（基础三参数 + 折叠的高级参数）
"""
import os
import re
import time
from datetime import datetime

from PySide6.QtWidgets import (QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                               QLineEdit, QFileDialog, QFrame, QProgressBar, QComboBox)
from PySide6.QtCore import Qt, QThread, Signal

from sas_engine.executor import run_sas
from ui_utils import show_dialog, primary_btn_style, success_btn_style, primary_outline_btn_style, scan_status_lbl_style


# =============================================================================
# 后台运行线程
# =============================================================================
class TFLsCombineRunner(QThread):
    """
    在子线程中调用 run_sas 执行 31_rtf_combine_call.sas。
    finished_signal 回传 (has_issue, summary, log_text, source_label)。
    """
    log_signal = Signal(str)
    finished_signal = Signal(bool, str, str, str)

    def __init__(self, sas_script):
        super().__init__()
        self.sas_script = sas_script
        self.is_cancelled = False

    def run(self):
        try:
            has_issue, summary, log_text, source_label = run_sas(self.sas_script, check_log=False, return_details=True)
            if self.is_cancelled:
                return
            self.finished_signal.emit(has_issue, summary, log_text, source_label)
        except Exception as e:
            if self.is_cancelled:
                return
            self.log_signal.emit(f"ERROR: {str(e)}")
            self.finished_signal.emit(True, f"异常: {str(e)}", "", "")


# =============================================================================
# 左侧表单组件 TFLsCombineForm
# =============================================================================
class TFLsCombineForm(QFrame):
    """
    TFLs Combine 的左侧业务表单。

    表单区块：
      - 顶部：刷新按钮 + 扫描状态
      - 说明文字
      - 三个主参数输入：31_rtf_combine_call（脚本路径）/ PDT XLSX（完整路径）/ OUTFILE
      - 折叠"高级参数"面板：11 项 SAS 宏参数（MODE/BYTYPE/BYSEC/COVERPAGE/
                           NOTIFY/DEBUG/DOCXYN/TXTLEN/ORDTYPE/OUTLOC/OUTTYPE/SECTION）
      - 按钮：▶ 合并 TFLs / 🟥 中止 / 📂 打开 03_reports
    """
    sig_log = Signal(str)
    sig_status = Signal(str, str)
    sig_step_update = Signal(str)
    sig_run_started = Signal()

    # ------------------------- 初始化 / UI -------------------------
    def __init__(self):
        super().__init__()
        self.base_path = ""
        self.p3 = ""
        self.p4 = ""
        self._setup_ui()

    def _show_msg(self, title, text, msg_type="info"):
        return show_dialog(self, title, text, msg_type)

    def _setup_ui(self):
        self.setObjectName("LeftPanel")
        self.setStyleSheet("#LeftPanel { background-color: #FFFFFF; border: 1px solid #E4E7ED; border-radius: 6px; }")
        form_layout = QVBoxLayout(self)
        form_layout.setAlignment(Qt.AlignTop)
        form_layout.setContentsMargins(25, 25, 25, 25)
        form_layout.setSpacing(12)

        # ---- 刷新按钮 + 扫描标签 ----
        self._step_name = "TFLs Combine"
        top_bar = QHBoxLayout()
        self.refresh_btn = QPushButton("🔄 刷新源文件")
        # v12.10.65：统一改用 home"📁 系统文件复制"同款蓝色外框样式
        self.refresh_btn.setStyleSheet(primary_outline_btn_style())
        self.refresh_btn.setCursor(Qt.PointingHandCursor)
        top_bar.addWidget(self.refresh_btn)
        self.scan_lbl = QLabel("")
        self.scan_lbl.setStyleSheet(scan_status_lbl_style())
        top_bar.addWidget(self.scan_lbl)
        top_bar.addStretch()
        form_layout.addLayout(top_bar)

        desc = QLabel("调用 31_rtf_combine_call.sas 合并 TFLs 输出 (RTF)。")
        desc.setStyleSheet("color: #303133; font-size: 14px; border: none; font-weight: bold;")
        form_layout.addWidget(desc)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 0)
        self.progress_bar.setFixedHeight(4)
        self.progress_bar.setTextVisible(False)  # v12.10.13：4px 太矮装不下文字，关闭百分比显示避免和上方 label 重叠
        self.progress_bar.setVisible(False)
        form_layout.addWidget(self.progress_bar)

        lbl_style = "border: none; color: #606266; min-width: 130px;"
        entry_style = "padding: 6px; border: 1px solid #DCDFE6; border-radius: 4px;"
        combo_style = "padding: 5px; border: 1px solid #DCDFE6; border-radius: 4px; background: #FFFFFF;"
        browse_style = "background-color: #F5F7FA; color: #606266; border: 1px solid #DCDFE6; padding: 6px 12px; border-radius: 4px;"

        # ---- 31_rtf_combine_call.sas 路径 (SAS 脚本保持原标签风格) ----
        row_sas = QHBoxLayout()
        lbl_sas = QLabel("31_rtf_combine_call：")
        lbl_sas.setStyleSheet(lbl_style)
        row_sas.addWidget(lbl_sas)
        self.sas_entry = QLineEdit()
        self.sas_entry.setStyleSheet(entry_style)
        row_sas.addWidget(self.sas_entry)
        browse_sas_btn = QPushButton("浏览")
        browse_sas_btn.setStyleSheet(browse_style)
        browse_sas_btn.clicked.connect(lambda: self.sas_entry.setText(
            QFileDialog.getOpenFileName(self, "选择 31_rtf_combine_call.sas",
                os.path.dirname(self.sas_entry.text()) if os.path.isfile(self.sas_entry.text()) else self.base_path,
                "*.sas")[0]
            or self.sas_entry.text()))
        row_sas.addWidget(browse_sas_btn)
        form_layout.addLayout(row_sas)

        # ---- PDT (展示完整路径) ----
        row_pdt = QHBoxLayout()
        lbl_pdt = QLabel("PDT XLSX：")
        lbl_pdt.setStyleSheet(lbl_style)
        row_pdt.addWidget(lbl_pdt)
        self.pdt_entry = QLineEdit()
        self.pdt_entry.setStyleSheet(entry_style)
        row_pdt.addWidget(self.pdt_entry)
        browse_pdt_btn = QPushButton("浏览")
        browse_pdt_btn.setStyleSheet(browse_style)
        browse_pdt_btn.clicked.connect(lambda: self._browse_pdt())
        row_pdt.addWidget(browse_pdt_btn)
        form_layout.addLayout(row_pdt)

        # ---- OUTFILE ----
        row_out = QHBoxLayout()
        lbl_out = QLabel("OUTFILE：")
        lbl_out.setStyleSheet(lbl_style)
        row_out.addWidget(lbl_out)
        self.outfile_entry = QLineEdit()
        self.outfile_entry.setStyleSheet(entry_style)
        row_out.addWidget(self.outfile_entry)
        form_layout.addLayout(row_out)

        # ---- 高级参数折叠 ----
        self.adv_toggle = QPushButton("▶ 高级参数")
        self.adv_toggle.setStyleSheet("""
            QPushButton { background: transparent; border: none; color: #409EFF; font-size: 13px; font-weight: bold; text-align: left; padding: 4px 0; }
            QPushButton:hover { color: #66B1FF; }
        """)
        self.adv_toggle.setCursor(Qt.PointingHandCursor)
        self.adv_toggle.clicked.connect(self._toggle_advanced)
        form_layout.addWidget(self.adv_toggle)

        self.adv_frame = QFrame()
        self.adv_frame.setVisible(False)
        adv_layout = QVBoxLayout(self.adv_frame)
        adv_layout.setContentsMargins(0, 0, 0, 0)
        adv_layout.setSpacing(10)

        def make_combo_row(label_text, options, default, min_w=130):
            inner = QHBoxLayout()
            inner.setSpacing(8)
            lbl_i = QLabel(label_text)
            lbl_i.setStyleSheet(lbl_style + f" min-width: {min_w}px;")
            inner.addWidget(lbl_i)
            combo = QComboBox()
            combo.setStyleSheet(combo_style)
            combo.addItems(options)
            combo.setCurrentText(default)
            combo.setFixedWidth(110)
            inner.addWidget(combo)
            inner.addStretch()
            return inner, combo

        def make_entry_row(label_text, default="", min_w=130):
            inner = QHBoxLayout()
            inner.setSpacing(8)
            lbl_i = QLabel(label_text)
            lbl_i.setStyleSheet(lbl_style + f" min-width: {min_w}px;")
            inner.addWidget(lbl_i)
            entry = QLineEdit(default)
            entry.setStyleSheet(entry_style)
            inner.addWidget(entry)
            inner.addStretch()
            return inner, entry

        # 第一行：MODE / BYTYPE / BYSEC
        row1 = QHBoxLayout()
        row1.setSpacing(20)
        m_l, self.mode_combo = make_combo_row("MODE：", ["publish", "review"], "publish", 60)
        bt_l, self.bytype_combo = make_combo_row("BYTYPE：", ["n", "y"], "n", 70)
        bs_l, self.bysec_combo = make_combo_row("BYSEC：", ["y", "n"], "y", 60)
        row1.addLayout(m_l)
        row1.addLayout(bt_l)
        row1.addLayout(bs_l)
        adv_layout.addLayout(row1)

        # 第二行：COVERPAGE / NOTIFY / DEBUG
        row2 = QHBoxLayout()
        row2.setSpacing(20)
        cp_l, self.coverpage_combo = make_combo_row("COVERPAGE：", ["y", "n"], "y", 90)
        nf_l, self.notify_combo = make_combo_row("NOTIFY：", ["y", "n"], "y", 70)
        db_l, self.debug_combo = make_combo_row("DEBUG：", ["n", "y"], "n", 60)
        row2.addLayout(cp_l)
        row2.addLayout(nf_l)
        row2.addLayout(db_l)
        adv_layout.addLayout(row2)

        # 第三行：DOCXYN / TXTLEN / ORDTYPE
        row3 = QHBoxLayout()
        row3.setSpacing(20)
        dx_l, self.docxyn_combo = make_combo_row("DOCXYN：", ["y", "n"], "y", 70)
        tl_l, self.txtlen_entry = make_entry_row("TXTLEN：", "3000", 70)
        # v12.10.66：新增 ORDTYPE 下拉（PDT=按 PDT 顺序排序 / ID=按编号排序），默认 PDT
        od_l, self.ordtype_combo = make_combo_row("ORDTYPE：", ["PDT", "ID"], "PDT", 80)
        row3.addLayout(dx_l)
        row3.addLayout(tl_l)
        row3.addLayout(od_l)
        adv_layout.addLayout(row3)

        # 第四行：OUTLOC
        oc_l, self.outloc_entry = make_entry_row("OUTLOC：", "", 130)
        adv_layout.addLayout(oc_l)

        # 第五行：OUTTYPE
        ot_l, self.outtype_entry = make_entry_row("OUTTYPE：", "", 130)
        adv_layout.addLayout(ot_l)

        # 第六行：SECTION
        sc_l, self.section_entry = make_entry_row("SECTION：", "", 130)
        adv_layout.addLayout(sc_l)

        form_layout.addWidget(self.adv_frame)

        # ---- 按钮区 ----
        btn_layout = QHBoxLayout()
        self.run_btn = QPushButton("▶ 合并 TFLs")
        self.run_btn.setStyleSheet(primary_btn_style())
        self.run_btn.setCursor(Qt.PointingHandCursor)
        self.run_btn.clicked.connect(self.execute_combine)
        btn_layout.addWidget(self.run_btn)

        self.cancel_btn = QPushButton("🟥 中止")
        self.cancel_btn.setStyleSheet(
            "QPushButton { background-color: #FEF0F0; color: #F56C6C; "
            "border: 1px solid #FBC4C4; padding: 8px 20px; border-radius: 4px; font-weight: bold; }"
            "QPushButton:hover { background-color: #FDE2E2; border-color: #F56C6C; }"
            "QPushButton:pressed { background-color: #FBD0D0; }"
        )
        self.cancel_btn.setCursor(Qt.PointingHandCursor)
        self.cancel_btn.setVisible(False)
        self.cancel_btn.clicked.connect(self.cancel_combine)
        btn_layout.addWidget(self.cancel_btn)

        self.open_reports_btn = QPushButton("📂 打开 03_reports")
        self.open_reports_btn.setStyleSheet(success_btn_style())
        self.open_reports_btn.setCursor(Qt.PointingHandCursor)
        self.open_reports_btn.clicked.connect(self._open_reports)
        btn_layout.addWidget(self.open_reports_btn)
        btn_layout.addStretch()

        form_layout.addLayout(btn_layout)
        form_layout.addStretch()

    # ------------------------- UI 辅助事件 -------------------------
    def _toggle_advanced(self):
        """切换"高级参数"面板的显隐"""
        visible = not self.adv_frame.isVisible()
        self.adv_frame.setVisible(visible)
        self.adv_toggle.setText("▼ 高级参数" if visible else "▶ 高级参数")

    def _browse_pdt(self):
        """PDT 浏览按钮回调（打开当前路径所在目录）"""
        cur = self.pdt_entry.text().strip()
        init_dir = os.path.dirname(cur) if cur and os.path.isfile(cur) else (
            os.path.join(self.base_path, "utility", "documentation") if self.base_path else "")
        path = QFileDialog.getOpenFileName(self, "选择 PDT 文件", init_dir, "Excel (*.xlsx)")[0]
        if path:
            self.pdt_entry.setText(path)

    def _open_reports(self):
        """打开 03_reports 目录"""
        p = os.path.join(self.base_path, "03_reports") if self.base_path else ""
        if p and os.path.isdir(p):
            os.startfile(p)
        else:
            self._show_msg("提示", "03_reports 目录不存在", "warning")

    # ------------------------- 状态清空 / 等待提示 -------------------------
    def clear_inputs(self):
        """由主控在路径未齐全时调用：清空所有输入，恢复默认值"""
        self.sas_entry.clear()
        self.pdt_entry.clear()
        self.outfile_entry.clear()
        self.bytype_combo.setCurrentText("n")
        self.bysec_combo.setCurrentText("y")
        self.mode_combo.setCurrentText("publish")
        self.coverpage_combo.setCurrentText("y")
        self.notify_combo.setCurrentText("y")
        self.debug_combo.setCurrentText("n")
        self.docxyn_combo.setCurrentText("y")
        self.txtlen_entry.setText("3000")
        self.ordtype_combo.setCurrentText("PDT")  # v12.10.66
        self.outloc_entry.clear()
        self.outtype_entry.clear()
        self.section_entry.clear()
        self.base_path = ""
        self.p3 = ""
        self.p4 = ""

    def set_wait_hint(self, show):
        """控制左侧上方等待提示的显隐"""
        if show:
            self.scan_lbl.setText("⏳ 等待填写完整路径...")
            self.scan_lbl.setStyleSheet(scan_status_lbl_style())
        else:
            self.scan_lbl.setText("")

    # ============================================================================
    # 全局快捷键钩子：F5 / Ctrl+Enter 由 TFLsWidget 路由到当前 step 的 form
    # ============================================================================
    def action_refresh(self):
        """F5：点击"🔄 刷新源文件"。"""
        btn = getattr(self, "refresh_btn", None)
        if btn is not None and btn.isEnabled():
            btn.click()

    def action_run(self):
        """Ctrl+Enter：点击"▶ 合并 TFLs"。运行中按钮 hidden 时自动空操作。"""
        btn = getattr(self, "run_btn", None)
        if btn is not None and btn.isEnabled() and btn.isVisible():
            btn.click()

    # ------------------------- 路径自动填充 -------------------------
    def update_paths(self, base_path, p3, p4):
        """由主控推送路径：自动定位 Call 脚本 / PDT 完整路径 / OUTFILE（含日期），文件不存在时置空"""
        self.base_path = base_path
        self.p3 = p3
        self.p4 = p4

        sas_default = os.path.join(base_path, "utility", "tools", "31_rtf_combine_call.sas")
        self.sas_entry.setText(sas_default if os.path.isfile(sas_default) else "")

        if p3 and p4:
            pdt_full_path = os.path.join(base_path, "utility", "documentation",
                                         f"{p3}_{p4}_PDT.xlsx".upper())
            self.pdt_entry.setText(pdt_full_path if os.path.isfile(pdt_full_path) else "")
        else:
            self.pdt_entry.clear()

        if p3 and p4:
            sysdate = datetime.now().strftime("%d%b%y").upper()
            self.outfile_entry.setText(f"{p3}_{p4}_{sysdate}")
        else:
            self.outfile_entry.clear()

    # ------------------------- 执行 / 取消 / 回调 -------------------------
    def execute_combine(self):
        sas_path = self.sas_entry.text().strip()
        if not sas_path or not os.path.exists(sas_path):
            self._show_msg("错误", f"找不到 Call 脚本：\n{sas_path}", "error")
            return

        pdt_display = self.pdt_entry.text().strip()
        outfile_val = self.outfile_entry.text().strip()

        if not pdt_display or not outfile_val:
            self._show_msg("错误", "PDT 和 OUTFILE 不能为空！", "error")
            return

        # 从完整路径提取不带扩展名的文件名
        pdt_val = os.path.splitext(os.path.basename(pdt_display))[0]

        # 收集所有参数
        params = {
            "pdt": pdt_val,
            "outfile": outfile_val,
            "bytype": self.bytype_combo.currentText().strip(),
            "bysec": self.bysec_combo.currentText().strip(),
            "mode": self.mode_combo.currentText().strip(),
            "coverpage": self.coverpage_combo.currentText().strip(),
            "notify": self.notify_combo.currentText().strip(),
            "debug": self.debug_combo.currentText().strip(),
            "docxyn": self.docxyn_combo.currentText().strip(),
            "txtlen": self.txtlen_entry.text().strip(),
            # v12.10.66：ORDTYPE 排序依据（PDT / ID），下拉始终有值故直接下发
            "ordtype": self.ordtype_combo.currentText().strip(),
        }
        # 可选参数：仅在用户填写时传入
        outloc_val = self.outloc_entry.text().strip()
        if outloc_val:
            params["outloc"] = outloc_val
        outtype_val = self.outtype_entry.text().strip()
        if outtype_val:
            params["outtype"] = f"%str({outtype_val})"
        section_val = self.section_entry.text().strip()
        if section_val:
            params["section"] = section_val

        # 构造宏调用
        param_str = ", ".join(f"{k}={v}" for k, v in params.items())
        new_call = f"%rtf_combine({param_str});"

        try:
            with open(sas_path, "r", encoding="utf-8") as f:
                content = f.read()

            pattern = re.compile(r'(?m)^[ \t]*%rtf_combine\s*\([^;]*?\)\s*;\s*$')
            if pattern.search(content):
                new_content = pattern.sub(new_call, content, count=1)
            else:
                new_content = content.rstrip() + "\n\n" + new_call + "\n"

            with open(sas_path, "w", encoding="utf-8") as f:
                f.write(new_content)
        except PermissionError:
            self._show_msg("权限拒绝", "Call 脚本被占用，请关闭关联程序后重试！", "error")
            return
        except Exception as e:
            self._show_msg("错误", f"写入 Call 脚本失败: {str(e)}", "error")
            return

        self.sig_run_started.emit()
        self._run_start_time = time.time() - 2.0

        self.run_btn.hide()
        self.cancel_btn.show()
        self.progress_bar.setVisible(True)

        self.sig_log.emit('<span style="color:#409EFF;">> 已更新 Call 脚本参数，向 SAS 提交 TFLs 合并任务...</span>')
        self.sig_log.emit(f'<span style="color:#909399;">&nbsp;&nbsp;{param_str}</span>')
        self.sig_status.emit("⏳ 正在执行中...", "#409EFF")

        self.thread = TFLsCombineRunner(sas_path)
        self.thread.log_signal.connect(
            lambda msg: self.sig_log.emit(f'<span style="color:#F56C6C; font-weight:bold;">{msg}</span>'))
        self.thread.finished_signal.connect(self.on_execute_finished)
        self.thread.start()

    def cancel_combine(self):
        if hasattr(self, 'thread') and self.thread.isRunning():
            self.thread.is_cancelled = True
        self.cancel_btn.hide()
        self.run_btn.show()
        self.progress_bar.setVisible(False)

        self.sig_step_update.emit("05 TFLs Combine 🟥")
        self.sig_log.emit("<span style='color:#F56C6C; font-weight:bold;'>[已中止] 🛑 用户手动取消了执行。</span>")
        self.sig_status.emit("🛑 已中止", "#F56C6C")

    def on_execute_finished(self, has_issue, summary, log_text, source_label):
        if hasattr(self, 'thread') and self.thread.is_cancelled:
            return

        self.cancel_btn.hide()
        self.run_btn.show()
        self.progress_bar.setVisible(False)

        has_content = False
        if log_text:
            for line in log_text.split('\n'):
                line_str = line.strip()
                if not line_str:
                    continue
                if re.match(r'^(ERROR|WARNING)', line_str, re.IGNORECASE):
                    has_content = True
                    color = "#F56C6C" if "ERROR" in line_str.upper() else "#E6A23C"
                    self.sig_log.emit(f'<span style="color:{color}; font-weight:bold;">{line_str}</span>')

        if not has_content:
            self.sig_log.emit('<span style="color:#67C23A;">> 运行完毕，日志干净，无 ERROR / WARNING。</span>')

        if has_issue or has_content:
            self.sig_step_update.emit("05 TFLs Combine ⚠️")
            self.sig_status.emit("⚠️ TFLs 合并完成，但日志存在警告或错误，请审阅！", "#E6A23C")
        else:
            self.sig_step_update.emit("05 TFLs Combine ✅")
            self.sig_status.emit("✅ TFLs 合并成功！", "#67C23A")
