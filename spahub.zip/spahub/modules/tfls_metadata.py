# -*- coding: utf-8 -*-
"""
modules/tfls_metadata.py
========================
02 Metadata Setup 模块。

职责：
  - 读取 setup.xlsx 的 TFL_SHELL / SDTMSPEC / ADAMSPEC 宏变量，定位 Shell/PDS 文件
  - 调用外部工具包 TFL_metadata（tfls_metadata_tadsl_disp / ..._tadsl_pop /
    ..._tadae_over / shell_to_demo）生成核心 Metadata 文件
  - 左侧表单提供 5 个文件路径输入 + 自动填充

文件结构：
  ├─ 外部工具包路径注册（确保 TFL_metadata 可 import）
  ├─ StreamCatcher         将外部模块的 stdout/stderr 转发到 Qt 信号
  ├─ MetadataRunner (QThread) 后台依次调用 4 个 TFL_metadata 子模块
  └─ MetadataForm  (QFrame)   左侧表单 + 信号

v12.10.56（本次改动）：demo_shell 跳过时 UI 明确告知用户
    配合 TFL_metadata/shell_to_demo.py v12.10.56：run_shell_to_demo 现在返回
    (status, msg) 元组。当 status=="skipped" 时（ADaM/SDTM PDS 未填 或 PDT 中
    无 14.1 段对应行），MetadataRunner 把状态挂到 self._demo_shell_status /
    self._demo_shell_skip_reason，MetadataForm._on_meta_finished 据此把状态栏
    显示从绿色"✅ Metadata 提取成功"改为橙色"⚠️ Metadata 完成（demo_shell 已跳过）"，
    并在日志面板追加一条总览（含跳过原因 + 下一步建议）。

    向后兼容：老版本 shell_to_demo 返回 None / 抛异常的情况都保留原行为，
    新增的 status 默认 "ok"。

v12.10.58：修复日志面板对含 '<' 字符的行被截断的问题
    用户截图：'WARNING: demo_shell 共有 3 条低置信度记录（<0.55），请重点核查上述 sheet。'
    在 02 Metadata Setup 日志面板里只显示到 "记录（" 就消失。
    根因（双重隐患）：
      1. StreamCatcher.write 把 print 文本未转义直接 emit
      2. MetadataForm._on_meta_log 把 text 直接拼进 f"<span style=...>{text}</span>"
         模板 → text 里的 "<0.55" 变成真 HTML 的一部分 → Qt QTextEdit 把它当未闭合
         tag 解析 → 从 "<" 起整段被吞到行末
    修复：
      - StreamCatcher.write/flush: html.escape() + 行缓冲（顺带防 stdout chunk 拆分）
      - MetadataForm._on_meta_log 注释清晰约定"输入必须已 escape"
      - MetadataForm._on_meta_progress 不再借道 _on_meta_log，自己 escape + emit

v12.10.72（本次改动）：修复 ADaM / SDTM PDS 自动定位抓到其它项目文件的 bug
    现象（用户截图）：在 SHR9999_test/csr_04 四级目录下运行 02 Metadata，
    ADaM PDS XLSX 却被填成了别项目的 SHR2004_101_csr_02_ADaM_PDS.xlsx，
    导致下游 shell_to_demo 按 ADaM PDS 文件名前缀命名，产出
    SHR2004_101_csr_02_demo_shell.xlsx（项目号串台）。
    根因：update_paths 里 ADaM/SDTM PDS 兜底用裸通配 glob('*ADaM_PDS.xlsx')[0]，
    当 utility/documentation 下残留其它项目的同类文件时会被错误抓走；SDTM 这次
    侥幸没出事，只因其 SDTMSPEC 解析到了正确现存文件、没走到兜底。
    修复：PDS / PDT 这类「项目号_csr号_固定名」文件，兜底必须约束在当前项目
    唯一前缀（如 SHR9999_test_csr_04）范围内精确匹配，匹配不到一律置空，
    绝不退回裸 glob。前缀由 _derive_project_prefix 从 PDT 文件名 / base_path
    文件夹结构推导。
"""
import os
import sys
import re   # v12.10.72: 项目前缀正则解析
import glob
import html  # v12.10.58: 转义 stdout 文本里的 < > & 防止被 QTextEdit 当 HTML tag 吞掉

# ================= 外部工具包路径注册 =================
# TFL_metadata 是外部独立 Python 包，放在项目同级目录或 Z:\projects\Z_PYTHON
#
# v12.10.71：sys.path.insert(0, ...) → sys.path.append(...)
#   理由同 main.py L40-72 注释。该路径 _TARGET_DIR 通常已经被 main.py 提前 append
#   到 sys.path 末尾（路径相同），这里的 if-not-in 判定会跳过；保留这段作为防御性
#   兜底（用户直接跑 modules/tfls_metadata.py 单元测试或绕过 main.py 启动时仍有效）。
_CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
_PARENT_DIR = os.path.dirname(_CURRENT_DIR)
_TARGET_DIR = os.path.join(_PARENT_DIR, "TFL_metadata")

# 兜底：本地找不到时用固定网络路径
if not os.path.exists(_TARGET_DIR):
    _TARGET_DIR = r"Z:\projects\Z_PYTHON\TFL_metadata"

if _TARGET_DIR not in sys.path:
    sys.path.append(_TARGET_DIR)
# ======================================================

from PySide6.QtWidgets import (QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                               QLineEdit, QFileDialog, QFrame, QProgressBar, QDialog)
from PySide6.QtCore import Qt, QThread, Signal

from ui_utils import show_dialog, primary_outline_btn_style, scan_status_lbl_style


# =============================================================================
# 辅助：stdout/stderr 重定向到 Qt 信号
# =============================================================================
class StreamCatcher:
    """
    将外部模块 print 出来的文本逐行推入 log_signal，用于将
    TFL_metadata 子模块的输出展示到 GUI 日志面板。

    v12.10.58：加行缓冲 + HTML 转义。
      修复用户截图反馈："WARNING: demo_shell 共有 3 条低置信度记录（<0.55），..."
      在日志面板里被截断到 "记录（" 就消失。

    根因（双重隐患）：
      1. sys.stdout 被重定向后，一行 print 经常被分多次 write() 调用
         （Windows + transformers/torch 大模型库的 stderr 干扰下尤其明显）
         → 不做行缓冲就直接 emit 会让一行被切成几段
      2. emit 出去的原始文本之后会进入 _on_meta_log 被拼到 <span> 模板里
         → 若 text 含 '<0.55' 这样的片段，Qt 把它当未闭合 HTML tag 吞掉
         整段消失。

    修复：
      - 内部缓冲：按 '\\n' 切分；最后一段（无 '\\n' 结尾）留缓冲等下次 write
      - emit 前一律 html.escape(): < → &lt;, > → &gt;, & → &amp;
        保证后续 _on_meta_log 拼到 <span> 模板里时 text 部分对 Qt 是纯字符
      - flush()/close() 把残留 buffer 吐出去（进程退出时常见）
    """
    def __init__(self, sig):
        self.sig = sig
        self._buf = ""

    def write(self, text):
        if not text:
            return
        self._buf += text
        if "\n" not in self._buf:
            return
        parts = self._buf.split("\n")
        self._buf = parts[-1]  # 末尾不完整片段留下，等下次 write 拼起来
        for line in parts[:-1]:
            line = line.rstrip("\r")  # Windows \r\n 兼容
            if line.strip():
                # html.escape() 让 _on_meta_log 拼 <span>{text}</span> 时 text
                # 部分一律是纯字符（< → &lt; / > → &gt; / & → &amp;）
                self.sig.emit(html.escape(line))

    def flush(self):
        # 进程退出 / 用户手动 flush 时把残留缓冲也吐出去
        if self._buf.strip():
            self.sig.emit(html.escape(self._buf.rstrip("\r\n")))
        self._buf = ""

    # 少数库会调用 sys.stdout.close()；同义于 flush 即可（不真关流）
    close = flush


# =============================================================================
# 后台运行线程
# =============================================================================
class MetadataRunner(QThread):
    """
    依次调用 TFL_metadata 工具包的 4 个子模块：
      1. tfls_metadata_tadsl_disp  参与者分布
      2. tfls_metadata_tadsl_pop   分析集
      3. tfls_metadata_tadae_over  不良事件汇总
      4. shell_to_demo             Shell → demo_shell 语义匹配（大模型）
    """
    log_signal = Signal(str)
    progress_signal = Signal(int, str)
    finished_signal = Signal(bool, str)

    def __init__(self, out_dir, shell_path, adam_path, sdtm_path, ecrf_path, code_path, pdt_path):
        super().__init__()
        self.out_dir = out_dir
        self.shell_path = shell_path
        self.adam_path = adam_path
        self.sdtm_path = sdtm_path
        self.ecrf_path = ecrf_path
        self.code_path = code_path
        self.pdt_path = pdt_path
        self.is_cancelled = False
        # v12.10.56：demo_shell 跳过状态——由 run() 接 shell_to_demo.run_shell_to_demo 的
        # (status, msg) 返回值赋值，由 MetadataForm._on_meta_finished 读取后决定 UI 显示。
        # 默认 "ok"（兼容老版 shell_to_demo 返回 None 的情况）。
        self._demo_shell_status = "ok"
        self._demo_shell_skip_reason = ""

    def run(self):
        old_out, old_err = sys.stdout, sys.stderr
        catcher = StreamCatcher(self.log_signal)
        sys.stdout = catcher
        sys.stderr = catcher
        try:
            self.progress_signal.emit(5, "正在后台静默加载环境依赖 (首次加载可能稍长)...")

            import tfls_metadata_tadsl_disp
            import tfls_metadata_tadsl_pop
            import tfls_metadata_tadae_over

            # v12.10.31：torch 单独 import 给清楚的错误（修 Issue 9）
            # 根因：shell_to_demo.py 顶层 `import torch`；frozen 打包时若 torch 未
            # 通过 --collect-all torch 进 bundle，运行到这一行才 ModuleNotFoundError，
            # 用户看到的就是截图里的"No module named 'torch'"裸异常框，没操作指引。
            # 修法：单独 try import torch，失败时给出 1) 用户该如何安装 2) 打包者
            # 该改 PyInstaller spec 的提示。其他 3 个 metadata 模块（disp/pop/over）
            # 不依赖 torch，已经成功跑了，不影响。
            try:
                import torch  # noqa: F401
            except ImportError as ie:
                raise Exception(
                    "demo_shell（语义匹配）依赖 PyTorch，但当前环境未检测到。\n\n"
                    "原因：\n"
                    "  • 开发机：尚未 pip install torch sentence-transformers FlagEmbedding\n"
                    "  • 打包机：PyInstaller 没有把 torch 收进 bundle\n\n"
                    "解决办法（请打包者参考）：\n"
                    "  1) 在 spec 文件里加 collect_all('torch')，或命令行加\n"
                    "       --collect-all torch --collect-all sentence_transformers\n"
                    "  2) 重新打包后 demo_shell 即可使用。\n\n"
                    "解决办法（用户临时跳过）：\n"
                    "  • 前 3 步 metadata 文件（参与者分布 / 分析集 / 不良事件汇总）已生成，\n"
                    "    可手动核对，跳过 demo_shell 步骤。\n\n"
                    f"[原始异常] {ie}"
                )

            import shell_to_demo

            if self.is_cancelled: return

            self.progress_signal.emit(15, "正在生成 参与者分布 (t14_1-1_1)...")
            # v11.1：把 shell_path 也传给 disp，便于其在多文件输出时识别 mockup 一变多并打印 NOTE
            ok, msg = tfls_metadata_tadsl_disp.run_tadsl_disp_init(self.out_dir, self.code_path, self.ecrf_path,
                                                                   self.pdt_path, "CN", self.shell_path)
            if not ok: raise Exception(msg)
            if self.is_cancelled: return

            self.progress_signal.emit(40, "正在生成 分析集 (t14_1-1_2)...")
            ok, msg = tfls_metadata_tadsl_pop.run_analysis_set_init(self.out_dir, self.shell_path, self.pdt_path)
            if not ok: raise Exception(msg)
            if self.is_cancelled: return

            self.progress_signal.emit(65, "正在生成 不良事件汇总 (t14_3_1-1_1)...")
            # v11.1：同上，shell_path 传给 tadae_over 用于 mockup 一变多识别
            ok, msg = tfls_metadata_tadae_over.run_tadae_over_init(self.out_dir, self.code_path, self.pdt_path,
                                                                    self.shell_path)
            if not ok: raise Exception(msg)
            if self.is_cancelled: return

            self.progress_signal.emit(85, "正在进行大模型语义匹配 (demo_shell)...")
            # v12.10.56：shell_to_demo.run_shell_to_demo 现在返回 (status, msg) 元组。
            #   - ("ok",      "已处理 N 个表，M 个变量...")          → 正常完成
            #   - ("skipped", "ADaM/SDTM PDS 均未提供或不含变量")    → early-return ②
            #   - ("skipped", "经 PDT 映射 + 14.1 过滤后无可处理 shell 表") → early-return ①
            #   - None / 其它形态                                    → 老版本兼容，按 "ok" 处理
            # 不让 demo_shell 的 skipped 抛 Exception——demo_shell 已在日志里打了 WARNING，
            # 让整个 metadata step 保持 "成功（含 demo_shell skip）" 而非 "失败"。
            demo_result = shell_to_demo.run_shell_to_demo(
                os.path.join(self.out_dir, "demo_shell.xlsx"), self.shell_path,
                self.adam_path, self.sdtm_path, self.pdt_path
            )
            if isinstance(demo_result, tuple) and len(demo_result) >= 2:
                self._demo_shell_status = str(demo_result[0] or "ok").strip().lower() or "ok"
                self._demo_shell_skip_reason = str(demo_result[1] or "").strip()
            # demo_result 为 None / 其它 → 保持构造时默认 ("ok", "")

            if self.is_cancelled: return

            # v12.10.56：根据 demo_shell 状态调整最终提示文案。整体仍是 success=True
            # （前 3 个 metadata 已成功生成；demo_shell skip 不视为失败）。
            if self._demo_shell_status == "skipped":
                self.progress_signal.emit(100, "完成（demo_shell 已跳过）")
                self.finished_signal.emit(
                    True,
                    f"⚠️ Metadata 完成，demo_shell 已跳过：{self._demo_shell_skip_reason}"
                )
            else:
                self.progress_signal.emit(100, "全部生成成功！")
                self.finished_signal.emit(True, "✅ 所有元数据文件已成功生成！")
        except Exception as e:
            if self.is_cancelled: return
            self.progress_signal.emit(100, "生成中断")
            self.finished_signal.emit(False, f"❌ {str(e)}")
        finally:
            sys.stdout = old_out
            sys.stderr = old_err


# =============================================================================
# 左侧表单组件 MetadataForm
# =============================================================================
class MetadataForm(QFrame):
    """
    Metadata Setup 的左侧业务表单。

    信号：
      sig_log           日志行
      sig_status        底部状态 + 颜色
      sig_step_update   步骤栏文字
      sig_run_started   运行开始（外部用于清空日志 / 启动耗时计时器）
    """
    sig_log = Signal(str)
    sig_status = Signal(str, str)
    sig_step_update = Signal(str)
    sig_run_started = Signal()

    # ------------------------- 初始化 -------------------------
    def __init__(self):
        super().__init__()
        self.base_path = ""
        self.pdt_path = ""
        self._setup_ui()

    def _show_msg(self, title, text, msg_type="info"):
        """统一弹窗引擎 - 委托至全局共享函数"""
        return show_dialog(self, title, text, msg_type)

    # ------------------------- UI 构造 -------------------------
    def _setup_ui(self):
        self.setObjectName("LeftPanel")
        self.setStyleSheet("#LeftPanel { background-color: #FFFFFF; border: 1px solid #E4E7ED; border-radius: 6px; }")
        form_layout = QVBoxLayout(self)
        form_layout.setAlignment(Qt.AlignTop)
        form_layout.setContentsMargins(25, 25, 25, 25)
        form_layout.setSpacing(20)

        # 任务1：TOC 风格刷新按钮 + 扫描状态标签
        self._step_name = "Metadata Setup"
        top_bar = QHBoxLayout()
        self.refresh_btn = QPushButton("🔄 刷新源文件")
        # v12.10.65：统一改用 home"📁 系统文件复制"同款蓝色外框样式
        self.refresh_btn.setStyleSheet(primary_outline_btn_style())
        self.refresh_btn.setCursor(Qt.PointingHandCursor)
        top_bar.addWidget(self.refresh_btn)
        self.scan_lbl = QLabel("")
        self.scan_lbl.setStyleSheet(scan_status_lbl_style())
        top_bar.addWidget(self.scan_lbl)
        top_bar.addStretch()
        form_layout.addLayout(top_bar)

        lbl = QLabel("提取 PDS、Shell 和 EDC 信息，自动生成核心 Metadata。")
        lbl.setStyleSheet("color: #303133; font-weight: bold; font-size: 14px; border: none; margin-bottom: 10px;")
        form_layout.addWidget(lbl)

        self.meta_prog = QProgressBar()
        self.meta_prog.setVisible(False)
        self.meta_prog.setFixedHeight(4)
        form_layout.addWidget(self.meta_prog)

        def add_row(label_text, filter_str):
            l = QHBoxLayout()
            lbl = QLabel(label_text)
            lbl.setStyleSheet("border: none; color: #606266;")
            l.addWidget(lbl)
            entry = QLineEdit()
            entry.setStyleSheet("padding: 6px; border: 1px solid #DCDFE6; border-radius: 4px;")
            l.addWidget(entry)
            b = QPushButton("浏览")
            b.setStyleSheet(
                "background-color: #F5F7FA; color: #606266; border: 1px solid #DCDFE6; padding: 6px 12px; border-radius: 4px;")
            b.clicked.connect(lambda checked=False, e=entry, f=filter_str: e.setText(
                QFileDialog.getOpenFileName(self, "选择文件",
                    os.path.dirname(e.text()) if os.path.isfile(e.text()) else self.base_path, f)[0] or e.text()))
            l.addWidget(b)
            form_layout.addLayout(l)
            return entry

        self.meta_shell_entry = add_row("1. Shell DOCX：", "*.docx")
        self.meta_adam_entry = add_row("2. ADaM PDS XLSX：", "*.xlsx")
        self.meta_sdtm_entry = add_row("3. SDTM PDS XLSX：", "*.xlsx")
        self.meta_ecrf_entry = add_row("4. EDC eCRF SAS7BDAT：", "*.sas7bdat")
        self.meta_code_entry = add_row("5. EDC Code SAS7BDAT：", "*.sas7bdat")
        # 任务2（v10）：新增 PDT XLSX 输入行 —— 4 个 TFL_metadata 子模块均会消费它来
        # 按 PDT 中登记的输出表清单展开 a/b/c 多文件，UI 上让用户能确认 / 覆盖默认。
        self.meta_pdt_entry = add_row("6. PDT XLSX：", "*.xlsx")

        bl = QHBoxLayout()
        self.meta_run_btn = QPushButton("▶ 提取并生成 Metadata")
        self.meta_run_btn.setStyleSheet(
            "background-color: #4A6FA5; color: white; border: none; padding: 8px 20px; border-radius: 4px; font-weight: bold;")
        self.meta_run_btn.clicked.connect(self.execute_meta)
        bl.addWidget(self.meta_run_btn)

        self.meta_cancel_btn = QPushButton("🟥 中止")
        self.meta_cancel_btn.setStyleSheet(
            "background-color: #FEF0F0; color: #F56C6C; border: 1px solid #FBC4C4; padding: 8px 20px; border-radius: 4px; font-weight: bold;")
        self.meta_cancel_btn.setVisible(False)
        self.meta_cancel_btn.clicked.connect(self.cancel_meta)
        bl.addWidget(self.meta_cancel_btn)

        meta_open_btn = QPushButton("📂 打开 metadata")
        meta_open_btn.setStyleSheet(
            "background-color: #3F9A6E; color: white; border: none; padding: 8px 20px; border-radius: 4px; font-weight: bold;")
        meta_open_btn.setToolTip("打开 utility/metadata（与 aCRF-03 Import EDC Definition 的同款按钮一致）")
        meta_open_btn.clicked.connect(
            lambda: os.startfile(os.path.join(self.base_path, "utility", "metadata")) if os.path.exists(
                os.path.join(self.base_path, "utility", "metadata")) else None)
        bl.addWidget(meta_open_btn)
        bl.addStretch()

        form_layout.addLayout(bl)
        form_layout.addStretch()

    # ------------------------- 路径解析 + 自动填充 -------------------------
    def update_paths(self, base_path, pdt_path):
        self.base_path = base_path
        self.pdt_path = pdt_path
        stat_dir = os.path.join(base_path, "utility", "documentation", "03_statistics")
        doc_dir = os.path.join(base_path, "utility", "documentation")
        meta_dir = os.path.join(base_path, "utility", "metadata")

        # 从 setup.xlsx 读取 TFL_SHELL / SDTMSPEC / ADAMSPEC 三个宏变量的值
        setup_vars = self._read_setup_macros(base_path)

        # --- 1. Shell DOCX ---
        # 规则：若 TFL_SHELL 为空或为 "Mockup_shell-PK_TFL_Shell"，使用模板兜底
        tfl_shell_val = setup_vars.get("TFL_SHELL", "").strip()
        MOCKUP_TEMPLATE = r"Z:\projects\utility\template\Mockup_shell-PK_TFL_Shell.docx"
        if not tfl_shell_val or tfl_shell_val.lower() == "mockup_shell-pk_tfl_shell":
            shell_path = MOCKUP_TEMPLATE
        else:
            # TFL_SHELL 值作为文件名（不带路径）拼接到 03_statistics 下
            candidate = os.path.join(stat_dir, tfl_shell_val)
            if not candidate.lower().endswith(".docx"):
                candidate += ".docx"
            if os.path.exists(candidate):
                shell_path = candidate
            else:
                # 找不到时回退为 glob 扫描
                shells = glob.glob(os.path.join(stat_dir, "*shell*.docx")) + glob.glob(
                    os.path.join(stat_dir, "*Shell*.docx"))
                shell_path = shells[0] if shells else MOCKUP_TEMPLATE
        self.meta_shell_entry.setText(shell_path)

        # v12.10.72：推导当前项目唯一前缀（如 SHR9999_test_csr_04），约束 PDS 兜底，
        # 杜绝抓到其它项目（如 SHR2004）残留的同类文件。
        proj_prefix = self._derive_project_prefix(base_path, pdt_path)

        # --- 2. ADAM PDS ---
        # 规则：优先使用 setup 中 ADAMSPEC 的值拼接路径；找不到则**仅在当前项目前缀
        #       范围内**精确匹配 <prefix>_ADaM_PDS.xlsx，匹配不到一律置空。
        adam_val = setup_vars.get("ADAMSPEC", "").strip()
        adam_path = ""
        if adam_val:
            candidate = os.path.join(doc_dir, adam_val)
            if not candidate.lower().endswith(".xlsx"):
                candidate += ".xlsx"
            if os.path.exists(candidate):
                adam_path = candidate
        if not adam_path:
            # v12.10.72：禁止裸 glob('*ADaM_PDS.xlsx')[0]——必须项目前缀约束。
            adam_path = self._match_pds_by_prefix(doc_dir, proj_prefix, "ADAM_PDS")
        self.meta_adam_entry.setText(adam_path)

        # --- 3. SDTM PDS ---
        sdtm_val = setup_vars.get("SDTMSPEC", "").strip()
        sdtm_path = ""
        if sdtm_val:
            candidate = os.path.join(doc_dir, sdtm_val)
            if not candidate.lower().endswith(".xlsx"):
                candidate += ".xlsx"
            if os.path.exists(candidate):
                sdtm_path = candidate
        if not sdtm_path:
            # v12.10.72：与 ADaM 同款——禁止裸 glob，必须项目前缀约束。
            sdtm_path = self._match_pds_by_prefix(doc_dir, proj_prefix, "SDTM_PDS")
        self.meta_sdtm_entry.setText(sdtm_path)

        self.meta_ecrf_entry.setText(os.path.join(meta_dir, "edcdef_ecrf.sas7bdat"))
        self.meta_code_entry.setText(os.path.join(meta_dir, "edcdef_code.sas7bdat"))

        # 任务2（v10）：把外部传入的 PDT 默认路径同步到 UI 输入行，方便用户确认 / 覆盖
        self.meta_pdt_entry.setText(self.pdt_path if (self.pdt_path and os.path.isfile(self.pdt_path)) else "")

    # ------------------------- v12.10.72 项目前缀工具 -------------------------
    @staticmethod
    def _derive_project_prefix(base_path, pdt_path):
        """推导当前项目的唯一前缀，如 'SHR9999_test_csr_04'。

        用途：约束 ADaM/SDTM PDS 的兜底匹配，杜绝抓到其它项目（如 SHR2004）
        残留的同类文件。匹配优先级：
          1. PDT 文件名（最权威，由 stepper 按当前项目推送）：去掉 _PDT.xlsx 后缀
          2. base_path 文件夹结构：<上级文件夹>_<csr 文件夹>
             例：.../SHR9999/SHR9999_test/csr_04 → 'SHR9999_test_csr_04'
        都推不出返回 ""（调用方据此置空，绝不退回裸 glob）。
        """
        # 1) 从 PDT 文件名解析（仅当严格以 _PDT.xlsx 结尾时）
        if pdt_path:
            m = re.match(r"^(.+?)_pdt\.xlsx$", os.path.basename(str(pdt_path)),
                         re.IGNORECASE)
            if m and m.group(1).strip():
                return m.group(1).strip()
        # 2) 兜底：<上级文件夹>_<csr 文件夹>
        try:
            norm = os.path.normpath(str(base_path))
            leaf = os.path.basename(norm)                 # csr_04
            parent = os.path.basename(os.path.dirname(norm))  # SHR9999_test
            if leaf and parent:
                return f"{parent}_{leaf}"
        except Exception:
            pass
        return ""

    @staticmethod
    def _match_pds_by_prefix(doc_dir, proj_prefix, suffix_token):
        """在 doc_dir 下**仅匹配当前项目前缀**的固定名 PDS 文件，找不到返回 ""。

        suffix_token: "ADAM_PDS" 或 "SDTM_PDS"（大小写不敏感）。
        只接受形如 <proj_prefix>_<...>ADaM_PDS.xlsx 的文件——前缀不符（其它项目）
        一律忽略；这是本次修复的核心：兜底绝不跨项目抓文件。
        """
        if not proj_prefix:
            return ""
        suffix_upper = suffix_token.upper() + ".XLSX"
        # 仅在以本项目前缀打头的 xlsx 里筛，避免抓到别项目的同类文件
        for f in glob.glob(os.path.join(doc_dir, f"{proj_prefix}_*.xlsx")):
            if os.path.basename(f).upper().endswith(suffix_upper):
                return f
        return ""

    def _read_setup_macros(self, base_path):
        """从 setup.xlsx 中读取宏变量 → 值的映射 (B列=宏名, C列=值)"""
        result = {}
        setup_path = os.path.join(base_path, "utility", "documentation", "setup.xlsx")
        if not os.path.exists(setup_path):
            return result
        try:
            import openpyxl
            wb = openpyxl.load_workbook(setup_path, data_only=True, read_only=True)
            for ws in wb.worksheets:
                for row in ws.iter_rows(values_only=True):
                    if len(row) < 3:
                        continue
                    key = row[1]
                    val = row[2]
                    if key is None:
                        continue
                    key_str = str(key).strip().upper()
                    if key_str in ("TFL_SHELL", "SDTMSPEC", "ADAMSPEC"):
                        result[key_str] = str(val).strip() if val is not None else ""
                if result:
                    break
            wb.close()
        except Exception:
            pass
        return result

    # ------------------------- 等待提示 -------------------------
    def set_wait_hint(self, show):
        """控制左侧上方等待提示的显隐"""
        if show:
            self.scan_lbl.setText("⏳ 等待填写完整路径...")
            self.scan_lbl.setStyleSheet(scan_status_lbl_style())
        else:
            self.scan_lbl.setText("")

    # ============================================================================
    # 全局快捷键钩子：F5 / Ctrl+Enter 由 TFLsWidget 路由到当前 step 的 form
    # ============================================================================
    def action_refresh(self):
        """F5：点击"🔄 刷新源文件"。"""
        btn = getattr(self, "refresh_btn", None)
        if btn is not None and btn.isEnabled():
            btn.click()

    def action_run(self):
        """Ctrl+Enter：点击"▶ 提取并生成 Metadata"。"""
        btn = getattr(self, "meta_run_btn", None)
        if btn is not None and btn.isEnabled() and btn.isVisible():
            btn.click()

    # ------------------------- 执行 / 取消 / 回调 -------------------------
    def execute_meta(self):
        """点击"提取并生成"：入口校验 → 覆盖确认 → 启动后台线程"""
        # 校验 Shell 输入框是否为空
        shell_path = self.meta_shell_entry.text().strip()
        if not shell_path:
            self._show_msg("错误", "Shell DOCX 路径不能为空，请先填写或刷新路径！", "error")
            return

        # v11.2：重置 demo_shell 低置信度计数器，避免连续两次执行的残留累计
        self._demo_shell_low_conf_count = 0

        out_dir = os.path.join(self.base_path, "utility", "metadata")
        os.makedirs(out_dir, exist_ok=True)

        existing_files = []
        if os.path.exists(out_dir):
            # 检测范围：Metadata 工具包输出的原始文件 + 用户可能手动修改后的中间产物
            # 包含：tadsl_disp → 参与者分布(t14_1-1_1)
            #       tadsl_pop  → 分析集(t14_1-1_2)
            #       tadae_teae_over → 不良事件汇总(t14_3_1-1_1)
            #       demo_shell → Shell 语义匹配
            #       t14_*/t141_*/t1431_* → 实际 TFL 输出文件
            patterns = [
                "demo_shell*.xlsx",
                # v12.10.52：shell_to_demo 现在按项目命名输出（<project>_demo_shell.xlsx），
                # 例如 SHR9999_test_csr_04_demo_shell.xlsx；这条 pattern 用于检测/覆盖这类
                # 项目前缀文件，老的 demo_shell.xlsx 也仍能被上一条 pattern 覆盖。
                "*_demo_shell*.xlsx",
                "tadae_teae_over*.xlsx",
                "tadsl_pop*.xlsx",
                "tadsl_disp*.xlsx",
                "t14_1-1_1*.xlsx",
                "t14_1-1_2*.xlsx",
                "t14_3_1-1_1*.xlsx",
                "t141_*.xlsx",
                "t1431_*.xlsx",
            ]
            seen = set()
            for pat in patterns:
                for f in glob.glob(os.path.join(out_dir, pat)):
                    if f not in seen:
                        seen.add(f)
                        existing_files.append(f)

        if existing_files:
            confirm = self._show_msg(
                "覆盖警告",
                f"检测到目标目录 (utility/metadata) 中已存在 {len(existing_files)} 个历史 Metadata 文件！\n\n本次生成将直接覆盖原有文件，是否确认继续？",
                "question"
            )
            if not confirm:
                self.sig_log.emit("<span style='color:#909399;'>已取消生成任务。</span>")
                return
            # v12.10.52：用户在弹窗里点了"确定覆盖"，先把检测到的 demo_shell 类文件物理删掉，
            # 避免 Excel 当前打开占用着旧文件、或下游同名 sheet 残留导致 wb.save 失败/写半。
            # 其它历史 metadata 文件（tadsl_disp / pop / tadae_teae_over / t14_*）由各自后续
            # pipeline 重写覆盖，不在这里删，减小误删面。
            _DEMO_SHELL_DELETE_PATTERNS = ("demo_shell*.xlsx", "*_demo_shell*.xlsx")
            deleted_n = 0
            for pat in _DEMO_SHELL_DELETE_PATTERNS:
                for f in glob.glob(os.path.join(out_dir, pat)):
                    try:
                        os.remove(f)
                        deleted_n += 1
                    except OSError as e:
                        # 多半是文件被 Excel 占用——明确告诉用户，让其关闭 Excel 再点
                        self.sig_log.emit(
                            f"<span style='color:#F56C6C;'>❌ 无法删除旧 demo_shell 文件 "
                            f"{os.path.basename(f)}：{e}（请关闭 Excel 后重试）</span>"
                        )
                        return
            if deleted_n:
                self.sig_log.emit(
                    f"<span style='color:#909399;'>&nbsp;&nbsp;ℹ 已清理 {deleted_n} 个旧 demo_shell 文件，"
                    "准备重新生成。</span>"
                )

        self.sig_run_started.emit()

        self.meta_run_btn.hide()
        self.meta_cancel_btn.show()
        self.meta_prog.setRange(0, 0)  # 开启无限流条
        self.meta_prog.setVisible(True)
        self.meta_prog.setValue(0)
        self.meta_prog.setVisible(True)

        self.sig_log.emit("<span style='color:#409EFF;'>> 启动 Metadata 提取管道...</span>")
        self.sig_status.emit("⏳ 正在执行中...", "#409EFF")

        self.meta_thread = MetadataRunner(
            out_dir=out_dir,
            shell_path=self.meta_shell_entry.text().strip(),
            adam_path=self.meta_adam_entry.text().strip(),
            sdtm_path=self.meta_sdtm_entry.text().strip(),
            ecrf_path=self.meta_ecrf_entry.text().strip(),
            code_path=self.meta_code_entry.text().strip(),
            # 任务2（v10）：以 UI 输入为准（允许用户用浏览按钮覆盖默认探测值）；
            # 若用户清空了输入，则回退到 update_paths 推送的 self.pdt_path
            pdt_path=(self.meta_pdt_entry.text().strip() or self.pdt_path)
        )
        self.meta_thread.log_signal.connect(self._on_meta_log)
        self.meta_thread.progress_signal.connect(self._on_meta_progress)
        self.meta_thread.finished_signal.connect(self._on_meta_finished)
        self.meta_thread.start()

    def _on_meta_log(self, text):
        """
        Slot for self.meta_thread.log_signal （来自 StreamCatcher.emit）。

        v12.10.58 约定（必读）：
          - 此处的 text **必须是已经 HTML-escape 过的纯字符**（< → &lt; / > → &gt;
            / & → &amp;）。当前唯一调用方是 StreamCatcher.write，已在该侧统一
            做了 html.escape()。
          - 本函数只负责套一层带颜色的 <span>，**绝不再 escape 一次**（否则会把
            StreamCatcher 已经转好的 &lt; 再转成 &amp;lt; 字面量）。
          - **如果未来要新增一个调用方传"故意带 HTML tag 的富文本"进来**，请
            自己 self.sig_log.emit(...) 直接发，不要走这个 slot — 看
            _on_meta_progress（v12.10.58 起改为直接 emit）的写法。
        """
        color = "#606266"
        if "ERROR" in text or "❌" in text:
            color = "#F56C6C"
        elif "WARNING" in text or "⚠️" in text:
            color = "#E6A23C"
        elif "✅" in text:
            color = "#67C23A"
        # v11.2：跟踪 demo_shell 低置信度警告条数，供成功完成时弹一条总览
        # shell_to_demo 输出格式：'WARNING: <sheet> | <desc> | conf=<float>'
        if "WARNING:" in text and "conf=" in text and "|" in text:
            self._demo_shell_low_conf_count = getattr(self, "_demo_shell_low_conf_count", 0) + 1
        self.sig_log.emit(f"<span style='color:{color};'>{text}</span>")

    def _on_meta_progress(self, val, msg):
        # self.meta_prog.setValue(val)
        # v12.10.58：原来借道 _on_meta_log 传 "<b>{msg}</b>" 进去依赖该函数不 escape。
        # 改为直接 emit：自己负责 escape msg 防注入 + 自己拼 <b>...</b>。
        # 好处：_on_meta_log 现在的"输入必须已 escape"约定彻底单一来源，
        #       未来加新的 log 来源不会再误用模板字符串导致 v12.10.58 这种截断 bug。
        safe_msg = html.escape(str(msg))
        self.sig_log.emit(f"<b>{safe_msg}</b>")

    def _on_meta_finished(self, success, msg):
        # 若已被用户取消，忽略结果
        if hasattr(self, 'meta_thread') and self.meta_thread.is_cancelled:
            return

        self.meta_cancel_btn.hide()
        self.meta_run_btn.show()
        self.meta_prog.setVisible(False)

        if success:
            # v12.10.56：根据 demo_shell 跳过状态决定 UI 状态颜色 + 文字。
            # success=True 不等于 "全员都成功"——demo_shell 在缺 PDS / 缺 PDT 段时
            # 会静默 skip 但 metadata step 整体仍算成功；此时改用橙色 ⚠️ 提示，
            # 避免用户误以为 demo_shell.xlsx 已生成。
            demo_status = "ok"
            demo_skip_reason = ""
            if hasattr(self, "meta_thread"):
                demo_status = getattr(self.meta_thread, "_demo_shell_status", "ok")
                demo_skip_reason = getattr(self.meta_thread, "_demo_shell_skip_reason", "")

            if demo_status == "skipped":
                self.sig_status.emit("⚠️ Metadata 完成（demo_shell 已跳过）", "#E6A23C")
                self.sig_step_update.emit("02 Metadata Setup ⚠️")
                # 日志面板追加一条总览（橙色加粗），含原因 + 下一步建议
                self.sig_log.emit(
                    f"<span style='color:#E6A23C; font-weight:bold;'>"
                    f"⚠️ demo_shell 已跳过：{html.escape(demo_skip_reason)}。"
                    f"前 3 个 metadata 文件（参与者分布 / 分析集 / 不良事件汇总）已正常生成；"
                    f"如需 demo_shell.xlsx，请按上方 WARNING 行的提示补齐相应输入后重跑 02 Metadata Setup。"
                    f"</span>"
                )
            else:
                self.sig_status.emit("✅ Metadata 提取成功！", "#67C23A")
                self.sig_step_update.emit("02 Metadata Setup ✅")

            # v11.2：成功完成后，如果 demo_shell 期间出现过低置信度警告，追加一条总览提示。
            # 注：demo_shell 跳过场景下 low_conf_n 一定是 0（_demo_shell_low_conf_count 由
            # demo_shell WARNING 行实时累加，跳过路径不会进入计数循环）。
            low_conf_n = getattr(self, "_demo_shell_low_conf_count", 0)
            if low_conf_n > 0:
                self.sig_log.emit(
                    f"<span style='color:#E6A23C; font-weight:bold;'>"
                    f"⚠️ 注意：demo_shell.xlsx 中存在 {low_conf_n} 条低置信度匹配记录"
                    f"（置信度 &lt; 0.55），请按上方 WARNING 行核对对应 sheet 与变量。</span>"
                )
            # 重置计数器，防止下次复用残留
            self._demo_shell_low_conf_count = 0
        else:
            self.sig_status.emit("❌ Metadata 提取失败！", "#F56C6C")
            self.sig_step_update.emit("02 Metadata Setup ❌")
            self._show_msg("错误", msg, "error")

    def cancel_meta(self):
        if hasattr(self, 'meta_thread') and self.meta_thread.isRunning():
            self.meta_thread.is_cancelled = True
            self.meta_thread.wait(3000)
        self.meta_cancel_btn.hide()
        self.meta_run_btn.show()
        self.meta_prog.setVisible(False)

        self.sig_status.emit("🛑 已中止", "#F56C6C")
        self.sig_step_update.emit("02 Metadata Setup 🟥")
        self.sig_log.emit("<span style='color:#F56C6C; font-weight:bold;'>[已中止] 🛑 用户手动取消了执行。</span>")
