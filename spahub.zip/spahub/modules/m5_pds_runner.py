# -*- coding: utf-8 -*-
"""
modules/m5_pds_runner.py
========================
M5「01 PDS for Define」独立子进程脚本（v12.10.111 加入）。

设计目的（解决用户反馈：生成 PDS 时整个 UI 卡顿严重）：
  原 PdsForDefineRunner 是 QThread，但 crt_vars 的实际工作（pandas 计算 + pyreadstat
  读 XPT + openpyxl 写 workbook）几乎都是 **纯 Python / 持有 GIL** 的操作，QThread 在
  CPython 下无法真正并行 → 主（UI）线程被 GIL 饿死 → 界面卡死。

  修复：把 crt_vars 整段调用搬到独立 Python 子进程（与 pdt_post_process_runner 同款
  方案）。子进程有自己的 GIL，主进程只在另一个线程里**阻塞读子进程 stdout**（I/O 等待
  会释放 GIL）→ UI 始终流畅。

调用约定：
  父进程：subprocess.Popen([python, "-u", "-m", "modules.m5_pds_runner"], stdin=PIPE, stdout=PIPE)
  父进程把参数 JSON 写入子进程 stdin（一行）：
      {
        "crt_import_dir": "<含 crt_vars 包目录的那一层>",
        "cfg_kwargs":     {ra_root, libname, testyn, overwrite, encoding, lng},
        "path_overrides": {xpt_dir, spec, spec_vars, define_dir, anno_study, tdm},
        "run_kwargs":     {out_path, lng, verbose, write_sdrg}
      }
  子进程 stdout：逐行 JSON：
      {"level": "info"|"ok"|"warn"|"err", "msg": "<text>"}          普通日志（crt_vars 的 print）
      {"level": "progress", "val": <int>, "msg": "<text>"}          进度
      {"level": "result", "ok": <bool>, "out_paths": [...], "msg": ""}  最终结果（仅一条）
  exit code：0 成功 / 1 失败。
"""
import sys
import os
import json

# 装 no-window-popen patch：本子进程内任何后续 subprocess.Popen 默认带 CREATE_NO_WINDOW。
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    from _no_window_popen import install as _install_no_window_popen
    _install_no_window_popen()
except Exception:
    pass

# 真实 stdout（emit 始终往这里写 JSON，即使后面把 sys.stdout 重定向到 _JsonStream）
_REAL_STDOUT = sys.stdout


def emit(level, msg="", **extra):
    """往真实 stdout 写一行 JSON，父进程逐行解析。"""
    obj = {"level": level, "msg": msg}
    if extra:
        obj.update(extra)
    try:
        _REAL_STDOUT.write(json.dumps(obj, ensure_ascii=False) + "\n")
        _REAL_STDOUT.flush()
    except Exception:
        pass


class _JsonStream:
    """把 crt_vars 的 print/stderr 逐行包成 JSON 行（行缓冲）；级别按内容粗分。"""
    def __init__(self):
        self._buf = ""

    def write(self, text):
        if not text:
            return
        self._buf += text
        while "\n" in self._buf:
            line, self._buf = self._buf.split("\n", 1)
            self._emit_line(line)

    def _emit_line(self, line):
        line = line.rstrip("\r")
        if not line.strip():
            return
        up = line.upper()
        if "ERROR" in up or "❌" in line:
            lvl = "err"
        elif "WARNING" in up or "⚠" in line:
            lvl = "warn"
        elif "✅" in line:
            lvl = "ok"
        else:
            lvl = "info"
        emit(lvl, line)

    def flush(self):
        if self._buf.strip():
            self._emit_line(self._buf)
            self._buf = ""

    close = flush


def main():
    raw = sys.stdin.read()
    try:
        params = json.loads(raw)
    except Exception as e:
        emit("result", f"参数解析失败：{e}", ok=False)
        return 1

    crt_dir = (params.get("crt_import_dir") or "").strip()
    if crt_dir and crt_dir not in sys.path:
        sys.path.append(crt_dir)
    cfg_kwargs = params.get("cfg_kwargs") or {}
    path_overrides = params.get("path_overrides") or {}
    run_kwargs = params.get("run_kwargs") or {}

    # 重定向 crt_vars 的 print/stderr → JSON 行
    sys.stdout = _JsonStream()
    sys.stderr = sys.stdout
    try:
        emit("progress", "正在加载外部包 crt_vars (首次加载 pandas/pyreadstat 可能稍长)...", val=5)
        import importlib
        try:
            crt_vars = importlib.import_module("crt_vars")
            crt_run_mod = importlib.import_module("crt_vars.run")
        except Exception as e:
            emit("result",
                 "无法导入外部包 crt_vars。请确认 sys.path 下存在 crt_vars/ 包，"
                 f"且已安装依赖 pandas / pyreadstat / openpyxl。\n[原始异常] {e}",
                 ok=False)
            return 1

        Config = getattr(crt_vars, "Config", None)
        run = getattr(crt_run_mod, "run", None)
        if Config is None or not callable(run):
            emit("result", "crt_vars 包结构异常：未找到 Config 或 run.run。", ok=False)
            return 1

        emit("progress", "正在构造 Config 并应用用户路径 ...", val=15)
        cfg = Config(**cfg_kwargs)

        # 用 UI 输入覆盖 Config 的派生路径属性（io_read.load_inputs 读取这些属性）
        attr_map = {
            "xpt_dir": "xpt_dir",
            "spec": "spec_path",
            "spec_vars": "spec_vars_path",
            "define_dir": "define_dir",
            "anno_study": "anno_study_path",
            "tdm": "tdm_path",
        }
        for ui_key, cfg_attr in attr_map.items():
            val = (path_overrides.get(ui_key) or "").strip()
            if val:
                setattr(cfg, cfg_attr, val)

        emit("progress", "正在生成 PDS 变量级 spec (spec_vars) ...", val=25)
        result = run(cfg, **run_kwargs)

        if isinstance(result, tuple):
            out_paths = [str(p) for p in result if p]
        elif result:
            out_paths = [str(result)]
        else:
            out_paths = []

        emit("progress", "生成成功！", val=100)
        emit("result", "", ok=True, out_paths=out_paths)
        return 0
    except Exception as e:
        emit("result", str(e), ok=False)
        return 1
    finally:
        sys.stdout = _REAL_STDOUT
        sys.stderr = _REAL_STDOUT


if __name__ == "__main__":
    sys.exit(main())
