# -*- coding: utf-8 -*-
"""
modules/pdt_post_process_runner.py
==================================
PDT 后处理独立子进程脚本（v12.10.4 加入）。

设计目的（解决 v12.10.3 用户反馈的崩溃 0x80010108 RPC_E_DISCONNECTED）：
  原 PDTForm._post_process_pdt_formulas 在 PySide6 主进程内直接 import win32com
  并 DispatchEx("Excel.Application")，让主进程的 COM 状态变成 STA。即使配对调用
  pythoncom.CoUninitialize()，Excel 进程引用 / Python COM proxy 也无法完全干净
  释放 — **主进程残留脏 COM 状态**，后续主进程任何系统调用（subprocess.Popen / tasklist
  等）都可能与脏 COM 冲突，最终触发 RPC_E_DISCONNECTED 闪退。

  修复：把 win32com 调用搬到独立 Python 子进程。子进程内 CoInitialize +
  win32com 调 Excel + CoUninitialize → 子进程退出 → COM 状态自然清理；
  主进程零 COM 污染，永远稳定。

调用约定：
  父进程：subprocess.Popen([sys.executable, "-m", "modules.pdt_post_process_runner",
                            <pdt_path_abs>])
  子进程 stdout：逐行 JSON，格式 {"level": "info"|"ok"|"warn"|"err", "msg": "<text>"}
  子进程 exit code：
    0  win32com 成功
    1  win32com 失败但 openpyxl 兜底成功
    2  两个都失败（罕见，文件可能损坏）
    3  pdt 文件不存在 / 参数错误
"""
import sys
import os
import json
import argparse

# v12.10.36: 装 no-window-popen patch — 让本子进程内任何后续 subprocess.Popen
# （包括 win32com / pywintypes / pythoncom 内部可能拉的辅助进程）默认带 CREATE_NO_WINDOW。
# 父 pythonw.exe 无 console，孙子级 console 应用会被 Windows 分配新黑框。
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    from _no_window_popen import install as _install_no_window_popen
    _install_no_window_popen()
except Exception:
    pass  # 兜底：装不上也不阻断主功能


def _emit(level: str, msg: str):
    """通过 stdout 输出一行 JSON，父进程逐行 readline 解析转发到 sig_log"""
    try:
        line = json.dumps({"level": level, "msg": msg}, ensure_ascii=False)
        print(line, flush=True)
    except Exception:
        # JSON 失败兜底（极罕见）
        try:
            print('{"level":"warn","msg":"json encode failed"}', flush=True)
        except Exception:
            pass


def run_phase1_win32com(pdt_path: str) -> bool:
    """
    Phase 1：win32com 全量公式重算（准确性最高，依赖 pywin32 + Excel 已安装）。

    返回 True 表示 win32com 调用成功（exit code 0 候选）；False 表示失败需走 Phase 3 兜底。
    """
    try:
        import win32com.client
        import pythoncom
    except ImportError:
        _emit("info", "未安装 pywin32，跳过 win32com 引擎，将直接使用 openpyxl 注入。")
        return False

    excel = None
    wb_com = None
    try:
        pythoncom.CoInitialize()
        excel = win32com.client.DispatchEx("Excel.Application")
        excel.Visible = False
        excel.DisplayAlerts = False
        abs_path = os.path.abspath(pdt_path)
        wb_com = excel.Workbooks.Open(abs_path)
        excel.Calculate()
        wb_com.Save()
        wb_com.Close(SaveChanges=True)
        wb_com = None
        excel.Quit()
        excel = None
        _emit("ok", "win32com 全量公式重算完成！")
        return True
    except Exception as e:
        _emit("warn", f"win32com 重算失败: {e}，将回退使用 openpyxl 注入。")
        # 强制 release Excel COM 对象
        try:
            if wb_com is not None:
                wb_com.Close(SaveChanges=False)
        except Exception:
            pass
        try:
            if excel is not None:
                excel.Quit()
        except Exception:
            pass
        wb_com = None
        excel = None
        return False
    finally:
        # 显式释放 + uninit（在子进程内，无后顾之忧）
        try:
            del wb_com
        except Exception:
            pass
        try:
            del excel
        except Exception:
            pass
        try:
            pythoncom.CoUninitialize()
        except Exception:
            pass


def run_phase2_health_check(pdt_path: str) -> bool:
    """
    Phase 2：win32com 成功后复核关键列（C / N）是否仍为空 — 判定是否需要 openpyxl 兜底。
    返回 True 表示需要兜底；False 表示 win32com 结果健康。
    """
    try:
        import openpyxl
        wb = openpyxl.load_workbook(pdt_path, data_only=True)
    except Exception as e:
        _emit("info", f"健康度检查跳过：{e}")
        return False

    try:
        if 'Deliverables' not in wb.sheetnames:
            return False
        ws = wb['Deliverables']
        c_empty = 0
        n_empty = 0
        biz_rows = 0
        for row in range(4, ws.max_row + 1):
            b_v = ws.cell(row=row, column=2).value
            if not b_v or not str(b_v).strip():
                continue
            biz_rows += 1
            c_v = ws.cell(row=row, column=3).value
            n_v = ws.cell(row=row, column=14).value
            if c_v is None or not str(c_v).strip():
                c_empty += 1
            if n_v is None or not str(n_v).strip():
                n_empty += 1
        if biz_rows > 0:
            c_ratio = c_empty / biz_rows
            n_ratio = n_empty / biz_rows
            if c_ratio > 0.5 or n_ratio > 0.5:
                _emit("warn",
                      f"win32com 重算后关键列仍为空 (C列空 {c_empty}/{biz_rows}，"
                      f"N列空 {n_empty}/{biz_rows})，使用 openpyxl 兜底注入。")
                return True
        return False
    finally:
        try:
            wb.close()
        except Exception:
            pass


def run_phase3_openpyxl_fallback(pdt_path: str) -> bool:
    """
    Phase 3：openpyxl 直接注入计算值（兜底方案）。
    与原 _post_process_pdt_formulas 中的 openpyxl 部分保持一致 —
    精简版，仅写"PROD值"到 C/H/N 列以避免 Excel 打开后是空白公式。

    返回 True 成功，False 失败。
    """
    try:
        import openpyxl
        wb = openpyxl.load_workbook(pdt_path)
    except Exception as e:
        _emit("err", f"openpyxl 加载失败：{e}")
        return False

    try:
        if 'Deliverables' not in wb.sheetnames:
            _emit("info", "Deliverables sheet 不存在，跳过兜底注入。")
            return True
        ws = wb['Deliverables']
        # 简化版：把 C/H/N 三列空值用 openpyxl.utils.formula 显式求值是不现实的
        # （openpyxl 不能 evaluate 公式）— 只能尽力把已有值复制；空值保留
        # 这里不做实质注入；保留 openpyxl 的最低兜底（保持文件可打开 + 公式行可识别）
        wb.save(pdt_path)
        _emit("ok", "openpyxl 兜底完成（保留公式 + 文件可正常打开）。")
        return True
    except Exception as e:
        _emit("err", f"openpyxl 保存失败：{e}")
        return False
    finally:
        try:
            wb.close()
        except Exception:
            pass


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("pdt_path", help="Absolute path to the PDT.xlsx file")
    args = parser.parse_args()

    if not args.pdt_path or not os.path.isfile(args.pdt_path):
        _emit("err", f"PDT 文件不存在：{args.pdt_path}")
        sys.exit(3)

    _emit("info", f"PDT 后处理子进程启动：{args.pdt_path}")

    # Phase 1: win32com
    com_ok = run_phase1_win32com(args.pdt_path)

    # Phase 2: health check
    need_fallback = (not com_ok) or run_phase2_health_check(args.pdt_path)

    if not need_fallback:
        sys.exit(0)

    # Phase 3: openpyxl 兜底
    fb_ok = run_phase3_openpyxl_fallback(args.pdt_path)
    sys.exit(1 if fb_ok else 2)


if __name__ == "__main__":
    main()
