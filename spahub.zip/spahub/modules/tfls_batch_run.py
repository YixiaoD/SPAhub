# -*- coding: utf-8 -*-
"""
modules/tfls_batch_run.py
=========================
04 Batch Run 模块。

职责：
  - 读 PDT 的 PGMNAMDV / PGMNAMQC 列统计每种 OUTTYPE 的程序数
  - 扫描 92_batch_script_generator_call.sas 中的 %batch_script_generator(...) 宏调用
  - 对每段宏调用：若 role+type 在 PDT 中计数 > 0，才生成对应 92_tmp_gen_*.sas 临时脚本
  - 每个临时脚本通过子进程 + watchdog 执行，生成最终跑批脚本
  - 生成完成后，左下方以可滑动列表展示每个跑批脚本，带单独的"运行"按钮

v12.10.32 变更（与本次需求相关）：
  - 进入 04 页面 / 点"🔄 刷新源文件" 时，直接扫 tools 下名称含 batch_script 的 .sas
    （除 92_batch_script_generator_call.sas / 92_tmp_gen_*.sas）并展示在 UI 列表，
    无需点击"生成"按钮即可看到已有跑批脚本。
    实际命名约定（用户 SHR9999_test/csr_04/utility/tools 验证）：
      xx_batch_script_xxx.sas，如 01_batch_script_sdtm_dev.sas、05_batch_script_tfl_dev.sas。
  - "生成批处理脚本"前先用相同正则探测 92call 中所有 out=... 名字，对比 tools 现存
    同名 .sas，弹覆盖确认（show_choice_dialog: 全部覆盖 / 跳过同名 / 取消）。
    选"跳过同名"会把冲突清单注入 BatchGenRunner.skip_labels，runner 内部跳过这些段。
  - 生成完成后，新生成的脚本以 #409EFF 蓝色 + 🆕 前缀置顶展示（其余按 label 排序在后）；
    UI 列表内容始终与 tools 目录实际文件一致（通过 _scan_tools_batch_scripts 重扫保证）。
  - 抽出 _render_script_row / _render_script_list / _render_footer_check_panel 三个
    渲染辅助方法，消除"扫描入口"与"生成入口"间的重复 UI 构造代码。

v12.10.114 变更：
  - 修复单脚本运行行进度条「运行中静止不滚动」。每行 prog_bar 原用 setRange(0,0)
    原生 indeterminate（无限流）模式，靠平台 style 自带动画驱动滑动 chunk；但该条挂
    在带 #LeftPanel stylesheet 的子树下，整子树走 QStyleSheetStyle，Windows 下原生
    busy 动画不被驱动 → 条静止（SAS 仍在 SingleBatchRunner 线程里跑，故"条不动、后台
    在执行"）。改为 _bind_single_run_events 内给每行 prog_bar 绑一个 MarqueeProgress
    （主线程 QTimer 周期 setValue 跑扫动，每次必重绘，不受 stylesheet 影响），
    setVisible(True)/(False) 统一换成 marquee.start()/stop()。
    与 aCRF v12.10.113 同根因、同方案。BatchRunForm 为 TFLs / SDTM / ADaM 三模式共用，
    一处修复三处生效。

文件结构：
  ├─ SingleBatchRunner (QThread)   单个跑批脚本的独立执行器（强制静默）
  ├─ BatchGenRunner   (QThread)    扫描 92_batch_call + 并发生成多个跑批脚本（支持 skip_labels）
  └─ BatchRunForm     (QFrame)     左侧表单 + 动态列表（扫描入口 + 生成入口共用渲染方法）
"""
import os
import re
import uuid
import time
import html
import pandas as pd
import concurrent.futures
import subprocess
import sys
import pickle

from PySide6.QtWidgets import (QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                               QLineEdit, QFileDialog, QFrame, QProgressBar, QWidget, QScrollArea, QSpacerItem,
                               QSizePolicy, QCheckBox)
from PySide6.QtCore import Qt, QThread, Signal, QTimer

from sas_engine.executor import run_sas, convert_windows_path_to_linux
from ui_utils import primary_btn_style, primary_outline_btn_style, scan_status_lbl_style
from modules.ui_progress import MarqueeProgress  # v12.10.114


# =============================================================================
# 单个跑批脚本执行器
# =============================================================================
class SingleBatchRunner(QThread):
    """
    单任务独立线程执行器。

    设计：
      - 拉起独立 Python 子进程，调用 sas_engine.run_sas
      - 用 pickle 文件作为 IPC，将 (has_issue, summary, log_text) 回传
      - 强制 check_log=False 以绕过 tkinter 弹窗在无 GUI 环境下的异常
    """
    finished_signal = Signal(bool, str, str)  # has_issue, summary, log_text

    def __init__(self, script_path):
        super().__init__()
        self.script_path = script_path
        self.is_cancelled = False
        self.proc = None

    def run(self):
        # v12.10.30：spahub_dir / 内联脚本字符串拼接 已迁移到 app_paths.child_command_run_sas
        res_path = self.script_path + ".res"
        if os.path.exists(res_path):
            try:
                os.remove(res_path)
            except:
                pass

        # 强制 check_log=False, return_details=True 进行纯后台静默跑批
        # frozen 时走 [SASEG.exe, "--child", "run_sas", ...]，开发模式走 [python, "-c", code]
        from app_paths import child_command_run_sas
        cmd = child_command_run_sas(self.script_path, res_path)
        self.proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                     creationflags=0x08000000)  # CREATE_NO_WINDOW — 父 pythonw.exe 无 console，避免 Windows 给子 python.exe 分配新黑框

        while self.proc.poll() is None:
            if self.is_cancelled:
                try:
                    self.proc.kill()
                except:
                    pass
                return
            time.sleep(0.5)

        if self.is_cancelled:
            return

        res_tuple = (False, "✅ 运行成功", "")
        if os.path.exists(res_path):
            try:
                with open(res_path, 'rb') as f:
                    res = pickle.load(f)
                    res_tuple = (res[0], res[1], res[2])
            except:
                pass
            try:
                os.remove(res_path)
            except:
                pass

        self.finished_signal.emit(*res_tuple)


# =============================================================================
# 批量生成跑批脚本的后台线程
# =============================================================================
class BatchGenRunner(QThread):
    """
    基于 PDT 程序数统计，扫描 92_batch_script_generator_call.sas 中的宏调用，
    逐段判断是否需要执行，满足条件者生成临时 .sas 并通过子进程执行。

    回传：
      log_signal       日志行
      progress_signal  (百分比, 文案)
      finished_signal  (success, msg, issues, scripts)
        - scripts 是成功生成的跑批脚本清单，展示到 UI 列表中
    """
    log_signal = Signal(str)
    progress_signal = Signal(int, str)
    finished_signal = Signal(bool, str, list, list)

    def __init__(self, pdt_path, batch_sas_path, concurrent_mode=False, force_type=None, skip_labels=None):
        """
        force_type: 可选 — 锁定 type 过滤到指定值（如 "adam"）。
            None  → TFLs 模块行为：扫描 92 脚本中所有 type 段，按 PDT 统计裁剪。
            "adam" → ADaM 模块行为：仅保留 type=adam 的宏调用，无视 PDT 中其它 OUTTYPE 的统计。
        skip_labels: 可选 — 一组 out_name，用户在覆盖确认弹窗选择"跳过同名"时由 BatchRunForm 传入，
                     运行时直接略过这些宏调用（不写临时脚本、不执行 SAS、不出现在 finished_signal scripts 中）。
                     v12.10.32 新增。
        """
        super().__init__()
        self.pdt_path = pdt_path
        self.batch_sas_path = batch_sas_path
        self.concurrent_mode = concurrent_mode
        self.force_type = (force_type or "").lower().strip() or None
        self.skip_labels = set(skip_labels or [])
        self.is_cancelled = False
        self.active_procs = []
        # v12.10.11：用于 mtime 检查 — 判断脚本是否本次真正重写过（残留旧脚本不算）
        self._gen_start_time = 0.0

    def run(self):
        try:
            self._gen_start_time = time.time()  # v12.10.11：用于 mtime 检查
            self.progress_signal.emit(10, "正在读取 PDT 进行智能非空排查与统计...")

            out_types = ['SDTM', 'ADAM', 'TABLE', 'LISTING', 'FIGURE']
            pdt_counts = {'dev': {t: 0 for t in out_types}, 'qc': {t: 0 for t in out_types}}

            try:
                df_dict = pd.read_excel(self.pdt_path, sheet_name=None)
                target_df = None
                for name, df in df_dict.items():
                    if 'OUTTYPE' in [str(c).upper().strip() for c in df.columns]:
                        target_df = df
                        break

                if target_df is None:
                    raise ValueError("PDT 中未找到包含 'OUTTYPE' 的表单。")

                target_df.columns = [str(c).upper().strip() for c in target_df.columns]

                for ot in out_types:
                    sub_df = target_df[target_df['OUTTYPE'].astype(str).str.upper().str.contains(ot, na=False)]
                    if sub_df.empty: continue

                    if 'PGMNAMDV' in sub_df.columns:
                        dev_vals = sub_df['PGMNAMDV'].fillna('').astype(str).str.strip().replace(
                            ['nan', 'NaN', 'None', 'none'], '')
                        pdt_counts['dev'][ot] = (dev_vals != '').sum()

                    if 'PGMNAMQC' in sub_df.columns:
                        qc_vals = sub_df['PGMNAMQC'].fillna('').astype(str).str.strip().replace(
                            ['nan', 'NaN', 'None', 'none'], '')
                        pdt_counts['qc'][ot] = (qc_vals != '').sum()

            except Exception as e:
                self.log_signal.emit(
                    f"<span style='color:#F56C6C;'>⚠️ PDT 解析失败，将退回全量生成模式: {str(e)}</span>")
                for ot in out_types:
                    pdt_counts['dev'][ot] = 99
                    pdt_counts['qc'][ot] = 99

            stat_msg = "<b>> 📊 PDT 程序非空数量探测结果：</b><br>"
            total_active = 0
            for ot in out_types:
                dev_c = pdt_counts['dev'][ot]
                qc_c = pdt_counts['qc'][ot]
                total_active += (dev_c + qc_c)
                color_dev = "#409EFF" if dev_c > 0 else "#C0C4CC"
                color_qc = "#67C23A" if qc_c > 0 else "#C0C4CC"
                stat_msg += f"&nbsp;&nbsp;• <b>{ot}</b>: DEV <span style='color:{color_dev};'>({dev_c} 个)</span> | QC <span style='color:{color_qc};'>({qc_c} 个)</span><br>"

            self.log_signal.emit(f"<span style='color:#606266;'>{stat_msg}</span>")

            if total_active == 0:
                self.progress_signal.emit(100, "校验完成")
                self.finished_signal.emit(True, "PDT 中未检测到任何非空程序，已跳过脚本生成。", [], [])
                return

            self.progress_signal.emit(30, "正在解析 92_batch_call 脚本...")

            # v12.10.24：force_type 模式打印锁定信息（与 InitPgm v12.10.11 同款风格）
            #   ADaM 模块用 force_type='adam'，仅保留 type=%str(adam) 独占段，
            #   跳过 type=%str(adam|sdtm|table|figure|listing) 这种"通用 batch_script_generator"段
            #   （这就是之前生成 07_batch_script_dev 等多余脚本的来源）。
            # v12.10.27：保留"（仅限本模块）"4 字简短说明（用户原话），其余括号内容删除。
            if self.force_type:
                self.log_signal.emit(
                    f"<span style='color:#909399;'>&nbsp;&nbsp;锁定 type 限制：TYPE=%str({self.force_type})（仅限本模块）</span>"
                )

            if not os.path.exists(self.batch_sas_path):
                raise FileNotFoundError(f"找不到模板文件: {self.batch_sas_path}")

            with open(self.batch_sas_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()

            base_dir = os.path.dirname(self.batch_sas_path)
            from app_paths import app_root as _ar; spahub_dir = _ar()
            uid = uuid.uuid4().hex[:6]
            generated_run_scripts = []
            files_to_cleanup = []
            tasks_to_run = []

            matches = re.finditer(r'(%batch_script_generator\s*\([\s\S]*?out\s*=\s*[a-zA-Z0-9_]+[^\)]*\))', content,
                                  re.IGNORECASE)

            macro_count = 0
            for match in matches:
                macro_count += 1
                full_macro_str = match.group(1)

                m_role = re.search(r'role\s*=\s*([a-zA-Z_]+)', full_macro_str, re.IGNORECASE)
                m_out = re.search(r'out\s*=\s*([a-zA-Z0-9_]+)', full_macro_str, re.IGNORECASE)
                m_type = re.search(r'type\s*=\s*(?:%str\()?([^,)]+)', full_macro_str, re.IGNORECASE)

                if m_role and m_type and m_out:
                    m_role_val = m_role.group(1).lower()
                    m_out_val = m_out.group(1).strip()
                    m_types_val = [t.strip().upper() for t in
                                   m_type.group(1).replace('%str(', '').replace(')', '').split('|')]

                    # v12.10.11：force_type 模式 — 只保留 type 集合中含目标值的宏调用
                    # （ADaM 模块用 force_type="adam"，跳过 sdtm/table/figure/listing 段）
                    # v12.10.24：升级为"独占"判定 — type 集合必须仅含 force_type，否则跳过。
                    #   旧逻辑 (ft in m_types_val) 误放过 type=%str(adam|sdtm|table|figure|listing)
                    #   这种"通用 batch_script_generator"段（如 07_batch_script_dev），导致
                    #   ADaM 模块跑出非 adam 专用的脚本。新逻辑要求 type 独占 ADAM。
                    # v12.10.27：去掉每个被跳过 macro 的逐行灰色日志（用户简洁要求）。
                    #   仅保留启动时的"锁定 type 限制：TYPE=%str(adam)（仅限本模块）"一行。
                    if self.force_type:
                        ft = self.force_type.upper()
                        types_set = {t for t in m_types_val if t}  # 去空+去重
                        if types_set != {ft}:
                            continue

                    should_run = False
                    if m_role_val in pdt_counts:
                        for t in m_types_val:
                            # force_type 模式只看锁定的那个 type 是否非空
                            if self.force_type and t.lower() != self.force_type:
                                continue
                            if pdt_counts[m_role_val].get(t, 0) > 0:
                                should_run = True
                                break

                    if should_run:
                        # v12.10.32：用户选"跳过同名"时，命中 skip 清单的 out_name 直接跳过
                        if m_out_val in self.skip_labels:
                            self.log_signal.emit(
                                f"<span style='color:#909399;'>&nbsp;&nbsp;跳过同名脚本：{m_out_val}.sas（用户在覆盖确认中选择保留原文件）</span>"
                            )
                            continue

                        tmp_path = os.path.join(base_dir, f"92_tmp_gen_{m_out_val}_{uid}.sas")
                        done_path = tmp_path + ".done"
                        res_path = tmp_path + ".res"
                        done_linux = convert_windows_path_to_linux(done_path)

                        sas_code = f"""
data _null_;
  if libref('adam') then call execute('%nrstr(%autorun)');
run;

{full_macro_str};

data _null_;
  file '{done_linux}'; put 'DONE';
run;
"""
                        with open(tmp_path, 'w', encoding='utf-8') as f:
                            f.write(sas_code)

                        tasks_to_run.append((m_out_val, tmp_path, done_path, res_path))
                        files_to_cleanup.extend([tmp_path, tmp_path.replace('.sas', '.log'), done_path, res_path])

            self.log_signal.emit(
                f"<span style='color:#909399;'>> 探针反馈：92 号脚本中共扫描到 {macro_count} 段宏代码，最终匹配生成 {len(tasks_to_run)} 个跑批脚本。</span>")

            if not tasks_to_run:
                self.finished_signal.emit(True, "未生成任何脚本（因 PDT 对应统计数全为 0）。", [], [])
                return

            completed = 0
            max_workers = 3 if self.concurrent_mode else 1
            issue_logs = []

            def exec_sas_generator(args):
                t_out_val, t_path, t_done, t_res = args[:4]
                if self.is_cancelled: return t_out_val, (True, "已取消", "", t_path)

                # v12.10.30：用工厂构造命令（兼容打包/开发模式）
                from app_paths import child_command_run_sas
                cmd = child_command_run_sas(t_path, t_res)
                proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL,
                                        stderr=subprocess.DEVNULL,
                                        creationflags=0x08000000)
                self.active_procs.append(proc)

                while proc.poll() is None:
                    if self.is_cancelled:
                        try:
                            proc.kill()
                        except:
                            pass
                        return t_out_val, (True, "已强制中止", "", t_path)
                    if os.path.exists(t_done):
                        time.sleep(1)
                        if proc.poll() is None:
                            try:
                                proc.kill()
                            except:
                                pass
                        break
                    time.sleep(0.5)

                res_tuple = (False, "✅ 生成成功", "", t_path)
                if os.path.exists(t_res):
                    try:
                        with open(t_res, 'rb') as f:
                            res_tuple = pickle.load(f)
                    except Exception:
                        pass

                return t_out_val, res_tuple

            with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = {executor.submit(exec_sas_generator, t): t for t in tasks_to_run}
                for future in concurrent.futures.as_completed(futures):
                    if self.is_cancelled: continue
                    out_name, res = future.result()
                    has_issue, summary, log_text, _ = res
                    completed += 1
                    self.progress_signal.emit(30 + int(60 * (completed / len(tasks_to_run))),
                                              f"已完成 {completed}/{len(tasks_to_run)} 编译任务...")

                    expected_script_path = os.path.join(base_dir, f"{out_name}.sas")

                    # v12.10.11：仅当 SAS 真正在本次任务内写入 / 重写过该脚本才注册 UI
                    # （单纯 os.path.exists 会被上次成功生成的残留脚本欺骗 — 这次因 PDT
                    # ERROR 没产生新脚本，但 .sas 文件还在 → 误以为本次成功 → UI 仍渲染）
                    fresh_script = False
                    if os.path.exists(expected_script_path):
                        try:
                            mt = os.path.getmtime(expected_script_path)
                            # 允许 2s 时钟偏差：mtime 必须 ≥ 本次起始时刻 - 2s
                            if mt >= (self._gen_start_time - 2.0):
                                fresh_script = True
                        except Exception:
                            pass

                    if fresh_script:
                        generated_run_scripts.append({
                            'label': out_name,
                            'path': expected_script_path
                        })
                        if has_issue:
                            issue_logs.append((out_name, summary, log_text, ""))
                            self.log_signal.emit(f"<span style='color:#E6A23C;'>⚠️ [{out_name}] 已生成，但日志存在警告: {summary}</span>")
                        else:
                            self.log_signal.emit(f"<span style='color:#67C23A;'>✅ {out_name} 脚本构建完毕。</span>")
                    else:
                        # 脚本未在本次任务内重写：记录告警，不注册到 UI
                        # 含两种场景：(1) 文件根本不存在 (2) 文件存在但是上次的残留
                        issue_logs.append((out_name, summary, log_text, ""))
                        if os.path.exists(expected_script_path):
                            stale_msg = "（检测到旧脚本残留，但本次未重写 — 可能 PDT 校验失败导致脚本未刷新）"
                        else:
                            stale_msg = "（PDT 数据校验失败或 SAS 执行异常）"
                        self.log_signal.emit(
                            f"<span style='color:#F56C6C;'>❌ [{out_name}] 脚本未生成{stale_msg}，"
                            f"请查看下方日志明细后修复 PDT 再重新生成。</span>"
                        )

            for f in files_to_cleanup:
                try:
                    if os.path.exists(f): os.remove(f)
                except Exception:
                    pass

            if self.is_cancelled: return

            self.progress_signal.emit(100, "准备就绪")
            if issue_logs:
                self.finished_signal.emit(False, "部分生成存在异常。", issue_logs, generated_run_scripts)
            else:
                self.finished_signal.emit(True, "✅ 批处理脚本依据 PDT 统计结果严格生成完毕！", [], generated_run_scripts)

        except Exception as e:
            if not self.is_cancelled:
                self.progress_signal.emit(100, "发生严重错误")
                self.finished_signal.emit(False, f"❌ 错误: {str(e)}", [], [])


# =============================================================================
# v11.3：log_chk / compare_chk 校验执行器（仿 03 init_pgm 临时脚本生命周期）
# =============================================================================
class LogCompareCheckRunner(QThread):
    """
    生成临时 .sas 脚本 → 提交执行 → 无论成败一律 cleanup（log/done/res 一并删）。

    与 SingleBatchRunner 一致的执行模式（独立 Python 子进程 + run_sas + watchdog），
    与方案"直接 submit 代码字符串"的关键差异：
      - SASEG 项目里 run_sas 会自动 %include autorun.sas 等前置宏，对 %log_chk /
        %compare_chk 这两个宏来说必须有 autorun 才能解析；in-memory submit 走的是
        裸 SASsession.submit()，不带 SASEG 的前置 include 链，所以**必须落盘走
        run_sas 路径**。
      - 临时 .sas 放在 utility/tools 下（与 92_run_*.sas 同目录），便于 run_sas
        在 base_path 推导日志输出位置；执行后立即 cleanup，不留痕。

    输出协议：
      finished_signal(kind, ok, summary, log_text, source_label)
        kind         "Log Check" / "Compare Check"
        ok           run_sas 返回的 has_issue 取反（True=无 ERROR/WARNING）
        summary      run_sas 给的简短文案
        log_text     real_log_content（用户后续查"详情"用）
        source_label SAS 服务器上 .log 的 Windows 路径
    """
    finished_signal = Signal(str, bool, str, str, str)
    log_signal = Signal(str)

    def __init__(self, sas_code: str, kind: str, scratch_dir: str):
        super().__init__()
        self.sas_code = sas_code
        self.kind = kind  # "Log Check" / "Compare Check"
        self.scratch_dir = scratch_dir
        self.proc = None
        self.is_cancelled = False

    def run(self):
        from app_paths import app_root as _ar, logs_dir as _ld
        spahub_dir = _ar()
        # 临时脚本命名：93/94_check_<uuid>.sas，避免与已生成的 92_run_*.sas 撞名
        prefix = "93_logchk" if self.kind == "Log Check" else "94_cmpchk"
        stem = f"{prefix}_{uuid.uuid4().hex[:8]}"
        sas_path = os.path.join(self.scratch_dir, stem + ".sas")
        log_path = os.path.join(self.scratch_dir, stem + ".log")
        res_path = sas_path + ".res"
        # v11.5：子进程 stderr 落到独立文件，避免 saspy 内 C 扩展崩溃时无任何痕迹
        stderr_path = sas_path + ".stderr"
        cleanup_paths = [sas_path, log_path, res_path, stderr_path]

        # v11.8：诊断埋点 — 主进程层闪退路径未知，在 worker 线程的关键节点也写 breadcrumb
        # v12.10.47：breadcrumb 也走本地 logs（Z 盘对测试用户只读）
        from datetime import datetime as _dt
        breadcrumb_path = os.path.join(_ld(), "crash.log")
        def _bc(stage):
            try:
                os.makedirs(os.path.dirname(breadcrumb_path), exist_ok=True)
                with open(breadcrumb_path, "a", encoding="utf-8") as f:
                    f.write(f"[{_dt.now().isoformat(timespec='milliseconds')}] LogCompareCheckRunner[{self.kind}] stage={stage}\n")
                    f.flush()
                    try:
                        os.fsync(f.fileno())
                    except OSError:
                        pass
            except Exception:
                pass

        _bc("worker_entry")

        def _persist_crash(rc, stderr_text, extra=""):
            """v11.5：子进程异常退出时，把堆栈+stderr 同步写到 logs/crash.log，
            避免出现"无痕闪退"——下次至少能事后取证。"""
            try:
                os.makedirs(os.path.dirname(breadcrumb_path), exist_ok=True)
                from datetime import datetime as _dt
                with open(breadcrumb_path, "a", encoding="utf-8") as cf:
                    cf.write(f"\n[{_dt.now().isoformat(timespec='seconds')}] {self.kind} 子进程异常\n")
                    cf.write(f"  returncode = {rc}\n")
                    if extra:
                        cf.write(f"  context    = {extra}\n")
                    if stderr_text:
                        cf.write("  --- subprocess stderr ---\n")
                        cf.write(stderr_text.rstrip() + "\n")
                    cf.write("  ---\n")
            except Exception:
                pass  # crash log 自身写失败不应再抛

        try:
            with open(sas_path, "w", encoding="utf-8") as f:
                f.write(self.sas_code)
            self.log_signal.emit(
                f"<span style='color:#909399;'>&nbsp;&nbsp;已落临时脚本：{html.escape(os.path.basename(sas_path))}（运行后将自动清理）</span>"
            )

            # v12.10.30：用 app_paths.child_command_run_sas 工厂构造命令
            # 兼容打包(SASEG.exe --child)与开发(python -c)两种模式
            from app_paths import child_command_run_sas
            cmd = child_command_run_sas(sas_path, res_path)
            stderr_f = open(stderr_path, "w", encoding="utf-8")
            try:
                self.proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=stderr_f,
                                             creationflags=0x08000000)
                while self.proc.poll() is None:
                    if self.is_cancelled:
                        try: self.proc.kill()
                        except Exception: pass
                        self.finished_signal.emit(self.kind, False, "已取消", "", "")
                        return
                    time.sleep(0.2)
            finally:
                try: stderr_f.close()
                except Exception: pass

            rc = self.proc.returncode
            stderr_text = ""
            try:
                if os.path.exists(stderr_path):
                    with open(stderr_path, "r", encoding="utf-8", errors="replace") as f:
                        stderr_text = f.read()
            except Exception:
                pass

            _bc("subprocess_done")
            # rc 非零 / .res 缺失 → 视为异常退出，写 crash.log + 给 UI 兜底反馈
            if not os.path.exists(res_path) or rc != 0:
                _persist_crash(rc, stderr_text, extra=f"sas_path={sas_path}")
                friendly = (
                    f"子进程异常退出（rc={rc}）。"
                    + (
                        " 可能是 SAS 服务断联或 saspy 底层 C 扩展崩溃；"
                        "完整 stderr 已写入 logs/crash.log。"
                        if rc != 0 else
                        " 子进程未产出结果（可能 SAS 服务断联）。"
                    )
                )
                self.finished_signal.emit(self.kind, False, friendly, stderr_text, "")
                return

            _bc("about_to_pickle_load")
            with open(res_path, "rb") as f:
                has_issue, summary, log_text, source_label = pickle.load(f)
            _bc(f"pickle_loaded has_issue={has_issue} log_text_len={len(log_text or '')}")

            # v11.8：truncate 超大 log_text，防止 776K 文本跨线程 emit 时 Qt 内部 GBK→UTF-8
            # 转码或字符串深拷贝触发 C 层异常。Detail 留在 .res 持久化（如需调试），
            # GUI 端只需要片段就够 _format_error_summary 抽 ERROR 行用。
            MAX_LOG_FOR_GUI = 200_000  # 200 KB 已足够覆盖任意 SAS 日志的全部 ERROR/WARNING
            if log_text and len(log_text) > MAX_LOG_FOR_GUI:
                _bc(f"truncating log_text {len(log_text)} -> {MAX_LOG_FOR_GUI}")
                # 抽取所有含 ERROR/WARNING 的行 + 前后各 1 行上下文，避免丢关键信息
                lines = log_text.splitlines()
                keep = set()
                for i, ln in enumerate(lines):
                    if re.search(r'^\s*(ERROR|WARNING)\s*:', ln, re.I):
                        keep.update(range(max(0, i-1), min(len(lines), i+2)))
                if keep:
                    log_text = "\n".join(lines[i] for i in sorted(keep))[:MAX_LOG_FOR_GUI]
                else:
                    # 没有 ERROR/WARNING：只取头尾各 100K
                    log_text = log_text[:100_000] + "\n... (中段已省略) ...\n" + log_text[-100_000:]
                _bc(f"truncated to {len(log_text)}")

            _bc("about_to_emit")
            self.finished_signal.emit(self.kind, not has_issue, summary or "", log_text or "", source_label or "")
            _bc("emit_returned")

        except Exception as e:
            import traceback as _tb
            tb_text = _tb.format_exc()
            _persist_crash(-1, tb_text, extra="LogCompareCheckRunner.run() 顶层异常")
            self.finished_signal.emit(self.kind, False, f"[Python 调用层异常] {e}（详情已写 logs/crash.log）", tb_text, "")
        finally:
            _bc("cleanup_start")
            for p in cleanup_paths:
                for _ in range(3):
                    try:
                        if os.path.exists(p):
                            os.remove(p)
                        break
                    except Exception:
                        time.sleep(0.3)
            _bc("cleanup_done")


# =============================================================================
# 左侧表单组件 BatchRunForm
# =============================================================================
class BatchRunForm(QFrame):
    """
    Batch Run 的左侧业务表单。

    UI 分两层：
      - 上层：刷新栏 + 说明 + 92_batch_call 输入行 + 进度条 + "⚙️ 生成批处理脚本"按钮
      - 下层（滚动区）：生成完成后，用动态列表展示每个 92_run_*.sas 脚本的
                        名称 / 状态 / 单独运行按钮
    """
    sig_log = Signal(str)
    sig_status = Signal(str, str)
    sig_step_update = Signal(str)
    sig_run_started = Signal()
    # v12.2：单纯"运行结束"信号 — 仅用于让外层 stepper 停掉耗时计数器，
    # 不修改 step 按钮文字（与 sig_step_update 区分开）。Log/Compare Check 完成后
    # 应只发这个，避免把 04 Batch Run 整体标记成"已完成"。
    sig_run_finished = Signal()
    # v12.3：日志面板"清空 + 重头记录"专用信号。
    sig_clear_log = Signal()
    # v12.10.11：Log/Compare Check 完成后通知 stepper 显示「📂 07_logs」+「📂 utility/documentation」
    # 两个文件夹打开按钮 — 因为这两个 check 会产生多个 .log/.xml 比较文件，不直接打开单个文件，
    # 而是把目录打开让用户自己浏览（与"详见日志文件"风格不同）。
    sig_show_check_paths = Signal(str, str)  # logs_dir, doc_dir（绝对路径，stepper 端绑定按钮 click）

    # ------------------------- 初始化 / UI -------------------------
    def __init__(self, force_type=None):
        """
        force_type: 可选 — 锁定 batch script generator 的 type 到指定值（如 "adam"）。
            None  → TFLs 模块行为：从 92_batch_call.sas 读所有 type 段（sdtm|adam|table|figure|listing），
                    走 PDT 统计裁剪。
            "adam" → ADaM 模块行为：仅保留 type=adam 的宏调用（无视 PDT 中其它 OUTTYPE）；
                     dev/qc 两条程序仍按 PDT 的 PGMNAMDV/PGMNAMQC 是否非空决定。
        """
        super().__init__()
        self.base_path = ""
        self.pdt_path = ""
        self.force_type = (force_type or "").lower().strip() or None
        self.single_runners = {}
        # v11.2：批量勾选清单与 log/compare 校验线程引用（默认空）
        self._chk_rows = []
        self._chk_thread = None
        # 跑批前置备份的线程引用 + 用户主动中止标志
        self._pre_thread = None
        self._pre_call_user_cancelled = False

        self._setup_ui()

    def _setup_ui(self):
        self.setObjectName("LeftPanel")
        self.setStyleSheet("#LeftPanel { background-color: #FFFFFF; border: 1px solid #E4E7ED; border-radius: 6px; }")

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)

        top_widget = QWidget()
        top_layout = QVBoxLayout(top_widget)
        top_layout.setContentsMargins(25, 25, 25, 15)
        top_layout.setSpacing(15)

        self._step_name = "Batch Run"
        top_bar_refresh = QHBoxLayout()
        self.refresh_btn = QPushButton("🔄 刷新源文件")
        # v12.10.65：统一改用 home"📁 系统文件复制"同款蓝色外框样式
        self.refresh_btn.setStyleSheet(primary_outline_btn_style())
        self.refresh_btn.setCursor(Qt.PointingHandCursor)
        top_bar_refresh.addWidget(self.refresh_btn)
        self.scan_lbl = QLabel("")
        self.scan_lbl.setStyleSheet(scan_status_lbl_style())
        top_bar_refresh.addWidget(self.scan_lbl)
        top_bar_refresh.addStretch()
        top_layout.addLayout(top_bar_refresh)

        # 任务4：跑批前置准备 —— 路径只读显示 + 执行按钮（后台运行，不弹 cmd）
        # 调用 <项目>/utility/tools/00_batch_pre_call.py 完成备份。
        # 设计变更（v10）：
        #   - 移除"备份模式"下拉，UI 只保留脚本路径只读显示，避免与下方弹窗交互重复
        #   - 点击"▶ 执行备份"后通过依次弹窗（show_choice_dialog / show_text_input_dialog）
        #     收集脚本里 input() 顺序的所有答案：备份模式 → 是否压缩 → (删除/名称)
        #   - 任意弹窗取消 → 中止整次流程，UI 不下发执行
        #   - 所有答案集齐后通过 stdin 一次性喂给后台子进程，stdout 实时进右侧日志
        prep_row = QHBoxLayout()
        prep_lbl = QLabel("跑批前置：")
        prep_lbl.setStyleSheet("border: none; color: #606266; min-width: 100px;")
        prep_row.addWidget(prep_lbl)

        self.pre_path_entry = QLineEdit()
        self.pre_path_entry.setReadOnly(True)
        self.pre_path_entry.setStyleSheet(
            "padding: 6px; border: 1px solid #DCDFE6; border-radius: 4px; background: #F5F7FA; color: #606266;"
        )
        self.pre_path_entry.setToolTip("跑批前置脚本路径（只读，由 4 级路径自动派生）")
        prep_row.addWidget(self.pre_path_entry, 1)

        self.btn_pre_call = QPushButton("▶ 执行备份")
        self.btn_pre_call.setStyleSheet("""
            QPushButton { background-color: #FDF6EC; color: #E6A23C; border: 1px solid #F5DAB1; padding: 6px 14px; border-radius: 4px; font-weight: bold; }
            QPushButton:hover { background-color: #E6A23C; color: white; border-color: #E6A23C; }
            QPushButton:pressed { background-color: #CFA85D; color: white; border-color: #CFA85D; }
            QPushButton:disabled { background-color: #F5F7FA; color: #C0C4CC; border-color: #E4E7ED; }
        """)
        self.btn_pre_call.setCursor(Qt.PointingHandCursor)
        self.btn_pre_call.setToolTip("点击后弹窗依次询问：备份模式 → 是否压缩 →（删除原文件 / 备份名称），全部确认后台执行")
        self.btn_pre_call.clicked.connect(self.run_batch_pre_call)
        prep_row.addWidget(self.btn_pre_call)

        # 跑批前置 — 中止按钮（默认隐藏，备份开始后切换显示，备份结束/取消后切回）
        self.btn_pre_cancel = QPushButton("🟥 中止备份")
        self.btn_pre_cancel.setStyleSheet("""
            QPushButton { background-color: #FEF0F0; color: #F56C6C; border: 1px solid #FBC4C4; padding: 6px 14px; border-radius: 4px; font-weight: bold; }
            QPushButton:hover { background-color: #F56C6C; color: white; border-color: #F56C6C; }
            QPushButton:pressed { background-color: #C46A66; color: white; border-color: #C46A66; }
            QPushButton:disabled { background-color: #F5F7FA; color: #C0C4CC; border-color: #E4E7ED; }
        """)
        self.btn_pre_cancel.setCursor(Qt.PointingHandCursor)
        self.btn_pre_cancel.setToolTip("中止当前正在运行的跑批前置备份")
        self.btn_pre_cancel.setVisible(False)
        self.btn_pre_cancel.clicked.connect(self._on_pre_call_cancel)
        prep_row.addWidget(self.btn_pre_cancel)

        top_layout.addLayout(prep_row)

        lbl = QLabel("依据 PDT 各类型程序实际非空数量，自动生成所需的批处理脚本。")
        lbl.setStyleSheet("color: #303133; font-weight: bold; font-size: 14px; border: none;")
        lbl.setWordWrap(True)
        top_layout.addWidget(lbl)

        self.batch_prog = QProgressBar()
        self.batch_prog.setVisible(False)
        self.batch_prog.setFixedHeight(4)
        self.batch_prog.setTextVisible(False)  # v12.10.13：4px 太矮装不下文字，关闭百分比显示避免和上方 label 重叠
        top_layout.addWidget(self.batch_prog)

        # 任务1：PDT XLSX 输入行（默认值由 update_paths 自动填入，可手动覆盖）
        pdt_row = QHBoxLayout()
        lbl_pdt = QLabel("PDT XLSX:")
        lbl_pdt.setStyleSheet("border: none; color: #606266; min-width: 100px;")
        pdt_row.addWidget(lbl_pdt)
        self.pdt_entry = QLineEdit()
        self.pdt_entry.setStyleSheet("padding: 6px; border: 1px solid #DCDFE6; border-radius: 4px;")
        pdt_row.addWidget(self.pdt_entry)
        top_layout.addLayout(pdt_row)

        row_lay = QHBoxLayout()
        lbl_f = QLabel("92_batch_call:")
        lbl_f.setStyleSheet("border: none; color: #606266; min-width: 100px;")
        row_lay.addWidget(lbl_f)
        self.sas_92_entry = QLineEdit()
        self.sas_92_entry.setStyleSheet("padding: 6px; border: 1px solid #DCDFE6; border-radius: 4px;")
        row_lay.addWidget(self.sas_92_entry)
        top_layout.addLayout(row_lay)

        btn_lay = QHBoxLayout()
        self.btn_gen_batch = QPushButton("⚙️ 生成批处理脚本")
        self.btn_gen_batch.setStyleSheet(primary_btn_style())
        self.btn_gen_batch.setCursor(Qt.PointingHandCursor)
        self.btn_gen_batch.clicked.connect(self.generate_batch_scripts)
        btn_lay.addWidget(self.btn_gen_batch)

        self.btn_cancel_gen = QPushButton("🟥 中止生成")
        self.btn_cancel_gen.setStyleSheet(
            "QPushButton { background-color: #FEF0F0; color: #F56C6C; "
            "border: 1px solid #FBC4C4; padding: 8px 20px; border-radius: 4px; font-weight: bold; }"
            "QPushButton:hover { background-color: #FDE2E2; border-color: #F56C6C; }"
            "QPushButton:pressed { background-color: #FBD0D0; }"
        )
        self.btn_cancel_gen.setCursor(Qt.PointingHandCursor)
        self.btn_cancel_gen.setVisible(False)
        self.btn_cancel_gen.clicked.connect(self.cancel_generation)
        btn_lay.addWidget(self.btn_cancel_gen)
        btn_lay.addStretch()
        top_layout.addLayout(btn_lay)

        main_layout.addWidget(top_widget)

        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        # v12.10.32：滚动条样式与项目其他 ScrollArea 保持一致（main_window / shortcuts / toc_gen 同款）
        self.scroll_area.setStyleSheet(
            "QScrollArea { border: none; border-top: 1px solid #EBEEF5; }"
            "QScrollBar:vertical { border: none; background: #F5F7FA; width: 10px; border-radius: 5px; }"
            "QScrollBar::handle:vertical { background: #DCDFE6; border-radius: 5px; }"
            "QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }"
        )

        self.matrix_widget = QWidget()
        self.matrix_layout = QVBoxLayout(self.matrix_widget)
        self.matrix_layout.setAlignment(Qt.AlignTop)
        self.matrix_layout.setContentsMargins(25, 15, 25, 25)
        self.matrix_layout.setSpacing(10)

        self.scroll_area.setWidget(self.matrix_widget)
        main_layout.addWidget(self.scroll_area)

    # ------------------------- 路径 / 等待提示 -------------------------
    def update_paths(self, base_path):
        """由主控推送路径；自动定位 PDT 和 92_batch_call，文件不存在时置空"""
        self.base_path = base_path
        doc_dir = os.path.join(base_path, "utility", "documentation")
        pdt_files = [f for f in os.listdir(doc_dir) if
                     f.endswith('PDT.xlsx') and not f.startswith('~')] if os.path.isdir(doc_dir) else []
        self.pdt_path = os.path.join(doc_dir, pdt_files[0]) if pdt_files else ""

        # 任务1：把自动探测到的 PDT 默认值填到输入框，方便用户确认 / 覆盖
        self.pdt_entry.setText(self.pdt_path if os.path.isfile(self.pdt_path) else "")

        sas_92 = os.path.join(base_path, "utility", "tools", "92_batch_script_generator_call.sas")
        self.sas_92_entry.setText(sas_92 if os.path.isfile(sas_92) else "")

        # 任务4（v10）：跑批前置脚本路径只读展示。文件不存在时显示空，不阻断界面。
        pre_path = os.path.join(base_path, "utility", "tools", "00_batch_pre_call.py")
        self.pre_path_entry.setText(pre_path if os.path.isfile(pre_path) else "")

        # v12.10.32：进入页面 / 刷新源文件 时，直接扫 tools 下名称含 batch_script 的脚本
        # 并展示在下方列表，无需点击"生成"按钮即可看到已存在的跑批脚本。
        # 排除 92_batch_script_generator_call.sas（它是生成器调用脚本本身）。
        existing = self._scan_tools_batch_scripts()
        self._render_script_list(existing, new_labels=set())

    def _clear_matrix(self):
        """清空下方滚动区的脚本列表"""
        while self.matrix_layout.count():
            item = self.matrix_layout.takeAt(0)
            if item.widget(): item.widget().deleteLater()
        # v11.2：复位批量勾选清单（避免跨次生成残留旧引用）
        self._chk_rows = []

    # ------------------------- v12.10.32：tools 下既有 batch_script 脚本扫描 + 渲染 -------------------------
    def _scan_tools_batch_scripts(self):
        """
        扫描 <base_path>/utility/tools/ 下名称含 'batch_script'（不区分大小写）的 .sas 文件。
        - 排除 92_batch_script_generator_call.sas（它是生成器调用脚本本身，不是被跑批的脚本）
        - 排除 92_tmp_gen_*.sas（生成过程中的临时脚本，跑批前后会被清掉）
        - 仅匹配 .sas 后缀（避免误抓同名 .log / .txt / .bak）

        v12.10.32 命名约定（与用户 SHR9999_test/csr_04/utility/tools 实际文件对齐）：
          xx_batch_script_xxx.sas，如 01_batch_script_sdtm_dev.sas、05_batch_script_tfl_dev.sas、
          07_batch_script_dev.sas。这些是 92call 中 %batch_script_generator(..., out=XXX) 的
          产物（out_name 即文件 stem）。

        返回：list of {'label': <无后缀文件名>, 'path': <绝对路径>}，按 label 排序。
        """
        result = []
        if not self.base_path:
            return result
        tools_dir = os.path.join(self.base_path, "utility", "tools")
        if not os.path.isdir(tools_dir):
            return result
        try:
            for fn in os.listdir(tools_dir):
                if not fn.lower().endswith(".sas"):
                    continue
                if "batch_script" not in fn.lower():
                    continue
                # 排除 92 号生成器调用脚本本身
                if fn == "92_batch_script_generator_call.sas":
                    continue
                # 排除生成过程的临时脚本
                if fn.startswith("92_tmp_gen_"):
                    continue
                full = os.path.join(tools_dir, fn)
                if not os.path.isfile(full):
                    continue
                result.append({'label': os.path.splitext(fn)[0], 'path': full})
        except Exception:
            pass
        result.sort(key=lambda x: x['label'])
        return result

    def _render_script_list(self, scripts, new_labels=None):
        """
        v12.10.32：把 scripts 渲染成下方列表，并附 footer 批量校验区。
        - scripts:    list of {'label', 'path'}
        - new_labels: set[str]，凡 label 在该集合中的，置于顶部 + 蓝色字体 + 🆕 前缀
                      未在集合中的，按 label 字母序排在新条目下方
        """
        new_labels = set(new_labels or [])
        self._clear_matrix()

        if not scripts:
            return  # 无脚本时不渲染 header / footer，保持页面干净

        # 排序：新生成的在前（按 label 排），其余在后（按 label 排）
        new_scripts = sorted([s for s in scripts if s['label'] in new_labels], key=lambda x: x['label'])
        old_scripts = sorted([s for s in scripts if s['label'] not in new_labels], key=lambda x: x['label'])

        header_lbl = QLabel("📂 跑批脚本列表：")
        header_lbl.setStyleSheet("color: #606266; font-weight: bold; border: none;")
        self.matrix_layout.addWidget(header_lbl)

        self._chk_rows = []
        # v12.10.65：颜色按列表渲染顺序奇偶交叉 — 全局 idx（new + old 拼接后从 0 数起）
        # 偶数索引 → 蓝（先蓝），奇数索引 → 绿（后绿），与 home 视觉规则统一。
        idx = 0
        for s in new_scripts:
            self._render_script_row(s, is_new=True, row_index=idx)
            idx += 1
        for s in old_scripts:
            self._render_script_row(s, is_new=False, row_index=idx)
            idx += 1

        # footer 批量校验区（与原 _on_gen_finished 末尾的 footer 完全一致）
        self._render_footer_check_panel()

    def _render_script_row(self, script, is_new=False, row_index=0):
        """
        渲染一条脚本运行行。从 _on_gen_finished 抽取，新增 is_new 参数：
        - is_new=True：name_lbl 用 #409EFF 蓝色 + 🆕 前缀，提示用户是本次新生成的
        - is_new=False：保留原黑色 #303133

        v12.10.65：新增 row_index 参数 — "▶ 运行脚本"按钮颜色按全局渲染顺序奇偶交叉
        （偶数行蓝、奇数行绿），与 home 视觉规则"先蓝后绿"一致。原来按 label 是否含
        "dev" 判定 → 同一段连续多个 dev/qc 会连续蓝或连续绿，没有视觉节奏。
        """
        row_w = QFrame()
        row_w.setStyleSheet("background-color: #F8F9FA; border: 1px solid #EBEEF5; border-radius: 4px;")
        row_lay = QHBoxLayout(row_w)
        row_lay.setContentsMargins(15, 10, 15, 10)

        # v11.3：勾选框
        row_chk = QCheckBox()
        row_chk.setCursor(Qt.PointingHandCursor)
        row_chk.setStyleSheet("""
            QCheckBox { color: #606266; font-size: 13px; border: none; spacing: 6px; }
            QCheckBox::indicator { width: 16px; height: 16px; border: 1px solid #DCDFE6; border-radius: 3px; background-color: #FFFFFF; }
            QCheckBox::indicator:hover { border: 1px solid #409EFF; }
            QCheckBox::indicator:checked { background-color: #4A6FA5; border: 1px solid #409EFF; image: none; }
            QCheckBox::indicator:checked:hover { background-color: #6385B6; border: 1px solid #66B1FF; }
        """)
        row_lay.addWidget(row_chk)

        if is_new:
            name_lbl = QLabel(f"🆕 📄 {script['label']}.sas")
            name_lbl.setStyleSheet("color: #409EFF; font-weight: bold; font-size: 13px; border: none;")
            name_lbl.setToolTip("本次新生成的跑批脚本")
        else:
            name_lbl = QLabel(f"📄 {script['label']}.sas")
            name_lbl.setStyleSheet("color: #303133; font-weight: bold; font-size: 13px; border: none;")
        row_lay.addWidget(name_lbl)

        status_lbl = QLabel("")
        status_lbl.setStyleSheet("border: none; font-size: 12px; min-width: 100px;")
        row_lay.addWidget(status_lbl)

        row_lay.addStretch()

        prog_bar = QProgressBar()
        prog_bar.setRange(0, 100)  # v12.10.114：determinate，由 MarqueeProgress 的 QTimer 驱动扫动（原 setRange(0,0) 原生 busy 在 stylesheet 子树下不滚动）
        prog_bar.setFixedWidth(80)
        prog_bar.setFixedHeight(4)
        prog_bar.setTextVisible(False)
        prog_bar.setVisible(False)
        row_lay.addWidget(prog_bar)

        btn_run = QPushButton("▶ 运行脚本")
        # v12.10.84：统一为绿色（取消 v12.10.65 的奇偶蓝绿交替）——所有"运行脚本"按钮
        #            一律用 success_btn_style 同款绿 #3F9A6E，色值与全局"打开/成功"绿一致。
        base, hover, pressed = "#3F9A6E", "#4FAB7E", "#348A60"   # 绿（同 success_btn_style v82）
        btn_run.setStyleSheet(
            f"QPushButton {{ background-color: {base}; color: white; border: none; "
            f"padding: 6px 15px; border-radius: 4px; font-weight: bold; }}"
            f"QPushButton:hover {{ background-color: {hover}; }}"
            f"QPushButton:pressed {{ background-color: {pressed}; }}"
        )
        btn_run.setCursor(Qt.PointingHandCursor)

        btn_cancel = QPushButton("🟥 中止")
        btn_cancel.setStyleSheet("""
            QPushButton { background-color: #FEF0F0; color: #F56C6C; border: 1px solid #FBC4C4; padding: 6px 15px; border-radius: 4px; font-weight: bold; }
            QPushButton:hover { background-color: #F56C6C; color: white; }
        """)
        btn_cancel.setVisible(False)

        detail_btn = QPushButton("📋 详情")
        detail_btn.setStyleSheet("""
            QPushButton { background-color: #FDF6EC; color: #E6A23C; border: 1px solid #F5DAB1; padding: 4px 10px; border-radius: 4px; font-size: 11px; }
            QPushButton:hover { background-color: #E6A23C; color: white; }
        """)
        detail_btn.setVisible(False)
        detail_btn.setCursor(Qt.PointingHandCursor)

        row_lay.addWidget(btn_run)
        row_lay.addWidget(btn_cancel)
        row_lay.addWidget(detail_btn)

        self._bind_single_run_events(script['label'], script['path'],
                                     btn_run, btn_cancel, prog_bar,
                                     status_lbl, detail_btn)
        self.matrix_layout.addWidget(row_w)

        self._chk_rows.append({
            "label": script['label'],
            "path": script['path'],
            "checkbox": row_chk,
        })

    def _render_footer_check_panel(self):
        """渲染 footer 批量校验面板（log_chk / compare_chk 入口）。
        从 _on_gen_finished 末尾抽取，与原行为完全一致。"""
        footer = QFrame()
        footer.setStyleSheet("background-color: #FFFFFF; border: 1px dashed #DCDFE6; border-radius: 4px;")
        footer_lay = QVBoxLayout(footer)
        footer_lay.setContentsMargins(15, 10, 15, 12)
        footer_lay.setSpacing(8)

        footer_top = QHBoxLayout()
        footer_top.setSpacing(8)

        footer_hint = QLabel("批量校验：勾选要参与校验的批处理脚本，下方按钮一次性提交对应宏。")
        footer_hint.setStyleSheet("color: #606266; font-size: 12px; border: none;")
        footer_top.addWidget(footer_hint)
        footer_top.addStretch()

        self._btn_chk_all = QPushButton("全选")
        self._btn_chk_none = QPushButton("全不选")
        for b in (self._btn_chk_all, self._btn_chk_none):
            b.setStyleSheet(
                "QPushButton { background-color: #F5F7FA; color: #606266; border: 1px solid #DCDFE6;"
                " padding: 4px 12px; border-radius: 4px; font-size: 13px; }"
                "QPushButton:hover { background-color: #EEF2FB; color: #409EFF; border-color: #C0CAE1; }"
            )
            b.setCursor(Qt.PointingHandCursor)
        self._btn_chk_all.clicked.connect(lambda: self._set_all_chk(True))
        self._btn_chk_none.clicked.connect(lambda: self._set_all_chk(False))
        footer_top.addWidget(self._btn_chk_all)
        footer_top.addWidget(self._btn_chk_none)

        footer_lay.addLayout(footer_top)

        footer_btn_row = QHBoxLayout()
        footer_btn_row.setSpacing(10)

        self._btn_log_chk = QPushButton("🔍 运行 Log Check")
        self._btn_log_chk.setStyleSheet("""
            QPushButton { background-color: #EEF2FB; color: #409EFF; border: 1px solid #C0CAE1; padding: 7px 18px; border-radius: 4px; font-weight: bold; font-size: 13px; }
            QPushButton:hover { background-color: #4A6FA5; color: white; border-color: #409EFF; }
            QPushButton:disabled { background-color: #F5F7FA; color: #C0C4CC; border-color: #E4E7ED; }
        """)
        self._btn_log_chk.setCursor(Qt.PointingHandCursor)
        self._btn_log_chk.setToolTip("对勾选的脚本提交 %log_chk 宏（dev / qc 均可）")
        self._btn_log_chk.clicked.connect(self.run_log_check)
        footer_btn_row.addWidget(self._btn_log_chk)

        self._btn_cmp_chk = QPushButton("🔬 运行 Compare Check")
        self._btn_cmp_chk.setStyleSheet("""
            QPushButton { background-color: #F0F9EB; color: #67C23A; border: 1px solid #C2E7B0; padding: 7px 18px; border-radius: 4px; font-weight: bold; font-size: 13px; }
            QPushButton:hover { background-color: #3F9A6E; color: white; border-color: #67C23A; }
            QPushButton:disabled { background-color: #F5F7FA; color: #C0C4CC; border-color: #E4E7ED; }
        """)
        self._btn_cmp_chk.setCursor(Qt.PointingHandCursor)
        self._btn_cmp_chk.setToolTip("对勾选的 QC 脚本提交 %compare_chk 宏；若含 dev 脚本会先弹窗征询")
        self._btn_cmp_chk.clicked.connect(self.run_compare_check)
        footer_btn_row.addWidget(self._btn_cmp_chk)

        footer_btn_row.addStretch()
        footer_lay.addLayout(footer_btn_row)

        # log/compare check 结果文件夹打开按钮（默认隐藏）
        footer_results_row = QHBoxLayout()
        footer_results_row.setSpacing(10)

        self._btn_log_chk_results = QPushButton("📂 Log Check Results")
        self._btn_log_chk_results.setStyleSheet("""
            QPushButton { background-color: #FFFFFF; color: #409EFF; border: 1px solid #C0CAE1; padding: 7px 14px; border-radius: 4px; font-weight: bold; font-size: 12px; }
            QPushButton:hover { background-color: #EEF2FB; }
        """)
        self._btn_log_chk_results.setCursor(Qt.PointingHandCursor)
        self._btn_log_chk_results.setToolTip("打开 Log Check 结果所在文件夹（07_logs）")
        self._btn_log_chk_results.setVisible(False)
        self._btn_log_chk_results.clicked.connect(self._open_log_chk_results)
        footer_results_row.addWidget(self._btn_log_chk_results)

        self._btn_cmp_chk_results = QPushButton("📂 Compare Check Results")
        self._btn_cmp_chk_results.setStyleSheet("""
            QPushButton { background-color: #FFFFFF; color: #67C23A; border: 1px solid #C2E7B0; padding: 7px 14px; border-radius: 4px; font-weight: bold; font-size: 12px; }
            QPushButton:hover { background-color: #F0F9EB; }
        """)
        self._btn_cmp_chk_results.setCursor(Qt.PointingHandCursor)
        self._btn_cmp_chk_results.setToolTip("打开 Compare Check 结果所在文件夹（09_validation）")  # v12.10.35：从 07_logs 改为 09_validation
        self._btn_cmp_chk_results.setVisible(False)
        self._btn_cmp_chk_results.clicked.connect(self._open_cmp_chk_results)
        footer_results_row.addWidget(self._btn_cmp_chk_results)

        footer_results_row.addStretch()
        footer_lay.addLayout(footer_results_row)

        self.matrix_layout.addWidget(footer)
        self.matrix_layout.addStretch()

    def _prompt_overwrite_conflicts(self, conflicts):
        """
        v12.10.32：生成前若新脚本会和 tools 下已有同名脚本冲突，弹窗征询用户。
        - conflicts: list of label
        返回："overwrite" / "skip" / None（取消）
        """
        from ui_utils import show_choice_dialog
        names = "<br>".join(f"&nbsp;&nbsp;• {n}.sas" for n in conflicts)
        text = (
            f"以下 {len(conflicts)} 个脚本在 tools 目录下已存在同名文件，"
            f"将被本次生成覆盖：<br><br>{names}<br><br>"
            f"请选择如何处理同名冲突。"
        )
        return show_choice_dialog(
            self, "覆盖确认", text,
            [("⚠️ 全部覆盖", "overwrite"),
             ("跳过同名", "skip")],
            cancellable=True,
        )

    def set_wait_hint(self, show):
        """控制左侧上方等待提示的显隐"""
        if show:
            self.scan_lbl.setText("⏳ 等待填写完整路径...")
            self.scan_lbl.setStyleSheet(scan_status_lbl_style())
        else:
            self.scan_lbl.setText("")

    # ============================================================================
    # 全局快捷键钩子：F5 由 TFLsWidget 路由到此处
    # 说明：本 step 是按脚本逐行运行（matrix 中每条 PDT 一个 ▶ 运行脚本 按钮），
    # Ctrl+Enter 语义不明确，故不实现 action_run。
    # ============================================================================
    def action_refresh(self):
        """F5：点击"🔄 刷新源文件"。"""
        btn = getattr(self, "refresh_btn", None)
        if btn is not None and btn.isEnabled():
            btn.click()

    # ============================================================================
    # 任务4：Batch 跑批前置准备（依次弹窗收集答案 → 后台运行 00_batch_pre_call.py）
    # ============================================================================
    def run_batch_pre_call(self):
        """
        点击"▶ 执行备份"：依次弹窗收集脚本所有交互输入，再后台执行。

        交互序列（严格对应脚本 collect_backup_options 的 input 顺序）：
          1) 备份模式      → choice_dialog → "1" (batch_pre) / "2" (csr_01)
          2) 是否压缩      → choice_dialog → "y" / "n"
          3) 分支：
             - batch_pre: 是否删除原文件 → choice_dialog → "y" / "n"
             - csr_01:    备份名称       → text_input_dialog（含校验：非空、不与
                          当前 csr 同名、无 <>:"/\\|?* 非法字符）

        任意弹窗"取消"则中止整次流程；UI 不下发执行。
        所有答案通过 stdin 一次性喂给后台子进程，stdout 实时进右侧日志面板。

        防重入：上一次脚本还在跑就拒绝再次下发，避免目录写竞争。
        """
        if not self.base_path:
            self.sig_log.emit("<span style='color:#F56C6C;'>❌ 项目路径未就绪，请先填完 4 级下拉框。</span>")
            return

        script_path = os.path.join(self.base_path, "utility", "tools", "00_batch_pre_call.py")
        if not os.path.exists(script_path):
            self.sig_log.emit(f"<span style='color:#F56C6C;'>❌ 找不到 batch pre 脚本：{script_path}</span>")
            return

        # 防重入
        if getattr(self, "_pre_thread", None) is not None and self._pre_thread.isRunning():
            self.sig_log.emit("<span style='color:#E6A23C;'>⏳ 上一次备份仍在运行，请等待其完成。</span>")
            return

        from ui_utils import show_choice_dialog, show_text_input_dialog, ScriptRunnerThread

        # ---- 弹窗 1：备份模式 ----
        mode = show_choice_dialog(
            self,
            title="跑批前置 — 选择备份模式",
            text="请选择要执行的备份模式：",
            options=[
                ("📦 batch pre 备份", "1"),
                ("🗄️ csr 整体备份", "2"),
            ],
        )
        if mode is None:
            self.sig_log.emit("<span style='color:#909399;'>已取消跑批前置备份。</span>")
            return

        # ---- 弹窗 2：是否压缩 ----
        zip_ans = show_choice_dialog(
            self,
            title="跑批前置 — 是否压缩备份目录",
            text="是否将备份文件夹压缩为 .zip？\n\n压缩可节省磁盘空间，但会增加耗时。",
            options=[
                ("✅ 是（压缩）", "y"),
                ("❌ 否（保留目录）", "n"),
            ],
        )
        if zip_ans is None:
            self.sig_log.emit("<span style='color:#909399;'>已取消跑批前置备份。</span>")
            return

        # ---- 弹窗 3：分支询问 ----
        if mode == "1":
            del_ans = show_choice_dialog(
                self,
                title="跑批前置 — 是否删除原文件",
                text=(
                    "是否删除原始文件夹中已成功备份的 SDTM / ADaM / Reports / .log 文件？\n\n"
                    "• 选「是」可清理冗余，但需确认备份完整。\n"
                    "• 选「否」保留原文件，安全保守。"
                ),
                options=[
                    ("⚠️ 是（删除原文件）", "y"),
                    ("✅ 否（保留原文件）", "n"),
                ],
            )
            if del_ans is None:
                self.sig_log.emit("<span style='color:#909399;'>已取消跑批前置备份。</span>")
                return
            mode_label = "batch pre 备份"
            stdin_text = f"1\n{zip_ans}\n{del_ans}\n"
            extra_note = f"压缩={zip_ans}, 删除原文件={del_ans}"
        else:
            # csr_01 模式：要求一个合法且不与当前 csr 同名的目录名
            csr_basename = os.path.basename(self.base_path).strip()

            def _validate_name(s):
                if not s:
                    return False, "文件夹名称不能为空。"
                if s == csr_basename:
                    return False, f"备份名称不能与当前目录 '{csr_basename}' 同名。"
                if any(c in s for c in '<>:"/\\|?*'):
                    return False, "名称包含非法字符 < > : \" / \\ | ? *。"
                return True, ""

            from datetime import datetime  # 兼容保留：validator 与日志格式后续可能用
            default_name = "ia_01"
            backup_name = show_text_input_dialog(
                self,
                title="跑批前置 — 输入整体备份名称",
                text="请输入 csr 整体备份的目录名称（将创建在当前 csr 同级位置）：",
                default=default_name,
                placeholder="例如：ia_01 / ia_02 / fa_01",
                validator=_validate_name,
            )
            if backup_name is None:
                self.sig_log.emit("<span style='color:#909399;'>已取消跑批前置备份。</span>")
                return
            mode_label = "csr 整体备份"
            stdin_text = f"2\n{zip_ans}\n{backup_name}\n"
            extra_note = f"压缩={zip_ans}, 备份名称={backup_name}"

        # ---- UI 进入"运行中"态并下发 ----
        # 隐藏"执行备份"按钮，显示"中止备份"按钮（互斥占位，避免误点重发）
        self.btn_pre_call.setVisible(False)
        self.btn_pre_cancel.setVisible(True)
        self.btn_pre_cancel.setEnabled(True)
        # 锁住"生成批处理脚本"按钮 — 备份和生成同时跑会写同目录
        try:
            self.btn_gen_batch.setEnabled(False)
        except Exception:
            pass
        self.sig_run_started.emit()
        self.sig_status.emit(f"⏳ 正在执行 {mode_label}（后台）...", "#E6A23C")
        self.sig_log.emit(
            f"<span style='color:#E6A23C; font-weight:bold;'>🧹 已下发 {mode_label}（后台执行，不弹控制台）...</span>"
        )
        self.sig_log.emit(f"<span style='color:#909399;'>&nbsp;&nbsp;参数：{extra_note}</span>")

        self._pre_thread = ScriptRunnerThread(
            script_path=script_path,
            cwd=os.path.dirname(script_path),
            stdin_text=stdin_text,
            parent=self,
        )
        self._pre_thread.line_signal.connect(self._on_pre_call_line)
        self._pre_thread.finished_signal.connect(self._on_pre_call_finished)
        self._pre_thread.start()

    def _on_pre_call_line(self, line):
        """ScriptRunnerThread 每行回调：原样推到日志面板（HTML 转义防注入）"""
        if not line:
            return
        safe = html.escape(line)
        # 关键词高亮：错误 / 完成 / 已备份
        lower = line.lower()
        if "error" in lower or "exception" in lower or "失败" in line:
            self.sig_log.emit(f"<span style='color:#F56C6C;'>{safe}</span>")
        elif "完成" in line or "成功" in line:
            self.sig_log.emit(f"<span style='color:#67C23A;'>{safe}</span>")
        else:
            self.sig_log.emit(f"<span style='color:#606266;'>{safe}</span>")

    def _on_pre_call_finished(self, return_code, full_output):
        """ScriptRunnerThread 结束回调：恢复 UI、写最终状态"""
        # 恢复双按钮可见性：显示"执行备份"，隐藏"中止备份"
        self.btn_pre_call.setVisible(True)
        self.btn_pre_call.setEnabled(True)
        self.btn_pre_cancel.setVisible(False)
        # 解锁"生成批处理脚本"按钮
        try:
            self.btn_gen_batch.setEnabled(True)
        except Exception:
            pass

        if return_code == 0:
            self.sig_status.emit("✅ 跑批前备份已完成", "#67C23A")
            self.sig_log.emit("<span style='color:#67C23A; font-weight:bold;'>✅ 跑批前备份脚本执行完毕。</span>")
        elif return_code == -1 or return_code == -9 or self._pre_call_user_cancelled:
            # -1 / -9 通常是 kill 后的 returncode；_pre_call_user_cancelled 是显式中止
            self.sig_status.emit("🛑 已中止跑批前备份", "#F56C6C")
            self.sig_log.emit("<span style='color:#F56C6C; font-weight:bold;'>🛑 用户已中止跑批前备份。</span>")
        else:
            self.sig_status.emit(f"❌ 备份失败（rc={return_code}）", "#F56C6C")
            self.sig_log.emit(
                f"<span style='color:#F56C6C; font-weight:bold;'>❌ 跑批前备份脚本失败，returncode={return_code}。</span>"
            )

        # v11.9：与 _on_check_finished 同款修复 —— 把 deleteLater 挂到 QThread.finished
        # 信号上，避免在 worker run() 还未真正返回时主动 deleteLater 触发 Qt qFatal。
        thread_ref = self._pre_thread
        self._pre_thread = None
        self._pre_call_user_cancelled = False  # 复位中止标志
        if thread_ref is not None:
            try:
                thread_ref.finished.connect(thread_ref.deleteLater)
            except Exception:
                pass

        # v12.2：通知外层停止耗时计数（与 _on_check_finished 同步处理，避免计时器一直跑）
        try:
            self.sig_run_finished.emit()
        except Exception:
            pass

    def _on_pre_call_cancel(self):
        """点击"🟥 中止备份"按钮：调 ScriptRunnerThread.cancel()。
        finished_signal 会随 proc kill 后被 emit，由 _on_pre_call_finished 收尾恢复 UI。"""
        thread = getattr(self, "_pre_thread", None)
        if thread is None or not thread.isRunning():
            # 已经结束 — 兜底一下 UI 状态
            self.btn_pre_call.setVisible(True)
            self.btn_pre_call.setEnabled(True)
            self.btn_pre_cancel.setVisible(False)
            try:
                self.btn_gen_batch.setEnabled(True)
            except Exception:
                pass
            return
        # 立即让中止按钮变灰防止重复点击
        self.btn_pre_cancel.setEnabled(False)
        self.sig_log.emit(
            "<span style='color:#F56C6C; font-weight:bold;'>🛑 收到中止请求，正在终止备份子进程树（taskkill /T）...</span>"
        )
        self._pre_call_user_cancelled = True
        try:
            thread.cancel()  # 内部：set _is_cancelled + taskkill /T
        except Exception as e:
            self.sig_log.emit(f"<span style='color:#F56C6C;'>❌ 中止失败：{e}</span>")

        # 保护机制：5 秒内若 finished_signal 仍未到来，强制走收尾流程恢复 UI。
        # 这样万一 kill 没生效或子进程 stdout 句柄没释放卡住 readline，UI 也不会卡住。
        from PySide6.QtCore import QTimer
        def _force_finalize():
            t = getattr(self, "_pre_thread", None)
            if t is None:
                return  # 已经被正常 _on_pre_call_finished 处理过
            # 强制走收尾流程
            self.sig_log.emit(
                "<span style='color:#F56C6C;'>⚠️ 子进程未在 5s 内退出，强制恢复 UI（后台进程可能仍在运行，需手动 taskkill）。</span>"
            )
            self._on_pre_call_finished(-9, "")
        QTimer.singleShot(5000, _force_finalize)

    # ============================================================================
    # v11.2：批量校验 —— 单栏勾选 + 两个动作按钮（log_check / compare_check）
    # ============================================================================
    def _set_all_chk(self, checked: bool):
        """全选 / 全不选 —— 仅作用于已渲染的勾选行"""
        for r in (self._chk_rows or []):
            try:
                r["checkbox"].setChecked(checked)
            except RuntimeError:
                # 控件已被 deleteLater 清理（_clear_matrix 后立刻触发）
                pass

    def _selected_labels(self):
        """收集当前已勾选的脚本 label（按行原始顺序）"""
        out = []
        for r in (self._chk_rows or []):
            try:
                if r["checkbox"].isChecked():
                    out.append(r["label"])
            except RuntimeError:
                pass
        return out

    @staticmethod
    def _build_check_outname(prefix: str, labels: list) -> str:
        """
        将多个 batch label 拼接为 out= 后缀片段。
        命名规则：先列出所有领域名（保留首次出现顺序，去重），再把 dev/qc 角色追加到末尾。
        例：
          ["01_batch_script_sdtm_dev"]                                                → "sdtm_dev"
          ["01_batch_script_sdtm_dev","03_batch_script_adam_dev","05_batch_script_tfl_dev"]
                                                                                       → "sdtm_adam_tfl_dev"
          ["02_batch_script_sdtm_qc","04_batch_script_adam_qc","06_batch_script_tfl_qc"]
                                                                                       → "sdtm_adam_tfl_qc"
          ["01_batch_script_sdtm_dev","02_batch_script_sdtm_qc"]                       → "sdtm_dev_qc"
        若 label 不符合 *_batch_script_<area>_<role> 模式，则退化为下划线拼接 label 本身。
        """
        import re as _re
        areas = []  # 领域，保留首次出现顺序
        roles = []  # dev / qc，最多两个，按首次出现顺序
        misc = []   # 不识别的兜底
        seen_a, seen_r, seen_m = set(), set(), set()
        for lab in labels:
            m = _re.search(r"_batch_script_([a-z]+)_(dev|qc)$", lab.lower())
            if m:
                area, role = m.group(1), m.group(2)
                if area not in seen_a:
                    areas.append(area); seen_a.add(area)
                if role not in seen_r:
                    roles.append(role); seen_r.add(role)
            else:
                if lab not in seen_m:
                    misc.append(lab); seen_m.add(lab)
        tokens = areas + roles + misc
        return prefix + "_".join(tokens) if tokens else prefix.rstrip("_")

    def _batch_log_status(self, label):
        """
        v11.5：检测 utility/tools/<label>.log 是否存在且 size > 0。
        返回 True 表示该 batch 已被运行（产生了非空 log），False 表示未跑或 log 为 0KB。

        说明（与用户提供的事实对齐）：
          - batchrun 脚本本身的 log 在 utility/tools 下（不在 07_logs）
          - 06/09 下逐个 .sas 的 log 才在 07_logs 下
          - "脚本是否被 batchrun 跑过"应以 utility/tools/<label>.log 为信号源
        """
        if not self.base_path:
            return False
        log_path = os.path.join(self.base_path, "utility", "tools", label + ".log")
        try:
            return os.path.isfile(log_path) and os.path.getsize(log_path) > 0
        except OSError:
            return False

    def _preflight_for_log_check(self, labels):
        """
        Log Check 前置：每个 label 单独检查 utility/tools/<label>.log。

        v12.3：返回 (ready, missing) 二元组，与 Compare Check 的 preflight 行为对齐：
          - 全部缺失 → ready=[]，由调用方阻断执行
          - 部分缺失 → ready/missing 均非空，由调用方弹窗确认是否仅跑 ready
          - 全部就绪 → ready=labels, missing=[]
        关键：仅传 ready 给宏端，不再传 missing（避免静默跳过让用户误以为已校验）。
        """
        # v12.3：与 Compare Check 对齐，明确切分 ready / missing
        # 上游调用方据此决定：全 missing → 阻断；部分 missing → 弹窗确认仅跑 ready；
        # 不再向 SAS 宏端传入缺 .log 的 label（避免静默跳过让用户误以为已校验）。
        ready = [l for l in labels if self._batch_log_status(l)]
        missing = [l for l in labels if not self._batch_log_status(l)]
        return ready, missing

    def _preflight_for_compare_check(self, qc_labels):
        """
        Compare Check 前置：要求每个 qc batch 必须存在配对的 dev 兄弟，且**两者**都
        已跑过（utility/tools 下两份非空 .log 都在）。

        命名约定（与生成器 92_batch_script_generator 一致）：
          xx_batch_script_<area>_qc  ↔  yy_batch_script_<area>_dev
        例：02_batch_script_sdtm_qc 的 dev 兄弟可能是 01_batch_script_sdtm_dev。
        我们用"去掉序号前缀 + 把 _qc 换成 _dev"做模式匹配，再在 _chk_rows 中找 label
        匹配 *_batch_script_<area>_dev 后缀的同 area 项作为兄弟。

        返回：
          (ready: list[qc_label], unmet: list[(qc_label, reason)])
          ready 至少 1 项才允许 compare check 提交，否则全 unmet 时阻止执行。
        """
        ready, unmet = [], []
        # 收集所有可见 row 的 label
        all_known_labels = [r["label"] for r in (self._chk_rows or [])]

        def _find_dev_sibling(qc_label):
            """匹配同 area 的 dev：去掉序号前缀（NN_）+ 把 _qc → _dev → 在 all_known_labels 中找"""
            m = re.match(r"^\d+_(.+)_qc$", qc_label.lower())
            if not m:
                return None
            stem_no_num = m.group(1)  # e.g. batch_script_sdtm
            dev_suffix = f"{stem_no_num}_dev"
            for cand in all_known_labels:
                # 同 area 的 dev：忽略前缀序号，匹配 *_<stem>_dev
                if re.match(rf"^\d+_{re.escape(stem_no_num)}_dev$", cand.lower()):
                    return cand
            # 若标准命名失败，再宽松匹配 endswith
            for cand in all_known_labels:
                if cand.lower().endswith(dev_suffix):
                    return cand
            return None

        for qc in qc_labels:
            dev = _find_dev_sibling(qc)
            if dev is None:
                unmet.append((qc, "未找到对应 dev 脚本（命名不符 NN_..._dev / NN_..._qc）"))
                continue
            qc_log_ok = self._batch_log_status(qc)
            dev_log_ok = self._batch_log_status(dev)
            if qc_log_ok and dev_log_ok:
                ready.append(qc)
            elif not qc_log_ok and not dev_log_ok:
                unmet.append((qc, f"{qc} 与 {dev} 均未跑过（utility/tools 下无 .log 或 .log 为空）"))
            elif not dev_log_ok:
                unmet.append((qc, f"配对的 dev 脚本 {dev} 未跑过"))
            else:
                unmet.append((qc, f"{qc} 自身未跑过"))
        return ready, unmet

    def run_log_check(self):
        """
        组合勾选脚本的 batch=label1|label2|... + out=93_log_<拼接>_&sysdate.，
        生成临时 .sas（含前置 autorun 引导 + %log_chk 宏调用），
        通过 run_sas 提交执行后立即清理临时脚本，不留痕。

        v11.5 修正：
          - 分隔符回到 `|`（log_chk 宏 line 93/95 使用 `|` split，正确格式）
          - 不再手动加 `.sas` 后缀（宏 line 96-98 内部 ext='sas' 自动补全）
          - 前置检查源改为 utility/tools/<label>.log（跑批脚本本体的 log）
        """
        labels = self._selected_labels()
        if not labels:
            self.sig_log.emit("<span style='color:#E6A23C;'>⚠️ 未勾选任何脚本，已忽略 Log Check。</span>")
            return
        if self._chk_thread is not None and self._chk_thread.isRunning():
            self.sig_log.emit("<span style='color:#E6A23C;'>⏳ 上一次校验仍在运行，请等待其完成。</span>")
            return

        ready, missing = self._preflight_for_log_check(labels)
        if not ready:
            # 全部脚本都没 .log → 阻断执行
            details_html = "<br>".join(
                f"<span style='color:#909399;'>&nbsp;&nbsp;&nbsp;&nbsp;• {html.escape(m)}</span>"
                for m in missing
            )
            self.sig_log.emit(
                "<span style='color:#F56C6C; font-weight:bold;'>❌ Log Check 前置检查失败：</span>"
                "<br><span style='color:#F56C6C;'>&nbsp;&nbsp;勾选的脚本均未跑过（utility/tools 下找不到对应 .log，或 .log 为空）：</span>"
                f"<br>{details_html}"
                "<br><span style='color:#909399;'>&nbsp;&nbsp;请先点击各脚本旁的 ▶ 运行脚本 完成跑批后再执行 Log Check。</span>"
            )
            return
        if missing:
            # v12.3：部分脚本缺 .log → 弹窗显式告知"哪些不能跑"，
            # 与 Compare Check 同款交互；用户确认后只把 ready 传给宏端，
            # 不再静默把 missing 也传过去让宏自己跳过（之前是没有 warning 的盲跑）。
            from ui_utils import show_choice_dialog
            missing_listing = "\n".join(f"  • {m}" for m in missing)
            ready_listing = "、".join(ready)
            choice = show_choice_dialog(
                self,
                title="Log Check — 部分脚本未运行过",
                text=(
                    f"以下 {len(missing)} 个脚本无法参与 Log Check（utility/tools 下找不到对应 .log 或 .log 为空）：\n"
                    f"{missing_listing}\n\n"
                    f"可继续仅对已运行过的 {len(ready)} 个脚本执行 Log Check：\n"
                    f"  {ready_listing}\n\n"
                    "请选择如何继续："
                ),
                options=[("✅ 仅运行已运行过的脚本", "ready_only")],
                cancellable=True,
            )
            if choice != "ready_only":
                self.sig_log.emit("<span style='color:#909399;'>已取消 Log Check。</span>")
                return
            details_html = "<br>".join(
                f"<span style='color:#909399;'>&nbsp;&nbsp;&nbsp;&nbsp;• {html.escape(m)}</span>"
                for m in missing
            )
            self.sig_log.emit(
                f"<span style='color:#E6A23C;'>⚠️ 以下 {len(missing)} 个脚本未跑过，已被排除（仅运行 {len(ready)} 个就绪项）：</span>"
                f"<br>{details_html}"
            )

        batch_arg = "|".join(ready)
        out_token = self._build_check_outname("", ready)
        out_arg = f"93_log_{out_token}_&sysdate."
        self._kick_off_check("Log Check", "log_chk", batch_arg, out_arg)

    def run_compare_check(self):
        """
        Compare Check 仅适用 QC 脚本。
        若用户勾选含 dev：弹窗"仅运行 QC 端脚本 / 取消"，明确征询；
        选择 qc_only → 继续仅以 qc 子集执行；
        取消 → 中止，不发起任何提交。

        v11.5：前置 = "qc 与对应 dev 都已跑过（两个 .log 都在 utility/tools 且非空）"
        """
        all_labels = self._selected_labels()
        if not all_labels:
            self.sig_log.emit("<span style='color:#E6A23C;'>⚠️ 未勾选任何脚本，已忽略 Compare Check。</span>")
            return
        if self._chk_thread is not None and self._chk_thread.isRunning():
            self.sig_log.emit("<span style='color:#E6A23C;'>⏳ 上一次校验仍在运行，请等待其完成。</span>")
            return

        qc_labels = [l for l in all_labels if l.lower().endswith("_qc")]
        dev_labels = [l for l in all_labels if l not in qc_labels]

        if dev_labels:
            from ui_utils import show_choice_dialog
            dev_listing = "、".join(dev_labels)
            qc_listing = "、".join(qc_labels) if qc_labels else "（无）"
            choice = show_choice_dialog(
                self,
                title="Compare Check — 含开发端脚本",
                text=(
                    f"当前勾选包含 {len(dev_labels)} 个 dev（开发端）脚本：\n  {dev_listing}\n\n"
                    f"Compare Check 仅适用于 QC 脚本（{len(qc_labels)} 个）：\n  {qc_listing}\n\n"
                    "请选择如何继续："
                ),
                options=[("✅ 仅运行 QC 端脚本", "qc_only")],
                cancellable=True,
            )
            if choice != "qc_only":
                self.sig_log.emit("<span style='color:#909399;'>已取消 Compare Check。</span>")
                return

        if not qc_labels:
            self.sig_log.emit("<span style='color:#F56C6C;'>❌ 勾选项中无任何 QC 脚本，无法执行 Compare Check。</span>")
            return

        ready, unmet = self._preflight_for_compare_check(qc_labels)
        if not ready:
            details_html = "<br>".join(
                f"<span style='color:#909399;'>&nbsp;&nbsp;&nbsp;&nbsp;• {html.escape(qc)}：{html.escape(reason)}</span>"
                for qc, reason in unmet
            )
            self.sig_log.emit(
                "<span style='color:#F56C6C; font-weight:bold;'>❌ Compare Check 前置检查失败：</span>"
                "<br><span style='color:#F56C6C;'>&nbsp;&nbsp;勾选的 QC 脚本均无可用的 dev/qc 配对（utility/tools 下两份 .log 都需存在且非空）：</span>"
                f"<br>{details_html}"
            )
            return
        if unmet:
            # v12.2：弹窗显式告知用户"哪些 QC 因缺 .log 不能跑"，并明示"仅运行已运行过的脚本"，
            # 提供取消选项；之前只在右侧日志面板写一条灰色 NOTE 容易被忽略。
            from ui_utils import show_choice_dialog
            unmet_listing = "\n".join(f"  • {qc}：{reason}" for qc, reason in unmet)
            ready_listing = "、".join(ready)
            choice = show_choice_dialog(
                self,
                title="Compare Check — 部分脚本未运行过",
                text=(
                    f"以下 {len(unmet)} 个 QC 脚本无法参与 Compare Check（缺 .log 或与 dev 不配对）：\n"
                    f"{unmet_listing}\n\n"
                    f"可继续仅对已运行过的 {len(ready)} 个 QC 脚本执行 Compare Check：\n"
                    f"  {ready_listing}\n\n"
                    "请选择如何继续："
                ),
                options=[("✅ 仅运行已运行过的脚本", "ready_only")],
                cancellable=True,
            )
            if choice != "ready_only":
                self.sig_log.emit("<span style='color:#909399;'>已取消 Compare Check。</span>")
                return
            details_html = "<br>".join(
                f"<span style='color:#909399;'>&nbsp;&nbsp;&nbsp;&nbsp;• {html.escape(qc)}：{html.escape(reason)}</span>"
                for qc, reason in unmet
            )
            self.sig_log.emit(
                f"<span style='color:#E6A23C;'>⚠️ 以下 {len(unmet)} 个 QC 脚本未通过 dev/qc 配对检查，已被排除（仅运行 {len(ready)} 个就绪项）：</span>"
                f"<br>{details_html}"
            )

        batch_arg = "|".join(ready)
        out_token = self._build_check_outname("", ready)
        out_arg = f"94_compare_{out_token}_&sysdate."
        self._kick_off_check("Compare Check", "compare_chk", batch_arg, out_arg)

    def _kick_off_check(self, kind: str, macro_name: str, batch_arg: str, out_arg: str):
        """统一构造 .sas 内容、起 LogCompareCheckRunner、UI 进入"运行中"态"""
        scratch_dir = os.path.join(self.base_path, "utility", "tools") if self.base_path else None
        if not scratch_dir or not os.path.isdir(scratch_dir):
            self.sig_log.emit(
                f"<span style='color:#F56C6C;'>❌ 找不到 utility\\tools 目录，无法落临时脚本：{scratch_dir}</span>"
            )
            return

        # v11.7：原本在此处注入 %terminate 拦截 hotfix 阻止 endsas 闪退；现 SAS 宏文件
        # 已在源头打补丁（log_chk.sas 的 endsas、compare_chk.sas 的 %abort 都改为
        # %abort cancel），不再需要 GUI 端 wrapper。保持调用方式与跑批脚本一致。
        sas_code = (
            "data _null_;\n"
            "  if libref('adam') then call execute('%nrstr(%autorun)');\n"
            "run;\n"
            f"%{macro_name}(batch={batch_arg},out={out_arg});\n"
        )

        self.sig_run_started.emit()
        self.sig_status.emit(f"⏳ 正在提交 {kind}...", "#409EFF")
        # v11.5：批量参数若过长，按 `|` 拆开逐行展示，避免在日志面板里出现单行 1000+ 字符把
        # 视觉宽度撑爆；同时让用户更直观看到逐个 batch 项。
        batches = [b for b in batch_arg.split("|") if b]
        self.sig_log.emit(f"<span style='color:#409EFF; font-weight:bold;'>🧪 提交 {kind}：</span>")
        self.sig_log.emit(f"<span style='color:#909399;'>&nbsp;&nbsp;batch（共 {len(batches)} 个）：</span>")
        for b in batches:
            self.sig_log.emit(f"<span style='color:#909399;'>&nbsp;&nbsp;&nbsp;&nbsp;• {html.escape(b)}</span>")
        self.sig_log.emit(f"<span style='color:#909399;'>&nbsp;&nbsp;out：{html.escape(out_arg)}</span>")
        for b in (getattr(self, '_btn_log_chk', None), getattr(self, '_btn_cmp_chk', None)):
            if b is not None:
                b.setEnabled(False)

        self._chk_thread = LogCompareCheckRunner(sas_code, kind, scratch_dir)
        self._chk_thread.log_signal.connect(self.sig_log.emit)
        self._chk_thread.finished_signal.connect(self._on_check_finished)
        self._chk_thread.start()

    def _on_check_finished(self, kind, ok, summary, log_text, source_label):
        """LogCompareCheckRunner 结束：恢复按钮、写最终状态、按需展开错误摘要"""
        # v11.8 诊断埋点：闪退发生在 finished_signal emit 之后但具体哪行不明，
        # 在每段路径之间写 logs/crash.log 留迹，下次再闪可以看到死在哪里。
        from datetime import datetime as _dt
        from app_paths import logs_dir as _ld
        breadcrumb_path = os.path.join(_ld(), "crash.log")
        def _bc(stage):
            try:
                os.makedirs(os.path.dirname(breadcrumb_path), exist_ok=True)
                with open(breadcrumb_path, "a", encoding="utf-8") as f:
                    f.write(f"[{_dt.now().isoformat(timespec='milliseconds')}] _on_check_finished[{kind}] stage={stage}\n")
                    f.flush()
                    try:
                        os.fsync(f.fileno())  # 关键：把数据真正落盘，闪退后能找到
                    except OSError:
                        pass
            except Exception:
                pass

        _bc("entry")
        for b in (getattr(self, '_btn_log_chk', None), getattr(self, '_btn_cmp_chk', None)):
            if b is not None:
                try: b.setEnabled(True)
                except Exception: pass
        _bc("btns_re_enabled")

        try:
            if ok:
                self.sig_status.emit(f"✅ {kind} 已完成", "#67C23A")
                self.sig_log.emit(
                    f"<span style='color:#67C23A; font-weight:bold;'>✅ {kind} 提交完毕：{html.escape(summary or '运行成功')}</span>"
                )
                # v12.10.11：成功路径也尝试抽 ERROR/WARNING — 即使 has_issue=False，宏内
                # 可能用 NOTE: WARNING:: 风格 put 输出业务级警告（非 SAS 标准 WARNING:），
                # _format_error_summary 不会捕获 NOTE，所以 ok 路径打不到这些。
                # 但若日志确有标准 ERROR/WARNING 行，这里也展示出来供用户审阅。
                if log_text:
                    has_std_issue = any(
                        re.match(r'^\s*(ERROR|WARNING)\s*:', l, re.I)
                        for l in log_text.splitlines()
                    )
                    if has_std_issue:
                        self.sig_log.emit(self._format_error_summary(log_text))
            else:
                self.sig_status.emit(f"⚠️ {kind} 完成（含 ERROR/WARNING）", "#E6A23C")
                self.sig_log.emit(
                    f"<span style='color:#E6A23C; font-weight:bold;'>⚠️ {kind} 提交完成：{html.escape(summary or '请查看日志详情')}</span>"
                )
                _bc("about_to_format_summary")
                if log_text:
                    summary_html = self._format_error_summary(log_text)
                    _bc(f"summary_built len={len(summary_html)}")
                    self.sig_log.emit(summary_html)
                    _bc("summary_emitted")
            # v12.10.12：左侧 footer 直接显示对应"Results"按钮（替代右上角两个按钮）
            # Log Check 完成 → 显示 📂 Log Check Results；Compare Check 完成 → 显示 📂 Compare Check Results
            # 不再 emit sig_show_check_paths（保留信号定义仅作向后兼容，stepper 端的右上角按钮已废弃）
            try:
                if kind == "Log Check":
                    btn = getattr(self, "_btn_log_chk_results", None)
                    if btn is not None:
                        btn.setVisible(True)
                elif kind == "Compare Check":
                    btn = getattr(self, "_btn_cmp_chk_results", None)
                    if btn is not None:
                        btn.setVisible(True)
            except Exception:
                pass
            _bc("source_label_emitted")
        except Exception as e:
            import traceback as _tb
            _bc(f"EXCEPT {type(e).__name__}: {e}")
            try:
                with open(breadcrumb_path, "a", encoding="utf-8") as f:
                    f.write(_tb.format_exc() + "\n")
            except Exception:
                pass

        # v12.1：永远不主动释放 _chk_thread，攒到列表让 GC 统一清理（避免 Qt 析构 race）。
        # v12.2 已实测稳定，移除之前的 heartbeat 探针。
        thread_ref = self._chk_thread
        self._chk_thread = None
        if thread_ref is not None:
            if not hasattr(self, '_retired_threads'):
                self._retired_threads = []
            self._retired_threads.append(thread_ref)
            try:
                thread_ref.finished.connect(thread_ref.quit)
            except Exception:
                pass
        _bc("end_clean")

        # v12.2：通知外层 stepper 停掉耗时计数器（不写"步骤完成✅"标记，与 sig_step_update 区分）。
        # 之前 Log/Compare Check 完成后从来不发任何"运行结束"信号，导致状态栏的 "(耗时: Xs)"
        # 持续累加；甚至切换项目目录后还在累，因为耗时定时器从未被 stop。
        try:
            self.sig_run_finished.emit()
        except Exception:
            pass

    # ------------------------- 错误摘要格式化 -------------------------
    def _format_error_summary(self, log_content):
        """从日志中抽取 ERROR / WARNING 行，HTML 高亮并做智能折叠（>10 条时折叠）"""
        if not log_content:
            return "<i style='color:#909399;'>未捕获到具体日志内容。</i>"

        # 加入 [Python 调用层异常] 匹配，防止底层解码崩溃的信息被过滤
        issues = [l.strip() for l in log_content.splitlines() if
                  re.search(r'^\s*(ERROR|WARNING)\s*:|\[Python 调用层异常\]', l, re.I)]

        def _style_line(line):
            safe_line = html.escape(line)  # HTML 转义防截断
            if "ERROR" in safe_line.upper() or "异常" in safe_line:
                return f"<span style='color:#F56C6C;'>{safe_line}</span>"
            return f"<span style='color:#E6A23C;'>{safe_line}</span>"

        if not issues:
            safe_log = html.escape(log_content[:400])
            return f"<i style='color:#909399;'>未定位到标准 ERROR/WARNING 行，截取部分日志供参考：</i><br><span style='color:#E6A23C;'>{safe_log}...</span>"

        if len(issues) <= 10:
            return "<br>".join([_style_line(e) for e in issues])

        clusters = {e[:40]: e for e in issues}
        return "<br>".join([_style_line(e) for e in
                            list(clusters.values())[:3]]) + "<br><i style='color:#909399;'>... (相似记录过多已智能折叠)</i>"

    # ------------------------- 批量生成 / 完成回调 -------------------------
    def generate_batch_scripts(self):
        """点击"生成批处理脚本"：校验输入 → 启动 BatchGenRunner"""
        # 任务1：以 UI 输入为准（允许用户覆盖自动探测到的默认 PDT）
        pdt_input = self.pdt_entry.text().strip()
        if not pdt_input:
            self.sig_log.emit("<span style='color:#F56C6C;'>❌ PDT XLSX 路径不能为空！</span>")
            return
        if not os.path.exists(pdt_input):
            self.sig_log.emit(f"<span style='color:#F56C6C;'>❌ 找不到 PDT 文件：{pdt_input}</span>")
            return
        self.pdt_path = pdt_input

        # 校验 92_batch_call 输入
        sas_92_path = self.sas_92_entry.text().strip()
        if not sas_92_path:
            self.sig_log.emit("<span style='color:#F56C6C;'>❌ 92_batch_call 路径不能为空！</span>")
            return
        if not os.path.exists(sas_92_path):
            self.sig_log.emit(f"<span style='color:#F56C6C;'>❌ 找不到文件：{sas_92_path}</span>")
            return

        # v12.10.32：预探测本次将生成的 out_name 清单，与 tools 现存 .sas 对比，弹覆盖确认
        # 解析 92call 拿到所有 out= 名字（不卡 PDT 计数，PDT 卡掉的段最坏只是 skip_labels
        # 里多塞了几个永远不会被生成的 label，对 runner 行为无副作用）。
        skip_labels = set()
        try:
            with open(sas_92_path, 'r', encoding='utf-8', errors='ignore') as f:
                _content = f.read()
            _out_names = re.findall(
                r'%batch_script_generator\s*\([\s\S]*?out\s*=\s*([a-zA-Z0-9_]+)',
                _content, re.IGNORECASE,
            )
            # force_type 模式下仍可能扫到非目标 type 段，但它们后续被 runner 跳过——
            # 这里不重复 force_type 过滤，宁可冲突清单多列几行供用户参考
            tools_dir = os.path.dirname(sas_92_path)
            conflicts = []
            for name in dict.fromkeys(_out_names):  # 去重保序
                if os.path.isfile(os.path.join(tools_dir, f"{name}.sas")):
                    conflicts.append(name)
            if conflicts:
                choice = self._prompt_overwrite_conflicts(conflicts)
                if choice is None:
                    # 用户取消，整次生成中止
                    self.sig_log.emit("<span style='color:#909399;'>> 用户取消生成（覆盖确认窗口已关闭）。</span>")
                    return
                if choice == "skip":
                    skip_labels = set(conflicts)
                # choice == "overwrite" → skip_labels 保持为空集，全量生成
        except Exception as _e:
            # 预探测失败不阻断生成，仅记一行日志（保留原有行为）
            self.sig_log.emit(
                f"<span style='color:#E6A23C;'>⚠️ 同名预探测失败，跳过覆盖检查继续生成：{_e}</span>"
            )

        # v12.3：仅"生成批处理脚本"触发日志面板清空（其他动作累加），
        # 让用户能看清"生成 → 单脚本运行 → Log/Compare Check"完整链路日志。
        self.sig_clear_log.emit()
        self.sig_run_started.emit()

        # v12.10.14：改回 setRange(0,0) 流动动画
        self.batch_prog.setRange(0, 0)
        self.batch_prog.setVisible(True)

        # v12.10.32：不再 _clear_matrix() —— 生成完成后由 _on_gen_finished 做"已有列表 + 新生成"
        # 的合并渲染，新脚本蓝色置顶；用户选"覆盖"则在 finished 阶段把同名旧条目从展示中剔除。

        self.sig_log.emit("<span style='color:#409EFF;'>> 启动 Batch Gen 引擎...</span>")
        self.sig_status.emit("⏳ 正在扫描 PDT 并生成脚本...", "#409EFF")

        self.gen_thread = BatchGenRunner(self.pdt_path, sas_92_path,
                                         concurrent_mode=True, force_type=self.force_type,
                                         skip_labels=skip_labels)
        self.gen_thread.log_signal.connect(self.sig_log.emit)

        # 进度文案 emit 到日志面板（流动条无 value，仅 setText 文案给用户看进度）
        self.gen_thread.progress_signal.connect(
            lambda v, m: self.sig_log.emit(f"<span style='color:#909399;'>{m}</span>"))
        self.gen_thread.finished_signal.connect(self._on_gen_finished)
        self.gen_thread.start()

    def _on_gen_finished(self, success, msg, issues, scripts):
        self.btn_cancel_gen.hide()
        self.btn_gen_batch.setEnabled(True)

        self.batch_prog.setRange(0, 100)
        self.batch_prog.setValue(100)
        self.batch_prog.setVisible(False)

        # v12.10.28：ADaM 模式 step 号 02 / TFLs 模式保持 04
        _step_no = "02" if self.force_type == "adam" else "04"

        if success:
            self.sig_status.emit(msg, "#67C23A")
            self.sig_step_update.emit(f"{_step_no} Batch Run ✅")
        else:
            self.sig_status.emit(msg, "#E6A23C")
            self.sig_step_update.emit(f"{_step_no} Batch Run ⚠️")

        if issues:
            for name, summary, log_text, source_label in issues:
                self.sig_log.emit(f"<br><b>[{name}] 日志明细:</b>")
                self.sig_log.emit(self._format_error_summary(log_text))

        # v12.10.32：合并渲染 —— 已有 tools 下的 batch_run 脚本 + 本次新生成的脚本
        #   - 本次新生成的 label 集合：new_labels
        #   - 用户若选"覆盖"，tools 中同名旧条目已被新生成的脚本物理覆盖（mtime 更新）；
        #     用户若选"跳过"，runner 端没生成同名脚本，旧条目仍是原文件 → 不视为新条目
        #   - "ui 中显示的永远和 tools 文件夹下真实的脚本是一致的"：重新扫一次 tools 拿到最终清单
        new_labels = set(s['label'] for s in scripts) if scripts else set()
        merged = self._scan_tools_batch_scripts()
        self._render_script_list(merged, new_labels=new_labels)

    def _open_log_chk_results(self):
        """打开 Log Check 结果文件夹（07_logs 下的 log_chk*.xml）"""
        path = os.path.join(self.base_path, "07_logs")
        try:
            if path and os.path.isdir(path):
                os.startfile(path)
            else:
                self.sig_log.emit(
                    f"<span style='color:#E6A23C;'>⚠️ 文件夹不存在：{path}</span>"
                )
        except Exception as e:
            self.sig_log.emit(f"<span style='color:#F56C6C;'>❌ 打开文件夹失败：{e}</span>")

    def _open_cmp_chk_results(self):
        """打开 Compare Check 结果文件夹（09_validation 下的 94_compare*.xml）

        v12.10.35：修复 bug —— 原先误指向 07_logs（与 Log Check 同目录），
        实际 %compare_chk 宏的 out=94_compare_..._&sysdate. 落在 09_validation。
        BatchRunForm 被 TFLs / ADaM(force_type=adam) / SDTM(SdtmBatchRunForm) 共用，
        此处一改三处生效。
        """
        path = os.path.join(self.base_path, "09_validation")
        try:
            if path and os.path.isdir(path):
                os.startfile(path)
            else:
                self.sig_log.emit(
                    f"<span style='color:#E6A23C;'>⚠️ 文件夹不存在：{path}</span>"
                )
        except Exception as e:
            self.sig_log.emit(f"<span style='color:#F56C6C;'>❌ 打开文件夹失败：{e}</span>")

    def _extract_batch_results(self, log_text):
        """从跑批日志中提取 FAILED / SUCCEED 结果"""
        if not log_text:
            return [], []
        pattern = re.compile(r'\[([^\]]+\.sas)\]\s*\|\s*Program execution \[(FAILED|SUCCEED)\]')
        succeeded, failed = [], []
        for match in pattern.finditer(log_text):
            path_str, status = match.group(1), match.group(2)
            if status == "FAILED":
                failed.append(path_str)
            else:
                succeeded.append(path_str)
        return succeeded, failed

    # ------------------------- 单脚本运行：事件绑定 -------------------------
    def _bind_single_run_events(self, lbl, path, btn_run, btn_cancel, prog_bar, status_lbl, detail_btn):
        """为动态列表中的每一行绑定"运行 / 中止 / 详情"三类按钮事件"""
        # v12.10.114：每行 prog_bar 各绑一个 MarqueeProgress（主线程 QTimer 驱动扫动），
        # 替代原生 setRange(0,0) 无限流——后者在 #LeftPanel stylesheet 子树下不滚动。
        # 作为闭包变量被 start_run / on_finish / cancel_run 捕获，随行的按钮连接一同存活；
        # timer parent=self（form），随表单析构，不会悬空。
        marquee = MarqueeProgress(prog_bar, self)

        def start_run():
            try:
                if not os.path.exists(path):
                    self.sig_log.emit(f"<span style='color:#F56C6C;'>❌ 错误：找不到目标跑批脚本 {path}</span>")
                    return

                btn_run.hide()
                btn_cancel.show()
                marquee.start()  # v12.10.114：QTimer 驱动扫动（替代 prog_bar.setVisible(True)+原生 busy）
                status_lbl.setText("⏳ 执行中...")
                status_lbl.setStyleSheet("border: none; font-size: 12px; color: #409EFF; font-weight: bold;")
                detail_btn.setVisible(False)

                self.sig_log.emit(f"<br><div style='text-align:center; color:#C0C4CC; font-size:11px; margin:6px 0;'>──────────── ▼ 跑批任务开始 ▼ ────────────</div>")
                self.sig_log.emit(
                    f"<span style='color:#409EFF; font-weight:bold;'>🚀 正在派发独立跑批任务：{lbl}，请耐心等待 SAS 引擎响应...</span>")

                thread = SingleBatchRunner(path)
                self.single_runners[lbl] = thread

                def on_finish(has_issue, summary, log_text):
                    try:
                        btn_run.show()
                        btn_cancel.hide()
                        marquee.stop()  # v12.10.114：停扫动 + 隐藏

                        succeeded, failed = self._extract_batch_results(log_text)
                        total = len(succeeded) + len(failed)

                        if total > 0:
                            parts = []
                            if succeeded:
                                parts.append(f"✅{len(succeeded)}")
                            if failed:
                                parts.append(f"❌{len(failed)}")
                            summary_text = " | ".join(parts)

                            if failed:
                                status_lbl.setText(f"❌ 失败 {len(failed)} 个")
                                status_lbl.setStyleSheet("border: none; font-size: 12px; color: #F56C6C; font-weight: bold;")
                                detail_btn.setVisible(True)
                                # 存储失败列表供详情弹窗使用
                                detail_btn.setProperty("failed_list", failed)
                                detail_btn.setProperty("succeeded_list", succeeded)
                                detail_btn.setProperty("task_label", lbl)
                            else:
                                status_lbl.setText(f"✅ 全部成功")
                                status_lbl.setStyleSheet("border: none; font-size: 12px; color: #67C23A; font-weight: bold;")

                            self.sig_log.emit(f"<b>📊 [{lbl}] 执行完毕 — {summary_text}</b>")
                            if failed:
                                self.sig_log.emit(f"<span style='color:#F56C6C;'>&nbsp;&nbsp;共 {len(failed)} 个程序失败，点击左侧「📋 详情」查看完整列表。</span>")
                        else:
                            status_lbl.setText("✅ 完毕")
                            status_lbl.setStyleSheet("border: none; font-size: 12px; color: #67C23A; font-weight: bold;")
                            self.sig_log.emit(f"<span style='color:#67C23A;'>✅ [{lbl}] 脚本执行完毕。</span>")

                        if has_issue:
                            self.sig_log.emit(f"<span style='color:#E6A23C;'>⚠️ [{lbl}] 日志存在 ERROR/WARNING: {summary}</span>")
                            self.sig_log.emit(self._format_error_summary(log_text))

                    except Exception as e:
                        import logging
                        logging.error(f"on_finish 回调异常: {e}", exc_info=True)

                thread.finished_signal.connect(on_finish)
                thread.start()

            except Exception as e:
                import logging
                logging.error(f"start_run 异常: {e}", exc_info=True)
                btn_run.show()
                btn_cancel.hide()
                marquee.stop()  # v12.10.114：异常时也停扫动 + 隐藏

        def cancel_run():
            if lbl in self.single_runners:
                t = self.single_runners[lbl]
                if t.isRunning():
                    t.is_cancelled = True
            btn_run.show()
            btn_cancel.hide()
            marquee.stop()  # v12.10.114：中止时停扫动 + 隐藏
            status_lbl.setText("🛑 已中止")
            status_lbl.setStyleSheet("border: none; font-size: 12px; color: #F56C6C; font-weight: bold;")
            self.sig_log.emit(f"<span style='color:#F56C6C; font-weight:bold;'>🛑 [{lbl}] 任务已被手动中止。</span>")

        def show_detail():
            failed = detail_btn.property("failed_list") or []
            succeeded = detail_btn.property("succeeded_list") or []
            task_label = detail_btn.property("task_label") or lbl
            self._show_result_detail_dialog(task_label, failed, succeeded)

        btn_run.clicked.connect(start_run)
        btn_cancel.clicked.connect(cancel_run)
        detail_btn.clicked.connect(show_detail)

    def _show_result_detail_dialog(self, task_label, failed, succeeded):
        """弹出可折叠的执行结果详情对话框"""
        from PySide6.QtWidgets import QDialog, QTextEdit
        dlg = QDialog(self)
        dlg.setWindowTitle(f"执行结果详情 — {task_label}")
        dlg.setMinimumSize(600, 420)
        dlg.setStyleSheet("QDialog { background-color: #FFFFFF; }")

        lay = QVBoxLayout(dlg)
        lay.setContentsMargins(20, 20, 20, 15)

        summary = QLabel(f"📊 <b>✅ 成功 {len(succeeded)} 个 | ❌ 失败 {len(failed)} 个</b>")
        summary.setStyleSheet("font-size: 15px; color: #303133;")
        lay.addWidget(summary)

        txt = QTextEdit()
        txt.setReadOnly(True)
        txt.setStyleSheet("font-family: Consolas; font-size: 12px; border: 1px solid #E4E7ED; border-radius: 4px; padding: 8px;")

        if failed:
            txt.append("<b style='color:#F56C6C;'>❌ 失败列表：</b>")
            for f_item in failed:
                txt.append(f"<span style='color:#F56C6C;'>&nbsp;&nbsp;✗ {html.escape(f_item)}</span>")
            txt.append("")

        if succeeded:
            txt.append("<b style='color:#67C23A;'>✅ 成功列表：</b>")
            for s_item in succeeded:
                txt.append(f"<span style='color:#67C23A;'>&nbsp;&nbsp;✓ {html.escape(s_item)}</span>")

        lay.addWidget(txt)

        btn_close = QPushButton("关闭")
        btn_close.setStyleSheet("background-color: #4A6FA5; color: white; border: none; padding: 8px 30px; border-radius: 4px; font-weight: bold;")
        btn_close.clicked.connect(dlg.accept)
        btn_lay = QHBoxLayout()
        btn_lay.addStretch()
        btn_lay.addWidget(btn_close)
        lay.addLayout(btn_lay)
        dlg.exec()

    # ------------------------- 生成阶段取消 -------------------------
    def cancel_generation(self):
        """中止正在进行的 BatchGenRunner（不影响已生成脚本的单独运行）"""
        if hasattr(self, 'gen_thread') and self.gen_thread.isRunning():
            self.gen_thread.is_cancelled = True
        self.btn_cancel_gen.hide()
        self.btn_gen_batch.setEnabled(True)
        self.batch_prog.setVisible(False)
        # v12.10.28：ADaM 模式 step 号 02 / TFLs 模式保持 04
        _step_no = "02" if self.force_type == "adam" else "04"
        self.sig_step_update.emit(f"{_step_no} Batch Run 🟥")
        self.sig_status.emit("🛑 已中止生成", "#F56C6C")
