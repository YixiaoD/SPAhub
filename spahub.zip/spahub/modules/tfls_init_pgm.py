# -*- coding: utf-8 -*-
"""
modules/tfls_init_pgm.py
========================
03 Initial PGM 模块。

职责：
  - 在 PROD 端生成 DEV/QC 初始程序（调用 91_initial_pgm_call.sas 或 61_ladae_template_call.sas）
  - 91 模式：拆分为 DEV / QC 两个任务，单线程顺序执行
  - 通过子进程 + 文件探针 (.done) 实现看门狗式强制中止，避免死锁
  - QC 自动跳过策略：PDT 中 [pgmnamqc] 列为空时不生成 QC 脚本
  - 合并日志：91_initial_pgm_call.log（DEV + QC 日志拼接）

并发策略（v12.10.66 起）：
  - UI 上不再提供"开启多线程并发加速"开关，单个任务永远走稳定的单线程顺序模式。
  - 用户如需并发，自行同时点击 91 和 61（每个起独立 QThread，彼此互不阻塞）。
  - InitPgmRunner.concurrent_mode 参数保留（默认 False），向后兼容。

文件结构：
  ├─ InitPgmRunner (QThread)       子进程 + watchdog 执行引擎
  └─ InitPgmForm  (QFrame)          左侧表单 + 双入口（91 / 61）
"""
import os
import re
import concurrent.futures
import subprocess
import sys
import pickle
import time
import uuid

from PySide6.QtWidgets import (QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                               QLineEdit, QFileDialog, QFrame, QProgressBar, QDialog, QCheckBox, QWidget)
from PySide6.QtCore import Qt, QThread, Signal

from sas_engine.executor import run_sas, review_log_from_content, convert_windows_path_to_linux, _extract_log_findings, \
    _build_log_summary
from ui_utils import show_dialog, primary_btn_style, danger_btn_style, success_btn_style, primary_outline_btn_style, scan_status_lbl_style

# v12.10.31：GitLab 推送子功能（仅 TFLs 模式启用，ADaM 模式下隐藏入口）。
# 解耦原则：所有 git 相关逻辑下沉到独立模块；本文件只承担 UI 入口和回调编排。
# v12.10.34：PullOnlyRunner 用于"仅 Pull 更新"按钮。
# v12.10.35：CredentialErrorDialog 用于 token 过期 / 撤销时的一键修复引导。
from modules.tfls_init_pgm_gitlab import (
    start_gitlab_push,
    GitlabPushProbeRunner, GitlabPushExecuteRunner, PullOnlyRunner,
    PullConfirmDialog, OutOfScopeDirtyDialog, CredentialErrorDialog,
    find_repo_root, parse_git_remote_url, git_current_branch,
    # v12.10.60：点击推送后把 git 采集挪到子线程，避免主界面卡死
    GitlabPushPrepareRunner, gitlab_push_after_prepare,
)


# =============================================================================
# 后台运行线程：子进程 + 看门狗
# =============================================================================
class InitPgmRunner(QThread):
    """
    执行 91/61 SAS 脚本的后台线程。

    关键设计：
      - 为每个子任务（DEV/QC/LADAE）生成一个临时 .sas，结尾追加写 .done 的探针
      - 用 subprocess 拉起独立 Python 子进程执行 run_sas，防止 SAS 挂起影响主进程
      - 轮询探针文件 .done 出现 → 判定 SAS 已完成 → 等待子进程自然退出 / 强杀
      - 所有临时产物（tmp.sas / tmp.log / tmp.done / tmp.res）在 finally 中清理
    """
    log_signal = Signal(str)
    progress_signal = Signal(int, str)
    finished_signal = Signal(bool, str, list)

    def __init__(self, mode, file_path, pdt_path="", concurrent_mode=False, force_type=None):
        """
        force_type: 可选 — 锁定 91_initial_pgm_call 的 TYPE= 段到指定值（如 "adam"）。
            None  → TFLs 模块行为：从 91_initial_pgm_call.sas 的 TYPE=%str(...) 段保留全部。
            "adam" → ADaM 模块行为：覆盖为 TYPE=%str(adam)，确保只生成 ADaM 的 dev/qc 程序。
        """
        super().__init__()
        self.mode = mode
        self.file_path = file_path
        self.pdt_path = pdt_path
        self.concurrent_mode = concurrent_mode
        self.force_type = (force_type or "").lower().strip() or None
        self.files_to_cleanup = []
        self.active_procs = []
        self.is_cancelled = False

    def run(self):
        try:
            tasks = []
            base_dir = os.path.dirname(self.file_path)

            if self.mode == "91":
                self.progress_signal.emit(10, "正在解析 91_initial_pgm_call.sas 提取参数...")

                skip_qc = False
                if getattr(self, 'pdt_path', "") and os.path.exists(self.pdt_path):
                    try:
                        import pandas as pd
                        df_dict = pd.read_excel(self.pdt_path, sheet_name=None)
                        has_qc = False
                        for sheet_name, d in df_dict.items():
                            lower_cols = [str(c).lower().strip() for c in d.columns]
                            if 'pgmnamqc' in lower_cols:
                                col_name = d.columns[lower_cols.index('pgmnamqc')]
                                val_series = d[col_name].iloc[2:].dropna()
                                valid_vals = [str(v).strip() for v in val_series
                                              if str(v).strip() and str(v).strip().lower() not in ('nan', 'none')]
                                if valid_vals:
                                    has_qc = True
                                    break
                        if not has_qc:
                            skip_qc = True
                            self.log_signal.emit(
                                "<span style='color:#E6A23C; font-weight:bold;'>⚠️ 提示：此 PDT 的 [pgmnamqc] 无记录，自动跳过 91_QC 程序生成。</span>")
                    except Exception:
                        pass

                try:
                    with open(self.file_path, 'r', encoding='utf-8', errors='replace') as f:
                        content = f.read()
                    match = re.search(r'(?i)TYPE\s*=\s*%str\([^)]*\)', content)
                    type_str = match.group(0) if match else "TYPE=%str(sdtm|adam|table|figure|listing)"
                except Exception:
                    type_str = "TYPE=%str(sdtm|adam|table|figure|listing)"

                # v12.10.11：force_type 模式下强制覆盖（ADaM 模块用 force_type="adam"）
                # 即使 91_initial_pgm_call.sas 里写的是 sdtm|adam|table|figure|listing，也只跑 adam
                # v12.10.27：保留"（仅限本模块）"4 字简短说明（用户原话）
                if self.force_type:
                    type_str = f"TYPE=%str({self.force_type})"
                    self.log_signal.emit(
                        f"<span style='color:#909399;'>&nbsp;&nbsp;锁定 type 限制：{type_str}（仅限本模块）</span>"
                    )

                uid = uuid.uuid4().hex[:6]
                dev_path = os.path.join(base_dir, f"91_init_dev_tmp_{uid}.sas")
                dev_done = dev_path + ".done"
                dev_res = dev_path + ".res"
                dev_done_linux = convert_windows_path_to_linux(dev_done)

                dev_code = f"data _null_;\n  if libref('adam') then call execute('%nrstr(%autorun)');\nrun;\n%initial_pgm(role=dev, {type_str});\n"
                dev_code += f"data _null_;\n  file '{dev_done_linux}';\n  put 'DONE';\nrun;\n"

                with open(dev_path, 'w', encoding='utf-8') as f:
                    f.write(dev_code)

                tasks = [("91_DEV 环境", dev_path, dev_done, dev_res)]
                self.files_to_cleanup.extend([dev_path, dev_path.replace('.sas', '.log'), dev_done, dev_res])

                # QC 端：仅当未跳过时才生成脚本文件，避免 skip_qc 情况下产生无法回收的残留
                if not skip_qc:
                    qc_path = os.path.join(base_dir, f"91_init_qc_tmp_{uid}.sas")
                    qc_done = qc_path + ".done"
                    qc_res = qc_path + ".res"
                    qc_done_linux = convert_windows_path_to_linux(qc_done)

                    qc_code = f"data _null_;\n  if libref('adam') then call execute('%nrstr(%autorun)');\nrun;\n%initial_pgm(role=qc, {type_str});\n"
                    qc_code += f"data _null_;\n  file '{qc_done_linux}';\n  put 'DONE';\nrun;\n"

                    with open(qc_path, 'w', encoding='utf-8') as f:
                        f.write(qc_code)

                    tasks.append(("91_QC 环境", qc_path, qc_done, qc_res))
                    self.files_to_cleanup.extend([qc_path, qc_path.replace('.sas', '.log'), qc_done, qc_res])

            else:
                self.progress_signal.emit(10, "正在准备执行 61_ladae_template 模板程序...")
                uid = uuid.uuid4().hex[:6]
                ladae_path = os.path.join(base_dir, f"61_init_ladae_tmp_{uid}.sas")
                ladae_done = ladae_path + ".done"
                ladae_res = ladae_path + ".res"
                ladae_done_linux = convert_windows_path_to_linux(ladae_done)

                with open(self.file_path, 'r', encoding='utf-8', errors='replace') as f:
                    ladae_content = f.read()
                ladae_code = ladae_content + f"\n\ndata _null_;\n  file '{ladae_done_linux}';\n  put 'DONE';\nrun;\n"

                with open(ladae_path, 'w', encoding='utf-8') as f:
                    f.write(ladae_code)

                tasks = [("61_LADAE 模板", ladae_path, ladae_done, ladae_res)]
                self.files_to_cleanup.extend([ladae_path, ladae_path.replace('.sas', '.log'), ladae_done, ladae_res])

            staggered_tasks = [(name, path, done_file, res_file, idx * 0.5) for idx, (name, path, done_file, res_file)
                               in enumerate(tasks)]

            issue_logs = []
            success_count = 0
            total_tasks = len(tasks)
            completed = 0
            log_contents_dict = {}
            # v12.10.30：spahub_dir 已不再用于子进程脚本字符串拼接，删除该局部计算

            max_workers = 3 if self.concurrent_mode else 1
            mode_str = "并发多线程(加速)" if self.concurrent_mode else "串行单线程(稳定)"
            self.log_signal.emit(f"<span style='color:#409EFF;'>> 启用 {mode_str} 模式，防挂死看门狗已启动...</span>")

            def run_sas_process(args):
                t_name, t_path, t_done, t_res, delay = args

                if delay > 0 and self.concurrent_mode:
                    for _ in range(int(delay * 10)):
                        if self.is_cancelled: return t_name, (True, "已取消", "", t_path)
                        time.sleep(0.1)

                if self.is_cancelled: return t_name, (True, "已取消", "", t_path)
                if os.path.exists(t_done): os.remove(t_done)
                if os.path.exists(t_res): os.remove(t_res)

                self.log_signal.emit(f"<span style='color:#409EFF;'>▶ 唤起 SAS 引擎: {t_name} ...</span>")

                # v12.10.30：用 app_paths.child_command_run_sas 工厂构造命令
                # frozen 模式 → [SASEG.exe, "--child", "run_sas", t_path, t_res]
                # 开发模式  → [python, "-c", code]（行为同旧版）
                from app_paths import child_command_run_sas
                cmd = child_command_run_sas(t_path, t_res)
                proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL,
                                        stderr=subprocess.DEVNULL,
                                        creationflags=0x08000000)
                self.active_procs.append(proc)

                killed_by_watchdog = False
                while proc.poll() is None:
                    if self.is_cancelled:
                        proc.kill()
                        return t_name, (True, "已强制中止", "", t_path)

                    if os.path.exists(t_done):
                        for _ in range(20):
                            if proc.poll() is not None: break
                            time.sleep(0.1)
                        if proc.poll() is None:
                            proc.kill()
                            killed_by_watchdog = True
                        break
                    time.sleep(1)

                result_tuple = None
                if os.path.exists(t_res):
                    try:
                        with open(t_res, 'rb') as f:
                            result_tuple = pickle.load(f)
                    except Exception:
                        pass

                if result_tuple:
                    return t_name, result_tuple

                log_path = t_path.replace('.sas', '.log')
                real_log_content = ""
                if os.path.exists(log_path):
                    try:
                        with open(log_path, 'r', encoding='utf-8', errors='replace') as f:
                            real_log_content = f.read()
                    except Exception:
                        pass

                findings = _extract_log_findings(real_log_content)
                summary = _build_log_summary(findings)
                has_issue = len(findings["errors"]) > 0 or len(findings["warnings"]) > 0

                if killed_by_watchdog and not summary:
                    summary = "✅ 运行成功 (探针确认执行完毕，看门狗安全接管)"
                    has_issue = False
                elif not summary:
                    summary = "❌ 运行完成（发现错误或警告）" if has_issue else "✅ 运行成功"

                return t_name, (has_issue, summary, real_log_content, t_path)

            with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                future_to_name = {executor.submit(run_sas_process, task): task[0] for task in staggered_tasks}
                for future in concurrent.futures.as_completed(future_to_name):
                    if self.is_cancelled: continue
                    name = future_to_name[future]
                    completed += 1
                    prog = 30 + int(60 * (completed / total_tasks))
                    self.progress_signal.emit(prog, f"已完成 {completed}/{total_tasks} 任务...")

                    try:
                        _, res = future.result()
                        has_issue, summary, log_text, source_label = res
                        log_contents_dict[name] = log_text if log_text else "[无日志返回]"

                        if has_issue:
                            issue_logs.append((name, summary, log_text, source_label))
                            self.log_signal.emit(
                                f"<span style='color:#F56C6C;'>⚠️ {name} 存在警告/错误: {summary}</span>")
                        else:
                            success_count += 1
                            self.log_signal.emit(f"<span style='color:#67C23A;'>✅ {name} 运行成功！</span>")
                    except Exception as e:
                        issue_logs.append((name, str(e), "", ""))
                        self.log_signal.emit(f"<span style='color:#F56C6C;'>❌ {name} 极度异常崩溃: {str(e)}</span>")

            if self.is_cancelled: return

            if self.mode == "91":
                merged_log_path = os.path.join(base_dir, "91_initial_pgm_call.log")
                try:
                    with open(merged_log_path, 'w', encoding='utf-8') as out_f:
                        for task_name in ["91_DEV 环境", "91_QC 环境"]:
                            content = log_contents_dict.get(task_name)
                            if content:
                                out_f.write(f"==========================================================\n")
                                out_f.write(f"=== LOG FROM: {task_name} ===\n")
                                out_f.write(f"==========================================================\n\n")
                                out_f.write(content)
                                out_f.write("\n\n")
                    self.log_signal.emit(
                        f"<span style='color:#67C23A;'>✅ 已合并全量日志至: 91_initial_pgm_call.log</span>")
                except Exception:
                    pass

            self.progress_signal.emit(100, "任务执行完毕！")

            if issue_logs:
                self.finished_signal.emit(False, f"共 {success_count} 个成功，{len(issue_logs)} 个异常。", issue_logs)
            else:
                self.finished_signal.emit(True, "✅ 选定程序均成功生成，完全干净！", [])

        except Exception as e:
            if not self.is_cancelled:
                self.progress_signal.emit(100, "生成中断")
                self.finished_signal.emit(False, f"❌ 严重错误: {str(e)}", [])

        finally:
            for f in self.files_to_cleanup:
                for _ in range(3):
                    try:
                        if os.path.exists(f):
                            os.remove(f)
                        break
                    except Exception:
                        time.sleep(0.5)


# =============================================================================
# 左侧表单组件 InitPgmForm
# =============================================================================
class InitPgmForm(QFrame):
    """
    Initial PGM 的左侧业务表单。

    左侧布局：
      - 顶部刷新按钮 + 扫描标签
      - 说明文字
      - 多线程并发勾选框
      - 进度条
      - 两行入口：91_initial_pgm_call / 61_ladae_template (各自带运行按钮)
      - 底部：中止并清理 / 打开 06_programs / 打开 09_validation
    """
    sig_log = Signal(str)
    sig_status = Signal(str, str)
    sig_step_update = Signal(str)
    sig_run_started = Signal()

    # v12.10.31：GitLab 推送相关信号 — 由 TFLsWidget 路由到右侧 Tab 2（Git 暂存面板）
    #   sig_gitlab_repo_info(repo_root, branch, remote_url)
    #     → update_paths 探测到仓库基本信息时 emit，给 Stash Panel 顶部信息条
    #   sig_gitlab_push_done(success, summary, status_dict)
    #     → Stage 2 Runner 完成时 emit，给 Stash Panel 刷新状态摘要 + commit 列表
    #   sig_gitlab_busy(busy)
    #     → push 期间 emit True，结束 emit False；用于禁用 / 启用右侧 Tab 2 的"重试"按钮
    sig_gitlab_repo_info = Signal(str, str, str)
    sig_gitlab_push_done = Signal(bool, str, dict)
    sig_gitlab_busy = Signal(bool)

    # ------------------------- 初始化 / UI -------------------------
    def __init__(self, force_type=None):
        """
        force_type: 可选 — 锁定 91_initial_pgm 的 TYPE= 段到指定值（如 "adam"）。
            None  → TFLs 模块行为：保留 91 脚本中原 TYPE=...（含 sdtm|adam|table|figure|listing）
            "adam" → ADaM 模块行为：强制 TYPE=%str(adam)，仅生成 ADaM 的 dev/qc 程序。
        """
        super().__init__()
        self.base_path = ""
        self.force_type = (force_type or "").lower().strip() or None
        # GitLab 推送的运行时状态（在 update_paths / push 流程中刷新）
        self._gitlab_repo_root = ""
        self._gitlab_branch = ""
        self._gitlab_remote_url = ""
        self._gitlab_probe_runner = None
        self._gitlab_exec_runner = None
        # v12.10.60：点击推送后的准备子线程（git 采集），完成前主界面不卡死
        self._gitlab_prepare_runner = None
        # 探测后保留的参数（Stage 1 → Stage 2 之间）
        self._gitlab_pending = None  # dict: selected_files / commit_msg
        # v12.10.34：仅 Pull 更新（独立于 push 主流程）
        self._gitlab_pull_runner = None
        self._setup_ui()

    def _setup_ui(self):
        self.setObjectName("LeftPanel")
        self.setStyleSheet("#LeftPanel { background-color: #FFFFFF; border: 1px solid #E4E7ED; border-radius: 6px; }")
        form_layout = QVBoxLayout(self)
        form_layout.setAlignment(Qt.AlignTop)
        form_layout.setContentsMargins(25, 25, 25, 25)
        form_layout.setSpacing(15)

        self._step_name = "Initial PGM"
        top_bar = QHBoxLayout()
        self.refresh_btn = QPushButton("🔄 刷新源文件")
        # v12.10.65：统一改用 home"📁 系统文件复制"同款蓝色外框样式（浅蓝底+蓝字+hover 翻转白字）
        self.refresh_btn.setStyleSheet(primary_outline_btn_style())
        self.refresh_btn.setCursor(Qt.PointingHandCursor)
        top_bar.addWidget(self.refresh_btn)
        self.scan_lbl = QLabel("")
        self.scan_lbl.setStyleSheet(scan_status_lbl_style())
        top_bar.addWidget(self.scan_lbl)
        top_bar.addStretch()
        form_layout.addLayout(top_bar)

        # v12.10.24: ADaM 模式下不显示 61_ladae_template 相关说明（仅 91 在 prod 端生成 ADaM dev/qc）
        if self.force_type == "adam":
            lbl = QLabel("基于 91_initial_pgm 在 PROD 端生成 ADaM 的 DEV/QC 初始程序（已锁定 type=adam）。")
        else:
            lbl = QLabel("基于 91_initial_pgm 和 61_ladae_template 在 PROD 端生成 DEV/QC 初始程序。")
        lbl.setStyleSheet("color: #303133; font-weight: bold; font-size: 14px; border: none;")
        lbl.setWordWrap(True)
        form_layout.addWidget(lbl)

        # v12.10.66：移除"开启多线程并发加速"checkbox。
        # 旧设计是单个 91/61 任务内部拆 DEV/QC 多线程并发；新策略改为"由用户同时点
        # 多个任务"实现并发（91 与 61 各自起 QThread，相互独立）— 既透明又稳定，
        # 避免 SAS 端因并发竞争出现偶发卡顿/报错。
        # InitPgmRunner 内的 concurrent_mode 逻辑保留不动（默认 False），向后兼容。

        self.pgm_prog = QProgressBar()
        self.pgm_prog.setVisible(False)
        self.pgm_prog.setFixedHeight(4)
        form_layout.addWidget(self.pgm_prog)

        def add_row(label_text, filter_str):
            l = QHBoxLayout()
            lbl = QLabel(label_text)
            lbl.setStyleSheet("border: none; color: #606266; min-width: 130px;")
            l.addWidget(lbl)
            entry = QLineEdit()
            entry.setStyleSheet("padding: 6px; border: 1px solid #DCDFE6; border-radius: 4px;")
            l.addWidget(entry)
            b = QPushButton("浏览")
            b.setStyleSheet(
                "background-color: #F5F7FA; color: #606266; border: 1px solid #DCDFE6; padding: 6px 12px; border-radius: 4px;")
            b.clicked.connect(lambda checked=False, e=entry, f=filter_str: e.setText(
                QFileDialog.getOpenFileName(self, "选择文件",
                    os.path.dirname(e.text()) if os.path.isfile(e.text()) else self.base_path, f)[0] or e.text()))
            l.addWidget(b)
            return l, entry

        l91, self.sas_91_entry = add_row("1. 91_initial_pgm_call:", "*.sas")
        self.run_91_btn = QPushButton("▶ 运行")
        self.run_91_btn.setStyleSheet(
            "QPushButton { background-color: #4A6FA5; color: white; border: none; "
            "padding: 6px 12px; border-radius: 4px; font-weight: bold; }"
            "QPushButton:hover { background-color: #6385B6; }"
            "QPushButton:pressed { background-color: #3A5687; }"
            "QPushButton:disabled { background-color: #B0B9D1; }"
        )
        self.run_91_btn.setCursor(Qt.PointingHandCursor)
        self.run_91_btn.clicked.connect(lambda: self.execute_pgm("91"))
        l91.addWidget(self.run_91_btn)
        form_layout.addLayout(l91)

        l61, self.sas_61_entry = add_row("2. 61_ladae_template:", "*.sas")
        self.run_61_btn = QPushButton("▶ 运行")
        self.run_61_btn.setStyleSheet(
            "QPushButton { background-color: #4A6FA5; color: white; border: none; "
            "padding: 6px 12px; border-radius: 4px; font-weight: bold; }"
            "QPushButton:hover { background-color: #6385B6; }"
            "QPushButton:pressed { background-color: #3A5687; }"
            "QPushButton:disabled { background-color: #B0B9D1; }"
        )
        self.run_61_btn.setCursor(Qt.PointingHandCursor)
        self.run_61_btn.clicked.connect(lambda: self.execute_pgm("61"))
        l61.addWidget(self.run_61_btn)
        # v12.10.24：把 61 行包进 QWidget 容器，便于 ADaM 模式下整行隐藏。
        #   保留 sas_61_entry / run_61_btn 属性（下游 update_paths / cancel_pgm /
        #   execute_pgm 仍引用它们），仅控制可见性 — 改动最小，不破坏其它代码路径。
        self._row61_w = QWidget()
        self._row61_w.setLayout(l61)
        if self.force_type == "adam":
            self._row61_w.setVisible(False)
        form_layout.addWidget(self._row61_w)

        bl = QHBoxLayout()
        self.pgm_cancel_btn = QPushButton("🟥 中止并清理")
        # outline-style cancel：浅粉底 + 红字 + 红边
        self.pgm_cancel_btn.setStyleSheet(
            "QPushButton { background-color: #FEF0F0; color: #F56C6C; "
            "border: 1px solid #FBC4C4; padding: 8px 20px; border-radius: 4px; font-weight: bold; }"
            "QPushButton:hover { background-color: #FDE2E2; border-color: #F56C6C; }"
            "QPushButton:pressed { background-color: #FBD0D0; }"
        )
        self.pgm_cancel_btn.setCursor(Qt.PointingHandCursor)
        self.pgm_cancel_btn.setVisible(False)
        self.pgm_cancel_btn.clicked.connect(self.cancel_pgm)
        bl.addWidget(self.pgm_cancel_btn)

        pgm_open_btn = QPushButton("📂 打开 06_programs")
        pgm_open_btn.setStyleSheet(success_btn_style())
        pgm_open_btn.setCursor(Qt.PointingHandCursor)
        pgm_open_btn.clicked.connect(
            lambda: os.startfile(os.path.join(self.base_path, "06_programs")) if os.path.exists(
                os.path.join(self.base_path, "06_programs")) else None)
        bl.addWidget(pgm_open_btn)

        pgm_open_qc_btn = QPushButton("📂 打开 09_validation")
        pgm_open_qc_btn.setStyleSheet(success_btn_style())
        pgm_open_qc_btn.setCursor(Qt.PointingHandCursor)
        pgm_open_qc_btn.clicked.connect(
            lambda: os.startfile(os.path.join(self.base_path, "09_validation")) if os.path.exists(
                os.path.join(self.base_path, "09_validation")) else None)
        bl.addWidget(pgm_open_qc_btn)

        # v12.10.31：🚀 推送至 GitLab —— 仅 TFLs 模式显示（ADaM 模式下整钮隐藏）
        # 视觉：与"开始批处理"同色系（#409EFF 蓝），跟绿色"打开 06/09"按钮拉开层级，
        #       提示这是个"网络写操作"，比纯目录跳转更重的动作。
        self.btn_push_gitlab = QPushButton("🚀 推送至 GitLab")
        self.btn_push_gitlab.setStyleSheet(
            "QPushButton { background-color: #4A6FA5; color: white; border: none; "
            "padding: 8px 18px; border-radius: 4px; font-weight: bold; }"
            "QPushButton:hover { background-color: #6385B6; }"
            "QPushButton:pressed { background-color: #3A5687; }"
            "QPushButton:disabled { background-color: #B0B9D1; }"
        )
        self.btn_push_gitlab.setCursor(Qt.PointingHandCursor)
        self.btn_push_gitlab.setToolTip(
            "将 06_programs / 09_validation / utility/macros 下选中的 *.sas\n"
            "推送到对应 GitLab 仓库（远端 URL 自动读 .git/config）")
        self.btn_push_gitlab.clicked.connect(self._open_gitlab_push_dialog)
        if self.force_type == "adam":
            self.btn_push_gitlab.setVisible(False)
        bl.addWidget(self.btn_push_gitlab)

        bl.addStretch()
        form_layout.addLayout(bl)
        form_layout.addStretch()

    # ------------------------- 路径 / 等待提示 -------------------------
    def update_paths(self, base_path, pdt_path=""):
        """由主控推送路径；自动定位两个 SAS 脚本，文件不存在时置空"""
        self.base_path = base_path
        self.pdt_path = pdt_path
        tools_dir = os.path.join(base_path, "utility", "tools")

        sas_91 = os.path.join(tools_dir, "91_initial_pgm_call.sas")
        self.sas_91_entry.setText(sas_91 if os.path.isfile(sas_91) else "")

        sas_61 = os.path.join(tools_dir, "61_ladae_template_call.sas")
        self.sas_61_entry.setText(sas_61 if os.path.isfile(sas_61) else "")

        # v12.10.31：探测 git 仓库信息推给右侧 Tab 2（Git 暂存面板）。
        # 仅 TFLs 模式做（ADaM 模式不暴露 GitLab 入口，没必要做无用功）。
        if self.force_type != "adam" and base_path:
            self._refresh_gitlab_repo_info()

    def _refresh_gitlab_repo_info(self):
        """读取 .git/config 中的 origin URL + 当前分支，emit 给 Stash Panel。"""
        repo_root = find_repo_root(self.base_path) if self.base_path else ""
        remote_url = parse_git_remote_url(repo_root, "origin") if repo_root else ""
        branch = git_current_branch(repo_root) if repo_root else ""

        self._gitlab_repo_root = repo_root
        self._gitlab_branch = branch
        self._gitlab_remote_url = remote_url
        self.sig_gitlab_repo_info.emit(repo_root, branch, remote_url)

    def set_wait_hint(self, show):
        """控制左侧上方等待提示的显隐"""
        if show:
            self.scan_lbl.setText("⏳ 等待填写完整路径...")
            self.scan_lbl.setStyleSheet(scan_status_lbl_style())
        else:
            self.scan_lbl.setText("")

    # ============================================================================
    # 全局快捷键钩子：F5 由 TFLsWidget 路由到此处
    # 说明：本 step 有 91 / 61 两个独立运行按钮，Ctrl+Enter 语义不明确，故不实现
    # action_run。按下时主窗口路由发现没有该方法会自动空操作。
    # ============================================================================
    def action_refresh(self):
        """F5：点击"🔄 刷新源文件"。"""
        btn = getattr(self, "refresh_btn", None)
        if btn is not None and btn.isEnabled():
            btn.click()

    # ------------------------- 执行 / 取消 / 回调 -------------------------
    def execute_pgm(self, mode):
        """点击运行按钮：校验输入 → 禁用按钮 → 启动后台线程"""
        # 校验输入框是否为空或文件是否存在
        target_path = self.sas_91_entry.text().strip() if mode == "91" else self.sas_61_entry.text().strip()
        mod_name = "91_initial_pgm_call" if mode == "91" else "61_ladae_template_call"

        if not target_path:
            show_dialog(self, "错误", f"{mod_name} 路径不能为空！", "error")
            return
        if not os.path.exists(target_path):
            show_dialog(self, "错误", f"找不到文件：\n{target_path}", "error")
            return

        self.sig_run_started.emit()
        self.run_91_btn.setEnabled(False)
        self.run_61_btn.setEnabled(False)
        self.pgm_cancel_btn.show()

        self.pgm_prog.setRange(0, 0)
        self.pgm_prog.setVisible(True)

        target_path = self.sas_91_entry.text().strip() if mode == "91" else self.sas_61_entry.text().strip()
        mod_name = "91_initial_pgm" if mode == "91" else "61_ladae_template"

        self.sig_log.emit(f"<span style='color:#409EFF;'>> 启动 {mod_name} 引擎...</span>")
        self.sig_status.emit(f"⏳ 正在执行 {mod_name} 中...", "#409EFF")

        self.pgm_thread = InitPgmRunner(mode=mode, file_path=target_path, pdt_path=getattr(self, 'pdt_path', ""),
                                        force_type=self.force_type)
        self.pgm_thread.log_signal.connect(self._on_pgm_log)
        self.pgm_thread.progress_signal.connect(self._on_pgm_progress)
        self.pgm_thread.finished_signal.connect(self._on_pgm_finished)
        self.pgm_thread.start()

    def _on_pgm_log(self, text):
        self.sig_log.emit(text)

    def _on_pgm_progress(self, val, msg):
        self.pgm_prog.setValue(val)
        self.sig_log.emit(f"<span style='color:#606266;'>{msg}</span>")

    def _format_error_summary(self, log_content):
        issues = [l.strip() for l in log_content.splitlines() if re.match(r'^\s*(ERROR|WARNING)\s*:', l, re.I)]

        if not issues:
            return "未探测到具体 ERROR/WARNING 行（可能是接口通讯异常，请查阅完整日志）。"

        def _style_line(line):
            if line.upper().startswith("ERROR"):
                return f"<span style='color:#F56C6C;'>{line}</span>"
            return f"<span style='color:#E6A23C;'>{line}</span>"

        if len(issues) <= 10:
            return "<br>".join([_style_line(e) for e in issues])

        clusters = {}
        for e in issues:
            prefix = e[:40]
            if prefix not in clusters:
                clusters[prefix] = e

        display = list(clusters.values())[:3]
        res = "<br>".join([_style_line(e) for e in display])
        return f"{res}<br><i style='color:#909399;'>... (由于相似记录过多，已智能折叠其余 {len(issues) - 3} 条。详细内容请点击上方【📄 打开合并日志】查阅)</i>"

    def _on_pgm_finished(self, success, msg, issue_logs):
        self.pgm_cancel_btn.hide()
        self.run_91_btn.setEnabled(True)
        self.run_61_btn.setEnabled(True)

        self.pgm_prog.setRange(0, 100)
        self.pgm_prog.setValue(100)
        self.pgm_prog.setVisible(False)

        # v12.10.28：ADaM 模式 step 号 01 / TFLs 模式保持 03
        _step_no = "01" if self.force_type == "adam" else "03"

        if success:
            self.sig_status.emit(msg, "#67C23A")
            self.sig_step_update.emit(f"{_step_no} Initial PGM ✅")
        else:
            if not issue_logs:
                self.sig_status.emit(msg, "#F56C6C")
                self.sig_step_update.emit(f"{_step_no} Initial PGM ❌")
            else:
                self.sig_status.emit("⚠️ 部分程序生成存在警告/错误，请严格核对！", "#E6A23C")
                self.sig_step_update.emit(f"{_step_no} Initial PGM ⚠️")

            for name, summary, log_text, source_label in issue_logs:
                self.sig_log.emit(f"<br><b>[{name}] 异常摘要:</b>")
                self.sig_log.emit(self._format_error_summary(log_text))

    def cancel_pgm(self):
        if hasattr(self, 'pgm_thread') and self.pgm_thread.isRunning():
            self.pgm_thread.is_cancelled = True
            for proc in self.pgm_thread.active_procs:
                try:
                    proc.kill()
                except Exception:
                    pass
            self.pgm_thread.wait()

        self.pgm_cancel_btn.hide()
        self.run_91_btn.setEnabled(True)
        self.run_61_btn.setEnabled(True)
        self.pgm_prog.setVisible(False)

        self.sig_status.emit("🛑 已中止", "#F56C6C")
        # v12.10.28：ADaM 模式 step 号 01 / TFLs 模式保持 03
        _step_no = "01" if self.force_type == "adam" else "03"
        self.sig_step_update.emit(f"{_step_no} Initial PGM 🟥")
        self.sig_log.emit(
            "<span style='color:#F56C6C; font-weight:bold;'>[已中止] 🛑 进程已强杀，相关临时文件已安全清理。</span>")

    # ============================================================================
    # v12.10.31：GitLab 推送编排（Stage 1 探测 → 用户决策 → Stage 2 执行）
    # ============================================================================
    def _gitlab_is_busy(self) -> bool:
        """判断当前是否正在 push 或 pull（Initial PGM 这一步是否被占用）。"""
        # v12.10.60：准备子线程（采集阶段）也算 busy，防止重复点击发起多次采集
        if self._gitlab_prepare_runner is not None and self._gitlab_prepare_runner.isRunning():
            return True
        if self._gitlab_probe_runner is not None and self._gitlab_probe_runner.isRunning():
            return True
        if self._gitlab_exec_runner is not None and self._gitlab_exec_runner.isRunning():
            return True
        # v12.10.34：仅 Pull 也算 busy（同样会动 git ref，不能与 push/91/61 并发）
        if self._gitlab_pull_runner is not None and self._gitlab_pull_runner.isRunning():
            return True
        return False

    def _pgm_is_busy(self) -> bool:
        """判断当前是否在跑 91/61 SAS 任务。"""
        return hasattr(self, 'pgm_thread') and self.pgm_thread is not None \
               and self.pgm_thread.isRunning()

    def _open_gitlab_push_dialog(self):
        """按钮回调：先做互斥检查，再交给 start_gitlab_push 起准备子线程（采集→对话框→Stage 1）。"""
        # 互斥 1：91/61 任务在跑，不允许 push
        if self._pgm_is_busy():
            show_dialog(self, "GitLab 推送",
                        "当前 91/61 SAS 任务还在执行中，请等待完成或先中止后再推送。",
                        "warning")
            return
        # 互斥 2：上一轮 push 还没完
        if self._gitlab_is_busy():
            show_dialog(self, "GitLab 推送",
                        "当前已有推送任务在执行中，请等待完成。",
                        "warning")
            return
        if not self.base_path:
            show_dialog(self, "GitLab 推送", "尚未识别项目路径。", "warning")
            return

        # v12.10.60：start_gitlab_push 现在只做秒级校验 + 起准备子线程即返回，
        # 不再在主线程同步跑 git，点击后窗口立即可响应。采集完成后回调
        # _on_gitlab_prepare_done → gitlab_push_after_prepare 弹树形对话框 + 启动 Stage 1。
        start_gitlab_push(self, self.base_path)

    def _on_gitlab_prepare_done(self, result: dict):
        """v12.10.60：准备子线程（GitlabPushPrepareRunner）采集完成回调（主线程执行）。

        清掉 runner 引用后交给 gitlab_push_after_prepare 接管所有对话框流程。
        忙碌态的复位由 gitlab_push_after_prepare 内部按分支处理（提前返回路径复位，
        进入 Stage 1 / Pull 的路径不复位、由对应 done 回调复位）。
        """
        self._gitlab_prepare_runner = None
        gitlab_push_after_prepare(self, result)

    def _gitlab_start_probe(self, repo_root: str, branch: str, remote_url: str,
                            selected_files: list, commit_msg: str):
        """由 start_gitlab_push 在用户确认对话框后调用，启动 Stage 1（探测）。"""
        # 缓存仓库信息（重试用 + emit 给 Stash Panel 顶部）
        self._gitlab_repo_root = repo_root
        self._gitlab_branch = branch
        self._gitlab_remote_url = remote_url
        self._gitlab_pending = {
            "selected_files": selected_files,
            "commit_msg": commit_msg,
        }
        self.sig_gitlab_repo_info.emit(repo_root, branch, remote_url)

        # UI 互斥反馈
        self._gitlab_set_buttons_busy(True)
        self.sig_log.emit(
            "<br><span style='color:#409EFF; font-weight:bold;'>"
            "[🚀 GitLab 推送]</span>"
            f"<span style='color:#909399;'>  仓库: {repo_root}  |  分支: {branch}</span>")
        self.sig_log.emit(
            f"<span style='color:#909399;'>  待推 {len(selected_files)} 个 SAS 文件，"
            f"commit msg: <i>{commit_msg[:80]}{'...' if len(commit_msg) > 80 else ''}</i></span>")

        # 启动 Stage 1
        self._gitlab_probe_runner = GitlabPushProbeRunner(
            repo_root=repo_root, branch=branch, selected_files=selected_files,
        )
        self._gitlab_probe_runner.sig_log.connect(self.sig_log.emit)
        self._gitlab_probe_runner.sig_done.connect(self._on_gitlab_probe_done)
        self._gitlab_probe_runner.start()

    def _on_gitlab_probe_done(self, result: dict):
        """Stage 1 完成回调：根据 result 决定弹哪些对话框，然后启动 Stage 2 或终止。"""
        # 释放探测 thread
        self._gitlab_probe_runner = None

        if not result.get("ok"):
            err = result.get("error") or "探测失败（未知原因）"
            self.sig_log.emit(
                f"<span style='color:#F56C6C; font-weight:bold;'>"
                f"[❌ 推送中止] {err}</span>")
            # v12.10.35: 认证错误 → 弹友好对话框（一键打开凭据管理器 / GitLab）
            if result.get("error_type") == "auth":
                self._show_credential_error_dialog(result.get("error_stderr", ""))
            self.sig_gitlab_push_done.emit(False, err, {})
            self._gitlab_set_buttons_busy(False)
            self._gitlab_pending = None
            return

        # 1. 决定 do_stash：是否存在范围外脏文件
        outside = result.get("dirty_outside_scope") or []
        do_stash = False
        if outside:
            dlg = OutOfScopeDirtyDialog(self, outside)
            if dlg.exec() != QDialog.Accepted:
                # 用户关闭窗口（点 X），按取消处理
                self._gitlab_log_user_cancel()
                return
            if dlg.choice == OutOfScopeDirtyDialog.CHOICE_CANCEL:
                self._gitlab_log_user_cancel()
                return
            do_stash = (dlg.choice == OutOfScopeDirtyDialog.CHOICE_STASH)
            self.sig_log.emit(
                f"<span style='color:#606266;'>  用户选择处理方式: <b>{dlg.choice}</b></span>")

        # 2. 决定 do_pull：远端是否领先
        behind = result.get("behind") or 0
        do_pull = False
        if behind > 0:
            recent = result.get("recent_log") or []
            dlg2 = PullConfirmDialog(self, self._gitlab_branch, behind, recent)
            if dlg2.exec() != QDialog.Accepted:
                self._gitlab_log_user_cancel(
                    "用户拒绝 Pull，本次推送取消（注意：尚未生成 commit，本地状态未变）")
                return
            do_pull = True

        # 3. 启动 Stage 2
        pending = self._gitlab_pending or {}
        if not pending.get("selected_files"):
            self._gitlab_log_user_cancel("勾选文件丢失（探测后状态异常），推送中止")
            return

        self._gitlab_exec_runner = GitlabPushExecuteRunner(
            repo_root=self._gitlab_repo_root,
            branch=self._gitlab_branch,
            selected_files=pending["selected_files"],
            commit_msg=pending["commit_msg"],
            do_stash=do_stash, do_pull=do_pull,
        )
        self._gitlab_exec_runner.sig_log.connect(self.sig_log.emit)
        self._gitlab_exec_runner.sig_progress.connect(self._on_gitlab_progress)
        self._gitlab_exec_runner.sig_done.connect(self._on_gitlab_execute_done)
        self._gitlab_exec_runner.start()

    def _on_gitlab_progress(self, val: int, msg: str):
        """Stage 2 进度回调 — 复用 pgm_prog 显示，但加蓝色提示前缀避免与 91/61 混淆。"""
        if val >= 100:
            self.pgm_prog.setRange(0, 100)
            self.pgm_prog.setValue(100)
        else:
            self.pgm_prog.setRange(0, 100)
            self.pgm_prog.setValue(val)
        self.pgm_prog.setVisible(True)

    def _on_gitlab_execute_done(self, success: bool, summary: str, status_dict: dict):
        """Stage 2 完成：emit 给 Stash Panel，恢复按钮，输出最终摘要日志。"""
        self._gitlab_exec_runner = None
        self._gitlab_pending = None
        self.pgm_prog.setVisible(False)
        self._gitlab_set_buttons_busy(False)

        # 推给右侧 Tab 2
        self.sig_gitlab_push_done.emit(success, summary, status_dict)

        # 日志总结
        if success:
            color = "#67C23A"
            icon = "✅"
            if status_dict.get("stash_pop_failed"):
                color = "#E6A23C"
                icon = "⚠️"
            self.sig_log.emit(
                f"<span style='color:{color}; font-weight:bold;'>"
                f"[GitLab 推送] {icon} {summary}</span>")
        else:
            self.sig_log.emit(
                f"<span style='color:#F56C6C; font-weight:bold;'>"
                f"[GitLab 推送] ❌ {summary}</span>")
            if status_dict.get("has_local_commit"):
                self.sig_log.emit(
                    "<span style='color:#E6A23C;'>"
                    "  本地 commit 已保留，可在右侧 [Git 暂存] tab 点 [🔁 重试推送]。</span>")
            # v12.10.35: 认证错误 → 弹友好对话框
            if status_dict.get("error_type") == "auth":
                self._show_credential_error_dialog(status_dict.get("error_stderr", ""))

    def _gitlab_log_user_cancel(self, extra_msg: str = ""):
        """用户取消时统一处理：清状态 + 输出日志 + emit 给 Stash Panel。"""
        msg = extra_msg or "用户取消了推送"
        self.sig_log.emit(
            f"<span style='color:#909399; font-weight:bold;'>[GitLab 推送] 🛑 {msg}</span>")
        # 不 emit sig_gitlab_push_done — 因为本质上没"完成一次 push"，
        # Stash Panel 当前状态保持不变即可
        self._gitlab_set_buttons_busy(False)
        self._gitlab_pending = None

    def _gitlab_set_buttons_busy(self, busy: bool):
        """push 期间禁用 91/61 + push 按钮；结束后恢复。"""
        # 91/61 按钮：push 在跑时不让用户启动 SAS 任务
        if hasattr(self, 'run_91_btn'):
            self.run_91_btn.setEnabled(not busy)
        if hasattr(self, 'run_61_btn'):
            self.run_61_btn.setEnabled(not busy)
        if hasattr(self, 'btn_push_gitlab'):
            self.btn_push_gitlab.setEnabled(not busy)
            if busy:
                self.btn_push_gitlab.setText("⏳ 推送中...")
            else:
                self.btn_push_gitlab.setText("🚀 推送至 GitLab")
        self.sig_gitlab_busy.emit(busy)

    def trigger_gitlab_push(self):
        """供右侧 Tab 2 的"🔁 重试推送"调用：等价于点击 push 按钮。"""
        self._open_gitlab_push_dialog()

    # ----------------------------------------------------------------------------
    # v12.10.34：仅 Pull 更新（git pull --ff-only，安全的单纯同步）
    # ----------------------------------------------------------------------------
    def _gitlab_start_pull_only(self, repo_root: str, branch: str, remote_url: str):
        """
        由 start_gitlab_push 在用户点"🔄 仅 Pull 更新"时调用。

        启动 PullOnlyRunner 后台执行 `git fetch + git merge --ff-only`，
        完成后弹结果对话框，给用户选是否继续打开 push 流程。

        与 push 主流程的关键区别：
          - 不需要 commit msg / 文件选择
          - 不动 working tree（除非 ff 真发生）
          - 不会留 MERGE_HEAD（git 拒绝时本地状态零变化）
          - 与 push 共享 _gitlab_is_busy 判定，互斥
        """
        # 缓存仓库信息（与 push 流程一致，便于后续重开 push 对话框）
        self._gitlab_repo_root = repo_root
        self._gitlab_branch = branch
        self._gitlab_remote_url = remote_url

        # UI 互斥反馈（与 push 同样 disable 91/61 + push 按钮）
        self._gitlab_set_buttons_busy(True)
        self.sig_log.emit(
            "<br><span style='color:#409EFF; font-weight:bold;'>"
            "[🔄 GitLab 仅 Pull]</span>"
            f"<span style='color:#909399;'>  仓库: {repo_root}  |  分支: {branch}</span>")

        # 启动 thread
        self._gitlab_pull_runner = PullOnlyRunner(
            repo_root=repo_root, branch=branch)
        self._gitlab_pull_runner.sig_log.connect(self.sig_log.emit)
        self._gitlab_pull_runner.sig_done.connect(self._on_gitlab_pull_only_done)
        self._gitlab_pull_runner.start()

    def _on_gitlab_pull_only_done(self, success: bool, summary: str, status_dict: dict):
        """
        Pull 完成回调。

        UI 反馈：
          - 成功 → QMessageBox 显示更新摘要 + "是否打开推送对话框" 选项
          - 失败 → QMessageBox 显示原因 + 引导（如 diverged 时建议走 push 流程，
                   dirty_tree 时提示先 commit/stash）
        """
        self._gitlab_pull_runner = None
        self._gitlab_set_buttons_busy(False)

        reason = status_dict.get("reason", "other")
        from PySide6.QtWidgets import QMessageBox

        if success:
            # 成功 — 摘要日志 + 提供"打开推送对话框"快捷入口
            self.sig_log.emit(
                f"<span style='color:#67C23A; font-weight:bold;'>"
                f"[🔄 GitLab 仅 Pull] {summary}</span>")

            box = QMessageBox(self)
            box.setWindowTitle("Pull 完成")
            box.setIcon(QMessageBox.Information)
            box.setText(summary)
            updated = status_dict.get("updated_count", 0)
            if updated > 0:
                box.setInformativeText(
                    f"本地分支已 fast-forward {updated} 个 commit。\n\n"
                    "是否打开推送对话框，查看是否还有要推送的文件？")
                btn_push = box.addButton("继续推送 →", QMessageBox.AcceptRole)
                btn_close = box.addButton("关闭", QMessageBox.RejectRole)
                box.setDefaultButton(btn_close)
                box.exec()
                if box.clickedButton() == btn_push:
                    # 重新进入 push 流程（文件列表可能因 ff 而变）
                    self._open_gitlab_push_dialog()
            else:
                # behind=0 — 本地已最新，无需 ff
                box.setInformativeText("无需任何更新操作。")
                box.exec()
        else:
            # 失败 — 根据 reason 给针对性引导
            self.sig_log.emit(
                f"<span style='color:#F56C6C; font-weight:bold;'>"
                f"[🔄 GitLab 仅 Pull] ❌ {summary}</span>")

            # v12.10.35: 认证错误 → 直接弹 CredentialErrorDialog（更详细引导）
            if status_dict.get("error_type") == "auth" or reason == "auth":
                self._show_credential_error_dialog(status_dict.get("stderr", ""))
                return

            box = QMessageBox(self)
            box.setWindowTitle("Pull 未执行")
            box.setText(summary)
            stderr = status_dict.get("stderr", "")
            if reason == "diverged":
                box.setIcon(QMessageBox.Warning)
                box.setInformativeText(
                    "建议：点击【🚀 推送至 GitLab】，主推送流程会自动 pull (含 merge commit) 再 push。")
                if stderr:
                    box.setDetailedText(stderr)
            elif reason == "dirty_tree":
                box.setIcon(QMessageBox.Warning)
                box.setInformativeText(
                    "建议：在仓库根执行 `git status` 查看脏文件，先 commit 或 stash 后再 Pull。")
                if stderr:
                    box.setDetailedText(stderr)
            elif reason == "network":
                box.setIcon(QMessageBox.Critical)
                box.setInformativeText("请检查 GitLab 服务器连通性 / VPN / 凭据。")
                if stderr:
                    box.setDetailedText(stderr)
            else:
                box.setIcon(QMessageBox.Critical)
                if stderr:
                    box.setDetailedText(stderr)
            box.addButton("关闭", QMessageBox.AcceptRole)
            box.exec()

    # ----------------------------------------------------------------------------
    # v12.10.35: 统一的"认证错误"对话框入口
    # ----------------------------------------------------------------------------
    def _show_credential_error_dialog(self, stderr_excerpt: str):
        """
        在三个回调（Stage 1 fail / Stage 2 fail / PullOnly fail）中复用。
        弹 CredentialErrorDialog 让用户一键修复凭据问题。

        本对话框不做重试 — 用户修复凭据后需手工再点 [🚀 推送至 GitLab] / [🔄 仅 Pull]。
        """
        if not self._gitlab_repo_root or not self._gitlab_branch:
            return  # 仓库信息不全（罕见），跳过
        dlg = CredentialErrorDialog(
            self,
            repo_root=self._gitlab_repo_root,
            remote_url=self._gitlab_remote_url,
            branch=self._gitlab_branch,
            stderr_excerpt=stderr_excerpt or "",
        )
        dlg.exec()