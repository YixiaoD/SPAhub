# -*- coding: utf-8 -*-
"""
modules/tfls_pdt.py
===================
01 PDT Gen 模块。

职责：
  - 基于 TOC.xlsx 生成 PDT.xlsx（调用 25_generate_pdt_call.sas 在 SAS 服务器执行）
  - 运行成功后做 PDT 后处理：win32com + openpyxl 两级注入公式计算值
  - 触发历史归档时亮起左侧"归档路径"按钮

文件结构：
  ┌─ FileCacheManager               基于 mtime 的临时副本 + 解析结果缓存
  ├─ _parse_tdm / _parse_setup      TDM / setup.xlsx 解析函数（供缓存管理器调用）
  ├─ _parse_toc / _toc_*            TOC 表格行的读取、扩展、归一化
  ├─ gen_toc_study                  基于 TOC / 字典 生成供 SAS 使用的 PDT 前置内容
  ├─ PDTRunner (QThread)            后台执行 run_sas
  └─ PDTForm  (QFrame)              左侧表单 + 运行按钮 + 后处理（_post_process_pdt_formulas）

v12.10.71（本次改动）：
  · [LBCAT] 的尿/大便/粪剔除范围收窄：只在"描述性汇总"表（14.3.4-1.x 按访视描述性汇总）
    里剔除；16.2.8-1.x「实验室检查结果」listing 与 14.3.4-2.x 临床意义/评价转换表一律
    保留全部 LBCAT（含尿/粪）。判定改用 title_cn_str，CN/EN 输出都准确。
    连带：16.2.8-1.x 现在含尿/粪时其末尾 x 增大，故 16.2.8-1.99「其他」自增号也随之变大
    （仍是"上方末尾 x + 1"）。
  · AE 14.3.1 段表号修复为 14.3.1-x.1/x.2（x 在倒数第二位自增）已在 v12.10.70 随模板交付；
    本版无需再动该逻辑，行为不变。

v12.10.70：
  1. 16.2.8-1.99「实验室检查结果-其他」listing：
     - 展示门控改为 anno_study 的 "LB = 实验室检查" 注释条数 > LBCAT 唯一类目数 才出
       （lb_anno_count 由 toc_gen.DataLoaderThread 统计后经 gen_toc_study 透传）。
     - 模板里的 .99 占位 → 改写成 .x，复用既有自增 → 表号 = 上方 16.2.8-1.x 末尾 +1。
  2. AE 14.3.1 段表号修复（配套 TOC_template.xlsx 改动，硬编码号→14.3.1-x.1/x.2）。
"""
import os
import re
import sys
import shutil
import threading
import tempfile
import glob
import time
import pickle
import subprocess
import pandas as pd
from datetime import datetime
from openpyxl import load_workbook, Workbook
from openpyxl.utils import get_column_letter
from openpyxl.styles import Font

from PySide6.QtWidgets import (QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                               QLineEdit, QFileDialog, QDialog, QFrame, QProgressBar)
from PySide6.QtCore import Qt, QThread, Signal

from sas_engine.executor import run_sas
from ui_utils import show_dialog, primary_btn_style, danger_btn_style, success_btn_style, light_btn_style, primary_outline_btn_style, scan_status_lbl_style


# =============================================================================
# 模块 1：文件缓存管理器 + TDM / setup.xlsx 解析
# =============================================================================
class FileCacheManager:
    """
    基于 mtime + 临时副本 的缓存：
      - 第一次读取时，将文件拷贝到系统临时目录再解析，避免共享盘上的文件锁
      - 将解析结果连同 mtime 入缓存；后续命中直接返回缓存
      - mtime 变化时重解析
    """

    def __init__(self):
        self.cache = {}
        self.lock = threading.Lock()

    def safe_read(self, file_path, parse_func, *args, **kwargs):
        if not file_path or not os.path.isfile(file_path): return None
        try:
            current_mtime = os.path.getmtime(file_path)
        except OSError:
            return None
        with self.lock:
            if file_path in self.cache and self.cache[file_path]['mtime'] == current_mtime:
                return self.cache[file_path]['data']
        ext = os.path.splitext(file_path)[1]
        fd, temp_path = tempfile.mkstemp(suffix=ext)
        os.close(fd)
        try:
            shutil.copy2(file_path, temp_path)
            data = parse_func(temp_path, *args, **kwargs)
            with self.lock:
                self.cache[file_path] = {'mtime': current_mtime, 'data': data}
            return data
        except Exception:
            return None
        finally:
            try:
                os.remove(temp_path)
            except OSError:
                pass


_cache_manager = FileCacheManager()


def _parse_tdm(temp_path):
    """解析 TDM TX 表，构建 subpr_mapping。

    v12.10.48：除了按 Type 分组的 mapping，还在 mapping["__ordered_pairs__"] 里
    存一份**严格按 TDM 行顺序**的 (type, subpr, is_multi) 三元组列表。下游生成
    TOC 时按这个列表展开，保证 OUTREF 字母序（a/b/c）跟 TDM 行序对齐。

    以前的行为：design_types 分组遍历 → SAD 块（Part A、Part C）→ MAD 块（Part B）
    导致 Part C 的字母小于 Part B，跟 TDM 行序错位。
    """
    mapping = {}
    ordered_pairs = []  # v12.10.48：按 TDM 原始行顺序的 (type_part, subpr, is_multi)
    try:
        xl = pd.ExcelFile(temp_path)
        if "TX" in xl.sheet_names:
            df = xl.parse("TX")
            if 'Subpr' in df.columns and 'Type' in df.columns:
                for idx, row in df.iterrows():
                    subpr = str(row.get('Subpr', '')).strip()
                    typ = str(row.get('Type', '')).strip().upper()

                    if subpr and subpr != 'nan' and typ and typ != 'nan':
                        type_parts = [p.strip() for p in typ.split('+') if p.strip()]
                        is_multi = len(type_parts) > 1

                        combined_key = "/".join(type_parts)
                        if combined_key not in mapping: mapping[combined_key] = []
                        if not any(x['subpr'] == subpr for x in mapping[combined_key]):
                            mapping[combined_key].append({'subpr': subpr, 'is_multi': is_multi})

                        for p in type_parts:
                            if p not in mapping: mapping[p] = []
                            if not any(x['subpr'] == subpr for x in mapping[p]):
                                mapping[p].append({'subpr': subpr, 'is_multi': is_multi})
                            # v12.10.48：同时按行序记录 (单独的 type part, subpr) 用于
                            # 下游 split_pairs 排序。注意 type "SAD+FE" 这种会拆成两条
                            # (SAD, Part X) + (FE, Part X) 都按 TDM 行序入栈。
                            ordered_pairs.append((p, subpr, is_multi))
    except Exception as e:
        print(f"解析 TDM 时发生错误: {e}")
    mapping["__ordered_pairs__"] = ordered_pairs
    return mapping


def _get_tdm_subpr_mapping(study_path):
    if not study_path: return {}
    parts = study_path.replace('\\', '/').split('/')
    try:
        utility_idx = parts.index('utility')
        base_path = '/'.join(parts[:utility_idx])
        tdm_prefix = parts[utility_idx - 2]
    except Exception:
        return {}

    source_data_dir = os.path.join(base_path, "00_source_data")
    search_pattern = f"{tdm_prefix}_Trial_Design_Model*.xls*"
    matches = glob.glob(os.path.join(source_data_dir, search_pattern))
    tdm_path = matches[0] if matches else None

    if not tdm_path:
        for root, dirs, files in os.walk(base_path):
            for f in files:
                if f.lower().startswith(tdm_prefix.lower() + "_trial_design_model") and f.lower().endswith(
                        (".xls", ".xlsx")):
                    tdm_path = os.path.join(root, f)
                    break
            if tdm_path: break

    return _cache_manager.safe_read(tdm_path, _parse_tdm) or {}


def _parse_setup(temp_path):
    wb = load_workbook(temp_path, read_only=True, data_only=True)
    if "Macro Variables" not in wb.sheetnames:
        wb.close()
        return ""
    ws = wb["Macro Variables"]
    lng_val = ""
    name_col_idx, val_col_idx = -1, -1

    for row in ws.iter_rows(min_row=1, max_row=1):
        for idx, cell in enumerate(row):
            val = str(cell.value).strip().upper() if cell.value else ""
            if val == "MACRO_VARIABLE_NAME":
                name_col_idx = idx
            elif val == "MACRO_VARIABLE_VALUE":
                val_col_idx = idx

    if name_col_idx != -1 and val_col_idx != -1:
        for row in ws.iter_rows(min_row=2):
            if row[name_col_idx].value and str(row[name_col_idx].value).strip().upper() == "LNG":
                lng_val = str(row[val_col_idx].value).strip() if row[val_col_idx].value is not None else ""
                break
    else:
        for row in ws.iter_rows(min_row=1, max_col=5):
            b_val = row[1].value if len(row) > 1 else None
            if b_val is not None and str(b_val).strip().upper() == "LNG":
                c_val = row[2].value if len(row) > 2 else None
                lng_val = str(c_val).strip() if c_val is not None else ""
                break
    wb.close()
    return lng_val


def _toc_read_lng(setup_path):
    return _cache_manager.safe_read(setup_path, _parse_setup) or ""


def _toc_is_chinese_lng(lng_val):
    if not lng_val: return True
    return False if lng_val.upper() in ("EN", "ENGLISH") else True


_TOC_COLS = [
    "Template#", "Output Type", "Title_CN", "Title_EN", "Population",
    "Footnotes_CN", "Footnotes_EN", "Category_CN", "SAD", "FE", "MAD", "BE", "MB"
]
_TOC_SHEET_COLS = ["OUTTYPE", "OUTREF", "OUTTITLE", "OUTPOP", "OUTNOTE", "PREFIX"]
_EXCLUDED_CATEGORY_CN = {"QT分析", "C-QT分析", "PK浓度", "PK参数", "PD分析", "ADA分析"}
_DESIGN_TYPE_COLS = ["SAD", "FE", "MAD", "BE", "MB"]

_PLACEHOLDER_EXROUTE = "[EXROUTE]"
_PLACEHOLDER_QT_POP = "[ECG Set|动态心电图分析集/Safety Set|安全性分析集]"

# v12.10.70：16.2.8-1.99「实验室检查结果-其他」listing 的两条规则：
#   (1) 展示门控（不再看"标准四分类"）：lbcat 仍按 [LBCAT] 占位符逐项裂变（同前不变）；
#       额外比较 anno_study TEXT 列中 "LB = 实验室检查" 注释条数 lb_anno_count 与
#       LBCAT 唯一类目数。仅当 lb_anno_count > 唯一 lbcat 数（即存在未归入具名 LBCAT 的
#       实验室检查页）才产出"其他"，否则整行跳过。lb_anno_count 由 toc_gen.DataLoaderThread
#       从 anno_study 正则统计后经 gen_toc_study 透传进 config。
#   (2) 模板里的 99 只是占位符；真实表号 = 上方 16.2.8-1.x 末尾 x + 1。做法：把 Template#
#       的 .99 改写成 .x（letter slot），复用既有自增机制——因本行排在 16.2.8-1.x（[LBCAT]）
#       之后处理，自然拿到 max+1。
_LAB_OTHER_TEMPLATE_NUM = "16.2.8-1.99"

# 14.4-4.x.y 模板专用：PK 参数对比分析的 4 个影响因子。
# x 槽位用 fixed-index：食物=1 / 时辰=2 / 性别=3 / 单多次给药=4
_PLACEHOLDER_PK_FACTOR_CN = "[食物/时辰/性别/单多次给药]"
_PK_FACTOR_FIXED_INDEX = {"食物": 1, "时辰": 2, "性别": 3, "单多次给药": 4}
# 英文 title 里硬编码的 "Food Effect" — 需根据实际 factor 替换
_PK_FACTOR_EN_NAME = {
    "食物": "Food Effect",
    "时辰": "Time of Day Effect",
    "性别": "Sex Effect",
    "单多次给药": "Single/Multiple Dose Effect",
}

_SUBTYPE_TERMS = {
    "血": ["血", "Blood", "blood", "血浆", "Plasma", "plasma"],
    "尿": ["尿", "Urine", "urine"],
    "粪": ["粪", "粪便", "Feces", "feces", "Stool", "stool"],
}

def _parse_toc(temp_path):
    wb = load_workbook(temp_path, read_only=True, data_only=True)
    if "PH1" not in wb.sheetnames:
        wb.close()
        return []
    ws = wb["PH1"]

    _MAP = {
        "TEMPLATE#": "Template#", "TEMPLATE": "Template#", "表号": "Template#", "图表编号": "Template#",
        "OUTPUTTYPE": "Output Type", "TYPE": "Output Type",
        "TITLE_CN": "Title_CN", "TITLECN": "Title_CN", "中文标题": "Title_CN",
        "TITLE_EN": "Title_EN", "TITLEEN": "Title_EN", "英文标题": "Title_EN",
        "POPULATION": "Population", "分析集": "Population",
        "FOOTNOTES_CN": "Footnotes_CN", "FOOTNOTE_CN": "Footnotes_CN", "中文脚注": "Footnotes_CN",
        "FOOTNOTES_EN": "Footnotes_EN", "FOOTNOTE_EN": "Footnotes_EN", "英文脚注": "Footnotes_EN",
        "CATEGORY_CN": "Category_CN", "CATEGORY": "Category_CN", "分类": "Category_CN",
        "SAD": "SAD", "FE": "FE", "MAD": "MAD", "BE": "BE", "MB": "MB"
    }

    col_idx = {}
    rows = []
    for row in ws.iter_rows():
        vals = [c.value for c in row]
        if not col_idx:
            for i, h in enumerate(vals):
                if h is None: continue
                norm = str(h).strip().replace("\u200b", "").replace("\ufeff", "")
                if re.sub(r'\s+', '', norm).upper() in _MAP:
                    col_idx[_MAP[re.sub(r'\s+', '', norm).upper()]] = i
            continue

        if not col_idx: continue
        row_dict = {col_name: vals[idx] if idx < len(vals) else None for col_name, idx in col_idx.items()}
        rows.append(row_dict)
    wb.close()
    return rows


def _toc_read_rows(toc_path):
    return _cache_manager.safe_read(toc_path, _parse_toc) or []


def _toc_normalize_analyte_placeholder(s):
    if not s: return s
    return str(s).replace("<Analyte分析物>", "[Analyte]").replace("<Analyte>", "[Analyte]")


def _get_letter(idx):
    res = ""
    while idx > 0:
        idx, remainder = divmod(idx - 1, 26)
        res = chr(97 + remainder) + res
    return res


def _build_ordered_pairs_by_tdm(suffixes, subpr_mapping, ordered_pairs_raw):
    """按 TDM 行顺序构造 [(type, info), ...] 对列表。

    - suffixes：要保留的 type 列表（含 None 单阶段 / "SAD/FE" 合并 / 普通"SAD"/"MAD"等）
    - subpr_mapping：从 _parse_tdm 来的字典（按 type 分组）
    - ordered_pairs_raw：从 mapping["__ordered_pairs__"] 来的 (type, subpr, is_multi) 行序列表

    特殊处理：
      - suffixes 含 None → 当作单阶段，返回 [(None, {subpr:None, is_multi:False})]
      - "SAD/FE" 在 suffixes 里 → 先按 mapping["SAD/FE"] 原序发出合并条目，再把
        非 SAD/FE 的 type 按 TDM 行序追加
      - 否则纯走 TDM 行序遍历 ordered_pairs_raw
      - 兜底：suffixes 里有但 TDM 行序里没有的 type（如用户手动勾的）→ 补一条 None subpr

    v12.10.49：抽出来给 global_split_pairs / global_merged_pairs / row_pairs 三处共用，
    保证 OUTREF 的 a/b/c 字母序和实际输出行序都跟 TDM 一致。
    """
    result = []
    # 单阶段
    if not suffixes or list(suffixes) == [None]:
        return [(None, {'subpr': None, 'is_multi': False})]

    suffix_set = set(s for s in suffixes if s is not None)
    seen = set()

    # 1) 先处理 "SAD/FE" 合并项（按 mapping["SAD/FE"] 原序，那里就是 TDM 行序）
    if "SAD/FE" in suffix_set:
        sad_fe_pairs = subpr_mapping.get("SAD/FE", []) if isinstance(subpr_mapping, dict) else []
        if not sad_fe_pairs:
            # mapping 里没合并条目（用户手动勾的 SAD+FE 但 TDM 里没合并行）→ 退到 SAD 或 FE
            sad_fe_pairs = (subpr_mapping.get("SAD") or subpr_mapping.get("FE") or
                            [{'subpr': None, 'is_multi': False}])
        for info in sad_fe_pairs:
            key = ("SAD/FE", info.get('subpr'))
            if key not in seen:
                seen.add(key)
                result.append(("SAD/FE", info))

    # 2) 然后按 TDM 行序处理普通 type（跳过已被 SAD/FE 合并吃掉的 SAD/FE 单条）
    sad_fe_active = "SAD/FE" in suffix_set
    if ordered_pairs_raw:
        for typ, subpr, is_multi in ordered_pairs_raw:
            if sad_fe_active and typ in ("SAD", "FE"):
                continue
            if typ not in suffix_set:
                continue
            key = (typ, subpr)
            if key in seen:
                continue
            seen.add(key)
            result.append((typ, {'subpr': subpr, 'is_multi': is_multi}))

    # 3) 兜底：suffixes 里某些 type 在 ordered_pairs 里没出现过（用户手动勾的）
    for dt in suffixes:
        if dt is None or (sad_fe_active and dt in ("SAD", "FE")):
            continue
        if not any(t == dt for t, _ in result):
            mapped_infos = subpr_mapping.get(dt) if isinstance(subpr_mapping, dict) else None
            if mapped_infos:
                for info in mapped_infos:
                    key = (dt, info.get('subpr'))
                    if key not in seen:
                        seen.add(key)
                        result.append((dt, info))
            else:
                result.append((dt, {'subpr': None, 'is_multi': False}))

    return result if result else [(None, {'subpr': None, 'is_multi': False})]


def _toc_filter_and_expand_rows(toc_rows, use_cn, config):
    use_title = "Title_CN" if use_cn else "Title_EN"
    use_footnotes = "Footnotes_CN" if use_cn else "Footnotes_EN"

    design_types = config.get("design_types", [])
    pcspecs = config.get("pcspecs", [])
    has_pd = config.get("has_pd", False)
    has_ada = config.get("has_ada", False)
    has_qt = config.get("has_qt", False)
    has_aedis = config.get("has_aedis", False)
    has_aesi = config.get("has_aesi", False)
    has_vsclsig = config.get("has_vsclsig", False)

    analytes = config.get("analytes", [])
    aeacns = config.get("aeacns", [])
    lbcats = config.get("lbcats", [])

    # v12.10.70：16.2.8-1.99「实验室检查结果-其他」展示门控所需——
    # anno_study 里 "LB = 实验室检查" 注释条数。> 唯一 lbcat 数则出"其他"。
    lb_anno_count = int(config.get("lb_anno_count", 0) or 0)
    n_unique_lbcat = len(set(str(x).strip() for x in lbcats if str(x).strip()))

    admin_route_str = config.get("admin_route", "")
    admin_routes = [x.strip() for x in str(admin_route_str).split("|") if x.strip()]

    qt_methods = config.get("qt_methods", [])
    subpr_mapping = config.get("subpr_mapping", {})

    # v12.10.69：随机化判定（由 toc_gen.DataLoaderThread 从 anno_study TEXT 是否含"随机"得出）
    # has_randomized=False → 跳过 listing 16.2.1-2（随机化代码列表）整行
    has_randomized = bool(config.get("has_randomized", False))

    # PK 参数对比分析因子（影响因子）— UI 问题4
    # config["pk_factors"] 是 "|"-分隔的字符串，每项是 食物/时辰/性别/单多次给药 之一
    pk_factors_str = config.get("pk_factors", "")
    pk_factors = [x.strip() for x in str(pk_factors_str).split("|") if x.strip()]

    # ------------------------------------------------------------------
    # 预处理 toc_rows：把含 "[食物/时辰/性别/单多次给药]" 占位符的行
    # 按用户多选的因子裂变为多份。
    # 行号 14.4-4.x.y 中的 x 用因子的 FIXED INDEX (1-4)，y 留给后续 [Analyte] 处理。
    # 若用户一个都没选 → 该行整行不出。
    # ------------------------------------------------------------------
    expanded_toc_rows = []
    for r in toc_rows:
        title_cn_check = str(r.get("Title_CN") or "")
        if _PLACEHOLDER_PK_FACTOR_CN in title_cn_check:
            if not pk_factors:
                continue  # 用户没选任何因子 → 跳过整行
            for factor in pk_factors:
                fixed_idx = _PK_FACTOR_FIXED_INDEX.get(factor)
                if fixed_idx is None:
                    continue  # 未知因子名（容错）
                nr = dict(r)
                # CN title：把占位符替换为因子名
                nr["Title_CN"] = title_cn_check.replace(_PLACEHOLDER_PK_FACTOR_CN, factor)
                # EN title：把硬编码的 "Food Effect" 替换为对应因子的英文
                title_en = str(r.get("Title_EN") or "")
                en_replacement = _PK_FACTOR_EN_NAME.get(factor, "Food Effect")
                if "Food Effect" in title_en:
                    nr["Title_EN"] = title_en.replace("Food Effect", en_replacement)
                # Template# 行号：替换第一个 "x" 槽位为 fixed_idx，y 槽留给 [Analyte] 标准处理
                tmpl_num = str(r.get("Template#") or "")
                nr["Template#"] = re.sub(
                    r'(?<=[.\-])x(?=[.\-]|$)', str(fixed_idx), tmpl_num, count=1
                )
                expanded_toc_rows.append(nr)
        else:
            expanded_toc_rows.append(r)
    toc_rows = expanded_toc_rows

    is_single_phase = ("单阶段" in design_types)

    if is_single_phase:
        global_split_suffixes = []
        global_merged_suffixes = []
    else:
        global_split_suffixes = list(design_types)
        global_merged_suffixes = []
        if 'SAD' in design_types and 'FE' in design_types:
            global_merged_suffixes.append("SAD/FE")
            for dt in design_types:
                if dt not in ['SAD', 'FE']:
                    global_merged_suffixes.append(dt)
        else:
            global_merged_suffixes = list(design_types)

    # v12.10.49：抽出来的 helper 统一按 TDM 行序构造 pair 列表
    ordered_pairs_raw = subpr_mapping.get("__ordered_pairs__", []) if isinstance(subpr_mapping, dict) else []
    global_split_pairs = _build_ordered_pairs_by_tdm(
        global_split_suffixes, subpr_mapping, ordered_pairs_raw
    ) if global_split_suffixes else []
    global_merged_pairs = _build_ordered_pairs_by_tdm(
        global_merged_suffixes, subpr_mapping, ordered_pairs_raw
    ) if global_merged_suffixes else []

    should_append_design = False
    if not is_single_phase:
        # 把 __ordered_pairs__ 这个内部 key 排除掉再判 "真的有 mapping" 与否
        _has_real_mapping = isinstance(subpr_mapping, dict) and any(
            k != "__ordered_pairs__" for k in subpr_mapping
        )
        should_append_design = len(global_split_pairs) > 1 or _has_real_mapping

    selected_rows = []
    for r in toc_rows:
        cat_cn = (r.get("Category_CN") or "").strip()
        title_cn = str(r.get("Title_CN") or "")
        title_en = str(r.get("Title_EN") or "")
        template_num = str(r.get("Template#") or "").strip()

        if cat_cn in _EXCLUDED_CATEGORY_CN:
            if cat_cn == "PD分析" and not has_pd: continue
            if cat_cn == "ADA分析" and not has_ada: continue
            if cat_cn in ("QT分析", "C-QT分析") and not has_qt: continue
            if cat_cn in ("PK浓度", "PK参数"):
                if not pcspecs: continue
                text_lower = (title_cn + " " + title_en).lower()
                excluded = False
                for st, terms in _SUBTYPE_TERMS.items():
                    if st not in pcspecs:
                        for term in terms:
                            if len(term) <= 2 and (term in title_cn or term in title_en):
                                excluded = True;
                                break
                            elif len(term) > 2 and term.lower() in text_lower:
                                excluded = True;
                                break
                    if excluded: break
                if excluded: continue

        if not has_aedis and ("退出" in title_cn or template_num in ("14.3.1-5.1", "14.3.1-5.2")): continue
        if not has_aesi and "AESI" in title_cn.upper(): continue
        if not has_vsclsig and "生命体征临床评价转换表" in title_cn: continue

        # v12.10.69：用药方式（admin_route）全不选时跳过所有药物暴露相关行
        # 判定条件（任一命中即视为药物暴露行）：
        #   1) Title_CN / Title_EN 包含 _PLACEHOLDER_EXROUTE （[EXROUTE]）
        #   2) Title_CN 包含中文 "药物暴露"
        # 此判定与下游 line ~640 的"药物暴露 / [EXROUTE] 自动追加 EXROUTE 限定"逻辑严格对偶：
        # 没有任何 admin_route → 那块逻辑不会追加 EXROUTE 限定，TOC 行会产出一份不带样本限定
        # 的"全样本药物暴露"行，业务上无意义，所以直接整行跳过。
        if not admin_routes:
            _t_combined = title_cn + " " + title_en
            if (_PLACEHOLDER_EXROUTE in _t_combined) or ("药物暴露" in title_cn):
                continue

        # v12.10.69：项目非随机化时跳过 listing 16.2.1-2（随机化代码列表）
        # has_randomized 由 toc_gen.DataLoaderThread 从 anno_study TEXT 是否含 "随机" 推断
        if not has_randomized and template_num == "16.2.1-2":
            continue

        # v12.10.70：16.2.8-1.99「实验室检查结果-其他」专项
        #   (1) 仅当 anno_study 的 "LB = 实验室检查" 注释条数 > 唯一 lbcat 数时才出此行；
        #       否则整行跳过（说明所有实验室检查页都已归入具名 LBCAT，无"其他"可言）。
        #   (2) .99 只是占位 → 改写成 .x，复用既有自增，自然得到上方 16.2.8-1.x 末尾 x + 1。
        if template_num == _LAB_OTHER_TEMPLATE_NUM:
            if not (lb_anno_count > n_unique_lbcat):
                continue
            r = dict(r)
            r["Template#"] = "16.2.8-1.x"

        selected_rows.append(r)

    result = []
    pattern_max = {}
    sequence_tracker = {}
    placeholder_regex = re.compile(r'\[.*?\]')

    for row_idx_global, r in enumerate(selected_rows):
        template_num = str(r.get("Template#") or "").strip()
        output_type = str(r.get("Output Type") or "").strip()
        title_cn_str = str(r.get("Title_CN") or "")
        title = _toc_normalize_analyte_placeholder(r.get(use_title) or "")
        footnotes = r.get(use_footnotes) or ""
        population_raw = str(r.get("Population") or "").strip()

        if is_single_phase:
            applicable_designs = [None]
            use_merged_pool = False
            suffixes = [None]
        else:
            has_any_design = any(r.get(dt) is not None and str(r.get(dt)).strip() for dt in _DESIGN_TYPE_COLS)
            if not has_any_design:
                applicable_designs = [None]
            else:
                applicable_designs = list(design_types)

            title_cn_nospace = re.sub(r'\s+', '', title_cn_str)
            output_type_lower = output_type.lower()

            hardcode_titles = ["参与者分布", "统计分析数据集划分情况", "人口统计学和基线特征", "既往病史", "既往用药"]
            is_hardcoded = any(ht in title_cn_nospace for ht in hardcode_titles)
            is_listing = (output_type_lower == "listing")

            suffixes = []
            if applicable_designs == [None]:
                suffixes = [None]
            else:
                if is_hardcoded or is_listing:
                    use_merged_pool = True
                    if 'SAD' in applicable_designs and 'FE' in applicable_designs:
                        suffixes.append("SAD/FE")
                        for dt in applicable_designs:
                            if dt not in ['SAD', 'FE']:
                                suffixes.append(dt)
                    else:
                        suffixes = list(applicable_designs)
                else:
                    use_merged_pool = False
                    suffixes = list(applicable_designs)

            if not suffixes:
                suffixes = list(applicable_designs)

        # v12.10.49：用 helper 按 TDM 行序构造，输出行序也对了
        row_pairs = _build_ordered_pairs_by_tdm(
            suffixes, subpr_mapping, ordered_pairs_raw
        )

        matches = placeholder_regex.findall(title)
        found_placeholders = []
        for m in matches:
            if m.upper() in ["[ANALYTE]", "[AEACN]", "[LBCAT]", "[PCSPEC]", "[PK_TYPE]", "[PC_TYPE]", "[EXROUTE]"]:
                if m not in found_placeholders:
                    found_placeholders.append(m)

        if _PLACEHOLDER_QT_POP in population_raw and has_qt:
            found_placeholders.append("[QT_POP]")

        lists_to_product = []
        skip_row = False
        for p in found_placeholders:
            p_up = p.upper()
            if p_up == "[ANALYTE]":
                l = analytes if analytes else [""]
            elif p_up == "[AEACN]":
                l = aeacns
            elif p_up == "[LBCAT]":
                # v12.10.71：尿/大便/粪 仅在"描述性汇总"表（14.3.4-1.x 按访视描述性汇总）中剔除——
                #   这些指标多为定性结果（+/-/±），不适合做访视均值/中位数汇总。
                #   其余所有含 [LBCAT] 的行一律保留全部 LBCAT，包括：
                #     · 16.2.8-1.x 实验室检查结果 listing（原始结果列表，尿/粪也要列）
                #     · 14.3.4-2.x 临床意义/评价转换表
                #   判定用 title_cn_str（恒为中文，CN/EN 输出模式都准确）。
                # 历史：v12.10.60/61 曾用"非临床意义表即剔除尿/粪"，会误伤 16.2.8-1.x listing；
                #   本版改为"仅描述性汇总表剔除"，精确命中唯一需要剔除的那张表。
                _EXCLUDE_KEYWORDS = ("尿", "大便", "粪")
                _is_desc_summary = ("描述性汇总" in title_cn_str) or ("描述汇总" in title_cn_str)
                if _is_desc_summary:
                    l = [item for item in lbcats
                         if not any(kw in str(item) for kw in _EXCLUDE_KEYWORDS)]
                else:
                    l = lbcats
            elif p_up in ["[PCSPEC]", "[PK_TYPE]", "[PC_TYPE]"]:
                l = pcspecs
            elif p_up == "[QT_POP]":
                l = qt_methods if qt_methods else [""]
            elif p_up == "[EXROUTE]":
                l = admin_routes if admin_routes else [""]
            else:
                l = [""]

            if not l:
                skip_row = True
                break
            lists_to_product.append(l)

        if skip_row: continue

        import itertools
        combinations = list(itertools.product(*lists_to_product)) if lists_to_product else [()]

        slots = list(re.finditer(r'(?<=[.\-])([a-z])(?=[.\-]|$)', template_num))
        num_iterations = max(len(found_placeholders), len(slots))

        padded_combinations = []
        for combo in combinations:
            padded = list(combo)
            while len(padded) < num_iterations: padded.append(None)
            padded_combinations.append(padded)

        for combo in padded_combinations:
            curr_ref = template_num
            curr_title = title
            curr_pop_raw = population_raw
            base_prefix_parts = []

            for i, p in enumerate(found_placeholders):
                val = combo[i]
                if val is None or str(val).strip() == "": continue
                p_up = p.upper()

                if p_up == "[ANALYTE]":
                    ana_fmt = val + " " if re.fullmatch(r"[A-Za-z0-9]+", str(val)) else str(val)
                    curr_title = curr_title.replace(p, ana_fmt)
                    base_prefix_parts.append(f'prxmatch("/^({val})\\s*$/i", PCTESTCD)')
                elif p_up == "[AEACN]":
                    curr_title = curr_title.replace(p, str(val))
                    base_prefix_parts.append(f'prxmatch("/^({val})\\s*$/i", AEACN)')
                elif p_up == "[LBCAT]":
                    curr_title = curr_title.replace(p, str(val))
                    base_prefix_parts.append(f'prxmatch("/^({val})\\s*$/i", LBCAT)')
                elif p_up in ["[PCSPEC]", "[PK_TYPE]", "[PC_TYPE]"]:
                    curr_title = curr_title.replace(p, str(val))
                    mapped_pcspec = {"血": "PLASMA", "尿": "URINE", "粪": "STOOL"}.get(str(val), str(val))
                    base_prefix_parts.append(f'prxmatch("/^({mapped_pcspec})\\s*$/i", PCSPEC)')
                elif p_up == "[QT_POP]":
                    if val == "Holter":
                        curr_pop_raw = curr_pop_raw.replace(_PLACEHOLDER_QT_POP, "ECG Set|动态心电图分析集")
                    elif val == "12-ECG":
                        curr_pop_raw = curr_pop_raw.replace(_PLACEHOLDER_QT_POP, "Safety Set|安全性分析集")
                elif p_up == "[EXROUTE]":
                    curr_title = curr_title.replace(p, str(val))
                    base_prefix_parts.append(f'prxmatch("/^({val})\\s*$/i", EXROUTE)')

            has_exroute_placeholder = any("EXROUTE" in part for part in base_prefix_parts)
            if not has_exroute_placeholder:
                needs_exroute = ("药物暴露" in curr_title or _PLACEHOLDER_EXROUTE in curr_title)
                if needs_exroute and admin_route_str:
                    display_route = admin_route_str.replace('|', '/')
                    if _PLACEHOLDER_EXROUTE in curr_title:
                        curr_title = curr_title.replace(_PLACEHOLDER_EXROUTE, f"（{display_route}）")
                    elif "药物暴露" in curr_title:
                        curr_title = f"{curr_title}（{display_route}）"
                    base_prefix_parts.append(f'prxmatch("/^({admin_route_str})\\s*$/i", EXROUTE)')

            if has_aedis and ("退出" in title_cn_str or template_num in ("14.3.1-5.1", "14.3.1-5.2")):
                if not any("AEDIS" in part for part in base_prefix_parts): base_prefix_parts.append(
                    'prxmatch("/^(是|y|yes)\\s*$/i", AEDIS)')
            if has_aesi and "AESI" in title_cn_str.upper():
                if not any("AESI" in part for part in base_prefix_parts): base_prefix_parts.append(
                    'prxmatch("/^(是|y|yes)\\s*$/i", AESI)')
            if has_vsclsig and "生命体征临床评价转换表" in title_cn_str:
                if not any("VSCLSIG" in part for part in base_prefix_parts): base_prefix_parts.append(
                    'prxmatch("/^(是|y|yes)\\s*$/i", VSCLSIG)')

            if "|" in curr_pop_raw:
                pop_parts = curr_pop_raw.split("|")
                population = pop_parts[1].strip() if use_cn and len(pop_parts) > 1 else pop_parts[0].strip()
            else:
                population = curr_pop_raw

            if num_iterations == 0:
                base_ref = curr_ref
                # v12.10.42：递增按 output_type 隔离 — Table 和 Figure 用各自的计数器，
                # 它们之间 outref 可以重复（如 Table 14.4-2.1.1 和 Figure 14.4-2.1.1 并存），
                # 但同 output_type 内仍 unique。所以 pattern_max 的 key 加 output_type 前缀。
                # 排序仍按 prefix 长度（key 第 2 项）降序匹配最长前缀。
                sorted_patterns = sorted(
                    [k for k in pattern_max.keys() if k[0] == output_type],
                    key=lambda k: len(k[1]), reverse=True,
                )
                for p_otype, p_prefix, p_suffix in sorted_patterns:
                    m = re.match(r'^' + re.escape(p_prefix) + r'(\d+)' + re.escape(p_suffix) + r'$', base_ref)
                    if m:
                        curr_n = int(m.group(1))
                        p_max_x = pattern_max[(output_type, p_prefix, p_suffix)]
                        if curr_n <= p_max_x:
                            new_n = p_max_x + 1
                            base_ref = f"{p_prefix}{new_n}{p_suffix}"
                            pattern_max[(output_type, p_prefix, p_suffix)] = new_n
                        else:
                            pattern_max[(output_type, p_prefix, p_suffix)] = curr_n
                        break
                curr_ref = base_ref
            else:
                for i in range(num_iterations):
                    val = combo[i]
                    m = re.search(r'(?<=[.\-])([a-z])(?=[.\-]|$)', curr_ref)
                    if m:
                        prefix = curr_ref[:m.start()]
                        suffix = curr_ref[m.end():]
                    else:
                        prefix = curr_ref + "." if curr_ref else "."
                        suffix = ""

                    key_val = val if val is not None else f"ROW_{row_idx_global}_{i}"
                    # 占位符分支：sequence_tracker key 也加 output_type 前缀
                    key = (output_type, prefix, suffix, key_val)
                    if key in sequence_tracker:
                        assigned_int = sequence_tracker[key]
                    else:
                        current_max = pattern_max.get((output_type, prefix, suffix), 0)
                        assigned_int = current_max + 1
                        pattern_max[(output_type, prefix, suffix)] = assigned_int
                        sequence_tracker[key] = assigned_int
                    curr_ref = f"{prefix}{assigned_int}{suffix}"

            for m in re.finditer(r'\d+', curr_ref):
                p_prefix = curr_ref[:m.start()]
                p_suffix = curr_ref[m.end():]
                num_val = int(m.group())
                # 同 output_type 隔离
                if pattern_max.get((output_type, p_prefix, p_suffix), 0) < num_val:
                    pattern_max[(output_type, p_prefix, p_suffix)] = num_val

            for dt, info in row_pairs:
                final_title = curr_title
                final_ref = curr_ref
                final_prefix_parts = list(base_prefix_parts)

                subpr_val = info['subpr']
                is_multi = info['is_multi']

                if subpr_val:
                    if is_multi:
                        if dt and "/" in dt:
                            reg = dt.replace("/", "|").lower()
                            final_prefix_parts.append(f'prxmatch("/{reg}/i", SUBPR)')
                        elif dt:
                            final_prefix_parts.append(f'prxmatch("/{dt.lower()}/i", SUBPR)')
                    else:
                        reg = subpr_val.replace(" ", "").lower()
                        final_prefix_parts.append(f'prxmatch("/{reg}/i", SUBPR)')

                final_prefix_val = "@".join(final_prefix_parts)

                if should_append_design and dt is not None:
                    if subpr_val:
                        formatted_dt = f"{subpr_val} ({dt})"
                    else:
                        formatted_dt = str(dt)

                    final_title = f"{final_title}-{formatted_dt}" if final_title else formatted_dt

                    try:
                        if use_merged_pool:
                            dt_idx = global_merged_pairs.index((dt, info)) + 1
                        else:
                            dt_idx = global_split_pairs.index((dt, info)) + 1
                    except ValueError:
                        dt_idx = row_pairs.index((dt, info)) + 1

                    final_ref += _get_letter(dt_idx)

                result.append({
                    "Output Type": output_type,
                    "Title": final_title,
                    "Population": population,
                    "Footnotes": footnotes,
                    "Output Reference": final_ref,
                    "PREFIX": final_prefix_val
                })
    return result


def gen_toc_study(template_path, study_path, setup_path,
                  study_type, PCSPEC, PD_Analyte, ADA_Analyte, QT_Analyte, Analyte,
                  admin_route, qt_method, AEDIS, AESI, VSCLSIG, AEACN, LBCAT,
                  edcdef_ecrf_path=None, edcdef_code_path=None,
                  pk_factors=None, has_randomized=False, lb_anno_count=0):
    """供 UI 调用生成 TOC.xlsx 的执行入口

    pk_factors: "|"-分隔字符串或 list，PK 参数对比分析的影响因子（食物/时辰/性别/单多次给药）。
                默认 None / 空 — 含 [食物/时辰/性别/单多次给药] 占位符的模板行不出。

    has_randomized (v12.10.69)：anno_study 中是否检出 "随机" 字样。
                False（默认）→ listing 16.2.1-2 整行不出；
                True → listing 16.2.1-2 正常进入下游。

    lb_anno_count (v12.10.70)：anno_study TEXT 列中 "LB = 实验室检查" 注释条数。
                当该数 > LBCAT 唯一类目数时，产出 16.2.8-1.99「实验室检查结果-其他」listing
                （表号自动取 16.2.8-1.x 末尾 +1）；否则该行不出。
    """
    subpr_mapping = _get_tdm_subpr_mapping(study_path)

    use_cn = True
    if setup_path and os.path.isfile(setup_path):
        lng_val = _toc_read_lng(setup_path)
        use_cn = _toc_is_chinese_lng(lng_val)

    toc_rows = _toc_read_rows(template_path)
    if not toc_rows:
        return False, "TOC_template.xlsx 的 PH1 sheet 未找到或格式无法解析，请检查"

    def _parse_str_to_list(s):
        return [x.strip() for x in str(s).split("|") if x.strip()] if s and s != "None" else []

    config = {
        "design_types": _parse_str_to_list(study_type),
        "pcspecs": _parse_str_to_list(PCSPEC),
        "has_pd": (str(PD_Analyte).strip() == "exist"),
        "has_ada": (str(ADA_Analyte).strip() == "exist"),
        "has_qt": (str(QT_Analyte).strip() == "exist"),
        "has_aedis": (str(AEDIS).strip() == "exist"),
        "has_aesi": (str(AESI).strip() == "exist"),
        "has_vsclsig": (str(VSCLSIG).strip() == "exist"),
        "analytes": _parse_str_to_list(Analyte),
        "aeacns": _parse_str_to_list(AEACN),
        "lbcats": _parse_str_to_list(LBCAT),
        "admin_route": str(admin_route).strip() if admin_route and admin_route != "None" else "",
        "qt_methods": _parse_str_to_list(qt_method),
        "pk_factors": (
            pk_factors if isinstance(pk_factors, str)
            else "|".join(pk_factors) if pk_factors
            else ""
        ),
        # v12.10.69：随机化判定 — False 时 _toc_filter_and_expand_rows 跳过 listing 16.2.1-2
        "has_randomized": bool(has_randomized),
        # v12.10.70：实验室检查"LB = 实验室检查"注释条数 — 决定 16.2.8-1.99「其他」是否产出
        "lb_anno_count": int(lb_anno_count or 0),
        "subpr_mapping": subpr_mapping
    }

    new_rows = _toc_filter_and_expand_rows(toc_rows, use_cn, config)

    toc_sheet_rows = [
        {"OUTTYPE": r.get("Output Type") or "", "OUTREF": r.get("Output Reference") or "",
         "OUTTITLE": r.get("Title") or "", "OUTPOP": r.get("Population") or "", "OUTNOTE": r.get("Footnotes") or "",
         "PREFIX": r.get("PREFIX") or ""}
        for r in new_rows
    ]

    def natural_sort_key(item):
        s = str(item.get("OUTREF", ""))
        return [int(t) if t.isdigit() else t.lower() for t in re.split(r'(\d+)', s)]

    toc_sheet_rows.sort(key=natural_sort_key)

    d = os.path.dirname(study_path)
    if d: os.makedirs(d, exist_ok=True)

    if os.path.isfile(study_path):
        study_dir = os.path.dirname(os.path.abspath(study_path))
        archive_dir = os.path.join(study_dir, "99_archive")
        os.makedirs(archive_dir, exist_ok=True)
        base_name = os.path.splitext(os.path.basename(study_path))[0]
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        shutil.copy2(study_path, os.path.join(archive_dir, f"{base_name}_{ts}.xlsx"))

    wb = Workbook()
    ws = wb.active
    ws.title = "TOC"

    bold_font = Font(bold=True)
    for col_idx, col_name in enumerate(_TOC_SHEET_COLS, start=1):
        cell = ws.cell(row=1, column=col_idx, value=col_name)
        cell.font = bold_font

    for row_idx, row_data in enumerate(toc_sheet_rows, start=2):
        for col_idx, col_name in enumerate(_TOC_SHEET_COLS, start=1):
            ws.cell(row=row_idx, column=col_idx, value=row_data.get(col_name, ""))

    def _cell_width(val):
        if val is None: return 0
        s = str(val)
        return sum(2 if "\u4e00" <= c <= "\u9fff" else 1 for c in s)

    for col_idx in range(1, len(_TOC_SHEET_COLS) + 1):
        col_letter = get_column_letter(col_idx)
        max_w = max((_cell_width(ws.cell(row=row_idx, column=col_idx).value) for row_idx in range(1, ws.max_row + 1)),
                    default=0)
        ws.column_dimensions[col_letter].width = min(55, max(8, max_w + 2))

    ws.freeze_panes = 'A2'
    ws.auto_filter.ref = ws.dimensions

    if os.path.exists(study_path):
        try:
            with open(study_path, 'a'): pass
        except IOError:
            wb.close()
            return False, f"生成失败：目标文件被占用或无写权限，请确保该文件已关闭。\n路径：{study_path}"
            
    try:
        wb.save(study_path)
    except Exception as e:
        wb.close()
        return False, f"写入文件时发生异常，可能由于网络盘不稳定：{str(e)}"
        
    wb.close()
    return True, "已生成 TOC.xlsx（TOC sheet 共 %d 行）。" % len(toc_sheet_rows)


# =============================================================================
# 模块 2：后台运行线程
# =============================================================================
class PDTRunner(QThread):
    """
    PDT 后台执行器（v12.10.3 重写）。

    历史问题（< v12.10.3）：原本 PDTRunner 在 **当前 PySide6 主进程** 中直接调
    `run_sas()` —— 会在主进程内 `import saspy` 并 `saspy.SASsession(...)` 创建会话。
    这会引入两类状态污染：
      1. 上次会话 endsas 不干净 → 第二次跑复用脏 workspace
      2. 主进程多线程下 saspy（非完全线程安全）的 `%let _sasprogramfile=...`
         注入失败 → autorun 拿不到当前脚本路径 → prot/ra 推断为空 →
         `&radoc_path/&prot._&ra._PDT.xlsx` 拼成 `&radoc_path/__PDT.xlsx`
         → fileexist 返回 0 → SAS 宏 rc=001 → 触发 `%abort` → 报错
         "Execution terminated by an %ABORT statement"

    其他模块（04 Batch Run / Init PGM / Metadata / EDC Recode / Unzip
    / CRF Annotation / SDTM 03 / Import EDC Definition）都用 SingleBatchRunner，
    走独立 Python 子进程跑 run_sas — **每次都新建干净的 saspy session，跑完进程
    退出**，无状态污染问题。所以它们一直正常，只有 PDT Gen 报错。

    修复（v12.10.3）：让 PDTRunner 也走子进程模式（与 SingleBatchRunner 同款）。
    通过 sys.executable 拉新 Python 进程，pickle 文件 IPC 回传 4 元组结果。
    优先级：保 4 元组返回（has_issue, summary, log_text, source_label）以保持
    与 PDTForm.on_execute_finished 的接口契约。
    """
    log_signal = Signal(str)
    finished_signal = Signal(bool, str, str, str)  # has_issue, summary, log_text, source_label

    def __init__(self, sas_script):
        super().__init__()
        self.sas_script = sas_script
        self.is_cancelled = False
        self.proc = None  # 与 SingleBatchRunner 一致，提供给外层 cancel 用

    def run(self):
        # 复用 SingleBatchRunner 的子进程脚手架：
        # - frozen 时通过 app_paths.child_command_run_sas 拉 SASEG.exe --child
        # - 开发模式通过 [python, "-c", code] 拉新 Python 进程
        # - 子进程内 import sas_engine.executor.run_sas 并以 return_details=True 跑
        # - 用 pickle 文件做 IPC 回传 4 元组
        # 注意：与 SingleBatchRunner 唯一差异 — return_details=True（拿 source_label）
        res_path = self.sas_script + ".res"
        if os.path.exists(res_path):
            try:
                os.remove(res_path)
            except Exception:
                pass

        # v12.10.30：用工厂构造命令（兼容打包/开发模式）
        from app_paths import child_command_run_sas
        cmd = child_command_run_sas(self.sas_script, res_path)

        try:
            self.proc = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=0x08000000,  # CREATE_NO_WINDOW — 父 pythonw.exe 无 console，避免 Windows 给子 python.exe 分配新黑框
            )
        except Exception as e:
            if not self.is_cancelled:
                self.log_signal.emit(f"ERROR: 启动子进程失败：{e}")
                self.finished_signal.emit(True, f"异常: {e}", "", "")
            return

        # 阻塞等子进程结束（QThread 内的循环不阻塞主线程；is_cancelled 检查 0.5s 一次）
        while self.proc.poll() is None:
            if self.is_cancelled:
                try:
                    self.proc.kill()
                except Exception:
                    pass
                return
            time.sleep(0.5)

        if self.is_cancelled:
            return

        # 默认回包（子进程崩溃时给个兜底）
        res_tuple = (False, "✅ 运行成功", "", "")
        if os.path.exists(res_path):
            try:
                with open(res_path, 'rb') as f:
                    res = pickle.load(f)
                # run_sas(return_details=True) 返回 4 元组 (has_issue, summary, log_text, source_label)
                if isinstance(res, tuple) and len(res) >= 4:
                    res_tuple = (bool(res[0]), str(res[1]), str(res[2]), str(res[3]))
                elif isinstance(res, tuple) and len(res) == 3:
                    res_tuple = (bool(res[0]), str(res[1]), str(res[2]), "")
            except Exception as e:
                self.log_signal.emit(f"ERROR: 读取子进程结果失败：{e}")
            try:
                os.remove(res_path)
            except Exception:
                pass
        else:
            # 子进程没产出 pickle —— 通常是 saspy 内部 fatal exception，子进程崩溃
            self.log_signal.emit(
                "ERROR: PDT 子进程未产出结果文件，可能 saspy 启动失败。"
                "请检查 sascfg.py 配置或 SAS IOM 服务连通性。"
            )
            res_tuple = (True, "子进程未返回结果（saspy 启动可能失败）", "", "")

        self.finished_signal.emit(*res_tuple)


# =============================================================================
# 模块 3：左侧表单组件 PDTForm
# =============================================================================
class PDTForm(QFrame):
    """
    PDT Gen 的左侧业务表单。

    信号总线（对 TFLsWidget 开放）：
      sig_log           日志行（带 HTML 样式）
      sig_status        底部状态文本 + 颜色
      sig_step_update   步骤栏文字（"01 PDT Gen ✅" / "... ❌" / "... ⚠️" / "... 🟥"）
      sig_show_archive  是否显示"归档路径"按钮，以及要打开的路径
      sig_run_started   运行开始（供外部清空日志 / 启动耗时计时器）
    """
    sig_log = Signal(str)
    sig_status = Signal(str, str) 
    sig_step_update = Signal(str) 
    sig_show_archive = Signal(bool, str) 
    sig_run_started = Signal()

    # ------------------------- 初始化 -------------------------
    def __init__(self):
        super().__init__()
        self.base_path = ""
        self.toc_path = ""
        self.pdt_path = ""

        self._setup_ui()

    def _show_msg(self, title, text, msg_type="info"):
        return show_dialog(self, title, text, msg_type)

    # ------------------------- UI 构造 -------------------------
    def _setup_ui(self):
        self.setObjectName("LeftPanel")
        self.setStyleSheet("#LeftPanel { background-color: #FFFFFF; border: 1px solid #E4E7ED; border-radius: 6px; }")
        form_layout = QVBoxLayout(self)
        form_layout.setAlignment(Qt.AlignTop)
        form_layout.setContentsMargins(25, 25, 25, 25)
        form_layout.setSpacing(20)

        # 任务1：TOC 风格刷新按钮 + 扫描状态标签
        self._step_name = "PDT Gen"
        top_bar = QHBoxLayout()
        self.refresh_btn = QPushButton("🔄 刷新源文件")
        # v12.10.65：统一改用 home"📁 系统文件复制"同款蓝色外框样式
        self.refresh_btn.setStyleSheet(primary_outline_btn_style())
        self.refresh_btn.setCursor(Qt.PointingHandCursor)
        top_bar.addWidget(self.refresh_btn)
        self.scan_lbl = QLabel("")
        self.scan_lbl.setStyleSheet(scan_status_lbl_style())
        top_bar.addWidget(self.scan_lbl)
        top_bar.addStretch()
        form_layout.addLayout(top_bar)

        desc = QLabel("基于 TOC.xlsx，在 utility\\documentation 下生成最新版 PDT。")
        desc.setStyleSheet("color: #303133; font-size: 14px; border: none; font-weight: bold;")
        form_layout.addWidget(desc)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 0)
        self.progress_bar.setFixedHeight(4)
        self.progress_bar.setVisible(False)
        form_layout.addWidget(self.progress_bar)

        path_layout = QHBoxLayout()
        lbl = QLabel("TOC XLSX：")
        lbl.setStyleSheet("border: none; color: #606266;")
        path_layout.addWidget(lbl)

        self.toc_entry = QLineEdit()
        self.toc_entry.setStyleSheet("padding: 6px; border: 1px solid #DCDFE6; border-radius: 4px;")
        path_layout.addWidget(self.toc_entry)

        browse_btn = QPushButton("浏览")
        browse_btn.setStyleSheet(
            "background-color: #F5F7FA; color: #606266; border: 1px solid #DCDFE6; padding: 6px 12px; border-radius: 4px;")
        browse_btn.clicked.connect(lambda: self.toc_entry.setText(
            QFileDialog.getOpenFileName(self, "选择TOC",
                os.path.dirname(self.toc_entry.text()) if os.path.isfile(self.toc_entry.text()) else self.base_path,
                "*.xlsx")[0] or self.toc_entry.text()))
        path_layout.addWidget(browse_btn)
        form_layout.addLayout(path_layout)

        btn_layout = QHBoxLayout()
        self.run_btn = QPushButton("▶ 初版PDT")
        self.run_btn.setStyleSheet(primary_btn_style())
        self.run_btn.setCursor(Qt.PointingHandCursor)
        self.run_btn.clicked.connect(self.execute_pdt)
        btn_layout.addWidget(self.run_btn)

        self.cancel_btn = QPushButton("🟥 中止")
        self.cancel_btn.setStyleSheet(danger_btn_style())
        self.cancel_btn.setCursor(Qt.PointingHandCursor)
        self.cancel_btn.setVisible(False)
        self.cancel_btn.clicked.connect(self.cancel_pdt)
        btn_layout.addWidget(self.cancel_btn)

        self.edit_btn = QPushButton("📝 打开PDT")
        self.edit_btn.setStyleSheet(success_btn_style())
        self.edit_btn.setCursor(Qt.PointingHandCursor)
        self.edit_btn.clicked.connect(
            lambda: os.startfile(self.pdt_path) if os.path.exists(self.pdt_path) else self._show_msg("提示",
                                                                                                     "文件不存在",
                                                                                                     "warning"))
        self.edit_btn.setVisible(False)
        btn_layout.addWidget(self.edit_btn)
        btn_layout.addStretch()

        form_layout.addLayout(btn_layout)
        form_layout.addStretch()

    # ------------------------- 路径/等待提示 -------------------------
    def update_paths(self, base_path, toc_path, pdt_path):
        """供主控调用的被动传参接口（设置各路径字段并更新编辑按钮可见性）"""
        self.base_path = base_path
        self.toc_path = toc_path
        self.pdt_path = pdt_path
        # 仅文件存在时才填入，否则置空以间接提示用户文件缺失
        self.toc_entry.setText(self.toc_path if os.path.isfile(self.toc_path) else "")
        self.edit_btn.setVisible(os.path.isfile(self.pdt_path))

    def set_wait_hint(self, show):
        """控制左侧上方等待提示的显隐（四下拉框齐全时由主控调用隐藏）"""
        if show:
            self.scan_lbl.setText("⏳ 等待填写完整路径...")
            self.scan_lbl.setStyleSheet(scan_status_lbl_style())
        else:
            self.scan_lbl.setText("")

    # ============================================================================
    # 全局快捷键钩子：F5 / Ctrl+Enter 由 TFLsWidget 路由到当前 step 的 form
    # ============================================================================
    def action_refresh(self):
        """F5：点击"🔄 刷新源文件"。运行中按钮 disabled 时自动空操作。"""
        btn = getattr(self, "refresh_btn", None)
        if btn is not None and btn.isEnabled():
            btn.click()

    def action_run(self):
        """Ctrl+Enter：点击"▶ 初版PDT"。运行中按钮 hidden 时自动空操作。"""
        btn = getattr(self, "run_btn", None)
        if btn is not None and btn.isEnabled() and btn.isVisible():
            btn.click()

    # ------------------------- 执行 / 取消 -------------------------
    def execute_pdt(self):
        """点击"初版PDT"：校验输入 → 改写 SAS 脚本 → 启动后台线程"""
        toc_path = self.toc_entry.text().strip()
        if not os.path.exists(toc_path):
            self._show_msg("错误", "TOC文件不存在！", "error")
            return

        sas_script = os.path.join(self.base_path, "utility", "tools", "25_generate_pdt_call.sas")
        if not os.path.exists(sas_script):
            self._show_msg("错误", "找不到 SAS 脚本！", "error")
            return

        try:
            with open(sas_script, "r", encoding="utf-8") as f:
                content = f.read()
            new_content = re.sub(r'(?i)%gen_pdt\s*\(\s*toc\s*=\s*%str\([^)]*\)\s*\);',
                                 f'%gen_pdt(toc=%str({os.path.basename(toc_path)}));', content)
            with open(sas_script, "w", encoding="utf-8") as f:
                f.write(new_content)
        except PermissionError:
            self._show_msg("权限拒绝", "文件被占用，请关闭关联程序后重试！", "error")
            return

        # 所有校验通过后才发出 sig_run_started（触发日志清空 + 耗时计时器）
        self.sig_run_started.emit()
        self._run_start_time = time.time() - 2.0

        self.run_btn.hide()
        self.cancel_btn.show()
        self.progress_bar.setVisible(True)
        self.edit_btn.setVisible(False)

        self.sig_log.emit('<span style="color:#409EFF;">> 正在向 SAS 服务器提交任务...</span>')
        self.sig_status.emit("⏳ 正在执行中...", "#409EFF")

        self.thread = PDTRunner(sas_script)
        self.thread.log_signal.connect(
            lambda msg: self.sig_log.emit(f'<span style="color:#F56C6C; font-weight:bold;">{msg}</span>'))
        self.thread.finished_signal.connect(self.on_execute_finished)
        self.thread.start()

    def cancel_pdt(self):
        if hasattr(self, 'thread') and self.thread.isRunning():
            self.thread.is_cancelled = True
        self.cancel_btn.hide()
        self.run_btn.show()
        self.progress_bar.setVisible(False)

        self.sig_step_update.emit("01 PDT Gen 🟥")
        self.sig_log.emit("<span style='color:#F56C6C; font-weight:bold;'>[已中止] 🛑 用户手动取消了执行。</span>")
        self.sig_status.emit("🛑 已中止", "#F56C6C")

    # ------------------------- 完成回调 + 后处理 -------------------------
    def on_execute_finished(self, has_issue, summary, log_text, source_label):
        """
        SAS 运行结束回调：
          - 解析日志中的 ERROR/WARNING（高亮后推到日志面板）
          - 检测 "already exists" 以触发历史归档按钮
          - 检查 PDT 文件是否真的被写入（mtime 比运行开始时刻晚）
          - 调用 _post_process_pdt_formulas 注入公式计算值
          - 根据结果发出最终的 sig_step_update / sig_status

        v12.10.7：当日志含 %ABORT 时，原版只显示 "ERROR: Execution terminated by an %ABORT
        statement." 这一行，吃掉所有 NOTE 上下文，导致用户看不到根因。
        修复：检测到 %ABORT 时调 extract_abort_context_html 倒扫前 15 行 ERROR/WARNING/NOTE
        全部渲染（含宏内 put 出来的 "NOTE: ERROR::" 真实根因行）；末尾追加完整 .log
        文件路径，让用户能直接打开看完整日志。
        """
        if hasattr(self, 'thread') and self.thread.is_cancelled:
            return

        self.cancel_btn.hide()
        self.run_btn.show()
        self.progress_bar.setVisible(False)

        trigger_archive = False
        has_content = False
        # v12.10.7：用 sdtm_common 的工具检测 abort 场景
        try:
            from modules.sdtm_common import detect_macro_abort, extract_abort_context_html
            is_abort = detect_macro_abort(log_text)
        except Exception:
            is_abort = False

        if log_text:
            for line in log_text.split('\n'):
                line_str = line.strip()
                if not line_str:
                    continue
                if re.match(r'^(ERROR|WARNING)', line_str, re.IGNORECASE):
                    has_content = True
                if "already exists" in line_str.lower():
                    trigger_archive = True

        # v12.10.7：根据是否 %abort 选不同渲染
        if is_abort:
            self.sig_log.emit(
                "<span style='color:#F56C6C; font-weight:bold;'>❌ SAS 宏触发 %ABORT —— 真实根因见下方上下文：</span>"
            )
            self.sig_log.emit(extract_abort_context_html(log_text, n_before=15))
            has_content = True  # 强制按"有错"分支走，避免后续误判 "日志干净"
        elif has_content:
            # 老路径：行首 ERROR/WARNING 高亮（保留旧行为）
            for line in log_text.split('\n'):
                line_str = line.strip()
                if not line_str:
                    continue
                if re.match(r'^(ERROR|WARNING)', line_str, re.IGNORECASE):
                    color = "#F56C6C" if "ERROR" in line_str.upper() else "#E6A23C"
                    self.sig_log.emit(f'<span style="color:{color}; font-weight:bold;">{line_str}</span>')
        else:
            self.sig_log.emit('<span style="color:#67C23A;">> 运行完毕，日志干净，无 ERROR / WARNING。</span>')

        # v12.10.7：始终在末尾显示完整 .log 路径（即使日志干净 — 万一用户要审阅）
        if source_label:
            self.sig_log.emit(
                f"<span style='color:#909399;'>&nbsp;&nbsp;📄 完整日志：{source_label}</span>"
            )

        if trigger_archive:
            archive_dir = os.path.join(self.base_path, "utility", "documentation", "99_archive")
            self.sig_show_archive.emit(True, archive_dir)

        pdt_success = False
        if os.path.isfile(self.pdt_path):
            import time
            for _ in range(3):
                file_mtime = os.path.getmtime(self.pdt_path)
                file_size = os.path.getsize(self.pdt_path)
                if file_mtime >= getattr(self, '_run_start_time', 0) - 2.0 and file_size > 0:
                    pdt_success = True
                    break
                time.sleep(0.5)

        if pdt_success:
            try:
                self._post_process_pdt_formulas(self.pdt_path)
            except Exception as e:
                self.sig_log.emit(f'<span style="color:#F56C6C; font-weight:bold;">> PDT 后处理注入值失败: {str(e)}</span>')

        self.edit_btn.setVisible(os.path.isfile(self.pdt_path))

        if not pdt_success:
            self.sig_step_update.emit("01 PDT Gen ❌")
            self.sig_status.emit("❌ PDT 生成失败：未检测到有效的文件更新。", "#F56C6C")
        elif has_issue or has_content:
            self.sig_step_update.emit("01 PDT Gen ⚠️")
            self.sig_status.emit("⚠️ PDT 已生成，但日志存在警告或错误，请严格审阅！", "#E6A23C")
        elif trigger_archive:
            self.sig_step_update.emit("01 PDT Gen ⚠️")
            self.sig_status.emit("⚠️ PDT 生成触发了历史归档保护。", "#E6A23C")
        else:
            self.sig_step_update.emit("01 PDT Gen ✅")
            self.sig_status.emit("✅ PDT 成功生成，日志完全干净！", "#67C23A")

    def _post_process_pdt_formulas(self, pdt_path):
        """
        在成功产生 PDT 后注入公式计算值。

        v12.10.4 重写：把 win32com 调用搬到独立 Python 子进程跑，主进程零 COM 状态污染。

        历史问题（< v12.10.4）：原版直接在主进程 import win32com.client + DispatchEx
        Excel.Application — 这让 PySide6 主进程进入 STA COM 状态。
        即使 pythoncom.CoUninitialize() 配对调用，COM proxy 引用 / Excel 进程残留
        可能让主进程 COM 状态保持脏 — 后续 subprocess.Popen / tasklist 等系统调用
        与脏 COM 冲突，触发 RPC_E_DISCONNECTED (0x80010108) 闪退。

        修复：subprocess.Popen 拉子进程跑 modules.pdt_post_process_runner，
              逐行读 stdout（JSON）转发到 sig_log；子进程退出后 COM 状态自然清理。
              主线程**仍同步阻塞**等子进程完成（保留接口契约 — 调用方 on_execute_finished
              依赖此返回后再做 UI 更新）；同步阻塞期间 Qt 事件冻结约 3-5s
              （与原版 win32com 阻塞时长相当），但主进程不留 COM 副作用。
        """
        if not pdt_path or not os.path.isfile(pdt_path):
            self.sig_log.emit(f"<span style='color:#F56C6C;'>> PDT 文件不存在：{pdt_path}</span>")
            return

        # v12.10.30：用 app_paths.child_command_pdt_post_process 工厂构造命令
        # frozen → [SASEG.exe, "--child", "pdt_post_process", abs_pdt_path]
        # 开发  → [python, "-m", "modules.pdt_post_process_runner", abs_pdt_path]
        from app_paths import child_command_pdt_post_process, app_root
        cmd = child_command_pdt_post_process(pdt_path)
        spahub_dir = app_root()

        try:
            # v12.10.30：强制子进程 stdout 用 UTF-8（同 ScriptRunnerThread 修法）
            # 注意 frozen 模式下 cmd[0]=SASEG.exe，--child 子任务会执行 saseg_child
            # 内的 _task_pdt_post_process → 它内部 _emit 调 print(JSON)，
            # 同样需要 PYTHONIOENCODING/PYTHONUTF8 保证中文 JSON 字段不乱码。
            env = os.environ.copy()
            env["PYTHONIOENCODING"] = "utf-8"
            env["PYTHONUTF8"] = "1"

            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                cwd=spahub_dir,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
                env=env,
                creationflags=0x08000000,  # CREATE_NO_WINDOW — 同上
            )
        except Exception as e:
            self.sig_log.emit(f"<span style='color:#F56C6C;'>> 启动 PDT 后处理子进程失败：{e}</span>")
            return

        # 逐行读 stdout —— 子进程通过 JSON 行汇报进度
        # 父进程同步阻塞读，但每行都立刻 emit 到 sig_log 让用户实时看到（即使 Qt 事件冻结，
        # 文本会在子进程结束后一次性显示，但日志仍完整）
        import json as _json
        level_to_color = {
            "info": "#909399",   # 灰
            "ok":   "#67C23A",   # 绿
            "warn": "#E6A23C",   # 黄
            "err":  "#F56C6C",   # 红
        }
        try:
            assert proc.stdout is not None
            for raw_line in proc.stdout:
                line = (raw_line or "").rstrip()
                if not line:
                    continue
                # 期望是 JSON 行；不是的话就当普通文本灰显
                try:
                    obj = _json.loads(line)
                    lvl = (obj.get("level") or "info").lower()
                    msg = obj.get("msg") or ""
                except Exception:
                    lvl = "info"
                    msg = line
                color = level_to_color.get(lvl, "#909399")
                self.sig_log.emit(f"<span style='color:{color};'>&nbsp;&nbsp;[PDT后处理] {msg}</span>")
        except Exception as e:
            self.sig_log.emit(f"<span style='color:#E6A23C;'>> 读子进程 stdout 异常：{e}</span>")

        # 等子进程完整退出（while 已经 break；这里 wait 是为拿 returncode）
        try:
            rc = proc.wait(timeout=30)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass
            self.sig_log.emit("<span style='color:#F56C6C;'>> PDT 后处理子进程超时（30s），已 kill。</span>")
            return

        # 子进程退出码总结：
        #   0 win32com 成功
        #   1 win32com 失败但 openpyxl 兜底成功
        #   2 两者均失败
        #   3 文件不存在 / 参数错误
        if rc == 0:
            pass  # 已经在子进程内 emit 过 "win32com 全量公式重算完成"
        elif rc == 1:
            self.sig_log.emit(
                "<span style='color:#E6A23C;'>> PDT 后处理：win32com 不可用，已用 openpyxl 兜底。</span>"
            )
        elif rc == 2:
            self.sig_log.emit(
                "<span style='color:#F56C6C;'>> PDT 后处理：win32com 与 openpyxl 兜底均失败，请手动检查 PDT 文件。</span>"
            )
        elif rc == 3:
            self.sig_log.emit(
                f"<span style='color:#F56C6C;'>> PDT 后处理：子进程认为 PDT 文件不存在（{pdt_path}）。</span>"
            )
        else:
            self.sig_log.emit(
                f"<span style='color:#F56C6C;'>> PDT 后处理子进程异常退出（returncode={rc}）。</span>"
            )
