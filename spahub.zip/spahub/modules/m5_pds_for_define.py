# -*- coding: utf-8 -*-
"""
modules/m5_pds_for_define.py
============================
M5 模块 - 02 PDS for vars

职责：
  - 调用外部独立 Python 包 crt_vars（位于 Z:\\projects\\Z_PYTHON\\CRT\\crt_vars），
    把 SDTM/ADaM 的 PDS 模板 + XPT + anno_study + TDM 重新生成
    <spec>_PDS_vars.xlsx（Define-XML 准备阶段的变量级 spec）。
  - 入口：crt_vars.run.run(cfg, out_path=..., lng=..., verbose=True, write_sdrg=...)
    cfg = crt_vars.Config(ra_root=<四级目录>, libname='sdtm'|'adam', ...)。
    Config 仅需一个 ra_root 即可派生全部路径（xpt_dir / spec / spec_vars /
    define_dir / anno_study / tdm）；本 UI 把这些派生值**自动填入可编辑输入框**，
    用户可逐项「浏览」覆盖（与 02 Metadata Setup 的输入风格一致）。

UI 设计（v12.10.111）：
  - 顶部：libname 下拉框（sdtm / adam，原生右侧下拉箭头），切换即重填下方源文件。
  - 源文件输入（自动填写 + 浏览，允许用户自选）：
      1. XPT 目录（xpt_dir）
      2. SDTM/ADaM PDS 模板（spec）
      3. 输出 spec_vars（out_path）
      4. define 输出目录（define_dir）
      5. anno_study（anno_study）
      6. TDM Trial Design Model（tdm，仅 SDTM 需要）
    ra_root（四级目录）不在 UI 暴露——由主控自动推送 base_path 作为 ra_root。
  - 高级参数（默认折叠，固定选项做下拉）：
      testyn(y/n) / lng(CN/EN) / overwrite(True/False) /
      write_sdrg(True/False) / encoding(文本，默认 utf-8)

运行机制：
  后台线程构造 Config(ra_root=base_path, libname, testyn, overwrite, encoding, lng)，
  再用 UI 6 个输入框的值**覆盖 Config 的派生路径属性**（cfg.xpt_dir / cfg.spec_path /
  cfg.anno_study_path / cfg.tdm_path / cfg.spec_vars_path / cfg.define_dir），最后
  run(cfg, out_path=<spec_vars 输入框>, ...)。io_read.load_inputs 正是读取这些属性，
  故 6 个输入框对引擎完全生效。

依赖（crt_vars 运行时）：pandas / pyreadstat / openpyxl（需全局安装，勿用 venv）。
"""
import os
import sys
import html
import importlib

# ================= 外部工具包路径注册 =================
# 包磁盘位置：Z:\projects\Z_PYTHON\CRT\crt_vars（包目录直接在 CRT 下）。
# 需要把「含 crt_vars 包目录的那一层」加入 sys.path，即 Z:\projects\Z_PYTHON\CRT。
# 兼容 zip 内的 crt_py\crt_vars 布局（登记 ...\CRT\crt_py）。
# 策略同 tfls_metadata：优先本地同级（开发/单测），找不到退回固定网络路径；
# sys.path.append（不 insert）避免抢占同名标准库。
_CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
_PARENT_DIR = os.path.dirname(_CURRENT_DIR)

_CRT_ROOT = r"Z:\projects\Z_PYTHON\CRT"
for _c in (os.path.join(_PARENT_DIR, "CRT"), os.path.join(os.path.dirname(_PARENT_DIR), "CRT")):
    if os.path.isdir(_c):
        _CRT_ROOT = _c
        break


def _resolve_crt_import_dir():
    """返回应加入 sys.path 的目录（其下存在 crt_vars/ 包目录）。
    兼容： <CRT>/crt_vars/__init__.py → 返回 <CRT>
           <CRT>/crt_py/crt_vars/__init__.py → 返回 <CRT>/crt_py
    找不到时退回 <CRT>（用户给定的网络盘布局）。
    """
    for sub in ("", "crt_py"):
        base = os.path.join(_CRT_ROOT, sub) if sub else _CRT_ROOT
        if os.path.isfile(os.path.join(base, "crt_vars", "__init__.py")):
            return base
    return _CRT_ROOT


_CRT_IMPORT_DIR = _resolve_crt_import_dir()
_CRT_PKG_DIR = os.path.join(_CRT_IMPORT_DIR, "crt_vars")  # 包目录（config.py 在此）

if _CRT_IMPORT_DIR and _CRT_IMPORT_DIR not in sys.path:
    sys.path.append(_CRT_IMPORT_DIR)
# ======================================================

from PySide6.QtWidgets import (QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                               QLineEdit, QComboBox, QFileDialog, QFrame, QProgressBar,
                               QWidget)
from PySide6.QtCore import Qt, QThread, Signal

from ui_utils import show_dialog, primary_outline_btn_style, scan_status_lbl_style


_LIBNAME_OPTIONS = ["sdtm", "adam"]
_TESTYN_OPTIONS = ["y", "n"]
_LNG_OPTIONS = ["CN", "EN"]
_BOOL_OPTIONS = ["True", "False"]
_DEFAULT_ENCODING = "utf-8"

# 与 sdtm_generate 的 dom/type 下拉同款样式：不覆写 ::drop-down，保留原生右侧箭头。
_COMBO_STYLE = ("padding: 6px 10px; border: 1px solid #DCDFE6; border-radius: 4px; "
                "background: #FFFFFF; color: #606266; font-weight: normal;")
_ENTRY_STYLE = "padding: 6px; border: 1px solid #DCDFE6; border-radius: 4px;"
_BROWSE_STYLE = ("background-color: #F5F7FA; color: #606266; border: 1px solid #DCDFE6; "
                 "padding: 6px 12px; border-radius: 4px;")


# v12.10.111：滚轮锁定的下拉框（仿 acrf_stepper._NoWheelComboBox）。
# 用户在左侧表单滚动时鼠标常飘过下拉框，QComboBox 默认 wheelEvent 会改 currentIndex
# → 误改 libname / testyn / overwrite 等。重写 wheelEvent 调 event.ignore()，让滚轮
# 只滚动外层页面、不改选项；改值只能靠鼠标点击展开候选列表。
class _NoWheelComboBox(QComboBox):
    def wheelEvent(self, event):
        event.ignore()



# =============================================================================
# 预览/默认派生用：独立加载 config.py（不经包 __init__，避免引入 pandas 重依赖）
# =============================================================================
_CONFIG_CLASS_CACHE = None


def _load_config_class_standalone():
    """直接按文件路径加载 crt_vars/config.py，返回其中的 Config 类（仅依赖标准库）。"""
    global _CONFIG_CLASS_CACHE
    if _CONFIG_CLASS_CACHE is not None:
        return _CONFIG_CLASS_CACHE
    cfg_py = os.path.join(_CRT_PKG_DIR, "config.py")
    if not os.path.isfile(cfg_py):
        return None
    try:
        import importlib.util
        mod_name = "crt_vars_config_standalone"
        spec = importlib.util.spec_from_file_location(mod_name, cfg_py)
        mod = importlib.util.module_from_spec(spec)
        sys.modules[mod_name] = mod   # dataclass 需要：exec 前先登记
        spec.loader.exec_module(mod)
        _CONFIG_CLASS_CACHE = getattr(mod, "Config", None)
    except Exception:
        _CONFIG_CLASS_CACHE = None
    return _CONFIG_CLASS_CACHE


# =============================================================================
# stdout/stderr → Qt 信号（行缓冲 + HTML 转义）
# =============================================================================
class _StreamCatcher:
    def __init__(self, sig):
        self.sig = sig
        self._buf = ""

    def write(self, text):
        if not text:
            return
        self._buf += text
        if "\n" not in self._buf:
            return
        parts = self._buf.split("\n")
        self._buf = parts[-1]
        for line in parts[:-1]:
            line = line.rstrip("\r")
            if line.strip():
                self.sig.emit(html.escape(line))

    def flush(self):
        if self._buf.strip():
            self.sig.emit(html.escape(self._buf.rstrip("\r\n")))
        self._buf = ""

    close = flush


# =============================================================================
# 高级参数折叠区（自包含，仿 sdtm_generate._CollapseSection）
# =============================================================================
class _CollapseSection(QFrame):
    def __init__(self, title="高级参数", parent=None):
        super().__init__(parent)
        self.setStyleSheet("QFrame { border: none; }")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(4)

        self.toggle_btn = QPushButton(f"▶ {title}")
        self.toggle_btn.setStyleSheet("""
            QPushButton { background: transparent; border: none; color: #409EFF;
                          font-size: 13px; font-weight: bold; text-align: left; padding: 4px 0; }
            QPushButton:hover { color: #66B1FF; }
        """)
        self.toggle_btn.setCursor(Qt.PointingHandCursor)
        self.toggle_btn.clicked.connect(self._on_toggle_clicked)
        lay.addWidget(self.toggle_btn, 0, Qt.AlignLeft)

        self.content = QFrame()
        self.content.setStyleSheet(
            "QFrame { background: #FAFBFC; border: 1px dashed #DCDFE6; border-radius: 4px; }")
        self.content_lay = QVBoxLayout(self.content)
        self.content_lay.setContentsMargins(10, 8, 10, 8)
        self.content_lay.setSpacing(8)
        self.content.setVisible(False)
        lay.addWidget(self.content)

        self._title = title
        self._expanded = False

    def _on_toggle_clicked(self):
        self._expanded = not self._expanded
        self.content.setVisible(self._expanded)
        self.toggle_btn.setText(f"{'▼' if self._expanded else '▶'} {self._title}")

    def addRow(self, layout):
        self.content_lay.addLayout(layout)


# =============================================================================
# 后台运行线程 —— 仅负责「起子进程 + 读其 stdout」，重活全在子进程（避免 GIL 卡 UI）
# =============================================================================
class PdsForDefineRunner(QThread):
    """
    v12.10.111：改为子进程方案。本 QThread 不再在进程内跑 crt_vars（pandas/openpyxl
    纯 Python 持 GIL 会卡死 UI），而是 subprocess.Popen 起 modules.m5_pds_runner，
    把参数 JSON 写到子进程 stdin，再**阻塞逐行读子进程 stdout**（I/O 等待释放 GIL，
    主线程 Qt 事件循环始终流畅）。子进程的 JSON 行解析后转成 log/progress/finished 信号。

    cfg_kwargs    : Config 构造标量参数（ra_root/libname/testyn/overwrite/encoding/lng）
    path_overrides: 6 个 UI 路径（覆盖 Config 派生属性）
    run_kwargs    : run() 参数（out_path/lng/verbose/write_sdrg）
    """
    log_signal = Signal(str)
    progress_signal = Signal(int, str)
    finished_signal = Signal(bool, str)

    def __init__(self, cfg_kwargs, path_overrides, run_kwargs):
        super().__init__()
        self.cfg_kwargs = dict(cfg_kwargs)
        self.path_overrides = dict(path_overrides)
        self.run_kwargs = dict(run_kwargs)
        self.is_cancelled = False
        self.proc = None

    def cancel(self):
        """主线程调用：标志位 + 杀子进程树。"""
        self.is_cancelled = True
        p = self.proc
        if p is None:
            return
        try:
            if p.poll() is None:
                if os.name == "nt":
                    # 杀整棵进程树（pandas/pyreadstat 不起孙进程，但稳妥起见 /T）
                    import subprocess
                    subprocess.run(
                        ["taskkill", "/F", "/T", "/PID", str(p.pid)],
                        creationflags=0x08000000,
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                    )
                else:
                    p.kill()
        except Exception:
            try:
                p.kill()
            except Exception:
                pass

    def run(self):
        import subprocess
        import json as _json
        from app_paths import child_command_m5_pds, app_root

        payload = _json.dumps({
            "crt_import_dir": _CRT_IMPORT_DIR,
            "cfg_kwargs": self.cfg_kwargs,
            "path_overrides": self.path_overrides,
            "run_kwargs": self.run_kwargs,
        }, ensure_ascii=False)

        env = os.environ.copy()
        env["PYTHONIOENCODING"] = "utf-8"
        env["PYTHONUTF8"] = "1"

        try:
            self.proc = subprocess.Popen(
                child_command_m5_pds(),
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                cwd=app_root(),
                encoding="utf-8",
                errors="replace",
                bufsize=1,
                env=env,
                creationflags=0x08000000,  # CREATE_NO_WINDOW（父 pythonw 无 console）
            )
        except Exception as e:
            self.finished_signal.emit(False, f"❌ 启动子进程失败：{e}")
            return

        # 把参数写入子进程 stdin（一行 JSON），随后关闭 stdin 让子进程开始读
        try:
            self.proc.stdin.write(payload + "\n")
            self.proc.stdin.flush()
            self.proc.stdin.close()
        except Exception as e:
            self.finished_signal.emit(False, f"❌ 向子进程写参数失败：{e}")
            try:
                self.proc.kill()
            except Exception:
                pass
            return

        ok = False
        final_msg = ""
        out_paths = []
        got_result = False
        try:
            for raw_line in self.proc.stdout:
                if self.is_cancelled:
                    break
                line = (raw_line or "").rstrip()
                if not line:
                    continue
                try:
                    obj = _json.loads(line)
                except Exception:
                    # 非 JSON（子进程 C 层 stderr 等）→ 当普通日志（escape 后交给 _on_log）
                    self.log_signal.emit(html.escape(line))
                    continue
                lvl = (obj.get("level") or "info").lower()
                if lvl == "progress":
                    self.progress_signal.emit(int(obj.get("val", 0) or 0), str(obj.get("msg", "")))
                elif lvl == "result":
                    got_result = True
                    ok = bool(obj.get("ok"))
                    final_msg = str(obj.get("msg", "") or "")
                    out_paths = list(obj.get("out_paths") or [])
                else:
                    # 普通日志行：_on_log 约定输入须已 escape（不再二次 escape）
                    self.log_signal.emit(html.escape(str(obj.get("msg", ""))))
        except Exception as e:
            self.log_signal.emit(f"<span style='color:#E6A23C;'>&gt; 读子进程 stdout 异常：{html.escape(str(e))}</span>")

        try:
            rc = self.proc.wait(timeout=30)
        except Exception:
            try:
                self.proc.kill()
            except Exception:
                pass
            rc = -1

        if self.is_cancelled:
            return

        if got_result and ok:
            msg = ("✅ 已生成：\n  " + "\n  ".join(out_paths)) if out_paths else (final_msg or "✅ spec_vars 生成完成。")
            self.finished_signal.emit(True, msg)
        elif got_result and not ok:
            self.finished_signal.emit(False, f"❌ {final_msg}" if final_msg else "❌ crt_vars 执行失败。")
        else:
            # 没收到 result 行（子进程异常退出 / 被杀）
            self.finished_signal.emit(False, f"❌ 子进程异常结束（exit={rc}），未返回结果。")


# =============================================================================
# 左侧表单组件 PdsForDefineForm
# =============================================================================
class PdsForDefineForm(QFrame):
    """
    M5 / 02 PDS for vars 的左侧业务表单。

    信号：
      sig_log / sig_status / sig_step_update / sig_run_started / sig_run_finished
    """
    sig_log = Signal(str)
    sig_status = Signal(str, str)
    sig_step_update = Signal(str)
    sig_run_started = Signal()
    sig_run_finished = Signal()

    def __init__(self):
        super().__init__()
        self.base_path = ""   # = Config.ra_root（四级目录，不在 UI 暴露）
        self._setup_ui()

    def _show_msg(self, title, text, msg_type="info"):
        return show_dialog(self, title, text, msg_type)

    # ------------------------- UI 构造 -------------------------
    def _setup_ui(self):
        self.setObjectName("LeftPanel")
        self.setStyleSheet("#LeftPanel { background-color: #FFFFFF; border: 1px solid #E4E7ED; border-radius: 6px; }")
        form_layout = QVBoxLayout(self)
        form_layout.setAlignment(Qt.AlignTop)
        form_layout.setContentsMargins(25, 25, 25, 25)
        form_layout.setSpacing(16)

        self._step_name = "PDS for vars"
        top_bar = QHBoxLayout()
        self.refresh_btn = QPushButton("🔄 刷新源文件")
        self.refresh_btn.setStyleSheet(primary_outline_btn_style())
        self.refresh_btn.setCursor(Qt.PointingHandCursor)
        self.refresh_btn.clicked.connect(self.action_refresh)
        top_bar.addWidget(self.refresh_btn)
        self.scan_lbl = QLabel("")
        self.scan_lbl.setStyleSheet(scan_status_lbl_style())
        top_bar.addWidget(self.scan_lbl)
        top_bar.addStretch()
        form_layout.addLayout(top_bar)

        title = QLabel("基于 PDS 模板 + XPT + anno_study + TDM，调用 crt_vars 生成变量级 spec（供 Define-XML 准备）。")
        title.setStyleSheet("color: #303133; font-weight: bold; font-size: 14px; border: none;")
        title.setWordWrap(True)
        form_layout.addWidget(title)

        self.prog = QProgressBar()
        self.prog.setVisible(False)
        self.prog.setFixedHeight(4)
        form_layout.addWidget(self.prog)

        # ---------- libname 下拉（原生右侧箭头） ----------
        lib_row = QHBoxLayout()
        lib_lbl = QLabel("libname：")
        lib_lbl.setStyleSheet("border: none; color: #606266; min-width: 150px;")
        lib_row.addWidget(lib_lbl)
        self.libname_combo = _NoWheelComboBox()
        self.libname_combo.setStyleSheet(_COMBO_STYLE)
        self.libname_combo.addItems(_LIBNAME_OPTIONS)
        self.libname_combo.currentIndexChanged.connect(self._on_libname_changed)
        lib_row.addWidget(self.libname_combo, 1)
        # v12.10.131：libname 现由 M5 顶部「数据类型」总开关驱动，整行包一层 QWidget 后隐藏
        # （combo 仍作状态容器，setCurrentText 触发 _on_libname_changed → 重填派生路径）。
        self._libname_row = QWidget()
        self._libname_row.setLayout(lib_row)
        form_layout.addWidget(self._libname_row)
        self._libname_row.setVisible(False)

        # ---------- 源文件输入（自动填写 + 浏览） ----------
        def add_row(label_text, browse, filter_str="*.xlsx"):
            """browse: 'dir' | 'file'"""
            l = QHBoxLayout()
            lbl = QLabel(label_text)
            lbl.setStyleSheet("border: none; color: #606266; min-width: 150px;")
            l.addWidget(lbl)
            entry = QLineEdit()
            entry.setStyleSheet(_ENTRY_STYLE)
            l.addWidget(entry)
            b = QPushButton("浏览")
            b.setStyleSheet(_BROWSE_STYLE)
            if browse == "dir":
                b.clicked.connect(lambda checked=False, e=entry: e.setText(
                    QFileDialog.getExistingDirectory(self, "选择目录",
                        e.text() if os.path.isdir(e.text()) else self.base_path) or e.text()))
            else:
                b.clicked.connect(lambda checked=False, e=entry, f=filter_str: e.setText(
                    QFileDialog.getOpenFileName(self, "选择文件",
                        os.path.dirname(e.text()) if os.path.isfile(e.text()) else self.base_path, f)[0] or e.text()))
            l.addWidget(b)
            form_layout.addLayout(l)
            return entry

        self.xpt_dir_entry = add_row("1. XPT 目录（xpt_dir）：", "dir")
        self.spec_entry = add_row("2. PDS 模板（spec）：", "file", "*.xlsx")
        # v12.10.121：3.输出 spec_vars / 4.define 输出目录 不再展示 —— 二者自动按 Config 派生，
        # 保留为**隐藏字段**（仍由 _fill_from_config 填充）供 runner 与「打开 define 目录」使用。
        self.spec_vars_entry = QLineEdit()
        self.define_dir_entry = QLineEdit()
        self.anno_study_entry = add_row("3. anno_study：", "file", "*.sas7bdat")
        self.tdm_entry = add_row("4. TDM（Trial Design Model）：", "file", "*.xlsx")

        # ---------- 高级参数（折叠） ----------
        # v12.10.121：标题列出具体参数名（与 SDTM-Gen 高级参数一致）
        self.adv = _CollapseSection("高级参数（testyn / lng / overwrite / write_sdrg）")

        def _adv_combo_row(label_text, options, default):
            row = QHBoxLayout()
            lbl = QLabel(label_text)
            lbl.setStyleSheet("border: none; color: #606266; min-width: 150px;")
            row.addWidget(lbl)
            combo = _NoWheelComboBox()
            combo.setStyleSheet(_COMBO_STYLE)
            combo.addItems(options)
            if default in options:
                combo.setCurrentIndex(options.index(default))
            row.addWidget(combo, 1)
            self.adv.addRow(row)
            return combo

        self.testyn_combo = _adv_combo_row("testyn：", _TESTYN_OPTIONS, "y")
        self.lng_combo = _adv_combo_row("lng（描述语言）：", _LNG_OPTIONS, "CN")
        self.overwrite_combo = _adv_combo_row("overwrite：", _BOOL_OPTIONS, "True")
        self.write_sdrg_combo = _adv_combo_row("write_sdrg：", _BOOL_OPTIONS, "True")
        # v12.10.111：encoding 不在 UI 暴露（固定走默认 utf-8）。

        form_layout.addWidget(self.adv)

        # ---------- 运行按钮区 ----------
        bl = QHBoxLayout()
        self.run_btn = QPushButton("▶ 生成 spec_vars")
        self.run_btn.setStyleSheet(
            "background-color: #4A6FA5; color: white; border: none; padding: 8px 20px; border-radius: 4px; font-weight: bold;")
        self.run_btn.clicked.connect(self.execute_run)
        bl.addWidget(self.run_btn)

        self.cancel_btn = QPushButton("🟥 中止")
        self.cancel_btn.setStyleSheet(
            "background-color: #FEF0F0; color: #F56C6C; border: 1px solid #FBC4C4; padding: 8px 20px; border-radius: 4px; font-weight: bold;")
        self.cancel_btn.setVisible(False)
        self.cancel_btn.clicked.connect(self.cancel_run)
        bl.addWidget(self.cancel_btn)

        open_btn = QPushButton("📂 打开 define 目录")
        open_btn.setStyleSheet(
            "background-color: #3F9A6E; color: white; border: none; padding: 8px 20px; border-radius: 4px; font-weight: bold;")
        open_btn.clicked.connect(self._open_define_dir)
        bl.addWidget(open_btn)
        bl.addStretch()
        form_layout.addLayout(bl)
        form_layout.addStretch()

    # ------------------------- 自动填写（从 Config 派生默认值） -------------------------
    def _fill_from_config(self):
        """用 base_path + 当前 libname 构造 Config，把 6 个派生路径填入输入框。
        与 02 Metadata 同款：自动填默认，用户可逐项浏览覆盖。"""
        if not self.base_path or not os.path.isdir(self.base_path):
            for e in (self.xpt_dir_entry, self.spec_entry, self.spec_vars_entry,
                      self.define_dir_entry, self.anno_study_entry, self.tdm_entry):
                e.clear()
            return
        Config = _load_config_class_standalone()
        if Config is None:
            # 退化：无法加载 config.py 做派生（不影响运行时包内 Config）——置空让用户手填
            for e in (self.xpt_dir_entry, self.spec_entry, self.spec_vars_entry,
                      self.define_dir_entry, self.anno_study_entry, self.tdm_entry):
                e.clear()
            return
        try:
            cfg = Config(ra_root=self.base_path,
                         libname=self.libname_combo.currentText().strip() or "sdtm")
            self.xpt_dir_entry.setText(cfg.xpt_dir or "")
            self.spec_entry.setText(cfg.spec_path or "")
            self.spec_vars_entry.setText(cfg.spec_vars_path or "")
            self.define_dir_entry.setText(cfg.define_dir or "")
            self.anno_study_entry.setText(cfg.anno_study_path or "")
            self.tdm_entry.setText(cfg.tdm_path or "")
        except Exception:
            pass

    def _on_libname_changed(self, *args):
        # 切换 sdtm/adam → 派生路径不同（tabulations/sdtm vs analysis/adam/datasets，
        # SDTM_PDS vs ADAM_PDS），重新自动填写。
        self._fill_from_config()

    def _open_define_dir(self):
        d = self.define_dir_entry.text().strip()
        if not d:
            sv = self.spec_vars_entry.text().strip()
            d = os.path.dirname(sv) if sv else ""
        if d and os.path.isdir(d):
            try:
                os.startfile(d)
            except Exception:
                pass
        else:
            self._show_msg("提示", f"define 目录尚不存在或未填写：\n{d or '(未知)'}", "info")

    # ------------------------- 数据类型总开关 -------------------------
    def set_data_type(self, data_type):
        """v12.10.131：由 M5Widget 顶部「数据类型」总开关驱动，设置 libname 并重填派生路径。
        canonical: "sdtm" / "adam"（大小写不敏感）。"""
        target = "adam" if (data_type or "").strip().lower() == "adam" else "sdtm"
        if self.libname_combo.currentText() != target:
            self.libname_combo.setCurrentText(target)   # 触发 _on_libname_changed → _fill_from_config
        else:
            self._fill_from_config()                     # 值未变不发信号，显式重填一次

    # ------------------------- 路径推送 -------------------------
    def update_paths(self, base_path):
        self.base_path = base_path
        self._fill_from_config()

    # ------------------------- 等待提示 -------------------------
    def set_wait_hint(self, show):
        if show:
            self.scan_lbl.setText("⏳ 等待填写完整路径...")
            self.scan_lbl.setStyleSheet(scan_status_lbl_style())
        else:
            self.scan_lbl.setText("")

    # ------------------------- 快捷键钩子 -------------------------
    def action_refresh(self):
        """F5 / 🔄 刷新源文件：按 base_path + libname 重新自动填写。"""
        self._fill_from_config()

    def action_run(self):
        btn = getattr(self, "run_btn", None)
        if btn is not None and btn.isEnabled() and btn.isVisible():
            btn.click()

    # ------------------------- 参数收集 -------------------------
    def _collect_cfg_kwargs(self):
        return {
            "ra_root": self.base_path,
            "libname": self.libname_combo.currentText().strip() or "sdtm",
            "testyn": self.testyn_combo.currentText().strip() or "y",
            "overwrite": (self.overwrite_combo.currentText().strip() == "True"),
            "encoding": _DEFAULT_ENCODING,
            "lng": self.lng_combo.currentText().strip() or "CN",
        }

    def _collect_path_overrides(self):
        return {
            "xpt_dir": self.xpt_dir_entry.text().strip(),
            "spec": self.spec_entry.text().strip(),
            "spec_vars": self.spec_vars_entry.text().strip(),
            "define_dir": self.define_dir_entry.text().strip(),
            "anno_study": self.anno_study_entry.text().strip(),
            "tdm": self.tdm_entry.text().strip(),
        }

    def _collect_run_kwargs(self):
        return {
            "out_path": self.spec_vars_entry.text().strip() or None,
            "lng": self.lng_combo.currentText().strip() or "CN",
            "verbose": True,
            "write_sdrg": (self.write_sdrg_combo.currentText().strip() == "True"),
        }

    # ------------------------- 执行 / 取消 / 回调 -------------------------
    def execute_run(self):
        if not self.base_path or not os.path.isdir(self.base_path):
            self._show_msg("错误", "项目路径（四级目录）无效，请先在顶部选择完整 csr 路径！", "error")
            return

        paths = self._collect_path_overrides()
        libname = self.libname_combo.currentText().strip() or "sdtm"

        # 入口校验：spec 模板必填且存在
        if not paths["spec"]:
            self._show_msg("错误", "PDS 模板（spec）路径不能为空，请先填写或刷新！", "error")
            return
        if not os.path.isfile(paths["spec"]):
            self._show_msg("错误", f"PDS 模板文件不存在：\n{paths['spec']}", "error")
            return

        # 输入存在性提示（非阻断输出类）
        missing = []
        if paths["xpt_dir"] and not os.path.isdir(paths["xpt_dir"]):
            missing.append(f"xpt_dir: {paths['xpt_dir']}")
        if paths["anno_study"] and not os.path.isfile(paths["anno_study"]):
            missing.append(f"anno_study: {paths['anno_study']}")
        if libname == "sdtm" and paths["tdm"] and not os.path.isfile(paths["tdm"]):
            missing.append(f"tdm: {paths['tdm']}")
        if missing:
            confirm = self._show_msg(
                "输入缺失", "以下输入不存在，仍要继续？\n\n" + "\n".join(missing), "question")
            if not confirm:
                self.sig_log.emit("<span style='color:#909399;'>已取消生成任务。</span>")
                return

        # v12.10.111：检测目标输出文件是否已存在 → 弹窗征询覆盖（类似 02 Metadata Setup）。
        # 输出 = spec_vars（out_path）；write_sdrg=True 时还会在同目录写 pds4sdrg.xlsx(SDTM)
        # 或 pds4adrg.xlsx(ADAM)。逐一检测已存在者并列给用户确认。
        spec_vars = paths["spec_vars"].strip()
        existing = []
        if spec_vars and os.path.isfile(spec_vars):
            existing.append(spec_vars)
        if self.write_sdrg_combo.currentText().strip() == "True" and spec_vars:
            sdrg_name = "pds4sdrg.xlsx" if libname == "sdtm" else "pds4adrg.xlsx"
            sdrg_path = os.path.join(os.path.dirname(spec_vars), sdrg_name)
            if os.path.isfile(sdrg_path):
                existing.append(sdrg_path)
        if existing:
            confirm = self._show_msg(
                "覆盖警告",
                f"检测到目标目录中已存在 {len(existing)} 个输出文件：\n\n"
                + "\n".join(os.path.basename(p) for p in existing)
                + "\n\n本次生成将直接覆盖原有文件，是否确认继续？",
                "question")
            if not confirm:
                self.sig_log.emit("<span style='color:#909399;'>已取消生成任务（用户取消覆盖）。</span>")
                return

        cfg_kwargs = self._collect_cfg_kwargs()
        run_kwargs = self._collect_run_kwargs()

        self.sig_run_started.emit()

        self.run_btn.hide()
        self.cancel_btn.show()
        self.prog.setRange(0, 0)
        self.prog.setVisible(True)
        self.prog.setValue(0)

        self.sig_log.emit(
            f"<span style='color:#409EFF;'>> 启动 PDS for vars（crt_vars，libname={libname}）...</span>")
        self.sig_status.emit("⏳ 正在执行中...", "#409EFF")

        self.runner = PdsForDefineRunner(cfg_kwargs, paths, run_kwargs)
        self.runner.log_signal.connect(self._on_log)
        self.runner.progress_signal.connect(self._on_progress)
        self.runner.finished_signal.connect(self._on_finished)
        self.runner.start()

    def _on_log(self, text):
        """text 已在 _StreamCatcher 侧 html.escape；此处只套颜色 <span>，不再 escape。"""
        color = "#606266"
        if "ERROR" in text or "❌" in text:
            color = "#F56C6C"
        elif "WARNING" in text or "⚠️" in text:
            color = "#E6A23C"
        elif "✅" in text:
            color = "#67C23A"
        self.sig_log.emit(f"<span style='color:{color};'>{text}</span>")

    def _on_progress(self, val, msg):
        self.sig_log.emit(f"<b>{html.escape(str(msg))}</b>")

    def _on_finished(self, success, msg):
        if hasattr(self, "runner") and self.runner.is_cancelled:
            return
        self.cancel_btn.hide()
        self.run_btn.show()
        self.prog.setVisible(False)

        if success:
            self.sig_status.emit("✅ spec_vars 生成成功！", "#67C23A")
            self.sig_step_update.emit("02 PDS for vars ✅")
            if msg:
                self.sig_log.emit(f"<span style='color:#67C23A; font-weight:bold;'>{html.escape(msg)}</span>")
        else:
            self.sig_status.emit("❌ 生成失败！", "#F56C6C")
            self.sig_step_update.emit("02 PDS for vars ❌")
            self._show_msg("错误", msg, "error")
        self.sig_run_finished.emit()

    def cancel_run(self):
        if hasattr(self, "runner") and self.runner.isRunning():
            self.runner.cancel()   # v12.10.111：标志位 + 杀子进程树
            self.runner.wait(5000)
        self.cancel_btn.hide()
        self.run_btn.show()
        self.prog.setVisible(False)

        self.sig_status.emit("🛑 已中止", "#F56C6C")
        self.sig_step_update.emit("02 PDS for vars 🟥")
        self.sig_log.emit("<span style='color:#F56C6C; font-weight:bold;'>[已中止] 🛑 用户手动取消了执行。</span>")
        self.sig_run_finished.emit()
