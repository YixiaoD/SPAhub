# -*- coding: utf-8 -*-
"""
modules/acrf_unzip.py
=====================
aCRF 模块 - 01 Unzip Source

职责：
  - 在 92_import 下自动定位最新的 DM 部门交付 zip
    （包含 SAS / PRO / HRS / SHR / HR 关键字优先；都没找到 → 用 mtime 最新）
  - 用户可手动浏览覆盖默认值
  - 点击 ▶ 运行 时，把所选 zip 文件名（仅 basename）回写到 20_unzip_call.sas 的
    %unzip(zip_file=%str(...)) 宏调用中，然后用 SingleBatchRunner 提交 SAS 执行
  - 解压结果：unzip 宏 outlib=source（即 00_source_data），把 zip 内容平铺过去

设计要点：
  - 行级替换：定位"含 %unzip(zip_file=" 的整行，整体覆写为标准格式
    避免对 %str(...) 内部嵌套括号做精确括号配对扫描
  - 写回前读入旧内容，对比发现"已是目标值"则跳过写盘，减少 utility/tools 噪音
  - 复用 SingleBatchRunner（v12.2 已稳定的子进程 + run_sas 模式）

v12.4 关键修复（unzip 静默失败的检测）：
  - unzip 宏在 zip 不存在时不会抛 ERROR/WARNING，反而会把 `ls: 无法访问 ...` 的报错
    当成一行 path 读进 _files_mv_99 然后 mv 走 → 仅看 ERROR/WARNING 会误判为"成功"。
  - 因此运行结束后扫描日志 keyword：
      失败信号：日志中含 'ls:' 且含 '无法访问' 或 'cannot access'  → 判失败
      展示信号：MPRINT(UNZIP): ... x "mv ..."   → 实际执行的搬运指令
                NOTE: ... N observations read from the data set WORK._FILES_MV_99   → 搬运行数
"""
import os
import re
import time
from datetime import datetime

from PySide6.QtWidgets import (QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                               QLineEdit, QFileDialog, QFrame, QProgressBar)
from PySide6.QtCore import Qt, Signal, QThread

from modules.tfls_batch_run import SingleBatchRunner
from ui_utils import (show_dialog, primary_outline_btn_style, scan_status_lbl_style,
                      primary_btn_style, danger_btn_style, success_btn_style, light_btn_style)


# 文件名关键字白名单（不区分大小写）：DM 部门交付包多半带这些前缀/含这些片段
_NAME_KEYWORDS = ("SAS", "PRO", "HRS", "SHR", "HR")


def pick_latest_in_dir(dir_path: str, want_zip: bool):
    """
    在指定目录下挑选"最新"的目标文件/目录。

    规则：
      - want_zip=True：仅看 .zip 文件
      - want_zip=False：仅看子目录
      - 按"含关键字"优先：若名字（不区分大小写）包含 SAS/PRO/HRS/SHR/HR 任一，先在这部分中按 mtime 取最新；
        若关键字组完全为空，再退回所有候选中按 mtime 取最新。
      - 找不到任何候选返回 ""

    返回：basename（不含路径），不存在则空串。
    """
    if not (dir_path and os.path.isdir(dir_path)):
        return ""

    candidates = []
    try:
        for name in os.listdir(dir_path):
            full = os.path.join(dir_path, name)
            if want_zip:
                if not os.path.isfile(full):
                    continue
                if not name.lower().endswith(".zip"):
                    continue
            else:
                if not os.path.isdir(full):
                    continue
            try:
                mtime = os.path.getmtime(full)
            except OSError:
                continue
            candidates.append((name, mtime))
    except OSError:
        return ""

    if not candidates:
        return ""

    upper_keywords = tuple(k.upper() for k in _NAME_KEYWORDS)

    def has_keyword(n):
        u = n.upper()
        return any(k in u for k in upper_keywords)

    keyworded = [c for c in candidates if has_keyword(c[0])]
    pool = keyworded if keyworded else candidates
    pool.sort(key=lambda x: x[1], reverse=True)
    return pool[0][0]


def _rewrite_unzip_call(sas_path: str, new_zip_name: str) -> tuple:
    """
    定位 20_unzip_call.sas 中 `%unzip(zip_file=...)` 行并整体覆写。

    返回 (changed: bool, msg: str)：
      - changed=True 表示文件被改写；
      - changed=False + msg 含原因（已经是目标值 / 找不到行 等）。

    设计：行级匹配 + 整体替换，避免对 %str(...) 内嵌括号做精确括号配对扫描。
    匹配规则：行起首允许任意空白；命中 `%unzip(zip_file=` 即视为目标行。
    """
    if not os.path.isfile(sas_path):
        return False, f"找不到 SAS 文件：{sas_path}"

    try:
        with open(sas_path, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
    except OSError as e:
        return False, f"读取 SAS 文件失败：{e}"

    # 命中第一行 `%unzip(zip_file=`，整行重写
    target_pattern = re.compile(r"^\s*%unzip\s*\(\s*zip_file\s*=", re.IGNORECASE)
    new_line = f"%unzip(zip_file=%str({new_zip_name}))\n"

    target_idx = None
    for i, line in enumerate(lines):
        if target_pattern.search(line):
            target_idx = i
            break

    if target_idx is None:
        return False, "未找到 %unzip(zip_file=...) 行"

    if lines[target_idx].rstrip("\r\n") == new_line.rstrip("\r\n"):
        return False, "SAS 文件已是目标值，无需改写"

    lines[target_idx] = new_line
    try:
        with open(sas_path, "w", encoding="utf-8") as f:
            f.writelines(lines)
    except OSError as e:
        return False, f"写回 SAS 文件失败：{e}"
    return True, "已更新 SAS 文件"


def _diagnose_unzip_log(log_text: str):
    """
    v12.4：对 unzip 宏的 SAS 日志做实质成败判定。

    背景：unzip 宏当 zip 文件不存在时不会抛 ERROR/WARNING；它执行 `ls .../zip_dest`
    管道时拿到 'ls: 无法访问 ...: 没有那个文件或目录'（中文 locale）或
    'ls: cannot access ...' （英文 locale），这一行被当成路径喂进 _files_mv_99
    然后被 mv 走，整套逻辑跑完反而是 1 obs。仅看 has_issue 会误判为成功。

    判定规则：
      - 失败信号：日志文本中同时含 'ls:' 和（'无法访问' 或 'cannot access'）
      - obs 信号：捕获 'NOTE: There were N observations read from the data set WORK._FILES_MV_99'
      - mv 展示：抓出 'MPRINT(UNZIP):' 含 'mv ' 的行作为搬运凭据

    返回 (ok: bool|None, summary: str, html: str)
      ok=True   实质成功
      ok=False  实质失败（zip 没找到 / mv 出错）
      ok=None   无法判定（既无失败信号又无成功信号）
      summary   一行总览，写到状态栏
      html      要追加到日志面板的 HTML 片段（已转义；失败行红色，搬运行灰色）
    """
    if not log_text:
        return None, "(无日志)", ""

    # 1. 失败信号
    text_lc = log_text.lower()
    cn_fail = "无法访问" in log_text and "ls:" in log_text
    en_fail = ("ls:" in log_text) and ("cannot access" in text_lc)
    failed = cn_fail or en_fail

    # 2. _FILES_MV_99 obs 数
    files_mv_obs = None
    m_obs = re.search(
        r"NOTE:\s*There\s+were\s+(\d+)\s+observations\s+read\s+from\s+the\s+data\s+set\s+WORK\._FILES_MV_99",
        log_text, re.IGNORECASE
    )
    if m_obs:
        files_mv_obs = int(m_obs.group(1))

    # 3. MPRINT(UNZIP) ... x "mv ... " 行（只取最后一段 mv 操作的）
    mv_lines = []
    for line in log_text.splitlines():
        s = line.rstrip()
        if "MPRINT(UNZIP):" in s and ("mv " in s or "mv\t" in s):
            mv_lines.append(s)

    # 4. 失败行（含 ls: 无法访问 / cannot access 的所有行，便于完整呈现）
    fail_lines = []
    for line in log_text.splitlines():
        s = line.rstrip()
        s_lc = s.lower()
        if ("ls:" in s) and ("无法访问" in s or "cannot access" in s_lc):
            fail_lines.append(s)

    # ---- 拼装回包 ----
    def _esc(s):
        return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))

    html_parts = []
    if files_mv_obs is not None:
        html_parts.append(
            f"<span style='color:#909399;'>&nbsp;&nbsp;NOTE: WORK._FILES_MV_99 共 {files_mv_obs} 行 mv 操作</span>"
        )
    if failed:
        html_parts.append(
            "<span style='color:#F56C6C;'>&nbsp;&nbsp;❗ 检测到 ls 报错 — 表示 92_import 下找不到匹配的 zip 文件，"
            "unzip 宏的临时目录从未真正生成。请核对 zip 文件名（区分大小写）。</span>"
        )
        for fl in fail_lines[:6]:
            html_parts.append(f"<span style='color:#F56C6C;'>&nbsp;&nbsp;{_esc(fl)}</span>")
        if len(fail_lines) > 6:
            html_parts.append(
                f"<span style='color:#F56C6C;'>&nbsp;&nbsp;… 还有 {len(fail_lines) - 6} 行类似失败信息 …</span>"
            )

    # 搬运凭据：仅成功路径下展示 mv 命令；失败时展示 mv 反而会让人困惑
    if not failed and mv_lines:
        for mv in mv_lines[:6]:
            html_parts.append(f"<span style='color:#909399;'>&nbsp;&nbsp;{_esc(mv)}</span>")
        if len(mv_lines) > 6:
            html_parts.append(
                f"<span style='color:#909399;'>&nbsp;&nbsp;… 还有 {len(mv_lines) - 6} 行 mv 命令 …</span>"
            )

    html_str = "<br>".join(html_parts) if html_parts else ""

    if failed:
        if files_mv_obs is not None:
            return False, f"未找到 zip 文件（_files_mv_99={files_mv_obs} 实为 ls 错误回显）", html_str
        return False, "未找到 zip 文件（ls 报『无法访问』）", html_str

    # 无失败信号
    if files_mv_obs is None:
        # 没拿到 obs 数 — 谨慎判 None（可能日志被截断）
        return None, "未捕获到 _files_mv_99 的 obs 数，请检查完整日志", html_str
    if files_mv_obs <= 0:
        return False, "_files_mv_99 obs=0，未搬运任何文件", html_str
    return True, f"已搬运 {files_mv_obs} 个文件到 00_source_data", html_str


# =============================================================================
# 后台路径扫描线程（v12.10.2 加入）
# 目的：消除 update_paths 在 Z:\ 网络盘上 listdir + getmtime 阻塞主线程的卡顿。
# 主线程立即 setText placeholder，IO 完成后通过 Signal 回主线程更新真实值。
# =============================================================================
class _UnzipPathScanThread(QThread):
    """扫描 92_import 下最新 zip + sas 脚本是否存在，结果通过 Signal 回主线程"""
    finished_signal = Signal(int, dict)  # token, {sas_exists, zip_name, src_dir_exists, src_dir, sas_path}

    def __init__(self, base_path: str, token: int, parent=None):
        super().__init__(parent)
        self.base_path = base_path or ""
        self.token = token

    def run(self):
        result = {
            "sas_exists": False,
            "sas_path": "",
            "zip_name": "",
            "src_dir": "",
            "src_dir_exists": False,
        }
        try:
            sas_path = os.path.join(self.base_path, "utility", "tools", "20_unzip_call.sas")
            result["sas_path"] = sas_path
            result["sas_exists"] = os.path.isfile(sas_path)
            src_dir = os.path.join(self.base_path, "92_import")
            result["src_dir"] = src_dir
            result["src_dir_exists"] = os.path.isdir(src_dir)
            result["zip_name"] = pick_latest_in_dir(src_dir, want_zip=True)
        except Exception:
            # 任何异常都让结果保留默认空值；主线程 setText 时会 fallback 到 placeholder
            pass
        self.finished_signal.emit(self.token, result)


# =============================================================================
# 左侧表单组件 UnzipSourceForm
# =============================================================================
class UnzipSourceForm(QFrame):
    """aCRF / 01 Unzip Source 的左侧业务表单"""

    sig_log = Signal(str)
    sig_status = Signal(str, str)
    sig_step_update = Signal(str)
    sig_run_started = Signal()
    sig_run_finished = Signal()

    def __init__(self):
        super().__init__()
        self.base_path = ""
        self._step_name = "Unzip Source"
        self._runner = None
        self._cancelled = False  # v12.10.20: 用户主动中止标志，防 race 闪退（与 acrf_edc_recode 同模式）
        # v12.10.2：后台路径扫描（避免 Z:\ 网络盘 listdir 阻塞主线程）
        self._path_scan_token = 0
        self._retired_path_threads = []
        self._setup_ui()

    # ------------------------- UI -------------------------
    def _setup_ui(self):
        self.setObjectName("LeftPanel")
        self.setStyleSheet("#LeftPanel { background-color: #FFFFFF; border: 1px solid #E4E7ED; border-radius: 6px; }")
        form = QVBoxLayout(self)
        form.setAlignment(Qt.AlignTop)
        form.setContentsMargins(25, 25, 25, 25)
        form.setSpacing(15)

        # 顶部刷新栏
        top_bar = QHBoxLayout()
        self.refresh_btn = QPushButton("🔄 刷新源文件")
        # v12.10.65：统一改用 home"📁 系统文件复制"同款蓝色外框样式
        self.refresh_btn.setStyleSheet(primary_outline_btn_style())
        self.refresh_btn.setCursor(Qt.PointingHandCursor)
        top_bar.addWidget(self.refresh_btn)
        self.scan_lbl = QLabel("")
        self.scan_lbl.setStyleSheet(scan_status_lbl_style())
        top_bar.addWidget(self.scan_lbl)
        top_bar.addStretch()
        form.addLayout(top_bar)

        title = QLabel("调用 20_unzip_call.sas，将 92_import 下的 zip 解压到 00_source_data。")
        title.setStyleSheet("color: #303133; font-weight: bold; font-size: 14px; border: none;")
        title.setWordWrap(True)
        form.addWidget(title)

        # 行 1：zip 文件
        row_zip = QHBoxLayout()
        lbl_zip = QLabel("源 ZIP 文件：")
        lbl_zip.setStyleSheet("border: none; color: #606266; min-width: 130px;")
        row_zip.addWidget(lbl_zip)
        self.zip_entry = QLineEdit()
        self.zip_entry.setStyleSheet("padding: 6px; border: 1px solid #DCDFE6; border-radius: 4px;")
        self.zip_entry.setPlaceholderText("等待 4 级路径填全后自动定位…")
        row_zip.addWidget(self.zip_entry, 1)
        self.btn_browse_zip = QPushButton("浏览")
        # v12.10.68：统一改用 helper（与 TOC ▶初版TOC/🟥中止/📂打开TOC 视觉一致）
        self.btn_browse_zip.setStyleSheet(light_btn_style())
        self.btn_browse_zip.setCursor(Qt.PointingHandCursor)
        self.btn_browse_zip.clicked.connect(self._on_browse_zip)
        row_zip.addWidget(self.btn_browse_zip)
        form.addLayout(row_zip)

        # 行 2：20_unzip_call.sas（只读，便于查看 + 打开）
        row_sas = QHBoxLayout()
        lbl_sas = QLabel("调用脚本：")
        lbl_sas.setStyleSheet("border: none; color: #606266; min-width: 130px;")
        row_sas.addWidget(lbl_sas)
        self.sas_entry = QLineEdit()
        self.sas_entry.setReadOnly(True)
        self.sas_entry.setStyleSheet(
            "padding: 6px; border: 1px solid #DCDFE6; border-radius: 4px; background: #F5F7FA; color: #606266;")
        row_sas.addWidget(self.sas_entry, 1)
        self.btn_open_sas = QPushButton("📂 打开")
        # v12.10.68：统一改用 helper（与 TOC ▶初版TOC/🟥中止/📂打开TOC 视觉一致）
        self.btn_open_sas.setStyleSheet(light_btn_style())
        self.btn_open_sas.setCursor(Qt.PointingHandCursor)
        self.btn_open_sas.clicked.connect(self._open_sas_file)
        row_sas.addWidget(self.btn_open_sas)
        form.addLayout(row_sas)

        # 进度条（运行中显示无限流）
        self.prog = QProgressBar()
        self.prog.setVisible(False)
        self.prog.setFixedHeight(4)
        self.prog.setTextVisible(False)  # v12.10.13：4px 太矮装不下文字，关闭百分比显示避免和上方 label 重叠
        form.addWidget(self.prog)

        # 运行按钮 + 中止按钮（运行中互斥显示）
        btn_row = QHBoxLayout()
        self.btn_run = QPushButton("▶ 运行 Unzip")
        # v12.10.68：统一改用 helper（与 TOC ▶初版TOC/🟥中止/📂打开TOC 视觉一致）
        self.btn_run.setStyleSheet(primary_btn_style())
        self.btn_run.setCursor(Qt.PointingHandCursor)
        self.btn_run.clicked.connect(self.run_unzip)
        btn_row.addWidget(self.btn_run)

        # v12.6：中止按钮 — 运行时显示，点击后 kill 子进程并主动复位 UI
        # （SingleBatchRunner 取消后不发 finished_signal，因此 form 自己负责 UI 恢复）
        self.btn_cancel = QPushButton("🟥 中止")
        # v12.10.68：统一改用 helper（与 TOC ▶初版TOC/🟥中止/📂打开TOC 视觉一致）
        self.btn_cancel.setStyleSheet(danger_btn_style())
        self.btn_cancel.setCursor(Qt.PointingHandCursor)
        self.btn_cancel.setVisible(False)
        self.btn_cancel.clicked.connect(self._on_cancel_run)
        btn_row.addWidget(self.btn_cancel)
        btn_row.addStretch()
        form.addLayout(btn_row)

        # v12.10.127：两个「打开目录」按钮移到第二行，避免与「运行 Unzip / 中止」挤在
        #   同一行时因左面板较窄被截断（原来 4 个按钮同排，两个打开按钮显示不全）。
        open_row = QHBoxLayout()
        self.btn_open_import = QPushButton("📂 打开 92_import")
        # v12.10.68：统一改用 helper（与 TOC ▶初版TOC/🟥中止/📂打开TOC 视觉一致）
        self.btn_open_import.setStyleSheet(success_btn_style())
        self.btn_open_import.setCursor(Qt.PointingHandCursor)
        self.btn_open_import.clicked.connect(self._open_import_dir)
        open_row.addWidget(self.btn_open_import)

        self.btn_open_src = QPushButton("📂 打开 00_source_data")
        # v12.10.68：统一改用 helper（与 TOC ▶初版TOC/🟥中止/📂打开TOC 视觉一致）
        self.btn_open_src.setStyleSheet(success_btn_style())
        self.btn_open_src.setCursor(Qt.PointingHandCursor)
        self.btn_open_src.clicked.connect(self._open_src_dir)
        open_row.addWidget(self.btn_open_src)
        open_row.addStretch()
        form.addLayout(open_row)
        form.addStretch()

    # ------------------------- 路径推送 / 自动探测 -------------------------
    def update_paths(self, base_path):
        """
        由主控推送路径；自动定位 92_import 下最新 zip 与 SAS 脚本。

        v12.10.2：IO 拆到后台线程（_UnzipPathScanThread），主线程立即返回，
        避免 Z:\\ 网络盘 listdir + getmtime 阻塞 ~1-2s 卡顿主线程。
        - 主线程：base_path 赋值 → 显示 ⏳ 占位 → 启动后台扫描
        - 后台线程：listdir + getmtime + isfile（在 Z:\\ 上 ~1-2s）
        - 回主线程：根据 token 校验后 setText 真实值
        """
        self.base_path = base_path or ""

        # 主线程立即清空输入框 + 显示扫描中提示（避免界面闪烁出旧值）
        self.sas_entry.setText("")
        self.zip_entry.clear()
        self.zip_entry.setPlaceholderText("⏳ 扫描 92_import 中…")
        self._set_scanning_hint(True)

        # 启动后台扫描；token 递增让旧结果失效
        self._path_scan_token += 1
        token = self._path_scan_token
        thread = _UnzipPathScanThread(self.base_path, token, parent=self)
        thread.finished_signal.connect(self._on_path_scan_done)
        # 防 GC：保留引用直到 finished
        self._retired_path_threads.append(thread)
        thread.start()

    def _set_scanning_hint(self, on: bool):
        """设置 scan_lbl 文案：扫描中 / 已就绪 / 等待路径。"""
        if on:
            self.scan_lbl.setText("⏳ 扫描中…")
            self.scan_lbl.setStyleSheet(scan_status_lbl_style("#409EFF"))
        else:
            self.scan_lbl.setText("")

    def _on_path_scan_done(self, token: int, result: dict):
        """后台扫描完成：若 token 仍是最新，主线程更新控件。"""
        if token != self._path_scan_token:
            return  # 过期结果丢弃（用户已切到新路径）

        # 1. SAS 脚本路径
        if result.get("sas_exists"):
            self.sas_entry.setText(result.get("sas_path", ""))
        else:
            self.sas_entry.setText("")

        # 2. 最新 zip
        zip_name = result.get("zip_name", "")
        src_dir = result.get("src_dir", "")
        src_dir_exists = result.get("src_dir_exists", False)
        if zip_name:
            self.zip_entry.setText(os.path.join(src_dir, zip_name))
        else:
            self.zip_entry.clear()
            if src_dir_exists:
                self.zip_entry.setPlaceholderText("92_import 下未找到 .zip")
            else:
                self.zip_entry.setPlaceholderText("92_import 目录不存在")

        self._set_scanning_hint(False)

        # 标记线程已完成，让 Qt 在事件循环空闲时回收（避免 race）
        sender = self.sender()
        if sender is not None:
            try:
                sender.finished.connect(sender.deleteLater)
            except Exception:
                pass

    def set_wait_hint(self, show):
        """控制左侧上方等待提示的显隐"""
        if show:
            self.scan_lbl.setText("⏳ 等待填写完整路径...")
            self.scan_lbl.setStyleSheet(scan_status_lbl_style())
        else:
            self.scan_lbl.setText("")

    # ------------------------- 浏览 / 打开 -------------------------
    def _on_browse_zip(self):
        """浏览按钮：QFileDialog 选择 .zip，默认起点为 92_import"""
        start_dir = ""
        if self.zip_entry.text().strip() and os.path.isfile(self.zip_entry.text().strip()):
            start_dir = os.path.dirname(self.zip_entry.text().strip())
        elif self.base_path:
            cand = os.path.join(self.base_path, "92_import")
            start_dir = cand if os.path.isdir(cand) else self.base_path
        path, _ = QFileDialog.getOpenFileName(self, "选择源 ZIP 文件（92_import）", start_dir, "ZIP 文件 (*.zip)")
        if path:
            self.zip_entry.setText(path)

    def _open_sas_file(self):
        sas_path = self.sas_entry.text().strip()
        if sas_path and os.path.isfile(sas_path):
            os.startfile(sas_path)
        else:
            show_dialog(self, "提示", "找不到 20_unzip_call.sas 文件。", "warning")

    def _open_src_dir(self):
        if not self.base_path:
            return
        src = os.path.join(self.base_path, "00_source_data")
        if os.path.isdir(src):
            os.startfile(src)

    def _open_import_dir(self):
        if not self.base_path:
            return
        imp = os.path.join(self.base_path, "92_import")
        if os.path.isdir(imp):
            os.startfile(imp)

    # ------------------------- 全局快捷键钩子 -------------------------
    def action_refresh(self):
        """F5：点击"🔄 刷新源文件" """
        btn = getattr(self, "refresh_btn", None)
        if btn is not None and btn.isEnabled():
            btn.click()

    def action_run(self):
        """Ctrl+Enter：触发 ▶ 运行 Unzip"""
        if self.btn_run.isEnabled():
            self.btn_run.click()

    # ------------------------- 运行入口 -------------------------
    def run_unzip(self):
        """点击 ▶ 运行：校验 → 改写 SAS → 后台跑 SAS"""
        zip_path = self.zip_entry.text().strip()
        if not zip_path:
            show_dialog(self, "提示", "源 ZIP 文件路径不能为空，请填写或浏览选择。", "warning")
            return
        if not os.path.isfile(zip_path):
            show_dialog(self, "错误", f"找不到 ZIP 文件：\n{zip_path}", "error")
            return
        if not zip_path.lower().endswith(".zip"):
            show_dialog(self, "提示", "所选文件不是 .zip，请确认后再试。", "warning")
            return

        sas_path = self.sas_entry.text().strip()
        if not sas_path or not os.path.isfile(sas_path):
            show_dialog(self, "错误", f"找不到 SAS 调用脚本：\n{sas_path}", "error")
            return

        # 不再每次都嵌入完整路径：%unzip 宏只接受 zip 文件名（默认从 00_source_data 解析）
        zip_name = os.path.basename(zip_path)
        # 防重入：上一次还在跑
        if self._runner is not None and self._runner.isRunning():
            self.sig_log.emit("<span style='color:#E6A23C;'>⏳ 上一次 Unzip 仍在运行中，请稍候…</span>")
            return

        # 改写 SAS
        changed, msg = _rewrite_unzip_call(sas_path, zip_name)
        self.sig_run_started.emit()
        self.sig_status.emit("⏳ 正在执行 Unzip…", "#409EFF")
        self.sig_log.emit(
            f"<span style='color:#409EFF; font-weight:bold;'>🚀 准备执行 20_unzip_call.sas</span>"
        )
        self.sig_log.emit(f"<span style='color:#909399;'>&nbsp;&nbsp;源 ZIP：{zip_name}</span>")
        self.sig_log.emit(f"<span style='color:#909399;'>&nbsp;&nbsp;脚本：{sas_path}</span>")
        if changed:
            self.sig_log.emit(
                f"<span style='color:#67C23A;'>&nbsp;&nbsp;✏️ 已写入 zip_file = %str({zip_name}) 到 SAS 文件。</span>"
            )
        else:
            self.sig_log.emit(f"<span style='color:#909399;'>&nbsp;&nbsp;ℹ️ {msg}</span>")

        # 进入运行态
        self.btn_run.setVisible(False)
        self.btn_cancel.setVisible(True)
        self.prog.setRange(0, 0)
        self.prog.setVisible(True)

        # 启动后台 SAS（复用 SingleBatchRunner：子进程 + run_sas，强制 check_log=False）
        self._runner = SingleBatchRunner(sas_path)
        self._runner.finished_signal.connect(self._on_runner_finished)
        self._t_start = time.time()
        self._runner.start()

    def _on_cancel_run(self):
        """v12.6：中止当前运行。SingleBatchRunner.is_cancelled=True + kill 子进程，
        然后主动复位 UI。

        v12.10.20: 修复"中止时无痕闪退"，与 acrf_edc_recode v12.10.17 同模式。
          原假设"runner 在取消分支下不会 emit finished_signal"在 race window 不成立：
          当 SAS 子进程恰好正常退出与中止信号竞争时，run() 已经走过 is_cancelled 检查，
          仍会 emit finished_signal → _on_runner_finished 访问已清 None 的 _runner → 闪退。
          修法：加 self._cancelled 标志，不再立即清 self._runner，留给 finished 内统一清理。
        """
        runner = self._runner
        if runner is None or not runner.isRunning():
            # 已经结束 — 仅复位 UI 防御
            self._reset_ui_after_run()
            return
        self._cancelled = True   # v12.10.20: 让 _on_runner_finished 检测后直接 return
        runner.is_cancelled = True
        try:
            if runner.proc and runner.proc.poll() is None:
                runner.proc.kill()
        except Exception:
            pass
        self.sig_status.emit("🛑 已中止 Unzip", "#F56C6C")
        self.sig_step_update.emit("01 Unzip Source 🟥")
        self.sig_log.emit("<span style='color:#F56C6C; font-weight:bold;'>🛑 用户已中止 Unzip 运行。</span>")
        self._reset_ui_after_run()
        # v12.10.20: 不再立即 self._runner = None — 留给 _on_runner_finished 内清理

    def _reset_ui_after_run(self):
        """统一的运行后 UI 复位：进度条隐藏，按钮 ▶/🟥 切回"▶ 显示、🟥 隐藏"。"""
        self.prog.setVisible(False)
        self.btn_run.setVisible(True)
        self.btn_cancel.setVisible(False)

    def _on_runner_finished(self, has_issue, summary, log_text):
        """SingleBatchRunner.finished_signal 回调

        v12.4：除了 ERROR/WARNING 自动检测外，再做一次"unzip 实质判定"——
        unzip 宏在 zip 不存在时会让 ls 报错并把错误信息当成路径喂进 _files_mv_99，
        因此仅看 has_issue 会误判为成功。我们改为：
          1. 扫描日志中的 'ls:' + '无法访问' / 'cannot access' → 命中即判定 unzip 失败
          2. 把 MPRINT(UNZIP) 的 mv 命令、_FILES_MV_99 obs 数都展示出来给用户
          3. 失败行标红 + 给出"请检查 92_import 下文件名"的提示

        v12.10.20: 检测 _cancelled 标志 → 直接 return 避免 race 闪退（同 acrf_edc_recode）
        """
        if getattr(self, "_cancelled", False):
            self._cancelled = False
            thread_ref = self._runner
            self._runner = None
            if thread_ref is not None:
                try:
                    thread_ref.finished.connect(thread_ref.deleteLater)
                except Exception:
                    pass
            return

        self._reset_ui_after_run()
        elapsed = time.time() - getattr(self, "_t_start", time.time())

        # v12.4：对 unzip 日志做实质判定
        unzip_ok, unzip_summary, unzip_html = _diagnose_unzip_log(log_text)
        # 综合判断：SAS 自身有 ERROR/WARNING 或 unzip 实质失败 → 整体失败
        is_failed = has_issue or (unzip_ok is False)

        if is_failed:
            if unzip_ok is False:
                self.sig_status.emit(f"❌ Unzip 失败：{unzip_summary}", "#F56C6C")
                self.sig_step_update.emit("01 Unzip Source ❌")
                self.sig_log.emit(
                    f"<span style='color:#F56C6C; font-weight:bold;'>❌ Unzip 隐式失败 — {unzip_summary}</span>"
                )
            else:
                self.sig_status.emit(f"❌ Unzip 完成（含警告/错误）", "#F56C6C")
                self.sig_step_update.emit("01 Unzip Source ⚠️")
                self.sig_log.emit(
                    f"<span style='color:#F56C6C; font-weight:bold;'>❌ Unzip 执行存在 ERROR/WARNING — {summary}</span>"
                )
            # unzip_html 优先（含失败行），否则退回 SAS 日志的 ERROR/WARNING 行
            if unzip_html:
                self.sig_log.emit(unzip_html)
            else:
                self.sig_log.emit(self._extract_issue_lines(log_text))
        else:
            self.sig_status.emit(f"✅ Unzip 完成（{elapsed:.1f}s）— {unzip_summary}", "#67C23A")
            self.sig_step_update.emit("01 Unzip Source ✅")
            self.sig_log.emit(
                f"<span style='color:#67C23A; font-weight:bold;'>✅ Unzip 执行完毕 — {summary}</span>"
            )
            if unzip_html:
                self.sig_log.emit(unzip_html)

        # v12.10.20: 安全读 script_path（兜底 None）
        try:
            if self._runner is not None and getattr(self._runner, "script_path", None):
                log_path = os.path.splitext(self._runner.script_path)[0] + ".log"
                if os.path.exists(log_path):
                    self.sig_log.emit(f"<span style='color:#909399;'>&nbsp;&nbsp;详细日志：{log_path}</span>")
        except Exception:
            pass

        # v11.9 安全释放 thread：仅 finished.connect(deleteLater)，避免 race
        thread_ref = self._runner
        self._runner = None
        if thread_ref is not None:
            try:
                thread_ref.finished.connect(thread_ref.deleteLater)
            except Exception:
                pass

    @staticmethod
    def _extract_issue_lines(log_text: str) -> str:
        """从完整 log_text 中抽取首批 ERROR/WARNING 行（最多 8 行）做前端展示"""
        if not log_text:
            return "<i style='color:#909399;'>(SAS 未返回日志内容)</i>"
        out = []
        for line in log_text.splitlines():
            s = line.strip()
            up = s.upper()
            if up.startswith("ERROR:") or up.startswith("WARNING:"):
                color = "#F56C6C" if up.startswith("ERROR:") else "#E6A23C"
                # 简单转义
                safe = (s.replace("&", "&amp;")
                         .replace("<", "&lt;")
                         .replace(">", "&gt;"))
                out.append(f"<span style='color:{color};'>&nbsp;&nbsp;{safe}</span>")
                if len(out) >= 8:
                    out.append("<i style='color:#909399;'>&nbsp;&nbsp;… 更多详见日志文件 …</i>")
                    break
        if not out:
            return "<i style='color:#909399;'>(未匹配到标准 ERROR/WARNING 行)</i>"
        return "<br>".join(out)
