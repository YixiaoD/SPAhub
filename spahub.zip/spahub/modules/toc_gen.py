# -*- coding: utf-8 -*-
# modules/toc_gen.py — TOC Gen 页（DataLoaderThread 扫描 anno_study/EDC 字典 → TOCRunnerThread 调 gen_toc_study）
#
# v12.10.70：DataLoaderThread 新增统计 anno_study TEXT 列中 "LB = 实验室检查" 注释条数
#   （lb_anno_count），随 result/kwargs 透传给 gen_toc_study，供下游决定
#   16.2.8-1.99「实验室检查结果-其他」listing 是否产出（条数 > LBCAT 唯一类目数才出）。
# v12.10.72：TOC Gen 日志措辞调整——
#   · 首行扫描提示改为"开始跨目录扫描 TDM、anno_study、EDC 数据库定义文件..."；
#   · 实验室检查"其他"门控日志改为"edcdef 中 LBCAT 类目 X 条，anno_study 类目 Y 条 → 产出/不产出…"，
#     去掉表号自增（"16.2.8-1.x 末尾+1"）等内置实现细节，不向用户展示。
# v12.10.109：TOC Gen 两处改进——
#   · 问题1 TX.Type 解析：除 "+" 外，"/"（及全角"／"）也作为阶段串联分隔符，
#     "SAD/FE" 等价于 SAD+FE → 两个阶段都自动勾选，不再误报"非预设阶段值"告警。
#   · 缺失项告警文案具体化：把笼统的"请修改源文件"改为对应「打开目录」按钮指向的实际文件——
#     问题1（来源 TDM）→ "请修改 Trial Design Model（TDM）"；
#     问题2（来源 anno_study）→ "请修改 aCRF 并更新 anno_study.sas7bdat"。
import os
import re
import shutil
import tempfile
import glob
import pandas as pd
from openpyxl import load_workbook, Workbook
from openpyxl.utils import get_column_letter
from openpyxl.styles import Font

from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QSplitter, QLabel,
                               QPushButton, QLineEdit, QFileDialog, QTextEdit, QDialog,
                               QFrame, QCheckBox, QGridLayout, QProgressBar, QScrollArea)
from PySide6.QtCore import Qt, QThread, Signal, QTimer  # 增加了 QTimer

from ui_utils import (show_dialog, show_text_input_dialog,
                      primary_btn_style, danger_btn_style, success_btn_style, light_btn_style,
                      primary_outline_btn_style, scan_status_lbl_style, log_textedit_style)


# === 底层读取引擎 ===
def read_sas_safe(file_path):
    """读 .sas7bdat：先拷到临时目录再读（避免共享盘锁）。

    encoding='utf-8' 必须显式指定 — 否则 pandas.read_sas 默认返回 bytes 对象，
    Chinese 字段会变成 b'\\xe5\\x89...' 这样的字面量，写到 TOC.xlsx 里也是乱码。
    国内 SAS 数据集底层一般是 UTF-8（SAS Dataset Encoding wlatin1/utf8），
    若遇 GBK 编码的旧数据集再回退一次。
    """
    if not file_path or not os.path.exists(file_path): return None
    ext = os.path.splitext(file_path)[1]
    fd, temp_path = tempfile.mkstemp(suffix=ext)
    os.close(fd)
    try:
        shutil.copy2(file_path, temp_path)
        try:
            return pd.read_sas(temp_path, format='sas7bdat', encoding='utf-8')
        except Exception:
            # 兜底：GBK 编码的旧数据集
            try:
                return pd.read_sas(temp_path, format='sas7bdat', encoding='gbk')
            except Exception:
                return None
    except Exception:
        return None
    finally:
        try:
            os.remove(temp_path)
        except:
            pass


def read_excel_safe(file_path, sheet_name=0):
    if not file_path or not os.path.exists(file_path): return None
    ext = os.path.splitext(file_path)[1]
    fd, temp_path = tempfile.mkstemp(suffix=ext)
    os.close(fd)
    try:
        shutil.copy2(file_path, temp_path)
        xl = pd.ExcelFile(temp_path)
        if isinstance(sheet_name, str) and sheet_name not in xl.sheet_names: return None
        return xl.parse(sheet_name)
    except:
        return None
    finally:
        try:
            os.remove(temp_path)
        except:
            pass


# === 后台扫描线程 ===
class DataLoaderThread(QThread):
    finished_signal = Signal(dict)

    def __init__(self, base_path, tdm_prefix, default_analyte_val):
        super().__init__()
        self.base_path = base_path
        self.tdm_prefix = tdm_prefix
        self.default_analyte_val = default_analyte_val

    def run(self):
        source_data_dir = os.path.join(self.base_path, "00_source_data")
        anno_dir = os.path.join(self.base_path, "utility", "documentation", "06_crt_preparation", "062_acrf")
        meta_dir = os.path.join(self.base_path, "utility", "metadata")

        anno_path = os.path.join(anno_dir, "anno_study.sas7bdat")
        ecrf_path = os.path.join(meta_dir, "edcdef_ecrf.sas7bdat")
        code_path = os.path.join(meta_dir, "edcdef_code.sas7bdat")

        found_tdm_path = None
        loaded_tdm_types = set()
        missing_items = []

        has_plasma, has_urine, has_stool = False, False, False
        has_pc = False  # v12.10.58：PC domain 是否存在（仿照 has_ada 模式）
        has_ada, has_vsclsig = False, False
        has_aedis, has_aesi = False, False
        aeacn_str, lbcat_str = "None", "None"
        ordered_analytes = []
        has_tdm_duplicate = False
        unknown_types = []  # v12.10.44：TDM TX.Type 列里未识别的文案（如"安全性分析"）
        # v12.10.69：anno_study 中是否含"随机"字样 → 决定是否产出 listing 16.2.1-2
        has_randomized = False
        # v12.10.70：anno_study TEXT 中 "LB = 实验室检查" 注释条数 → 决定 16.2.8-1.99「其他」是否出
        lb_anno_count = 0

        if self.tdm_prefix:
            search_pattern = f"{self.tdm_prefix}_Trial_Design_Model*.xls*"
            matches = glob.glob(os.path.join(source_data_dir, search_pattern))
            if matches: found_tdm_path = matches[0]

        if not found_tdm_path:
            missing_items.append(f"缺失 TDM 文件: {source_data_dir}")
        else:
            df_tdm = read_excel_safe(found_tdm_path, "TX")
            # v12.10.44：预设阶段类型集（SAD+FE / SAD/FE 这种串联会逐一拆分判定，所以两个都纳入预设）
            # v12.10.109：串联分隔符同时支持 "+" 与 "/"（含全角"／"）
            # 行为：
            #   - 完全在预设里  → 全部保留为 loaded_tdm_types
            #   - 完全不在预设里（如只有"安全性分析"）→ loaded_tdm_types 空 → 下游自动降级 {"单阶段"}
            #   - 混合（如 SAD + 其他）→ 只保留预设里的（SAD），未识别的部分进 unknown_types
            #     列表，由 _on_scan_finished 在右侧日志打 WARNING 让用户自行确认
            _KNOWN_STAGES = {"SAD", "MAD", "FE", "BE", "MB"}
            if df_tdm is not None and 'Subpr' in df_tdm.columns and 'Type' in df_tdm.columns:
                seen_combos = set()
                for idx, row in df_tdm.iterrows():
                    subpr = str(row.get('Subpr', '')).strip()
                    typ = str(row.get('Type', '')).strip().upper()
                    if subpr.lower() == 'nan': subpr = ""
                    if typ.lower() == 'nan' or not typ: continue
                    combo = (subpr, typ)
                    if combo in seen_combos: has_tdm_duplicate = True
                    seen_combos.add(combo)
                    # v12.10.109：阶段串联分隔符支持 "+" 与 "/"（含全角"／"）——"SAD/FE" 视作 SAD+FE
                    for part in re.split(r'[+/／]', typ):
                        p = part.strip().upper()
                        if not p:
                            continue
                        if p in _KNOWN_STAGES:
                            loaded_tdm_types.add(p)
                        else:
                            # 不在预设里 → 不入 loaded_tdm_types（避免后续把"安全性分析"当成阶段处理），
                            # 但要记下来在日志里告知用户
                            if p not in unknown_types:
                                unknown_types.append(p)

        df_anno = read_sas_safe(anno_path)
        if df_anno is None:
            missing_items.append(f"缺失 anno_study.sas7bdat: {anno_dir}")
        else:
            df_anno.columns = [c.upper() for c in df_anno.columns]
            for col in df_anno.columns:
                if df_anno[col].dtype == 'object':
                    df_anno[col] = df_anno[col].apply(
                        lambda x: x.decode('utf-8', 'ignore') if isinstance(x, bytes) else str(x))
            if 'TEXT' in df_anno.columns:
                # v12.10.69：先取一份未 upper() 的原始文本，用于检测 Chinese "随机" 关键字
                # （upper() 不影响中文但保留原文便于将来扩展其它中文关键字检查）
                all_text_raw = "".join(df_anno['TEXT'].dropna().astype(str))
                if "随机" in all_text_raw:
                    has_randomized = True
                # v12.10.70：统计 "LB = 实验室检查" 注释条数（= 不同实验室检查 CRF 页数）。
                #   下游与 LBCAT 唯一类目数比较：> 时产出 16.2.8-1.99「实验室检查结果-其他」。
                #   允许 = 号两侧任意空白、LB 大小写不敏感（中文部分原样）。
                _re_lb_anno = re.compile(r'LB\s*=\s*实验室检查', re.IGNORECASE)
                lb_anno_count = sum(
                    len(_re_lb_anno.findall(str(t)))
                    for t in df_anno['TEXT'].dropna().astype(str)
                )
                all_text_nospace = re.sub(r'\s+', '', "".join(df_anno['TEXT'].dropna().astype(str))).upper()
                # v12.10.58：仿照 has_ada（IS domain 检 ISTESTCD=ADA）的模式，先检 PC domain 是否存在。
                # PC domain 的核心标识字段是 PCTESTCD（任意值）；只要 anno_study 里出现过 PCTESTCD=...
                # 即认为做了 PK 分析。
                # 修复历史 bug：原 has_plasma 逻辑 ("PCSPEC" not in text or "PCSPEC=PLASMA" in text)
                # 在 PC domain 根本不存在时也命中，导致 PK 浓度(血)/PK 参数(血) 误自动勾选。
                if re.search(r"PCTESTCD\s*=", all_text_nospace): has_pc = True
                # PCSPEC 细分（血/尿/粪）仅当 PC domain 存在时才做；不存在 → 三者全 False
                # → 下游 q2_cbs 不勾选 → PCSPEC="None" → tfls_pdt._toc_filter_and_expand_rows
                # 中的 `if not pcspecs: continue` 自动跳过所有 PK 浓度/PK 参数行
                if has_pc:
                    if "PCSPEC" not in all_text_nospace or "PCSPEC=PLASMA" in all_text_nospace: has_plasma = True
                    if "PCSPEC=URINE" in all_text_nospace: has_urine = True
                    if "PCSPEC=STOOL" in all_text_nospace: has_stool = True
                if re.search(r"ISTESTCD=['\"]?ADA['\"]?", all_text_nospace): has_ada = True
                if "VSCLSIG" in all_text_nospace: has_vsclsig = True

                if 'RECT' in df_anno.columns:
                    analytes_tmp = []
                    for idx, row in df_anno.iterrows():
                        t_val = str(row['TEXT']).upper()
                        if 'PCTESTCD' in t_val:
                            parts = t_val.split('=')
                            if len(parts) > 1:
                                analyte_cln = re.sub(r"['\"\;]", "", parts[1]).strip()
                                y_val = float(str(row['RECT']).split(',')[1].strip()) if len(
                                    str(row['RECT']).split(',')) >= 2 else 0.0
                                if analyte_cln: analytes_tmp.append({'a': analyte_cln, 'y': y_val})
                    analytes_tmp.sort(key=lambda x: x['y'])
                    seen = set()
                    for item in analytes_tmp:
                        if item['a'] not in seen:
                            seen.add(item['a'])
                            ordered_analytes.append(item['a'])

        if not ordered_analytes and self.default_analyte_val:
            ordered_analytes.append(self.default_analyte_val)

        df_ecrf = read_sas_safe(ecrf_path)
        if df_ecrf is not None:
            all_text_ecrf = "".join(df_ecrf.astype(str).apply(lambda row: "".join(row), axis=1).tolist()).upper()
            if "AEDIS" in all_text_ecrf: has_aedis = True
            if "AESI" in all_text_ecrf: has_aesi = True

        df_code = read_sas_safe(code_path)
        if df_code is not None:
            df_code.columns = [c.upper() for c in df_code.columns]
            if 'CODE_NAME' in df_code.columns and 'CODE_LABEL' in df_code.columns:
                df_aeacn = df_code[df_code['CODE_NAME'].astype(str).str.strip().str.upper() == 'AEACN']
                aeacn_list = [str(v).strip() for v in df_aeacn['CODE_LABEL'] if
                              str(v).strip() and not re.search(r'(?i)applicable|不适用|剂量不变|changed', str(v))]
                if aeacn_list: aeacn_str = "|".join(list(dict.fromkeys(aeacn_list)))

                mask = df_code['CODE_NAME'].astype(str).str.strip().str.upper() == 'LBCAT'
                if 'CODE_GRP' in df_code.columns:
                    mask = mask & (df_code['CODE_GRP'].astype(str).str.strip().str.upper() == 'LB')
                lbcat_list = [str(v).strip() for v in df_code[mask]['CODE_LABEL'] if str(v).strip()]
                if lbcat_list: lbcat_str = "|".join(list(dict.fromkeys(lbcat_list)))

        result = {
            "tdm_types": loaded_tdm_types, "has_tdm_duplicate": has_tdm_duplicate, "missing_items": missing_items,
            "unknown_tdm_types": unknown_types,  # v12.10.44：未识别的 Type 文案，用于日志警告
            "has_plasma": has_plasma, "has_urine": has_urine, "has_stool": has_stool, "has_ada": has_ada,
            "has_pc": has_pc,  # v12.10.58：PC domain 是否存在（决定 PK 项警告文案分支）
            "has_vsclsig": has_vsclsig,
            "has_aedis": has_aedis, "has_aesi": has_aesi, "aeacn_str": aeacn_str, "lbcat_str": lbcat_str,
            "tdm_path": found_tdm_path, "ordered_analytes": ordered_analytes,
            # v12.10.69：anno_study 是否含"随机"字样 → 决定 listing 16.2.1-2 是否产出
            "has_randomized": has_randomized,
            # v12.10.70：anno_study "LB = 实验室检查" 注释条数 → 决定 16.2.8-1.99「其他」是否产出
            "lb_anno_count": lb_anno_count,
        }
        self.finished_signal.emit(result)


# === 独立的 TOC 生成线程 ===
class TOCRunnerThread(QThread):
    finished_signal = Signal(bool, str)

    def __init__(self, kwargs):
        super().__init__()
        self.kwargs = kwargs
        self.is_cancelled = False

    def run(self):
        try:
            from modules.tfls_pdt import gen_toc_study
            success, msg = gen_toc_study(**self.kwargs)
            if self.is_cancelled:
                return
            self.finished_signal.emit(success, msg)
        except Exception as e:
            if self.is_cancelled:
                return
            self.finished_signal.emit(False, f"异常: {str(e)}")


# === 核心 UI 组件 ===
class TOCGenWidget(QWidget):
    def __init__(self, gui):
        super().__init__()
        self.gui = gui
        self.base_path = ""
        self.p2 = ""
        self.p3 = ""
        self.extracted_data = {}
        self._orphan_threads = []

        self.q1_cbs = {}
        self.q2_cbs = {}
        self.q3_cbs = {}
        self.q4_cbs = {}      # 问题4：PK 参数对比分析的影响因子（食物/时辰/性别/单多次给药 多选）
        self.analyte_cbs = []
        self.qt_cbs = {}

        # v12.10.57：Q3"其他"选项的用户自定义文本（勾选时弹输入框获取）
        self.q3_other_text = ""

        # --- 新增：弹窗拦截标记 ---
        self.pending_missing_warning = False

        self._setup_ui()

    def showEvent(self, event):
        """【生命周期钩子】：当组件被切换到前台显示时触发"""
        super().showEvent(event)
        # 检查是否有挂起的缺失警告，延迟 200 毫秒确保 UI 渲染完成再弹窗
        if getattr(self, 'pending_missing_warning', False):
            QTimer.singleShot(200, self._show_delayed_warning)

    def _show_delayed_warning(self):
        """实际执行弹窗"""
        if getattr(self, 'pending_missing_warning', False):
            show_dialog(self, "文件缺失", "部分前置字典文件未找到，请查看右侧日志。", "warning")
            self.pending_missing_warning = False

    def _show_msg(self, title, text, msg_type="info", path=None):
        """统一弹窗引擎 - 委托至全局共享函数"""
        return show_dialog(self, title, text, msg_type, path=path)

    def update_path(self, base_path, p2, p3):
        self.base_path = base_path
        self.p2 = p2
        self.p3 = p3

        selected_count = sum(1 for p in self.gui.selected_paths if p)
        paths_complete = selected_count == 4

        if not paths_complete:
            # 未填完：清空输入框，显示等待提示
            if hasattr(self, 'tmpl_entry'):
                self.tmpl_entry.clear()
            if hasattr(self, 'toc_entry'):
                self.toc_entry.clear()
            self.scan_lbl.setText("⏳ 等待填写完整路径...")
            if hasattr(self, 'edit_btn'):
                self.edit_btn.setVisible(False)
            return

        new_default = os.path.join(base_path, "utility", "template", "TOC_template.xlsx")
        if not os.path.exists(new_default):
            new_default = r"Z:\projects\utility\template\TOC_template.xlsx"

        if hasattr(self, 'tmpl_entry'):
            self.tmpl_entry.setText(new_default)
        if hasattr(self, 'toc_entry'):
            self.toc_entry.setText(os.path.join(base_path, "utility", "documentation", "03_statistics", "TOC.xlsx"))

        self._check_edit_status()
        self.run_background_scan()

    def _check_edit_status(self):
        if hasattr(self, 'edit_btn'):
            path = self.toc_entry.text().strip()
            self.edit_btn.setVisible(os.path.isfile(path))

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.splitter = QSplitter(Qt.Horizontal)
        self.splitter.setStyleSheet("QSplitter::handle { background-color: #EBEEF5; width: 4px; }")

        self.left_panel = QFrame()
        self.left_panel.setObjectName("LeftPanel")
        self.left_panel.setStyleSheet(
            "#LeftPanel { background-color: #FFFFFF; border: 1px solid #E4E7ED; border-radius: 6px; }")

        self.left_layout = QVBoxLayout(self.left_panel)
        self.left_layout.setAlignment(Qt.AlignTop)
        self.left_layout.setContentsMargins(25, 25, 25, 25)
        self.left_layout.setSpacing(15)

        top_bar = QHBoxLayout()
        self.refresh_btn = QPushButton("🔄 刷新源文件")
        # v12.10.65：统一改用 home"📁 系统文件复制"同款蓝色外框样式（之前用 light_btn_style，
        # hover 后字仍为蓝色不变白；现在与其它模块的"刷新源文件"按钮以及 home 完全一致）
        self.refresh_btn.setStyleSheet(primary_outline_btn_style())
        self.refresh_btn.setCursor(Qt.PointingHandCursor)
        self.refresh_btn.clicked.connect(self.run_background_scan)
        top_bar.addWidget(self.refresh_btn)

        self.scan_lbl = QLabel("等待扫描...")
        self.scan_lbl.setStyleSheet(scan_status_lbl_style())
        top_bar.addWidget(self.scan_lbl)
        top_bar.addStretch()
        self.left_layout.addLayout(top_bar)

        lbl1 = QLabel("第一步：填写如下问题")
        lbl1.setStyleSheet("font-weight: bold; font-size: 14px; color: #303133; border: none;")
        self.left_layout.addWidget(lbl1)

        q1_lbl = QLabel("问题1  请选择当前分析设计类型（多选框）：")
        q1_lbl.setStyleSheet("border: none; color: #606266;")
        self.left_layout.addWidget(q1_lbl)

        cb_style = "QCheckBox { color: #606266; font-size: 13px; }"

        grid1 = QGridLayout()
        for i, opt in enumerate(["单阶段", "SAD", "FE", "MAD", "BE", "MB"]):
            cb = QCheckBox(opt)
            cb.setStyleSheet(cb_style)
            cb.setEnabled(False)
            cb.clicked.connect(lambda checked, c=cb: self._on_manual_click(c))
            self.q1_cbs[opt] = cb
            grid1.addWidget(cb, i // 3, i % 3)
        self.left_layout.addLayout(grid1)

        lbl2 = QLabel("问题2  请选择除安全性终点外的其他终点（多选框）：")
        lbl2.setStyleSheet("margin-top: 10px; border: none; color: #606266;")
        self.left_layout.addWidget(lbl2)
        grid2 = QGridLayout()
        pk_opts = ["PK浓度(血)", "PK浓度(尿)", "PK浓度(粪)", "PK参数(血)", "PK参数(尿)", "PK参数(粪)"]
        other_opts = ["PD分析", "ADA分析", "QT分析"]
        for i, opt in enumerate(pk_opts + other_opts):
            cb = QCheckBox(opt)
            cb.setStyleSheet(cb_style)
            if opt not in ["PD分析", "QT分析"]:
                cb.clicked.connect(lambda checked, c=cb: self._on_manual_click(c))
            self.q2_cbs[opt] = cb
            grid2.addWidget(cb, i // 3, i % 3)
        self.left_layout.addLayout(grid2)

        lbl3 = QLabel("问题3  请选择用药方式（多选框）：")
        lbl3.setStyleSheet("margin-top: 10px; border: none; color: #606266;")
        self.left_layout.addWidget(lbl3)
        # v12.10.57：用药方式 4 → 6 选项（加"吸入"和"其他"），布局改为 2 行 3 列
        # "其他" 勾选时弹输入框由用户自定义；不勾选 → 后端不出对应药物暴露行
        grid3 = QGridLayout()
        for i, opt in enumerate(["口服", "推注", "滴注", "输注", "吸入", "其他"]):
            cb = QCheckBox(opt)
            cb.setStyleSheet(cb_style)
            cb.setChecked(opt == "口服")  # 默认仅勾选"口服"，与旧版行为一致
            if opt == "其他":
                cb.clicked.connect(lambda checked, c=cb: self._on_q3_other_clicked(c))
            self.q3_cbs[opt] = cb
            grid3.addWidget(cb, i // 3, i % 3)
        self.left_layout.addLayout(grid3)

        # 问题4：PK 参数对比分析的影响因子（多选）
        # 默认全不选 — 不选则模板里 14.4-4.x.y 行整行不出
        # 多选时按"食物=1, 时辰=2, 性别=3, 单多次给药=4"的固定 index 给 x 槽位赋值
        lbl4 = QLabel("问题4  请选择影响药代动力学参数对比分析因子（多选框）：")
        lbl4.setStyleSheet("margin-top: 10px; border: none; color: #606266;")
        self.left_layout.addWidget(lbl4)
        grid4 = QGridLayout()
        for i, opt in enumerate(["食物", "时辰", "性别", "单多次给药"]):
            cb = QCheckBox(opt)
            cb.setStyleSheet(cb_style)
            cb.setChecked(False)  # 默认全不选
            self.q4_cbs[opt] = cb
            grid4.addWidget(cb, 0, i)
        self.left_layout.addLayout(grid4)

        self.supp_frame = QFrame()
        self.supp_frame.setStyleSheet("border: none;")
        supp_lay = QVBoxLayout(self.supp_frame)
        supp_lay.setContentsMargins(0, 0, 0, 0)

        self.supp_pk_lbl = QLabel("补充问题  若选择PK浓度或PK参数终点，请确认分析物名称：")
        self.supp_pk_lbl.setStyleSheet("margin-top: 10px; border: none; color: #606266;")
        supp_lay.addWidget(self.supp_pk_lbl)

        self.analyte_grid = QGridLayout()
        supp_lay.addLayout(self.analyte_grid)

        btn_lay = QHBoxLayout()
        self.add_analyte_btn = QPushButton("+ 添加其他")
        self.add_analyte_btn.setStyleSheet(
            "color: #409EFF; background: transparent; border: none; text-decoration: underline;")
        self.add_analyte_btn.setCursor(Qt.PointingHandCursor)
        self.add_analyte_btn.clicked.connect(self._add_other_analyte)
        btn_lay.addWidget(self.add_analyte_btn)
        btn_lay.addStretch()
        supp_lay.addLayout(btn_lay)

        self.supp_qt_lbl = QLabel("补充问题  若选择QT分析，选择具体方式（多选框）：")
        self.supp_qt_lbl.setStyleSheet("margin-top: 10px; border: none; color: #606266;")
        supp_lay.addWidget(self.supp_qt_lbl)
        self.qt_grid = QHBoxLayout()
        for opt in ["Holter", "12-ECG"]:
            cb = QCheckBox(opt)
            cb.setStyleSheet(cb_style)
            cb.setChecked(opt == "12-ECG")
            self.qt_cbs[opt] = cb
            self.qt_grid.addWidget(cb)
        self.qt_grid.addStretch()
        supp_lay.addLayout(self.qt_grid)
        self.left_layout.addWidget(self.supp_frame)

        lbl4 = QLabel("\n第二步：基于TOC_template.xlsx，生成TOC.xlsx。")
        lbl4.setStyleSheet("font-weight: bold; font-size: 14px; color: #303133; border: none;")
        self.left_layout.addWidget(lbl4)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 0)
        self.progress_bar.setFixedHeight(4)
        self.progress_bar.setVisible(False)
        self.left_layout.addWidget(self.progress_bar)

        lay_tmpl = QHBoxLayout()
        tmpl_l = QLabel("TOC_template.xlsx：")
        tmpl_l.setStyleSheet("border: none; color: #606266;")
        lay_tmpl.addWidget(tmpl_l)
        self.tmpl_entry = QLineEdit()
        self.tmpl_entry.setStyleSheet("padding: 6px; border: 1px solid #DCDFE6; border-radius: 4px;")
        lay_tmpl.addWidget(self.tmpl_entry)
        self.left_layout.addLayout(lay_tmpl)

        lay_toc = QHBoxLayout()
        toc_l = QLabel("项目层面TOC.xlsx：")
        toc_l.setStyleSheet("border: none; color: #606266;")
        lay_toc.addWidget(toc_l)
        self.toc_entry = QLineEdit()
        self.toc_entry.setStyleSheet("padding: 6px; border: 1px solid #DCDFE6; border-radius: 4px;")
        self.toc_entry.textChanged.connect(self._check_edit_status)
        lay_toc.addWidget(self.toc_entry)

        browse_btn = QPushButton("浏览")
        browse_btn.setStyleSheet(light_btn_style())
        browse_btn.setCursor(Qt.PointingHandCursor)
        browse_btn.clicked.connect(lambda: self.toc_entry.setText(
            QFileDialog.getOpenFileName(self, "选择", self.base_path, "*.xlsx")[0] or self.toc_entry.text()
        ))
        lay_toc.addWidget(browse_btn)
        self.left_layout.addLayout(lay_toc)

        btn_layout = QHBoxLayout()
        self.run_btn = QPushButton("▶ 初版TOC")
        self.run_btn.setStyleSheet(primary_btn_style())
        self.run_btn.setCursor(Qt.PointingHandCursor)
        self.run_btn.clicked.connect(self.run_generate)
        btn_layout.addWidget(self.run_btn)

        self.cancel_btn = QPushButton("🟥 中止")
        self.cancel_btn.setStyleSheet(danger_btn_style())
        self.cancel_btn.setCursor(Qt.PointingHandCursor)
        self.cancel_btn.clicked.connect(self.cancel_run)
        self.cancel_btn.setVisible(False)
        btn_layout.addWidget(self.cancel_btn)

        self.edit_btn = QPushButton("📂 打开TOC")
        self.edit_btn.setStyleSheet(success_btn_style())
        self.edit_btn.setCursor(Qt.PointingHandCursor)
        self.edit_btn.clicked.connect(self.open_toc)
        self.edit_btn.setVisible(False)
        btn_layout.addWidget(self.edit_btn)
        btn_layout.addStretch()

        self.left_layout.addLayout(btn_layout)
        self.left_layout.addStretch()

        # v12.10.39：左侧问题区垂直方向可能很长（Q1-Q4 + supp PK + analytes + supp QT），
        # 在小屏幕或最大化前的窗口下补充问题会被压缩。包一层 QScrollArea，让左侧区域
        # 在内容超过可视高度时出现垂直滚动条，舒展显示所有 UI。
        self._left_scroll = QScrollArea()
        self._left_scroll.setWidget(self.left_panel)
        self._left_scroll.setWidgetResizable(True)
        self._left_scroll.setFrameShape(QFrame.NoFrame)  # 去掉滚动区自带边框（避免与 left_panel 双边框）
        self._left_scroll.setStyleSheet(
            "QScrollArea { background: transparent; border: none; }"
            "QScrollBar:vertical { background: #F5F7FA; width: 10px; }"
            "QScrollBar::handle:vertical { background: #C0C4CC; border-radius: 5px; min-height: 20px; }"
            "QScrollBar::handle:vertical:hover { background: #909399; }"
            "QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }"
        )
        self.splitter.addWidget(self._left_scroll)

        self.right_panel = QFrame()
        self.right_panel.setStyleSheet("background-color: #FFFFFF; border: 1px solid #E4E7ED; border-radius: 6px;")
        right_layout = QVBoxLayout(self.right_panel)
        right_layout.setContentsMargins(10, 10, 10, 10)

        log_title = QLabel("📄 运行日志 (Console Log)")
        log_title.setStyleSheet("font-size: 13px; font-weight: bold; color: #606266; border: none;")
        right_layout.addWidget(log_title)

        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        # v12.10.72：统一日志样式 — 与所有 stepper / autoanno 日志面板一致，含统一滚动条
        self.log_text.setStyleSheet(log_textedit_style(with_padding=False))
        right_layout.addWidget(self.log_text)

        self.splitter.addWidget(self.right_panel)
        self.splitter.setStretchFactor(0, 5)
        self.splitter.setStretchFactor(1, 5)
        layout.addWidget(self.splitter)

    def _add_other_analyte(self):
        self._show_msg("添加分析物指引",
                       "若需添加其他分析物，请直接前往源文件 (anno_study.sas7bdat) 中添加。\n完成后请点击左上角「刷新源文件」。",
                       "info",
                       path=os.path.join(self.base_path, "utility", "documentation", "06_crt_preparation", "062_acrf"))

    def run_background_scan(self):
        if getattr(self, 'loader_thread', None) and self.loader_thread.isRunning():
            self._orphan_threads.append(self.loader_thread)

        self.log_text.clear()
        self.refresh_btn.setEnabled(False)
        self.run_btn.setEnabled(False)
        self.scan_lbl.setText("正在后台扫描...")
        self.log_text.append("> 开始跨目录扫描 TDM、anno_study、EDC 数据库定义文件...")

        self.loader_thread = DataLoaderThread(self.base_path, self.p3, self.p2)
        self.loader_thread.finished_signal.connect(self._on_scan_finished)
        self.loader_thread.start()

    def _on_scan_finished(self, data):
        self.refresh_btn.setEnabled(True)
        self.run_btn.setEnabled(True)
        self.scan_lbl.setText("✅ 扫描完成")
        self.extracted_data = data

        # v12.10.59：has_pc=False 时不再输出 "捕获到 N 个分析物" / PCSPEC / PCTESTCD 三行
        #   - 这三条本质都是 PC domain 信息，PC domain 不存在时数据都是空（N=0、(无)、(无)），
        #     强行输出会让用户误以为是分析物提取失败
        #   - 换成单行灰色提示，明确告知 "未检测到 PC domain，跳过 PC 相关信息"
        if data.get('has_pc', False):
            self.log_text.append(f"> 扫描成功！捕获到 {len(data['ordered_analytes'])} 个分析物。")

            # v12.10.43：把扫描结果显式回显到日志面板，便于排查为何某些占位符行没生成
            # PCSPEC：anno_study TEXT 列里 PCSPEC=PLASMA/URINE/STOOL 的命中情况 → 血/尿/粪
            pcspec_parts = []
            if data.get('has_plasma'): pcspec_parts.append("血")
            if data.get('has_urine'): pcspec_parts.append("尿")
            if data.get('has_stool'): pcspec_parts.append("粪")
            pcspec_disp = "/".join(pcspec_parts) if pcspec_parts else "（无）"
            self.log_text.append(
                f"<span style='color:#67C23A;'>> PCSPEC（样本类型）：{pcspec_disp}</span>"
            )

            # PCTESTCD：anno_study 中提取的分析物名（按 y 坐标排序后的列表）
            analytes = data.get('ordered_analytes') or []
            analytes_disp = " / ".join(analytes) if analytes else "（无）"
            self.log_text.append(
                f"<span style='color:#67C23A;'>> PCTESTCD（分析物 {len(analytes)} 个）：{analytes_disp}</span>"
            )
        else:
            self.log_text.append(
                "<span style='color:#909399;'>> 扫描成功（未检测到 PC domain，跳过 PCSPEC / PCTESTCD 信息）。</span>"
            )

        # EDC 字典扫描结果
        aeacn_str = data.get('aeacn_str', 'None') or 'None'
        lbcat_str = data.get('lbcat_str', 'None') or 'None'
        self.log_text.append(
            f"<span style='color:#67C23A;'>> EDC 字典扫描："
            f"AEDIS={'Y' if data.get('has_aedis') else 'N'}  "
            f"AESI={'Y' if data.get('has_aesi') else 'N'}  "
            f"VSCLSIG={'Y' if data.get('has_vsclsig') else 'N'}</span>"
        )
        self.log_text.append(f"<span style='color:#67C23A;'>> AEACN 类目：{aeacn_str}</span>")
        self.log_text.append(f"<span style='color:#67C23A;'>> LBCAT 类目：{lbcat_str}</span>")

        # v12.10.72：实验室检查"其他"门控日志 —— 仅展示业务计数，不暴露表号自增等内置逻辑。
        #   _n_lbcat = edcdef 中 LBCAT 唯一类目数；_lb_cnt = anno_study "LB = 实验室检查" 注释条数。
        _lb_cnt = int(data.get('lb_anno_count', 0) or 0)
        _n_lbcat = 0 if lbcat_str in ('', 'None') else len(
            dict.fromkeys([x.strip() for x in lbcat_str.split('|') if x.strip()]))
        if _lb_cnt > _n_lbcat:
            self.log_text.append(
                f"<span style='color:#67C23A;'>> edcdef 中 LBCAT 类目 {_n_lbcat} 条，"
                f"anno_study 类目 {_lb_cnt} 条 → 产出「实验室检查结果-其他」</span>")
        else:
            self.log_text.append(
                f"<span style='color:#909399;'>> edcdef 中 LBCAT 类目 {_n_lbcat} 条，"
                f"anno_study 类目 {_lb_cnt} 条 → 不产出「实验室检查结果-其他」</span>")

        # v12.10.69：随机化项目识别 — anno_study TEXT 含"随机"字样 → 项目为随机
        # 触发后下游 _toc_filter_and_expand_rows 才会保留 listing 16.2.1-2（随机化代码列表）
        # v12.10.70：日志简化为单行 "随机化设计 / 开放性设计"
        if data.get('has_randomized', False):
            self.log_text.append("<span style='color:#67C23A;'>> 随机化设计</span>")
        else:
            self.log_text.append("<span style='color:#909399;'>> 开放性设计</span>")

        if data["missing_items"]:
            for m in data["missing_items"]: self.log_text.append(
                f"<span style='color:#F56C6C; font-weight:bold;'>警告：{m}</span>")

            # --- 核心新增：静默拦截逻辑 ---
            if self.isVisible():
                self._show_msg("文件缺失", "部分前置字典文件未找到，请查看右侧日志。", "warning")
            else:
                self.pending_missing_warning = True

        # v12.10.44：TDM TX.Type 列里出现非预设阶段的文案（如"安全性分析"、"前导期"等）
        # 时打 WARNING，让用户自行确认是不是漏勾选了别的阶段。这些未识别值不会自动入
        # tdm_types，所以不会污染下游的 PDT 生成。
        unknown_tdm = data.get("unknown_tdm_types") or []
        if unknown_tdm:
            self.log_text.append(
                f"<span style='color:#E6A23C; font-weight:bold;'>⚠️ 检测到 TX.Type 列中含非预设阶段值："
                f"{' / '.join(unknown_tdm)}。这些文案不会自动作为研究阶段处理，"
                f"请人工确认是否需要在问题1中手动调整勾选。</span>"
            )

        # 互斥逻辑：如果含有其他任何阶段，强制剔除单阶段
        tdm_types = data["tdm_types"]
        has_others = any(t in tdm_types for t in ["SAD", "FE", "MAD", "BE", "MB"])
        if has_others and "单阶段" in tdm_types:
            tdm_types.remove("单阶段")
        if not tdm_types:
            tdm_types = {"单阶段"}

        for opt, cb in self.q1_cbs.items():
            if opt.upper() in [t.upper() for t in tdm_types] or (opt == "单阶段" and "单阶段" in tdm_types):
                cb.setChecked(True)
                cb.setEnabled(False)
                cb.setProperty("warn", None)
                cb.setStyleSheet("QCheckBox { color: #909399; font-size: 13px; }")
            else:
                cb.setChecked(False)
                cb.setEnabled(True)
                # v12.10.109：文案具体化 → 指向「打开目录」按钮对应的 TDM 文件
                cb.setProperty("warn", f"TDM 中未包含此类型：[{opt}]\n请修改 Trial Design Model（TDM）后刷新。")
                cb.setProperty("warn_path", os.path.join(self.base_path, "00_source_data"))
                cb.setStyleSheet("QCheckBox { color: #409EFF; font-size: 13px; }")

        pk_auto = {
            "PK浓度(血)": data["has_plasma"], "PK参数(血)": data["has_plasma"],
            "PK浓度(尿)": data["has_urine"], "PK参数(尿)": data["has_urine"],
            "PK浓度(粪)": data["has_stool"], "PK参数(粪)": data["has_stool"]
        }
        warn_path_acrf = os.path.join(self.base_path, "utility", "documentation", "06_crt_preparation", "062_acrf")

        for opt, cb in self.q2_cbs.items():
            if opt in pk_auto and pk_auto[opt]:
                cb.setChecked(True)
                cb.setEnabled(False)
                cb.setProperty("warn", None)
                cb.setStyleSheet("QCheckBox { color: #909399; font-size: 13px; }")
            elif opt == "ADA分析" and data["has_ada"]:
                cb.setChecked(True)
                cb.setEnabled(False)
                cb.setProperty("warn", None)
                cb.setStyleSheet("QCheckBox { color: #909399; font-size: 13px; }")
            elif opt in ["PD分析", "QT分析"]:
                pass
            else:
                cb.setChecked(False)
                cb.setEnabled(True)
                if "PK" in opt:
                    # v12.10.58：has_pc=False 时改用"无对应 PC domain"统一文案（与 ADA 的 IS domain 提示对称）
                    # has_pc=True 但具体 PCSPEC 缺失时保留原"anno_study 不包含：[opt]"细粒度文案
                    if not data.get("has_pc", False):
                        cb.setProperty("warn", "无对应 PC domain，请修改 aCRF 并更新 anno_study.sas7bdat 后刷新。")
                    else:
                        cb.setProperty("warn", f"anno_study 不包含：[{opt}]\n请修改 aCRF 并更新 anno_study.sas7bdat 后刷新。")
                    cb.setProperty("warn_path", warn_path_acrf)
                if opt == "ADA分析":
                    cb.setProperty("warn", "无对应 IS domain，请修改 aCRF 并更新 anno_study.sas7bdat 后刷新。")
                    cb.setProperty("warn_path", warn_path_acrf)
                cb.setStyleSheet("QCheckBox { color: #409EFF; font-size: 13px; }")

        while self.analyte_grid.count():
            w = self.analyte_grid.takeAt(0).widget()
            if w: w.deleteLater()
        self.analyte_cbs = []
        for i, a in enumerate(data["ordered_analytes"]):
            cb = QCheckBox(a)
            cb.setStyleSheet("QCheckBox { color: #909399; font-size: 13px; border: none; }")
            cb.setChecked(True)
            cb.setEnabled(False)
            self.analyte_cbs.append(cb)
            self.analyte_grid.addWidget(cb, i // 3, i % 3)

        self._toggle_supp()
        for cb in self.q2_cbs.values(): cb.toggled.connect(self._toggle_supp)
        self._check_edit_status()

    def _toggle_supp(self):
        has_pk = any(self.q2_cbs[o].isChecked() for o in
                     ["PK浓度(血)", "PK浓度(尿)", "PK浓度(粪)", "PK参数(血)", "PK参数(尿)", "PK参数(粪)"])
        self.supp_pk_lbl.setVisible(has_pk)
        self.add_analyte_btn.setVisible(has_pk)
        for i in range(self.analyte_grid.count()):
            w = self.analyte_grid.itemAt(i).widget()
            if w: w.setVisible(has_pk)

        has_qt = self.q2_cbs["QT分析"].isChecked()
        self.supp_qt_lbl.setVisible(has_qt)
        for cb in self.qt_cbs.values(): cb.setVisible(has_qt)

    def _on_manual_click(self, cb):
        if cb.isChecked() and cb.property("warn"):
            self._show_msg("操作被系统拦截", cb.property("warn"), "warning", path=cb.property("warn_path"))
            cb.setChecked(False)

    def _on_q3_other_clicked(self, cb):
        """v12.10.57：Q3"其他"勾选时弹文本输入框由用户自定义用药方式名。

        - 勾选：弹 show_text_input_dialog 让用户输入；输入为空 / 取消 → 自动取消勾选
                输入有效 → 保存到 self.q3_other_text，checkbox 文本变为 "其他: <输入>"
        - 取消勾选：清空 q3_other_text，checkbox 文本恢复为 "其他"
        """
        if cb.isChecked():
            default_val = self.q3_other_text or ""
            txt = show_text_input_dialog(
                self,
                title="请输入用药方式",
                text="请输入「其他」对应的用药方式名称（例如：皮下注射、舌下含服、外用）：",
                default=default_val,
                placeholder="例如：皮下注射",
            )
            if txt and txt.strip():
                self.q3_other_text = txt.strip()
                cb.setText(f"其他: {self.q3_other_text}")
            else:
                # 用户取消或输入空 → 自动取消勾选并恢复原文本
                self.q3_other_text = ""
                cb.setChecked(False)
                cb.setText("其他")
        else:
            # 主动取消勾选 → 清空记录
            self.q3_other_text = ""
            cb.setText("其他")

    def run_generate(self):
        study_path = self.toc_entry.text().strip()

        if os.path.isfile(study_path):
            if not self._show_msg("覆盖确认", f"目标路径已存在同名文件:\n{study_path}\n\n是否确认覆盖并重新生成？",
                                  "question"):
                return

        self.log_text.append("\n<span style='color:#409EFF;'>> 开始执行 TOC 引擎生成...</span>")
        self.run_btn.hide()
        self.cancel_btn.show()
        self.progress_bar.setVisible(True)

        study_type = "|".join([k for k, v in self.q1_cbs.items() if v.isChecked()])
        pcspec_list = []
        if self.q2_cbs["PK浓度(血)"].isChecked() or self.q2_cbs["PK参数(血)"].isChecked(): pcspec_list.append("血")
        if self.q2_cbs["PK浓度(尿)"].isChecked() or self.q2_cbs["PK参数(尿)"].isChecked(): pcspec_list.append("尿")
        if self.q2_cbs["PK浓度(粪)"].isChecked() or self.q2_cbs["PK参数(粪)"].isChecked(): pcspec_list.append("粪")
        PCSPEC = "|".join(pcspec_list) if pcspec_list else "None"

        PD_Analyte = "exist" if self.q2_cbs["PD分析"].isChecked() else "None"
        ADA_Analyte = "exist" if self.q2_cbs["ADA分析"].isChecked() else "None"
        QT_Analyte = "exist" if self.q2_cbs["QT分析"].isChecked() else "None"

        # v12.10.57：用药方式 6 选项；"其他" 勾选 → 替换为 self.q3_other_text 自定义文本
        # 全不勾选 → admin_route="" → tfls_pdt 端跳过所有药物暴露行
        admin_route_parts = []
        for k, v in self.q3_cbs.items():
            if not v.isChecked():
                continue
            if k == "其他":
                if self.q3_other_text.strip():
                    admin_route_parts.append(self.q3_other_text.strip())
                # 自定义文本为空 → 不计入（防御：理论上 _on_q3_other_clicked 已拦截）
            else:
                admin_route_parts.append(k)
        admin_route = "|".join(admin_route_parts)
        qt_method_str = "|".join(
            [k for k, v in self.qt_cbs.items() if v.isChecked()]) if QT_Analyte == "exist" else "None"
        final_analytes = [cb.text() for cb in self.analyte_cbs if cb.isChecked()]
        Analyte = "|".join(final_analytes) if final_analytes else "None"

        # 问题4：影响因子（多选，不选则空字符串 → tfls_pdt 那边会跳过 14.4-4.x.y 模板行）
        pk_factors = "|".join([k for k, v in self.q4_cbs.items() if v.isChecked()])

        # v12.10.40：修历史 bug — DataLoaderThread 写入的 result 字段名是
        # has_aedis / has_aesi / has_vsclsig (布尔) 和 aeacn_str / lbcat_str (字符串),
        # 但下面 kwargs 一直是用 AEDIS / AESI / ... 大写 key 去 .get()，永远拿到 'None'。
        # 因此 EDC占位行（[AEACN]/[LBCAT] 等）从未真正裂变出来。
        # 这里做正确的 key 翻译：把 has_* 布尔 → "exist"/"None"，把 *_str → 直接用。
        edc_aedis = "exist" if self.extracted_data.get('has_aedis', False) else "None"
        edc_aesi = "exist" if self.extracted_data.get('has_aesi', False) else "None"
        edc_vsclsig = "exist" if self.extracted_data.get('has_vsclsig', False) else "None"
        edc_aeacn = self.extracted_data.get('aeacn_str', 'None') or 'None'
        edc_lbcat = self.extracted_data.get('lbcat_str', 'None') or 'None'

        kwargs = {
            "template_path": self.tmpl_entry.text().strip(),
            "study_path": study_path,
            "setup_path": os.path.join(os.path.dirname(os.path.dirname(study_path)), "setup.xlsx"),
            "study_type": study_type, "PCSPEC": PCSPEC, "PD_Analyte": PD_Analyte,
            "ADA_Analyte": ADA_Analyte, "QT_Analyte": QT_Analyte, "Analyte": Analyte,
            "admin_route": admin_route, "qt_method": qt_method_str,
            "pk_factors": pk_factors,
            "AEDIS": edc_aedis,
            "AESI": edc_aesi,
            "VSCLSIG": edc_vsclsig,
            "AEACN": edc_aeacn,
            "LBCAT": edc_lbcat,
            # v12.10.69：透传随机化判定（DataLoaderThread 从 anno_study 检测得到）
            # gen_toc_study 接收 has_randomized=True/False，传递给 _toc_filter_and_expand_rows
            # 内部用于决定是否产出 listing 16.2.1-2（随机化代码列表）
            "has_randomized": bool(self.extracted_data.get("has_randomized", False)),
            # v12.10.70：透传 "LB = 实验室检查" 注释条数 → 决定 16.2.8-1.99「实验室检查结果-其他」是否产出
            "lb_anno_count": int(self.extracted_data.get("lb_anno_count", 0) or 0),
        }

        self.run_thread = TOCRunnerThread(kwargs)
        self.run_thread.finished_signal.connect(self._on_generate_finished)
        self.run_thread.start()

    def cancel_run(self):
        if hasattr(self, 'run_thread') and self.run_thread.isRunning():
            self.run_thread.is_cancelled = True
        self.cancel_btn.hide()
        self.run_btn.show()
        self.progress_bar.setVisible(False)
        self.log_text.append("<span style='color:#F56C6C; font-weight:bold;'>[已中止] 🛑 用户手动取消了执行。</span>")

    def _on_generate_finished(self, success, msg):
        # 若已被用户取消，忽略结果
        if hasattr(self, 'run_thread') and self.run_thread.is_cancelled:
            return

        self.cancel_btn.hide()
        self.run_btn.show()
        self.progress_bar.setVisible(False)

        self._check_edit_status()

        if success:
            # v12.10.49：成功后不再弹窗 — 用户直接点右下角"📂 打开TOC"按钮即可
            self.log_text.append(f"<span style='color:#67C23A;'>> {msg}</span>")
            toc_path = self.toc_entry.text().strip()
            if toc_path:
                self.log_text.append(
                    f"<span style='color:#67C23A;'>> 输出文件：{toc_path}</span>"
                )
            self.log_text.append(
                "<span style='color:#67C23A;'>> 点击右下角 \"📂 打开TOC\" 按钮查看。</span>"
            )
            self.gui.update_status("TOC 已成功生成。")
        else:
            self.log_text.append(f"<span style='color:#F56C6C;'>> 生成失败: {msg}</span>")
            self._show_msg("执行异常", msg, "error")

    def open_toc(self):
        p = self.toc_entry.text().strip()
        if os.path.exists(p): os.startfile(p)
