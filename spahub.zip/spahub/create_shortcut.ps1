# =============================================================================
# create_shortcut.ps1 - Create SPAhub.lnk on Desktop
# =============================================================================
# Usage:
#   powershell -ExecutionPolicy Bypass -File .\create_shortcut.ps1

$TargetPath = "Z:\projects\Z_PYTHON\SPAhub\launcher.bat"
$IconLocation = "Z:\projects\Z_PYTHON\SPAhub\resources\spahub.ico"
$WorkingDirectory = "Z:\projects\Z_PYTHON\SPAhub"
$ShortcutPath = "$env:USERPROFILE\Desktop\SPAhub.lnk"

$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut($ShortcutPath)
$Shortcut.TargetPath = $TargetPath
$Shortcut.WorkingDirectory = $WorkingDirectory
if (Test-Path $IconLocation) {
    $Shortcut.IconLocation = $IconLocation
}
$Shortcut.WindowStyle = 7
$Shortcut.Description = "SPAhub - SAS Programming Automation Hub"
$Shortcut.Save()

Write-Host "OK: shortcut created at $ShortcutPath" -ForegroundColor Green
Write-Host "    Double-click desktop icon to launch SPAhub."
