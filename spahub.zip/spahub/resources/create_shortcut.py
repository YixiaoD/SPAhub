"""
SPA Platform 桌面快捷方式自动创建脚本
================================
作用：在桌面创建 "SPA Platform.lnk"，**直接指向 C:\\Python_396\\pythonw.exe + main.py**，
      跳过 SPAhub.bat 中转层。图标仍指向 %LOCALAPPDATA%\\SPAhub\\spahub.ico。

v12.10.75: 快捷方式由 SPAhub.lnk 改名为 "SPA Platform.lnk"（程序文件夹路径与
           %LOCALAPPDATA%\\SPAhub\\ 不变，仅桌面图标显示名变更）。

v12.10.48: 改 target 从 SPAhub.bat 改为 pythonw.exe
============================================================
**为什么改**：原方案 .lnk → SPAhub.bat → cmd.exe → start pythonw → main.py，
cmd.exe 是 console subsystem，Windows shell 启动它时**不会**显示 IDC_APPSTARTING
（鼠标右侧旋转动画）。用户双击快捷方式后 splash 出现前的几秒到几十秒完全
没视觉反馈，看起来"双击没反应"。

新方案：.lnk → pythonw.exe + main.py，pythonw 是 GUI subsystem，shell
自动显示等待光标，直到 pythonw 创建第一个窗口（splash）或 5 秒超时。
配套的 main.py v12.10.48 已自包含 sys.path 和 sys.pycache_prefix 设置，
不再依赖 .bat 设置环境变量。

**SPAhub.bat 仍保留**作为开发者从 cmd / IDE 启动的入口，不影响兼容性。
桌面用户的标准启动方式改为本方案。

为什么用 Python 而不是 PowerShell?
  - PowerShell 在企业环境常被 GPO 限执行策略
  - cmd 没有原生创建 .lnk 的命令
  - Python + pywin32 是最可靠跨用户的方式（pywin32 已在前置依赖列表里）

调用：
  C:\\Python_396\\python.exe Z:\\projects\\Z_PYTHON\\SPAhub\\resources\\create_shortcut.py

前置：%LOCALAPPDATA%\\SPAhub\\spahub.ico 必须存在（先 copy）。
      pythonw.exe 和 main.py 自动检查。
"""
from __future__ import annotations

import os
import sys


def _fail(msg: str, code: int = 1) -> None:
    print(f"ERROR: {msg}", file=sys.stderr)
    sys.exit(code)


def main() -> int:
    if os.name != "nt":
        _fail("This script only runs on Windows.")

    try:
        from win32com.client import Dispatch  # pywin32
    except ImportError:
        _fail(
            "pywin32 not installed. Install first:\n"
            "  C:\\Python_396\\Scripts\\pip.exe install -i "
            "https://pypi.tuna.tsinghua.edu.cn/simple/ pywin32"
        )
        return 1  # unreachable, satisfies type checker

    local_appdata = os.environ.get("LOCALAPPDATA")
    user_profile = os.environ.get("USERPROFILE")
    if not local_appdata or not os.path.isdir(local_appdata):
        _fail(f"LOCALAPPDATA env var invalid: {local_appdata!r}")
    if not user_profile or not os.path.isdir(user_profile):
        _fail(f"USERPROFILE env var invalid: {user_profile!r}")

    spahub_local_dir = os.path.join(local_appdata, "SPAhub")
    icon_ico = os.path.join(spahub_local_dir, "spahub.ico")

    # v12.10.48: 新 target = pythonw.exe + main.py（跳过 SPAhub.bat）
    pythonw_exe = r"C:\Python_396\pythonw.exe"
    main_py = r"Z:\projects\Z_PYTHON\SPAhub\main.py"
    spahub_z_dir = r"Z:\projects\Z_PYTHON\SPAhub"

    if not os.path.isfile(pythonw_exe):
        _fail(
            f"Python not found: {pythonw_exe}\n"
            f"Verify with: dir {pythonw_exe}\n"
            f"如未安装，让管理员从公司共享拷贝 Python 3.9.6 到 C:\\Python_396\\"
        )
    if not os.path.isfile(main_py):
        _fail(
            f"SPAhub main.py not found: {main_py}\n"
            f"Verify with: dir {main_py}\n"
            f"如 Z 盘连接异常，先 net use Z: 重连"
        )
    if not os.path.isfile(icon_ico):
        _fail(
            f"Icon not found: {icon_ico}\n"
            f"Run this first:\n"
            f"  mkdir %LOCALAPPDATA%\\SPAhub 2>nul\n"
            f"  copy /Y Z:\\projects\\Z_PYTHON\\SPAhub\\resources\\"
            f"spahub.ico {icon_ico}"
        )

    desktop = os.path.join(user_profile, "Desktop")
    if not os.path.isdir(desktop):
        # 极少数公司把桌面定向到 OneDrive 等 — 兜底走 SHGetKnownFolderPath
        try:
            import ctypes
            from ctypes import wintypes
            CSIDL_DESKTOPDIRECTORY = 0x0010
            buf = ctypes.create_unicode_buffer(wintypes.MAX_PATH)
            ctypes.windll.shell32.SHGetFolderPathW(
                None, CSIDL_DESKTOPDIRECTORY, None, 0, buf
            )
            if buf.value and os.path.isdir(buf.value):
                desktop = buf.value
        except Exception:
            pass
    if not os.path.isdir(desktop):
        _fail(f"Desktop folder not found at {desktop}")

    # v12.10.75：快捷方式改名 SPAhub.lnk → "SPA Platform.lnk"（程序文件夹路径不变）
    lnk_path = os.path.join(desktop, "SPA Platform.lnk")

    shell = Dispatch("WScript.Shell")
    shortcut = shell.CreateShortcut(lnk_path)
    # v12.10.48: target → pythonw.exe（GUI subsystem，触发 IDC_APPSTARTING 等待光标）
    shortcut.TargetPath = pythonw_exe
    shortcut.Arguments = f'"{main_py}"'
    shortcut.IconLocation = icon_ico
    shortcut.WorkingDirectory = spahub_z_dir
    # v12.10.48: WindowStyle=1 (Normal) — pythonw 自身无 console，不需要 Minimized
    shortcut.WindowStyle = 1
    shortcut.Description = "SPA Platform - Statistical Programming Automation Platform"
    shortcut.save()

    print("OK: SPA Platform desktop shortcut created.")
    print(f"  Path:     {lnk_path}")
    print(f"  Target:   {pythonw_exe}")
    print(f"  Args:     \"{main_py}\"")
    print(f"  Icon:     {icon_ico}")
    print(f"  WorkDir:  {spahub_z_dir}")
    print(f"  WinStyle: 1 (Normal, pythonw 无 console 窗口)")
    print()
    print("v12.10.48 优化：双击图标后鼠标右侧会显示等待动画，")
    print("直到 SPAhub splash 出现（或 5 秒超时），双击不再'看似没反应'。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
