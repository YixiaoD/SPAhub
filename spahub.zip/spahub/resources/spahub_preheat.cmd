@echo off
REM ============================================================================
REM  SPAhub SMB Preheat Script
REM  v12.10.48
REM  ----------------------------------------------------------------------------
REM  Purpose:
REM    Pre-warm the Windows SMB client's directory/attribute cache for the
REM    SPAhub source tree on Z:\. After running, subsequent os.stat() calls
REM    from Python (import machinery checking .py mtime vs .pyc) will hit
REM    the local SMB cache instead of round-tripping to the file server.
REM
REM  Why this helps:
REM    SPAhub runs from Z:\ (network share). Python's import system does
REM    os.stat() on every .py file to check if the .pyc is stale. Each stat
REM    on a network file is an SMB2 QUERY_INFO round-trip (5-50ms). With
REM    ~45 SPAhub .py files, that's 0.2-2.2 seconds of pure stat overhead
REM    on a cold SMB cache (e.g., first thing in the morning after overnight
REM    cache expiry).
REM
REM    Running this script pre-loads the SMB attribute cache for all .py
REM    files. The cache typically lives for 10s-600s (configurable via
REM    HKLM\SYSTEM\...\Lanmanworkstation\Parameters\DirectoryCacheLifetime),
REM    so run this shortly before launching SPAhub.
REM
REM  Deployment options:
REM    1. Windows Task Scheduler: trigger = "At log on", delay 30s
REM       action = cmd /c "%LOCALAPPDATA%\SPAhub\spahub_preheat.cmd"
REM    2. Shell:Startup folder: copy this file (or a shortcut) to
REM       %APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\
REM    3. Manual: run before first SPAhub launch of the day
REM
REM  Cost: ~0.5-3 seconds (one pass of dir /s, runs silently, no window).
REM ============================================================================

REM Silent: redirect all output to nul
REM The sole purpose is to make Windows SMB client cache the stat metadata.
dir /s /b "Z:\projects\Z_PYTHON\SPAhub\*.py" >nul 2>nul
dir /s /b "Z:\projects\Z_PYTHON\SPAhub\*.pyd" >nul 2>nul
dir /s /b "Z:\projects\Z_PYTHON\TFL_metadata\*.py" >nul 2>nul

REM Also touch the key resource files (splash, ico) so their metadata is cached
if exist "Z:\projects\Z_PYTHON\SPAhub\resources\splash.png" (
    dir "Z:\projects\Z_PYTHON\SPAhub\resources\splash.png" >nul 2>nul
)

exit /b 0

