@echo off
REM  SPAhub Cold-Start Diagnostic  v12.10.48
REM  Run from cmd on a cold morning before any SPAhub launch.
setlocal EnableDelayedExpansion
set "LOGDIR=%LOCALAPPDATA%\SPAhub\logs"
if not exist "%LOGDIR%" mkdir "%LOGDIR%"
set "LOGFILE=%LOGDIR%\diag.log"
echo ====== [%DATE% %TIME%] Cold-Start Diagnostic ====== >> "%LOGFILE%"
echo.
echo === SPAhub Cold-Start Diagnostic  %DATE% %TIME% ===
echo.
echo [1/5] SMB stat cold: dir /s Z:\...\SPAhub\*.py
set "T1S=%TIME%"
dir /s /b "Z:\projects\Z_PYTHON\SPAhub\*.py" >nul 2>nul
set "T1E=%TIME%"
echo   %T1S% -- %T1E%
echo [1] %T1S% -- %T1E% >> "%LOGFILE%"
echo [2/5] SMB stat warm (cached):
set "T2S=%TIME%"
dir /s /b "Z:\projects\Z_PYTHON\SPAhub\*.py" >nul 2>nul
set "T2E=%TIME%"
echo   %T2S% -- %T2E%
echo [2] %T2S% -- %T2E% >> "%LOGFILE%"
echo   If [1] is much slower than [2], SMB cache miss is the bottleneck.
echo.
echo [3/5] Python import cold from Z:\
set "T3S=%TIME%"
C:\Python_396\python.exe -c "import time;t0=time.perf_counter();import sys;sys.path.insert(0,r'Z:\projects\Z_PYTHON\SPAhub');from gui.main_window import SASEGGUI;print(f'  import: {(time.perf_counter()-t0)*1000:.0f} ms')"
set "T3E=%TIME%"
echo   %T3S% -- %T3E%
echo [3] %T3S% -- %T3E% >> "%LOGFILE%"
echo [4/5] Python import warm (cached):
set "T4S=%TIME%"
C:\Python_396\python.exe -c "import time;t0=time.perf_counter();import sys;sys.path.insert(0,r'Z:\projects\Z_PYTHON\SPAhub');from gui.main_window import SASEGGUI;print(f'  import: {(time.perf_counter()-t0)*1000:.0f} ms')"
set "T4E=%TIME%"
echo   %T4S% -- %T4E%
echo [4] %T4S% -- %T4E% >> "%LOGFILE%"
echo.
echo [5/5] Local copy import (isolates network from Defender):
set "LC=%LOCALAPPDATA%\SPAhub\diag_local"
if exist "%LC%" rd /s /q "%LC%" >nul 2>nul
robocopy "Z:\projects\Z_PYTHON\SPAhub" "%LC%" /E /NFL /NDL /NJH /NJS /nc /ns /np >nul 2>nul
set "T5S=%TIME%"
C:\Python_396\python.exe -c "import time,sys,os;t0=time.perf_counter();sys.path.insert(0,os.path.join(os.environ['LOCALAPPDATA'],'SPAhub','diag_local'));from gui.main_window import SASEGGUI;print(f'  import(local): {(time.perf_counter()-t0)*1000:.0f} ms')"
set "T5E=%TIME%"
echo   %T5S% -- %T5E%
echo [5] %T5S% -- %T5E% (local) >> "%LOGFILE%"
rd /s /q "%LC%" >nul 2>nul
echo.
echo === INTERPRETATION ===
echo   [1] much slower than [2]: SMB cache miss. Fix: spahub_preheat.cmd
echo   [3] much slower than [4] but [1] ~ [2]: Defender. Fix: GPO exclusion
echo   [3] much slower than [5]: network confirmed. Fix: preheat or freeze
echo   [3] ~ [5] both slow: local Defender or page cache. Fix: Defender exclusion
echo.
echo Log saved to: %LOGFILE%
echo ====== END ====== >> "%LOGFILE%"
endlocal
pause

