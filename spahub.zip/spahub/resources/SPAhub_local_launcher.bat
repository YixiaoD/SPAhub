@echo off
REM ============================================================================
REM  SPAhub Local Trusted Launcher Template
REM  ----------------------------------------------------------------------------
REM  This file is meant to be COPIED to %LOCALAPPDATA%\SPAhub\SPAhub.bat by
REM  end users. Do NOT modify the file in Z:\projects\Z_PYTHON\SPAhub\resources\.
REM
REM  Why this exists:
REM    Running launcher.bat directly from the Z: network share triggers a
REM    Windows security warning (Mark of the Web) AND the GPO blocks loading
REM    the .ico icon from network paths. By copying this template to a local
REM    %LOCALAPPDATA%\SPAhub\ folder, both issues disappear because the
REM    shortcut, the .bat, and the .ico are all on local C: drive.
REM
REM  Deployment (run from cmd, NOT PowerShell):
REM    mkdir %LOCALAPPDATA%\SPAhub 2>nul
REM    copy /Y Z:\projects\Z_PYTHON\SPAhub\resources\spahub.ico %LOCALAPPDATA%\SPAhub\spahub.ico
REM    copy /Y Z:\projects\Z_PYTHON\SPAhub\resources\SPAhub_local_launcher.bat %LOCALAPPDATA%\SPAhub\SPAhub.bat
REM    Then create desktop shortcut pointing to %LOCALAPPDATA%\SPAhub\SPAhub.bat
REM    and set its icon to %LOCALAPPDATA%\SPAhub\spahub.ico
REM ============================================================================

set "PYTHONPYCACHEPREFIX=%LOCALAPPDATA%\SPAhub\pycache"
set "PYTHONNOUSERSITE=1"
set "PYTHONPATH=Z:\projects\Z_PYTHON\SPAhub;Z:\projects\Z_PYTHON\TFL_metadata"
cd /d "Z:\projects\Z_PYTHON\SPAhub"
start "" "C:\Python_396\pythonw.exe" "Z:\projects\Z_PYTHON\SPAhub\main.py"
