# SASEG - SAS Autoexec & Tools

药企临床统计编程（Biostatistics）桌面端自动化生产工具（Python + PySide6 + SAS 后台引擎）。

## 目录结构

```
SASEG/
├── main.py                          # 应用主入口
├── ui_utils.py                      # 全局共享 UI 工具（统一弹窗引擎）
├── README.md
│
├── sas_engine/                      # SAS 执行引擎层（纯逻辑，无 GUI 依赖）
│   ├── __init__.py                  # 统一导出 run_sas 等核心接口
│   ├── executor.py                  # SAS 提交、日志解析、错误提取
│   └── sascfg.py                    # SASPy 连接配置（IOM 地址、Java 路径）
│
├── modules/                         # 业务模块层（各步骤的线程 Runner + 表单 Form）
│   ├── __init__.py
│   ├── toc_gen.py                   # TOC 生成模块（Step 00）
│   ├── tfls_pdt.py                  # PDT 生成 + TOC 引擎核心（Step 01）
│   ├── tfls_metadata.py             # Metadata 提取模块（Step 02）
│   ├── tfls_init_pgm.py            # Initial PGM 生成模块（Step 03）
│   └── tfls_batch_run.py           # Batch Run 跑批模块（Step 04）
│
└── gui/                             # 界面层
    ├── __init__.py
    ├── main_window.py               # 主窗口 SASEGGUI（路由、下拉框、网格）
    ├── shortcuts.py                 # 快捷工具面板（ShortcutWidget）
    └── tfls_stepper.py              # TFLs 步骤导航器（TFLsWidget，信号总线）
```

## 启动方式

```bash
cd SASEG
python main.py
```

## 模块职责

| 模块 | 说明 |
|------|------|
| **sas_engine/** | 封装 SASPy 连接与 SAS 代码提交逻辑，解析日志中的 ERROR/WARNING，提供 `run_sas()` 统一接口。已移除 Tkinter 依赖，所有交互由上层 PySide6 处理。 |
| **modules/toc_gen.py** | 扫描 TDM、anno_study 等前置字典，引导用户选择分析设计类型后调用 `gen_toc_study()` 生成 TOC.xlsx。 |
| **modules/tfls_pdt.py** | 包含 TOC 模板解析与展开引擎（`gen_toc_study`）以及 PDT 生成表单。PDT 后处理采用 openpyxl 直接注入公式值 + win32com 可选增强双阶段策略。 |
| **modules/tfls_metadata.py** | 从 PDS、Shell、EDC 中提取元数据，自动生成 t14 系列 Metadata 文件。 |
| **modules/tfls_init_pgm.py** | 基于 91/61 脚本生成 DEV/QC 初始程序。采用 subprocess + Watchdog 防死锁方案。 |
| **modules/tfls_batch_run.py** | 依据 PDT 非空程序数量智能拆解 92_batch_call 宏，生成跑批脚本并支持单任务独立执行。执行结果自动提取 FAILED/SUCCEED 统计。 |
| **gui/main_window.py** | 主窗口框架：侧边栏导航、四级路径下拉框（带防抖）、Home 页文件网格。 |
| **gui/tfls_stepper.py** | TFLs 五步流水线导航器，统一管理各模块的信号连接、日志面板、状态标签。每次运行自动清空历史日志。 |
| **gui/shortcuts.py** | 快捷工具面板，异步加载外部工具图标。 |
| **ui_utils.py** | 统一弹窗引擎 `show_dialog()`，支持 info/warning/error/question 类型及文件路径导航。 |

## 关键设计决策

- **协作式线程取消**：所有 QThread Runner 使用 `is_cancelled` 标志位实现安全退出，避免 `terminate()` 引发的死锁风险。
- **Watchdog 防死锁（03/04）**：subprocess 隔离 + .done 探针文件 + 超时强杀，彻底规避 SAS IOM 通信卡死。
- **日志清空策略**：每个模块点击运行按钮时自动清空历史日志；04 Batch Run 允许多次运行脚本累加日志，但重新生成脚本时重置。
- **跑批结果提取**：04 Batch Run 自动从 SAS 日志中解析 `Program execution [FAILED|SUCCEED]` 行，以红/绿色分类展示执行统计。

## 版本变更记录（aCRF 模块）

### v12.9.8
- **Final 完成自动切到「运行日志」tab** — 之前用户运行完 Final 仍停在 annomap tab
  看不到执行结果。新增 `sig_final_finished` 信号，stepper 端 `_on_final_finished_switch_log`
  通过缓存的 `_right_tabs` 引用 `setCurrentIndex(0)` 切到运行日志。
- **annomap page / origin 列允许复制** — 根因：QTableWidget 默认 Ctrl+C 行为依赖 selection，
  但 standard 列被 cellWidget（QComboBox）占据，鼠标点击会先到 combo 让用户感觉"点不中
  cell"。修法：给 `annomap_table` 装右键菜单 + `eventFilter` 拦截 Ctrl+C，把选中 cell
  按 (row, col) 排序、tab 分隔列、换行分隔行写剪贴板（兼容 Excel 粘贴）。
- **annomap 重跑结束底部状态行** — 用户停留在 annomap tab 时之前感知不到运行结果
  （只有运行日志 tab 有提示）。新增 `annomap_status_lbl` 在 tab 底部，根据 `has_error /
  has_warning` 显示成功/警告/错误简略文案 + 着色。`sig_autoanno_finished` 加参数
  `(has_error, has_warning, summary)`，stepper 接收后切样式。
- **运行日志区分 ERROR vs WARNING 颜色** — 之前笼统"❌ 含 ERROR/WARNING"标红，
  纯 WARNING 时给用户错误的"运行失败"心理预期。新增静态方法 `_split_has_error_warning`
  扫日志拆分两态；`_on_draft_finished` / `_on_final_finished` 三分支：
    * 含 ERROR → 红 (`#F56C6C`) "❌"
    * 仅 WARNING → 黄 (`#E6A23C`) "⚠"
    * 干净通过 → 绿 (`#67C23A`) "✅"
  `_extract_issue_lines` 行级颜色保持原有红/黄分色不变。
- **toc 文案改写**：「正在后台强力扫描...」→「正在后台扫描...」。
- **4 级路径第一级默认 `projects`** — 约 90% 场景用户打开应用就要进 projects；之前每次都要手动
  选一遍。`refresh_first_dropdown` 在 dirs 包含 "projects" 时自动 setCurrentIndex 并触发
  `_on_combo_activated(0)` 级联填充第 2 级。Z:\\ 下不存在 projects（边缘场景如本地测试机）
  时保持原行为不预填。

### v12.9.7
- **annomap 默认值修改弹窗确认** — 之前直接改值无提示，用户误操作风险高。
  原值非空时，**提交**（从下拉选中 / lineEdit 失焦）若值有变 → 弹 question 弹窗确认；
  用户取消则用 `setCurrentText` 还原原值（用 `rolling_back` 标志位防 `currentTextChanged`
  递归）。`currentTextChanged` 仍即时标蓝/复白做视觉反馈，但确认在提交时刻进行（避免每按
  一键弹窗）。原值为空（首次填入）不弹确认。
- **annomap standard 列禁滚轮防误改** — 用户滚动表格时鼠标常飘过 standard 列上方，
  QComboBox 默认 `wheelEvent` 改 `currentIndex` 导致大量误改。新增 `_NoWheelComboBox`
  子类重写 `wheelEvent → event.ignore()`，让事件冒泡到 `QTableWidget` 滚动表格。改值
  只能通过点击下拉箭头或键盘输入做模糊筛选。
- **导入/导出 xfdf 弹窗右移避开 Adobe** — 弹窗与 Acrobat 居中窗口重叠压在 PDF 上面。
  扩展 `ui_utils.show_dialog` 加 `align="right"` 参数：`exec()` 前 `adjustSize()` + `move()`
  到主屏幕右半区（screen.x + 62% screen.width, screen.y + 25% screen.height）。两处
  Adobe 引导弹窗都加 `align="right"`。

### v12.9.6
- **「首次运行」按钮跑完仍不消失** — v12.9.5 把锁死与 `has_issue` 绑定，但 SAS autoanno
  几乎一定会有 WARNING（standard 列空缺 / 字符截断等），导致 `has_issue=True` 时按钮永远
  不消失。修法：full 模式跑完即无条件 `setVisible(False)`。出错时用户走「🔄 刷新源文件」重置。
- **standard 列 QComboBox 没下拉箭头** — v12.9.5 写了 `QComboBox::drop-down { border: none; }`
  但没指定 `image:` 让 Qt 画箭头 → 箭头区透明；同时 `min-height: 20px` 太矮容纳不下箭头。
  修法：完全去掉 `drop-down` 子选择器（用系统主题原生绘制），`min-height` 提到 24px，
  表格 `verticalHeader().setDefaultSectionSize(30)` 让行高足够。
- **「📋 导入 xfdf」弹窗文案改写**：用 `💬`（评论按钮）和 `⋮`（选项菜单）emoji
  描述 Adobe 侧边栏操作；步骤 2 的"位于同目录"括号合并成一行；删除步骤 4
  （final/acrf.pdf 导出 xfdf 改由 23 Final 的「📂 用 Adobe 打开」自动弹窗引导）。
- **23 Final「📂 用 Adobe 打开」加导出 xfdf 弹窗**：与 22 导入弹窗对称，指引用户
  💬 评论 → ⋮ 选项 → 导出所有注释到数据文件 → 选 .xfdf 类型保存到 PDF 同目录
  （触发自动文件监听把路径填入下方框）。

### v12.9.5
- **完全移除 PyMuPDF 路径**：删除 `_try_import_pymupdf` / `_export_xfdf_from_pdf` /
  `_inject_xfdf_into_pdf` / `_PdfRenderThread` / `PdfPreviewDialog` / `_show_pdf_preview` /
  `sig_draft_preview_ready` / `btn_preview_acrf_in_tab` 等所有相关代码。根因：PyMuPDF 的
  `add_freetext_annot` 不能还原 xfdf 中 line/polygon/highlight/ink 等多种注释类型，
  颜色/边框/字号一律失真，无法替代 Adobe 手动 Import Comments 的效果。全程改为手动。
- **ecrf 复制重命名逻辑改**：`_do_full_draft` 中只把源 PDF 复制到 `draft/ecrf.pdf`；
  062_acrf 下原 PDF 维持不动。`coordination.py` 的 `&fp` 参数同步指向 `062_acrf/draft/`。
- **首次运行按钮锁死改 `setVisible(False)`**：旧版 `setEnabled(False)` 在 `_exit_running`
  之后执行，中间存在 race condition 导致按钮残留可点击态。`setVisible(False)` 直接从
  布局移除按钮，唯一解锁路径是 `update_paths`（刷新源文件 / 切项目）。
- **annomap standard 列恢复 QComboBox**：v12.9.4 改的"延迟编辑（QLineEdit + QCompleter）"
  缺下拉箭头视觉提示，本版恢复 v12.9 的"每行一个 QComboBox"设计 — `setEditable(True)` +
  `QCompleter MatchContains` 同时支持下拉点选与模糊联想输入。
- **修改过的单元格自动标蓝**：QComboBox 的 `currentTextChanged` 信号触发样式切换，
  与原值不同 → 浅蓝底深蓝字粗体；恢复原值 → 默认白底。
- **保存并重跑多线程化**：新增 `_AnnomapSaveThread`（QThread），openpyxl `load_workbook + save`
  从主线程移到子线程；按钮点击后立即显示"⏳ 正在保存..."无卡顿。子线程 finished 后回主
  线程触发 `_do_autoanno_only`。
- **"导出 xfdf"按钮改为"导入 xfdf"**：旧版把 draft 下的 xfdf 复制到桌面再让用户去 Adobe
  导入，多此一步。新版直接用 Adobe 打开 `draft/ecrf.pdf`（与 draft.xfdf 已同目录），弹窗
  指引用户在 Adobe 中 `Comments → ⋮ → Import Comments` 选 `draft.xfdf`，然后另存为
  `acrf.pdf` 放到 `final/` 用于 23 Final Annotation。

### v12.9.4
- 「保存并重跑」防重入 + autoanno_only 模式独立中止按钮，不再联动左侧 btn_run_draft。
- annomap standard 列延迟编辑（已在 v12.9.5 改为 QComboBox）。
- splash 70% 缩放。

### v12.9.3
- openpyxl `load_workbook(data_only=True)` 在 datetime cached numFmt 不一致时崩 →
  改 `read_only=True` 容错读数据；样式单独再开 wb 扒色。
- 「保存并重跑」连点引发 BadZipFile / 0xC0000409 闪退（已通过防重入 + setEnabled(False) 治理）。
