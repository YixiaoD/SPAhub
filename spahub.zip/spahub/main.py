# -*- coding: utf-8 -*-
"""
main.py — SAS Autoexec & Tools 主入口
=====================================

启动流程：
  1. 注册全局异常钩子 sys.excepthook → 写 logs/crash.log，并弹窗提示用户
  2. 安装 Qt 消息处理器，捕获 QtFatalMsg
  3. 创建 QApplication → 立即显示 QSplashScreen（让用户立刻看到反馈）
  4. 异步导入主窗口模块 + 构造 SASEGGUI（含路径下拉框延迟初始化）
  5. 显示主窗口、关闭 Splash

关键性能点：
  - SplashScreen 在导入 gui.main_window 之前显示，规避 import 阻塞
  - SASEGGUI 用 _minimal=True 模式仅搭骨架，完整初始化在 QTimer 中分阶段进行
  - saspy 已改为 sas_engine.executor.run_sas 内部延迟 import，本入口不再触发
"""
import sys
import os


# ============================================================================
# v12.10.71（本次改动 — 核心）：sys.path 网络盘重排
# ----------------------------------------------------------------------------
# 必须放在 main.py 最顶端、所有其它 import 之前执行（faulthandler / logging /
# traceback 这些标准库不受 sys.path 顺序影响，无所谓；但 PySide6 / from gui...
# 这种用户路径 import 都要等这一步做完才安全）。
#
# 现象：SPAhub 部署在 Z:\projects\Z_PYTHON\SPAhub\（SMB 网络盘）。Python 启动时
# 自动把 cwd 设为 sys.path[0]，所以一开始 sys.path[0] 就是 Z:\…。后续无论是
# main.py L72 的 sys.path.append(_main_dir) 还是 modules/tfls_metadata.py L67
# 的 sys.path.append(_TARGET_DIR)，都来不及改变 sys.path[0]。
#
# 影响：MetadataRunner.run() 里 `import torch`（~50 子模块）和 shell_to_demo.py
# 头部 `from transformers import ...`（~2000 子模块）每次 import 都按 sys.path
# 顺序先 stat 一次 Z:\，每次 ~25ms 的 SMB roundtrip。诊断报告实测：
#   - import torch:           5.24s
#   - from transformers ...: 44.74s
#   累计 50s 卡顿，占 02 Metadata Setup 首次运行 ~110s 的 45%。
#
# 修复：把 sys.path 中所有 Windows 网络盘条目（映射盘符 + UNC）从头部挪到末尾。
# 本地 C:\Python_396\lib\site-packages 优先命中，torch / transformers 子模块全部
# 从本地找；网络盘只在本地都不命中时作为兜底，用于 SPAhub 自身的 modules / gui /
# sas_engine 包（数量少，影响 < 0.5s 可忽略）。
#
# 仅 Windows 生效；其它平台不动 sys.path。预期收益：02 Metadata Setup 首次运行
# 时长从 ~110s 砍到 ~60-65s。
#
# 防御：所有 ctypes 调用包 try-except，失败时不动 sys.path（绝不能因为加速代码
# 失败影响主流程）。`if remotes and locals_` 保证「纯本地」「纯网络」「空 sys.path」
# 都安全（不动）。
def _spahub_move_network_drives_to_end_of_syspath():
    if os.name != "nt":
        return
    try:
        import ctypes
        DRIVE_REMOTE = 4
        GetDriveType = ctypes.windll.kernel32.GetDriveTypeW
    except Exception:
        return  # ctypes 不可用就放弃，原 sys.path 不动

    locals_, remotes = [], []
    for p in sys.path:
        is_remote = False
        if isinstance(p, str) and p:
            if p.startswith("\\\\"):
                # UNC 路径 (\\server\share\...) 一律视为网络盘
                is_remote = True
            elif len(p) >= 3 and p[1] == ":" and p[2] in ("\\", "/"):
                try:
                    if GetDriveType(p[0].upper() + ":\\") == DRIVE_REMOTE:
                        is_remote = True
                except Exception:
                    pass
        (remotes if is_remote else locals_).append(p)

    # 只有同时存在本地 + 网络条目时才重排（否则维持原顺序）
    if remotes and locals_:
        sys.path[:] = locals_ + remotes


_spahub_move_network_drives_to_end_of_syspath()
del _spahub_move_network_drives_to_end_of_syspath


import traceback
import logging
import faulthandler
from datetime import datetime

# v12.10.48: 自包含启动环境配置 — 让快捷方式可直接指向 pythonw + main.py（跳过 .bat）
# ===========================================================================
# 目的：原桌面 .lnk → SPAhub.bat → cmd → start pythonw 链路里，cmd.exe 是
# console subsystem，Windows shell 启动它时不会显示 IDC_APPSTARTING 等待光标。
# 用户双击快捷方式后 splash 出现前的 5-20 秒完全没视觉反馈。
#
# 新链路：桌面 .lnk → pythonw.exe + main.py（GUI subsystem），shell 自动显示
# 鼠标右侧旋转动画直到 splash 出现（或 5 秒超时）。
#
# 此前由 SPAhub.bat 设置的环境变量，现在 main.py 自包含，使得 pythonw 直接拉起
# main.py 时也能用：
#   - PYTHONPATH 加 SPAhub 自身 + 同级 TFL_metadata
#   - PYTHONPYCACHEPREFIX → sys.pycache_prefix 重定向到本地 %LOCALAPPDATA%
#
# 兼容：SPAhub.bat 仍可用（重复设置无害）。
#
# v12.10.71（本次改动）：sys.path.insert(0, ...) → sys.path.append(...)
# ---------------------------------------------------------------------------
# 现象：SPAhub 部署在 Z:\projects\Z_PYTHON\SPAhub\（SMB 网络盘）。原 insert(0, ...)
# 把两个 Z:\ 路径插到 sys.path[0/1]。后续任何 `import xxx` 都会按 sys.path 顺序先
# stat 这两个网络盘路径，每次 ~20-30ms 的 SMB roundtrip。
#
# 影响最大的是 modules/tfls_metadata.py 的 MetadataRunner.run() 里 `import torch`
# （~50 子模块 → 5s 卡顿）和 shell_to_demo.py 的 `from transformers import ...`
# （~2000 子模块 → 45s 卡顿）。诊断报告实测 import 阶段累计 ~50s。
#
# 改成 append：本地 C:\Python_396\lib\site-packages 优先命中，transformers/torch
# 子模块全部从本地找；网络盘只在本地都不命中时作为兜底，用于 SPAhub 自身的
# modules / gui / sas_engine 包（数量少，影响 < 0.5s 可忽略）。
#
# 潜在风险：如果 site-packages 里有同名包会先命中。SPAhub 用的包名
# （modules / gui / sas_engine / TFL_metadata / shell_to_demo 等）都不会冲突。
# 如果将来出现冲突，可改回 insert(0) 并在 main.py 后续位置加一次 sys.path 重排。
_main_dir = os.path.dirname(os.path.abspath(__file__))
if _main_dir not in sys.path:
    sys.path.append(_main_dir)
_tfl_metadata_dir = os.path.join(os.path.dirname(_main_dir), "TFL_metadata")
if os.path.isdir(_tfl_metadata_dir) and _tfl_metadata_dir not in sys.path:
    sys.path.append(_tfl_metadata_dir)
# sys.pycache_prefix 需要 Python 3.8+；SPAhub 标准部署用 3.9.6 支持。
# 注意：这只影响**后续 import**的 .py 写出的 pyc 位置，main.py 本身不写 pyc。
sys.pycache_prefix = os.path.join(
    os.environ.get("LOCALAPPDATA", os.path.expanduser("~")),
    "SPAhub", "pycache"
)

# v12.10.36: monkey-patch subprocess.Popen 默认带 CREATE_NO_WINDOW
# 父 pythonw.exe 无 console，需让本进程内所有后续 subprocess.Popen 默认隐藏 console，
# 否则 saspy 在 in-process 跑时 spawn 的 java.exe 会弹黑窗（同样 win32com 拉的子进程也会）。
from _no_window_popen import install as _install_no_window_popen
_install_no_window_popen()

# v12.10.41: 设置 AppUserModelID — 让 Windows 任务栏 / Alt-Tab 把 SPAhub 当成
# 一个独立的应用（图标用我们自己的 spahub.ico），而不是显示成 python.exe 的图标。
# 必须在 QApplication 创建前调用，且必须在每个用 pythonw.exe 启动的 SPAhub 进程里调用一次。
# 性能开销 = 一次 ctypes 调用，<1ms。
if os.name == "nt":
    try:
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
            "HengruiPharma.SPAhub.Main.1"
        )
    except Exception:
        pass  # 不影响主功能

# ===== 全局崩溃防御：未捕获异常写入日志文件 =====
# 路径计算用 app_paths.app_root()
from app_paths import app_root, logs_dir
_LOG_DIR = logs_dir()
_CRASH_LOG = os.path.join(_LOG_DIR, "crash.log")

# v11.8 关键诊断：开启 faulthandler 把 C 层 fault（segfault / abort / stack overflow）
# 也持久化到 crash.log。Python 的 sys.excepthook 只能拦 Python 异常，对 saspy 底层
# C 扩展导致的 STATUS_STACK_BUFFER_OVERRUN (0xC0000409) 这类 SEH 异常无能为力 —
# faulthandler 直接挂到 OS 信号 / SEH，闪退前能写一份 traceback 到指定文件。
_FAULT_LOG = os.path.join(_LOG_DIR, "faulthandler.log")
try:
    _fault_fp = open(_FAULT_LOG, "a", buffering=1, encoding="utf-8")
    _fault_fp.write(f"\n========== {datetime.now().isoformat(timespec='seconds')} 启动 ==========\n")
    _fault_fp.flush()
    faulthandler.enable(file=_fault_fp, all_threads=True)
except Exception:
    pass  # 启用失败不影响正常启动

logging.basicConfig(
    filename=_CRASH_LOG,
    level=logging.ERROR,
    format="%(asctime)s [%(levelname)s] %(message)s",
    encoding="utf-8",
)

# v12.10.17：强制 logging 立即 flush — 闪退前最后写的日志要保证落盘
# 默认 FileHandler 有缓冲，闪退时缓冲区可能丢失。装个 force-flush 包装。
for _h in logging.getLogger().handlers:
    try:
        _orig_emit = _h.emit
        def _flushed_emit(record, _h=_h, _orig=_orig_emit):
            _orig(record)
            try:
                _h.flush()
            except Exception:
                pass
        _h.emit = _flushed_emit
    except Exception:
        pass

def _global_exception_hook(exc_type, exc_value, exc_tb):
    """拦截所有未捕获异常，写入 logs/crash.log"""
    if issubclass(exc_type, KeyboardInterrupt):
        sys.__excepthook__(exc_type, exc_value, exc_tb)
        return
    tb_text = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
    logging.error(f"未捕获异常:\n{tb_text}")
    # 尝试弹窗通知用户
    try:
        from PySide6.QtWidgets import QMessageBox, QApplication
        app = QApplication.instance()
        if app:
            QMessageBox.critical(
                None, "程序异常",
                f"发生未预期的错误，详细信息已记录至:\n{_CRASH_LOG}\n\n"
                f"异常类型: {exc_type.__name__}\n"
                f"异常信息: {exc_value}"
            )
    except Exception:
        pass

sys.excepthook = _global_exception_hook

# v12.10.17：装 sys.unraisablehook 捕获 Qt Slot 内的"silent crash"
# 根因：PySide6 Slot 调用是 C 层 invoke，Python 异常在 Slot 内抛出会被 Qt 静默吞掉
# （只在 stderr 印一行 "TypeError ..." 然后继续 — 但严重场景如 NoneType.attr 触发
# 后续状态损坏导致主线程崩溃 → app 闪退且 sys.excepthook 不触发）。
# Python 3.8+ 的 sys.unraisablehook 能拦到这类"未引发到栈顶但已记录"的异常。
def _unraisable_hook(unraisable):
    """捕获 Qt Slot / __del__ / GC finalizer 等场景的未引发异常"""
    try:
        tb_text = "".join(traceback.format_exception(
            unraisable.exc_type, unraisable.exc_value, unraisable.exc_traceback
        ))
        ctx = ""
        if unraisable.object is not None:
            ctx = f" (in {type(unraisable.object).__name__})"
        msg = unraisable.err_msg or "Exception ignored"
        logging.error(f"Qt Slot/Finalizer 未引发异常{ctx}: {msg}\n{tb_text}")
    except Exception:
        pass
    # 不调 sys.__unraisablehook__ — 默认 hook 只 print 到 stderr，对用户无价值

try:
    sys.unraisablehook = _unraisable_hook
except AttributeError:
    pass  # Python < 3.8 不支持

# v12.10.17：装 threading.excepthook 兜底子线程内未捕获异常
# QThread.run() 内的异常默认会被 Qt 吃掉 → 主线程信号链断裂 → 后续操作触发闪退
import threading
def _thread_exception_hook(args):
    try:
        tb_text = "".join(traceback.format_exception(args.exc_type, args.exc_value, args.exc_traceback))
        thread_name = args.thread.name if args.thread else "unknown"
        logging.error(f"子线程 {thread_name} 未捕获异常:\n{tb_text}")
    except Exception:
        pass

try:
    threading.excepthook = _thread_exception_hook
except AttributeError:
    pass

# Qt 线程内异常也需要捕获
def _qt_message_handler(mode, context, message):
    if mode.name == b'QtFatalMsg':
        logging.error(f"Qt Fatal: {message} (file={context.file}, line={context.line})")

try:
    from PySide6.QtCore import qInstallMessageHandler, QtMsgType
    qInstallMessageHandler(_qt_message_handler)
except Exception:
    pass


# ============================================================================
# 启动入口（仅在直接运行时执行）
# ============================================================================
if __name__ == "__main__":
    # 先只 import 必需的轻量模块（不触碰 gui.main_window，避免 import 阻塞）
    from PySide6.QtWidgets import QApplication, QSplashScreen
    from PySide6.QtGui import QPixmap
    from PySide6.QtCore import Qt, QTimer

    app = QApplication(sys.argv)

    # v12.10.41 + v12.10.46 修订：给 app 设全局窗口图标（配合上面 SetCurrentProcessExplicitAppUserModelID）
    # 让任务栏 / Alt-Tab / 标题栏左上角都显示 SPAhub 的 hub 图标，而不是 python.exe 默认图标。
    #
    # 关键：必须按"本地优先"顺序找 ico。Windows GPO 在企业环境下常常拦截
    # QIcon 从网络盘加载 .ico（和桌面快捷方式白纸是同源问题）。如果直接用 Z 盘
    # 的 ico，QIcon 会静默失败 → 任务栏 fallback 到 python.exe 图标。
    #
    # 部署文档已要求用户在第一步把 ico 拷到 %LOCALAPPDATA%\SPAhub\spahub.ico,
    # 这里优先用那个本地副本。本地没有再退回到 bundle 的 Z 盘原文件。
    try:
        from PySide6.QtGui import QIcon
        from app_paths import bundle_root as _bundle_root
        _icon_candidates = []
        _local_appdata = os.environ.get("LOCALAPPDATA")
        if _local_appdata:
            _icon_candidates.append(os.path.join(_local_appdata, "SPAhub", "spahub.ico"))
        _icon_candidates.append(os.path.join(_bundle_root(), "resources", "spahub.ico"))
        for _candidate in _icon_candidates:
            if os.path.isfile(_candidate):
                _ico = QIcon(_candidate)
                # QIcon 加载失败时 isNull() 返回 True 或 availableSizes() 空 — 都跳过
                if not _ico.isNull() and _ico.availableSizes():
                    app.setWindowIcon(_ico)
                    break
    except Exception:
        pass

    # ---- Splash ---------------------------------------------------------
    # v12.9.2：splash 简化 — 去掉绿球动画。
    # 历史教训：之前 v11.4~v12.9 都尝试在 splash 上画动态绿球，但 Qt 的 SplashScreen 在
    # 启动期间主线程被 import 阻塞（saspy / openpyxl / pymupdf 等大模块加载），QTimer 没机会
    # 触发 paintEvent，所以"球永远不动"。即便用 app.processEvents() 也只是单次刷新。
    # 用户报告"还是不能动"完全合理 — 加载完成后 splash 就 close 了，根本来不及动画。
    # 解法：彻底放弃动画，用静态 QSplashScreen 即可（也省去 ~30 行自绘代码）。
    # splash.png 由 PIL 2× 渲染 + LANCZOS 缩放生成，580x340 尺寸，清晰度比 v12.9 大幅提升。
    # v12.10.30：splash.png 是只读资源，frozen 时打进 _MEIPASS 临时目录，
    # 开发模式与 main.py 同级。app_paths.bundle_root() 帮我们统一处理。
    from app_paths import bundle_root
    splash_path = os.path.join(bundle_root(), "resources", "splash.png")
    splash = None
    if os.path.exists(splash_path):
        from PySide6.QtWidgets import QSplashScreen
        pix = QPixmap(splash_path)
        # v12.9.4：splash 缩小至 70%（用户要求）
        # 用 QPixmap.scaled + SmoothTransformation 保留清晰度 — 比修改源文件更灵活，
        # 未来调整比例只改一个数字即可
        if not pix.isNull():
            new_w = max(1, int(pix.width() * 0.7))
            new_h = max(1, int(pix.height() * 0.7))
            pix = pix.scaled(new_w, new_h, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        splash = QSplashScreen(pix, Qt.WindowStaysOnTopHint)
        splash.show()
        app.processEvents()

    # ---- 重活：import 主窗口模块（saspy 已延迟到 run_sas 内部，此处不再阻塞）----
    from gui.main_window import SASEGGUI

    # ---- 构造主窗口（minimal 骨架，重 IO 推到 _post_init）------------------
    window = SASEGGUI(_minimal=True)
    window.show()

    if splash is not None:
        splash.finish(window)

    # ---- 主窗口可见后的延迟初始化：路径扫描 / 路由完整接线 ----------------
    # singleShot(0) → 等当前事件循环空了再跑，主窗口先 paint 出来
    QTimer.singleShot(0, window._post_init)

    sys.exit(app.exec())
