# -*- coding: utf-8 -*-
"""
ui_utils.py — 全局共享 UI 工具
==============================

统一弹窗引擎 show_dialog：
  - 支持 info / warning / error / question 四种类型
  - question 类型返回 True（确认）/ False（取消）
  - 可选参数 path：弹窗上显示"📂 打开文件路径"按钮，指向指定目录
  - 所有模块通过本函数弹窗，避免各自实现风格不一致

通用脚本后台运行器 ScriptRunnerThread：
  - 启动 Python 子进程（CREATE_NO_WINDOW 不弹控制台）
  - 通过 stdin 一次性喂入预设答案（替代脚本里的 input() 交互）
  - stdout/stderr 合并后实时按行回传到 line_signal
  - 结束时通过 finished_signal 上报 (returncode, full_output)
  - 任务2（Home 系统文件复制）和任务4（Batch 前置备份）共用本类

只读日志查看对话框 ScriptOutputDialog：
  - 提供"详情"按钮主动触发的查看入口
  - 主要用于任务2 完成后查看完整复制摘要（不在主面板自动弹窗，由用户主动点击）
"""
import os
import sys
import subprocess
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                               QTextEdit, QLineEdit)
from PySide6.QtCore import Qt, QThread, Signal


# =============================================================================
# 按钮样式 helpers（v12.10.43 引入）
# -----------------------------------------------------------------------------
# 之前各模块按钮都用 inline setStyleSheet，没有 :hover / :pressed 选择器，
# 用户点击或悬停时无视觉反馈，常以为程序卡死。这里集中提供 4 套配色：
#   primary  蓝     用于"运行/生成/启动"主操作
#   danger   红     用于"中止/删除"危险操作
#   success  绿     用于"打开/编辑产物"成功后操作
#   light    灰     用于"浏览/刷新/打开目录"次要操作
#
# 使用示例：
#   from ui_utils import primary_btn_style
#   self.run_btn.setStyleSheet(primary_btn_style())
# =============================================================================

def primary_btn_style():
    """主蓝按钮（主操作：运行/生成/推送）。v12.10.81：统一皇家蓝 #4A6FA5（与主题同源）。"""
    return (
        "QPushButton { background-color: #4A6FA5; color: white; font-weight: bold; "
        "border: none; padding: 8px 20px; border-radius: 4px; }"
        "QPushButton:hover { background-color: #6385B6; }"
        "QPushButton:pressed { background-color: #3A5687; }"
        "QPushButton:disabled { background-color: #B0B9D1; }"
    )


def danger_btn_style():
    """危险红按钮：用于"中止"等。v12.10.81：深一档 #B85450，与柔和主题协调。"""
    return (
        "QPushButton { background-color: #B85450; color: white; font-weight: bold; "
        "border: none; padding: 8px 20px; border-radius: 4px; }"
        "QPushButton:hover { background-color: #A93226; }"
        "QPushButton:pressed { background-color: #922B21; }"
        "QPushButton:disabled { background-color: #E2A9A2; }"
    )


def success_btn_style():
    """成功绿按钮：用于"打开文件夹/打开生成文件"等。v12.10.82：调亮为 #3F9A6E（v81 的 #348A60 偏暗）。"""
    return (
        "QPushButton { background-color: #3F9A6E; color: white; font-weight: bold; "
        "border: none; padding: 8px 20px; border-radius: 4px; }"
        "QPushButton:hover { background-color: #4FAB7E; }"
        "QPushButton:pressed { background-color: #348A60; }"
        "QPushButton:disabled { background-color: #B6DEC4; }"
    )


def light_btn_style():
    """浅灰按钮：用于"浏览 / 打开目录"等次要操作。v12.10.81：hover 改皇家蓝调，与主题一致。"""
    return (
        "QPushButton { background-color: #F4F6FA; color: #5A6678; "
        "border: 1px solid #D5DBE6; border-radius: 4px; padding: 6px 12px; }"
        "QPushButton:hover { background-color: #EEF2FB; color: #4A6FA5; "
        "border-color: #4A6FA5; }"
        "QPushButton:pressed { background-color: #DCE4F5; color: #3A5687; "
        "border-color: #3A5687; }"
        "QPushButton:disabled { background-color: #F5F7FA; color: #C0C4CC; "
        "border-color: #E4E7ED; }"
    )


def primary_outline_btn_style():
    """蓝色外框按钮：默认浅蓝底+深蓝字+蓝边，hover 反转为深蓝底白字。

    v12.10.65：原本 home 页"📁 系统文件复制"按钮用的 inline css，提炼成公共
    helper。其它模块的"🔄 刷新源文件"按钮（原本是无 hover 的灰底）统一改用此样式，
    与 home 视觉一致。

    与 primary_btn_style 的区别：
      - primary：实心填充，视觉权重高，用于"运行/生成"等主操作（一行只该有一个）
      - primary_outline：外框风格，视觉权重中等，用于"刷新/复制/打开"等"次主操作"
    """
    return (
        "QPushButton { background-color: #FFFFFF; color: #4A6FA5; "
        "border: 1px solid #C0CAE1; padding: 6px 14px; border-radius: 4px; font-weight: bold; }"
        "QPushButton:hover { background-color: #4A6FA5; color: white; border-color: #4A6FA5; }"
        "QPushButton:disabled { background-color: #F5F7FA; color: #C0C4CC; border-color: #E4E7ED; }"
    )


def scan_status_lbl_style(color="#E6A23C"):
    """form 顶部"⏳ 等待..." / "✅ 已就绪" 等状态标签的统一样式。

    v12.10.66：原 inline 样式 `font-size:12px; font-style:italic;` 导致 ⏳ ✅ ⚠ 等
    emoji 顶部被裁切。当时加 padding + 提 font-size，但**没解决根因** — 用户反馈截图
    显示沙漏依然只剩底半截（同截图中按钮里的 🔄 完整 → 证明 emoji 本身渲染没问题）。

    v12.10.67：定位真正根因 — **italic 是元凶**。
      - 详细机制：italic 作用到 QLabel 时，Qt 会让 emoji 字体（Windows 上的
        Segoe UI Emoji）做斜体渲染。但 emoji 字体没有 italic 变体，Qt 退而用 painter
        几何变换强制倾斜 → 把 ⏳ ⚠ 等纵向偏高的 emoji 顶部推出可绘区，padding 救不了
        （padding 是 widget 边距，变换发生在 painter 层级，先于 widget 裁切）。
      - 修复：移除 font-style: italic。emoji 字体走默认 baseline → 顶部不被推出可绘区。
      - 保留橙色 #E6A23C 默认（"等待中"的核心语义信号），font-size 提到 14px（更清晰），
        padding 1px 2px（保留小内边距兜底）。
      - 新增 color 参数：原本各 stepper / runtime 路径会用 inline italic 样式重新 set，
        覆盖 helper 设的非 italic 样式（v12.10.66 漏改）。本次让所有这些路径也走 helper，
        通过 color 参数传不同状态颜色（橙=等待，蓝=扫描中，绿=已就绪，红=错误）。

    color: 状态颜色（QSS 合法颜色值）。常见取值：
      - #E6A23C 橙（等待中 / 路径不全） — 默认
      - #4A6FA5 蓝（扫描中）
      - #67C23A 绿（已就绪 / 扫描完成）
      - #F56C6C 红（错误）
    """
    return f"color: {color}; border: none; font-size: 14px; padding: 1px 2px;"


def unified_scrollbar_style():
    """v12.10.72：统一应用内所有滚动条样式 — 与 shortcuts 页（一站式导航）
    QScrollArea 完全一致，区别于 Qt 默认的灰白宽条。

    设计：浅灰轨道 + 灰圆角 thumb + hover 加深，无 add/sub line 箭头。
    用法：在任何 QTextEdit / QScrollArea / QListWidget 等的 setStyleSheet
    字符串里拼接本片段即可（CSS selector 是 QScrollBar，不会污染 widget 本体）。

    typical usage:
        widget.setStyleSheet(my_widget_style + unified_scrollbar_style())
    """
    return (
        "QScrollBar:vertical { border: none; background: #F5F7FA; width: 10px; border-radius: 5px; }"
        "QScrollBar::handle:vertical { background: #DCDFE6; border-radius: 5px; min-height: 20px; }"
        "QScrollBar::handle:vertical:hover { background: #C0C4CC; }"
        "QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }"
        "QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: transparent; }"
        "QScrollBar:horizontal { border: none; background: #F5F7FA; height: 10px; border-radius: 5px; }"
        "QScrollBar::handle:horizontal { background: #DCDFE6; border-radius: 5px; min-width: 20px; }"
        "QScrollBar::handle:horizontal:hover { background: #C0C4CC; }"
        "QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0; }"
        "QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal { background: transparent; }"
    )


def log_textedit_style(with_padding=True):
    """v12.10.72：日志面板（QTextEdit）的统一样式 — 浅灰底 + 等宽字 + 浅边框 + 统一滚动条。
    替代各处零散的 inline 字符串，确保所有 stepper / TOC / autoanno 等日志面板视觉一致。

    with_padding=True 时含 8px 内边距（适合左右栏式右侧日志面板，文字不贴边）；
    False 时无 padding（适合 splash 这种紧凑场景，外层已自带留白）。
    """
    pad = "padding: 8px;" if with_padding else ""
    return (
        f"QTextEdit {{ background-color: #F8F9FA; color: #606266; font-family: Consolas;"
        f" border: 1px solid #E4E7ED; border-radius: 4px; {pad} font-size: 12px; }}"
        + unified_scrollbar_style()
    )


def show_dialog(parent, title, text, msg_type="info", path=None, align="center"):
    """
    统一弹窗引擎，支持 info/warning/error/question 类型，可选文件路径导航。
    对于 question 类型，返回 True（确认）或 False（取消）。
    其余类型始终返回 False。

    v12.9.7：新增 align 参数 ("center" / "right")。
      - "center"（默认）：用 Qt 默认居中策略（相对 parent，无 parent 时屏幕中央）
      - "right"：把弹窗 move 到主屏幕右半区，避开正中央
        用例：用 Adobe 打开 PDF 后弹"操作指引"，避免与 Acrobat 窗口完全重合压在 PDF 上面

    v12.10.13：parent 统一锁到顶层 QMainWindow（parent.window()）— 避免传入 QFrame
    或子 Form 时弹窗位置漂移、modal 范围错乱。Qt 的 QDialog modal 需以顶层窗口为父
    才能正确阻塞主窗口；传 QFrame 会让弹窗在 widget 树上挂错位置，行为不确定。
    """
    # 锁定到顶层窗口（QMainWindow）— widget.window() 自动找最近的 top-level
    if parent is not None:
        try:
            top = parent.window()
            if top is not None:
                parent = top
        except Exception:
            pass

    dlg = QDialog(parent)
    dlg.setWindowTitle(title)
    # v12.8：原 setFixedSize(420,200) 在长路径报错（如 Z:\projects\...\utility\tools\dir_bat_create_copy_files.py）
    # 时会把后半截字符截断，用户看不到完整提示。改成 minimum + 弹性尺寸：
    #   - minWidth 540 保证常见长 Windows 路径完整显示一行
    #   - 高度让 layout 自动算（基于 wordWrap 后的行数 + 按钮区）
    dlg.setMinimumSize(540, 200)
    dlg.setMaximumWidth(800)  # 防止极长 path 把窗口拉得超过屏幕
    dlg.setStyleSheet("""
        QDialog { background-color: #FFFFFF; }
        QLabel { color: #303133; font-size: 14px; }
        QPushButton { border-radius: 4px; padding: 6px 20px; font-size: 13px; font-weight: bold; }
        QPushButton#btnBlue { background-color: #4A6FA5; color: white; border: none; }
        QPushButton#btnBlue:hover { background-color: #6385B6; }
        QPushButton#btnPlain { background-color: #F5F7FA; color: #606266; border: 1px solid #DCDFE6; }
        QPushButton#btnPlain:hover { background-color: #E4E7ED; }
        QPushButton#btnPath { background-color: #FDF6EC; color: #E6A23C; border: 1px solid #F5DAB1; }
        QPushButton#btnPath:hover { background-color: #E6A23C; color: white; }
    """)
    lay = QVBoxLayout(dlg)
    lay.setContentsMargins(25, 25, 25, 20)

    icon_map = {"info": "✅", "warning": "⚠️", "error": "❌", "question": "❓"}
    lbl = QLabel(f"{icon_map.get(msg_type, '')} {text}")
    lbl.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
    lbl.setWordWrap(True)
    lay.addWidget(lbl)
    lay.addStretch()

    btn_lay = QHBoxLayout()
    if path:
        p_btn = QPushButton("📂 打开文件路径")
        p_btn.setObjectName("btnPath")
        p_btn.clicked.connect(
            lambda: os.startfile(path) if os.path.exists(path) else show_dialog(parent, "错误", "路径不存在", "error"))
        btn_lay.addWidget(p_btn)

    btn_lay.addStretch()

    result = [False]

    if msg_type == "question":
        btn_yes = QPushButton("确认")
        btn_yes.setObjectName("btnBlue")
        btn_yes.clicked.connect(lambda: (result.__setitem__(0, True), dlg.accept()))

        btn_no = QPushButton("取消")
        btn_no.setObjectName("btnPlain")
        btn_no.clicked.connect(dlg.reject)

        btn_lay.addWidget(btn_yes)
        btn_lay.addWidget(btn_no)
    else:
        btn_ok = QPushButton("OK")
        btn_ok.setObjectName("btnBlue")
        btn_ok.clicked.connect(dlg.accept)
        btn_lay.addWidget(btn_ok)

    lay.addLayout(btn_lay)

    # v12.9.7：align="right" 时把弹窗移到屏幕右半区，避免与 Adobe Acrobat 窗口重合
    # 注意：此时 dialog 尚未 show，sizeHint 还没算出来，先 adjustSize 再 move 比较准
    if align == "right":
        try:
            from PySide6.QtWidgets import QApplication
            dlg.adjustSize()
            screen = QApplication.primaryScreen().availableGeometry()
            target_x = screen.x() + int(screen.width() * 0.62)
            target_y = screen.y() + int(screen.height() * 0.25)
            dlg.move(target_x, target_y)
        except Exception:
            pass  # 多屏 / headless 等异常环境下退化到默认居中

    dlg.exec()
    return result[0]


# =============================================================================
# 选项对话框 / 文本输入对话框（任务1：跑批前置交互式弹窗）
# =============================================================================
def show_choice_dialog(parent, title, text, options, cancellable=True):
    """
    多选一对话框：每个选项一个按钮，点击即返回该选项的 value。

    参数：
        options: list of (label, value)，按顺序左到右排列。
        cancellable: 是否提供"取消"按钮，True 时取消返回 None。

    返回：
        被选中选项的 value；若用户关闭对话框/点取消则返回 None。

    设计：
      - 与 show_dialog 同款样式（白底 + 蓝色主按钮 + 灰色次按钮）
      - 单行选项数 ≤ 3 时横向排列，>3 时折行（避免按钮被压扁）
    """
    dlg = QDialog(parent)
    dlg.setWindowTitle(title)
    dlg.setMinimumSize(460, 200)
    dlg.setStyleSheet("""
        QDialog { background-color: #FFFFFF; }
        QLabel { color: #303133; font-size: 14px; }
        QPushButton { border-radius: 4px; padding: 8px 18px; font-size: 13px; font-weight: bold; }
        QPushButton#btnBlue { background-color: #4A6FA5; color: white; border: none; }
        QPushButton#btnBlue:hover { background-color: #6385B6; }
        QPushButton#btnPlain { background-color: #F5F7FA; color: #606266; border: 1px solid #DCDFE6; }
        QPushButton#btnPlain:hover { background-color: #E4E7ED; }
    """)
    lay = QVBoxLayout(dlg)
    lay.setContentsMargins(25, 25, 25, 20)
    lay.setSpacing(15)

    lbl = QLabel(f"❓ {text}")
    lbl.setWordWrap(True)
    lay.addWidget(lbl)
    lay.addStretch()

    selected = [None]

    btn_lay = QHBoxLayout()
    btn_lay.setSpacing(10)
    btn_lay.addStretch()
    # 第一个选项用主蓝色，其余用次按钮风格，引导用户视觉聚焦
    for idx, (label, value) in enumerate(options):
        b = QPushButton(label)
        b.setObjectName("btnBlue" if idx == 0 else "btnPlain")
        b.clicked.connect(lambda checked=False, v=value: (selected.__setitem__(0, v), dlg.accept()))
        btn_lay.addWidget(b)

    if cancellable:
        cb = QPushButton("取消")
        cb.setObjectName("btnPlain")
        cb.clicked.connect(dlg.reject)
        btn_lay.addWidget(cb)

    lay.addLayout(btn_lay)
    dlg.exec()
    return selected[0]


def show_text_input_dialog(parent, title, text, default="", placeholder="", validator=None):
    """
    文本输入对话框：用于需要用户输入字符串的场景（任务1 csr 整体备份命名）。

    参数：
        validator: 可选，签名 (text:str) -> (ok:bool, err_msg:str)。
                   用户点击确定时调用，ok=False 时把 err_msg 显示在对话框里且不关闭对话框。

    返回：
        用户确认的文本（去首尾空白）；用户点取消或关闭则返回 None。
    """
    dlg = QDialog(parent)
    dlg.setWindowTitle(title)
    dlg.setMinimumSize(460, 220)
    dlg.setStyleSheet("""
        QDialog { background-color: #FFFFFF; }
        QLabel { color: #303133; font-size: 14px; }
        QLabel#errLbl { color: #F56C6C; font-size: 12px; }
        QLineEdit { padding: 6px 10px; border: 1px solid #DCDFE6; border-radius: 4px; font-size: 13px; }
        QLineEdit:focus { border-color: #4A6FA5; }
        QPushButton { border-radius: 4px; padding: 8px 18px; font-size: 13px; font-weight: bold; }
        QPushButton#btnBlue { background-color: #4A6FA5; color: white; border: none; }
        QPushButton#btnBlue:hover { background-color: #6385B6; }
        QPushButton#btnPlain { background-color: #F5F7FA; color: #606266; border: 1px solid #DCDFE6; }
        QPushButton#btnPlain:hover { background-color: #E4E7ED; }
    """)
    lay = QVBoxLayout(dlg)
    lay.setContentsMargins(25, 25, 25, 20)
    lay.setSpacing(12)

    lbl = QLabel(f"❓ {text}")
    lbl.setWordWrap(True)
    lay.addWidget(lbl)

    edit = QLineEdit()
    if default:
        edit.setText(default)
    if placeholder:
        edit.setPlaceholderText(placeholder)
    edit.selectAll()
    lay.addWidget(edit)

    err_lbl = QLabel("")
    err_lbl.setObjectName("errLbl")
    err_lbl.setVisible(False)
    err_lbl.setWordWrap(True)
    lay.addWidget(err_lbl)

    lay.addStretch()

    result = [None]

    def _on_ok():
        val = edit.text().strip()
        if validator is not None:
            ok, err_msg = validator(val)
            if not ok:
                err_lbl.setText(f"⚠️ {err_msg}")
                err_lbl.setVisible(True)
                return
        result[0] = val
        dlg.accept()

    btn_lay = QHBoxLayout()
    btn_lay.addStretch()
    btn_ok = QPushButton("确定")
    btn_ok.setObjectName("btnBlue")
    btn_ok.setDefault(True)
    btn_ok.clicked.connect(_on_ok)
    btn_lay.addWidget(btn_ok)

    btn_cancel = QPushButton("取消")
    btn_cancel.setObjectName("btnPlain")
    btn_cancel.clicked.connect(dlg.reject)
    btn_lay.addWidget(btn_cancel)
    lay.addLayout(btn_lay)

    # Enter 键也走 _on_ok（含 validator 校验）
    edit.returnPressed.connect(_on_ok)

    dlg.exec()
    return result[0]


# =============================================================================
# 后台脚本运行线程（任务2 / 任务4 共用）
# =============================================================================
class ScriptRunnerThread(QThread):
    """
    在后台运行 Python 脚本，不弹控制台窗口。

    设计要点：
      - python -u 关闭 stdout 缓冲，让 print 输出实时可读，避免日志一次性涌现
      - stderr 合并到 stdout（subprocess.STDOUT），统一日志流，避免行错位
      - encoding='utf-8' + errors='replace' 兼容脚本里 robocopy / 中文输出可能出现的非标准字节
      - CREATE_NO_WINDOW (0x08000000) 阻止 Python 子进程弹出控制台
      - 通过 stdin 一次性写入预设答案应对脚本里的 input()；写完立即关闭 stdin，
        避免脚本读到 EOF 之后还卡在等待

    回传协议：
      - line_signal(str)        每读到一行就 emit（已 rstrip）
      - finished_signal(int,str) 子进程结束：returncode + 完整输出（行用 \\n 拼接）
    """
    line_signal = Signal(str)
    finished_signal = Signal(int, str)

    def __init__(self, script_path, cwd, stdin_text="", parent=None):
        super().__init__(parent)
        self.script_path = script_path
        self.cwd = cwd
        self.stdin_text = stdin_text
        self._proc = None
        self._is_cancelled = False

    def run(self):
        try:
            CREATE_NO_WINDOW = 0x08000000

            # 强制子 Python 进程 stdout 用 UTF-8 输出。
            env = os.environ.copy()
            env["PYTHONIOENCODING"] = "utf-8"
            env["PYTHONUTF8"] = "1"

            # 用 wrapper 包一层（修两个问题）：
            #   1. user script 内 subprocess.Popen 拉 robocopy 等的二级 console
            #   2. user script subprocess.Popen 默认 stdout=None 继承父句柄
            wrapper = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                   "_runner_no_console.py")
            cmd = [sys.executable, "-u", wrapper, self.script_path]

            self._proc = subprocess.Popen(
                cmd,
                cwd=self.cwd,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding='utf-8',
                errors='replace',
                creationflags=CREATE_NO_WINDOW,
                env=env,
            )

            # 一次性把所有交互答案写到 stdin，再关闭它，让脚本的 input() 顺序读完
            if self.stdin_text:
                try:
                    self._proc.stdin.write(self.stdin_text)
                    self._proc.stdin.flush()
                except Exception:
                    pass
            try:
                self._proc.stdin.close()
            except Exception:
                pass

            # 用一个独立 reader thread 异步读 stdout；主循环只 poll proc 状态。
            # 这样即使 user script 内的子进程残留句柄导致父 stdout 永远不来 EOF，
            # 主循环检测到 proc 已退出后也能强制收尾，触发 finished_signal。
            import queue, threading, time
            out_q = queue.Queue()
            EOF_SENTINEL = object()

            def _reader():
                try:
                    for raw in iter(self._proc.stdout.readline, ''):
                        out_q.put(raw)
                except Exception:
                    pass
                out_q.put(EOF_SENTINEL)

            reader = threading.Thread(target=_reader, daemon=True)
            reader.start()

            collected = []
            eof_received = False
            while not self._is_cancelled:
                try:
                    item = out_q.get(timeout=0.3)
                except queue.Empty:
                    # 0.3s 没新行 → 检查 proc 是否已退出
                    if self._proc.poll() is not None:
                        # proc 已退出。再给 reader 1s 排空残余 buffer，然后强制走 finished
                        deadline = time.time() + 1.0
                        while time.time() < deadline:
                            try:
                                item2 = out_q.get(timeout=0.1)
                                if item2 is EOF_SENTINEL:
                                    eof_received = True
                                    break
                                line = item2.rstrip()
                                collected.append(line)
                                self.line_signal.emit(line)
                            except queue.Empty:
                                continue
                        break
                    continue

                if item is EOF_SENTINEL:
                    eof_received = True
                    break
                line = item.rstrip()
                collected.append(line)
                self.line_signal.emit(line)

            # 收尾：等 proc 退出（一般已退）
            try:
                self._proc.wait(timeout=2.0)
            except Exception:
                pass
            rc = self._proc.returncode if self._proc.returncode is not None else -1
            self.finished_signal.emit(rc, "\n".join(collected))
        except Exception as e:
            self.finished_signal.emit(-1, f"[启动子进程异常] {e}")

    def cancel(self):
        """主动取消：标志位 + 杀整个进程树。
        proc.kill() 在 Windows 只调 TerminateProcess（仅杀直接 proc），
        孙进程（如 user script 拉的 robocopy → cmd → ...）会继续跑且持有
        stdout 句柄 → 父 readline 永远不收 EOF → finished 信号不发。
        改用 taskkill /F /T /PID 杀整棵树。"""
        self._is_cancelled = True
        if self._proc is None or self._proc.poll() is not None:
            return
        # 优先 taskkill /T（杀整棵树，含所有子孙进程）
        try:
            import subprocess as _sp
            _sp.run(
                ["taskkill", "/F", "/T", "/PID", str(self._proc.pid)],
                stdout=_sp.DEVNULL, stderr=_sp.DEVNULL,
                creationflags=0x08000000,  # CREATE_NO_WINDOW
                timeout=5,
            )
        except Exception:
            # 兜底：如果 taskkill 不可用（极罕见），退到普通 kill
            try:
                self._proc.kill()
            except Exception:
                pass


# =============================================================================
# 脚本输出查看对话框（任务2 详情按钮 / 任务4 可复用）
# =============================================================================
class ScriptOutputDialog(QDialog):
    """
    只读对话框，展示脚本完整 stdout/stderr。

    设计：
      - 仅由用户主动点击"详情"触发，不做自动弹窗
      - 等宽字体 + 浅灰底，与各模块日志面板风格保持一致
      - 不可编辑，避免误改后再传入其他流程
    """
    def __init__(self, title, log_text, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(720, 480)
        self.setStyleSheet("QDialog { background-color: #FFFFFF; }")

        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 20, 20, 15)
        lay.setSpacing(10)

        head = QLabel(f"📋 {title}")
        head.setStyleSheet("font-size: 14px; font-weight: bold; color: #303133;")
        lay.addWidget(head)

        txt = QTextEdit()
        txt.setReadOnly(True)
        txt.setPlainText(log_text or "(无输出)")
        txt.setStyleSheet(
            "background-color: #F8F9FA; color: #606266; font-family: Consolas; "
            "border: 1px solid #E4E7ED; border-radius: 4px; padding: 8px; font-size: 12px;"
        )
        lay.addWidget(txt, 1)

        btn_lay = QHBoxLayout()
        btn_lay.addStretch()
        btn_close = QPushButton("关闭")
        btn_close.setStyleSheet(
            "background-color: #4A6FA5; color: white; border: none; padding: 8px 30px; "
            "border-radius: 4px; font-weight: bold;"
        )
        btn_close.clicked.connect(self.accept)
        btn_lay.addWidget(btn_close)
        lay.addLayout(btn_lay)



# ============================================================================
# v12.10.90：ChevronStepBar — 箭头管道式步骤条（方案B：chevron 连续咬合）
# ----------------------------------------------------------------------------
# 替代各 stepper 顶部"一排 QPushButton + 下划线选中"的旧步骤栏。每个步骤是一段
# chevron 箭头块（右端尖、左端凹槽，相邻块互相咬合，像流程管线）；当前/点击的步骤
# 整块填充皇家蓝 #4A6FA5 + 白字，其余浅灰底 + 灰字。点击任一段 emit step_clicked(step)。
#
# 兼容性：用 QPainter 自绘多边形，不依赖任何 QSS 边框/圆角特性，旧版 Qt 同样稳定。
# 旧代码 self.step_btns[step].setText/.text/.setChecked 通过 StepProxy 转发，无需改动。
# ============================================================================
from PySide6.QtWidgets import QWidget, QSizePolicy
from PySide6.QtGui import QPainter, QColor, QPolygon, QPen, QFont, QFontMetrics
from PySide6.QtCore import QPoint, QRect, QSize


class ChevronStepBar(QWidget):
    step_clicked = Signal(str)

    PAD = 22       # 文本左右内边距
    DEPTH = 16     # 箭头尖/凹槽深度
    HEIGHT = 44

    COL_ACTIVE_BG = "#4A6FA5"
    COL_ACTIVE_BD = "#4A6FA5"
    COL_ACTIVE_TX = "#FFFFFF"
    COL_HOVER_BG = "#E1E8F6"
    COL_HOVER_TX = "#4A6FA5"
    COL_IDLE_BG = "#EDF2FA"
    COL_IDLE_BD = "#D6DEEA"
    COL_IDLE_TX = "#8A94A6"

    def __init__(self, steps, labels, parent=None):
        super().__init__(parent)
        self._steps = list(steps)
        self._labels = dict(labels)                       # step -> 显示文本
        self._active = self._steps[0] if self._steps else None
        self._hover = None
        self._rects = {}                                  # step -> (x_left, x_right) 命中范围
        self.setMouseTracking(True)
        self.setCursor(Qt.PointingHandCursor)
        self.setMinimumHeight(self.HEIGHT)
        # v12.10.91：Expanding —— 步骤条横向占满 stepper 栏，各段等宽等间隔。
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

    # ---------- 公共 API（供 stepper / StepProxy 调用）----------
    def set_active(self, step):
        if step in self._steps and step != self._active:
            self._active = step
            self.update()

    def active_step(self):
        return self._active

    def set_label(self, step, text):
        if step in self._labels and self._labels[step] != text:
            self._labels[step] = text
            self.updateGeometry()
            self.update()

    def get_label(self, step):
        return self._labels.get(step, "")

    # ---------- 尺寸 ----------
    def _bar_font(self):
        f = QFont()
        f.setPixelSize(15)
        f.setBold(True)
        return f

    def sizeHint(self):
        fm = QFontMetrics(self._bar_font())
        total = self.DEPTH + 2
        for s in self._steps:
            total += fm.horizontalAdvance(self._labels.get(s, "")) + 2 * self.PAD + self.DEPTH
        return QSize(total, self.HEIGHT)

    def minimumSizeHint(self):
        return self.sizeHint()

    # ---------- 命中 ----------
    def _hit(self, x):
        for s, (xl, xr) in self._rects.items():
            if xl <= x <= xr:
                return s
        return None

    def mousePressEvent(self, e):
        x = int(e.position().x())
        s = self._hit(x)
        if s is not None and s != self._active:
            self.step_clicked.emit(s)

    def mouseMoveEvent(self, e):
        x = int(e.position().x())
        hv = self._hit(x)
        if hv != self._hover:
            self._hover = hv
            self.update()

    def leaveEvent(self, e):
        if self._hover is not None:
            self._hover = None
            self.update()

    # ---------- 绘制 ----------
    def paintEvent(self, ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        f = self._bar_font()
        p.setFont(f)
        h = self.height()
        d = self.DEPTH
        n = len(self._steps)
        if n == 0:
            p.end()
            return
        # v12.10.91：等宽分槽，横向占满整条（与旧版"等间隔铺满"一致）。
        W = self.width()
        xs = [round(i * W / n) for i in range(n + 1)]
        self._rects = {}
        for i, s in enumerate(self._steps):
            x0 = xs[i]
            x1 = xs[i + 1]
            if i == 0:
                poly = QPolygon([
                    QPoint(x0, 0), QPoint(x1 - d, 0),
                    QPoint(x1, h // 2),
                    QPoint(x1 - d, h), QPoint(x0, h),
                ])
                x_left = x0
            else:
                poly = QPolygon([
                    QPoint(x0 - d, 0), QPoint(x1 - d, 0),
                    QPoint(x1, h // 2),
                    QPoint(x1 - d, h), QPoint(x0 - d, h),
                    QPoint(x0, h // 2),
                ])
                x_left = x0 - d
            if s == self._active:
                bg, bd, tc = self.COL_ACTIVE_BG, self.COL_ACTIVE_BD, self.COL_ACTIVE_TX
            elif s == self._hover:
                bg, bd, tc = self.COL_HOVER_BG, self.COL_IDLE_BD, self.COL_HOVER_TX
            else:
                bg, bd, tc = self.COL_IDLE_BG, self.COL_IDLE_BD, self.COL_IDLE_TX
            p.setBrush(QColor(bg))
            p.setPen(QPen(QColor(bd), 1))
            p.drawPolygon(poly)
            p.setPen(QColor(tc))
            tr = QRect(x0, 0, x1 - x0, h)
            p.drawText(tr, Qt.AlignCenter, self._labels.get(s, ""))
            self._rects[s] = (x_left, x1)
        p.end()


class StepProxy:
    """让旧代码里 self.step_btns[step].setText/.text/.setChecked 继续可用，转发到 ChevronStepBar。"""
    def __init__(self, bar, step):
        self._bar = bar
        self._step = step

    def setText(self, text):
        self._bar.set_label(self._step, text)

    def text(self):
        return self._bar.get_label(self._step)

    def setChecked(self, on):
        if on:
            self._bar.set_active(self._step)

    def isChecked(self):
        return self._bar.active_step() == self._step

    # 旧代码可能调用的无关方法 — 安全吞掉
    def setStyleSheet(self, *a, **k):
        pass

    def setToolTip(self, *a, **k):
        pass

    def setVisible(self, *a, **k):
        pass
