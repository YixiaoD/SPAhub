# -*- coding: utf-8 -*-
"""
app_paths.py
============
集中处理路径计算 + 子进程命令构造（dev 模式版）。

API：
  - is_frozen() / bundle_root()   兼容保留 — main.py 和 sas_engine/executor.py 用
                                  dev 模式下：is_frozen 永远 False，bundle_root = app_root
  - app_root() / logs_dir()       modules/ 下取应用根目录、日志目录
  - child_command_*               ScriptRunner / 各 stepper 拉子进程的命令
                                  都返回 [python.exe, "-c"|"-m"|"-u", ...]
"""
import os
import sys


def is_frozen() -> bool:
    """dev 模式版恒定 False（保留 API 给 sas_engine.executor 等老调用方）。"""
    return False


def app_root() -> str:
    """SPAhub 应用根目录（main.py 同级）。"""
    return os.path.dirname(os.path.abspath(__file__))


def bundle_root() -> str:
    """dev 模式下与 app_root 相同（保留 API 给 main.py 找 splash.png 等资源）。"""
    return app_root()


# v12.10.47: logs 路径缓存（避免每次都做可写性测试）
_CACHED_LOGS_DIR: str = ""


def logs_dir() -> str:
    """永久日志目录（crash.log + 各模块运行日志）。自动创建。

    v12.10.47 起优先用 ``%LOCALAPPDATA%\\SPAhub\\logs\\``（用户本地，任何账户都能写），
    后备到 ``app_root()/logs/`` （Z 盘开发模式 / 管理员场景）。

    缘由：Z 盘共享对测试用户基本只读，excepthook 想写 crash.log 会静默失败，
    崩溃信息丢失。本地 AppData 任何用户都有完全控制权，零权限问题。

    第一次调用时做一次性可写性测试 + 缓存结果，后续 O(1)。
    """
    global _CACHED_LOGS_DIR
    if _CACHED_LOGS_DIR:
        return _CACHED_LOGS_DIR

    candidates = []
    local = os.environ.get("LOCALAPPDATA")
    if local:
        candidates.append(os.path.join(local, "SPAhub", "logs"))
    candidates.append(os.path.join(app_root(), "logs"))

    for p in candidates:
        try:
            os.makedirs(p, exist_ok=True)
            # 真正测一下可写（仅靠 isdir 不够 — 偶有目录存在但 ACL 禁写的情况）
            tf = os.path.join(p, ".write_test")
            with open(tf, "w") as f:
                f.write("ok")
            os.remove(tf)
            _CACHED_LOGS_DIR = p
            return p
        except OSError:
            continue

    # 双双失败：还是返回 app_root/logs 让上层调用方决定怎么处理
    _CACHED_LOGS_DIR = candidates[-1] if candidates else os.path.join(app_root(), "logs")
    return _CACHED_LOGS_DIR


# ============================================================================
# 子进程命令工厂
# ============================================================================
# Runner（tfls_pdt / tfls_batch_run / tfls_init_pgm 等）通过下面工厂拿
# subprocess.Popen 的 cmd 列表。
#
# 子进程通信仍用 pickle 文件 IPC（与原方案一致）。
# ============================================================================


def child_command_run_sas(script_path: str, res_path: str) -> list:
    """构造跑 SAS 脚本的 Python 子进程命令。

    子进程内部逻辑：
      1. install no-window-popen patch（让 saspy spawn java 时不弹黑窗）
      2. from sas_engine.executor import run_sas
      3. res = run_sas(...); pickle.dump(res, ...)
    """
    code = (
        # v12.10.36: 子进程顶部装 monkey-patch，让 saspy 内部 spawn java.exe 不弹黑窗
        "import sys\n"
        f"sys.path.insert(0, r'{app_root()}')\n"
        "from _no_window_popen import install as _install\n"
        "_install()\n"
        # 主体逻辑
        "import pickle\n"
        "from sas_engine.executor import run_sas\n"
        f"res = run_sas(r'{script_path}', None, False, False, True)\n"
        f"with open(r'{res_path}', 'wb') as f:\n"
        "    pickle.dump(res, f)\n"
    )
    return [sys.executable, "-c", code]


def child_command_pdt_post_process(pdt_path: str) -> list:
    """构造跑 PDT 后处理（win32com 公式重算）的子进程命令。
    子进程会逐行 stdout JSON 回报进度。"""
    return [sys.executable, "-m", "modules.pdt_post_process_runner", os.path.abspath(pdt_path)]


def child_command_run_user_script(script_path: str) -> list:
    """构造跑用户脚本（utility/tools/*.py）的子进程命令。
    用于 ui_utils.ScriptRunnerThread 起备份 / 复制 等用户脚本。"""
    return [sys.executable, "-u", os.path.abspath(script_path)]


def child_command_m5_pds() -> list:
    """构造跑 M5「01 PDS for Define」（crt_vars）的子进程命令。
    子进程从 stdin 读 JSON 参数，逐行 stdout JSON 回报进度/日志/结果
    （见 modules/m5_pds_runner.py）。-u 关闭缓冲保证行级流式输出。"""
    return [sys.executable, "-u", "-m", "modules.m5_pds_runner"]


def child_command_m5_codelist() -> list:
    """构造跑 M5「02 PDS for Codelist」（crt_codelist）的子进程命令。
    子进程从 stdin 读 JSON 参数，逐行 stdout JSON 回报进度/日志/结果
    （见 modules/m5_codelist_runner.py）。-u 关闭缓冲保证行级流式输出。"""
    return [sys.executable, "-u", "-m", "modules.m5_codelist_runner"]


def child_command_acrf_update() -> list:
    """v12.10.118：构造跑 aCRF「05 aCRF Update」的子进程命令。
    子进程从 stdin 读 JSON 参数，逐行 stdout JSON 回报日志/结果
    （见 modules/acrf_annotation_update_runner.py）。-u 关闭缓冲保证行级流式输出。"""
    return [sys.executable, "-u", "-m", "modules.acrf_annotation_update_runner"]
