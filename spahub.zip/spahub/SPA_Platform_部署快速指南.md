# SPA Platform 测试用户部署指南 v1.6

> 适用版本：v12.10.48 及以上（改名自 v12.10.75）；**05 aCRF Update 步骤需 v12.10.125 及以上**
> 适用平台：Windows 10 / Windows 11
>
> **v1.5 → v1.6 更新**（新增 aCRF · 05 aCRF Update 步骤：外部包 acrf_update_spahub + PyPDF2 依赖）：
> - ⚠ **新增外部包（部门侧前置，一次性，管理员维护）**：自 SPAhub **v12.10.125** 起，
>   aCRF 模块新增 **05 aCRF Update**（把上一版 CRF 的人工 xfdf 注释迁移到新版 CRF 页码 +
>   仍空白的表单交 autoanno 补白 + 合并）。其引擎与逻辑作为**外部 sibling 包 `acrf_update_spahub`**
>   部署，须放到 **`Z:\\projects\\Z_PYTHON\\aCRF\\acrf_update_spahub\\`**（与 `autoanno_draft`
>   平级，跨项目共享）。测试用户无需自己部署，但若该目录不可达，05 aCRF Update 运行时会报
>   「找不到 acrf_update_spahub 包」。
> - ⚠ **新增必装包 `PyPDF2`**：05 aCRF Update 引擎用 **PyPDF2** 读 CRF 书签（`openpyxl`
>   为既有依赖、无需重装）。故本机全局 Python 需再装 1 个包：`PyPDF2`（导入名 `PyPDF2`）。
>   并入 aCRF 装包步骤、`aCRF OK` 验证、自检 `[8/8] import` 与第六节 AI 模板。
> - 05 aCRF Update 复用 03/04 已装的 autoanno（`pymupdf` / `pdfminer.six` / `pyyaml` 及部门包
>   `autoanno_draft`），无新增其它依赖。
> - 缺 `PyPDF2` 或外部包不可达时 SPAhub 主体仍能启动、其它模块照常；**仅 aCRF · 05 aCRF Update**
>   会失败并提示。其它模式（SDTM / ADaM / TFLs / aCRF 其余步骤）不受影响。
>
> **v1.4 → v1.5 更新**（aCRF CRF Annotation 草标改本机 Python，新增 PDF 依赖）：
> - ⚠ **新增必装包**：自 SPAhub **v12.10.99** 起，aCRF · 03 CRF Annotation 的「22 Draft
>   Annotation（草标）」不再走 SAS，改为**本机 Python** 调部门 annodraft 工具包。该工具用
>   **PyMuPDF + pdfminer.six** 抽取 eCRF 坐标、用 **PyYAML** 读表单映射，故本机全局 Python
>   需新增 3 个包：`pymupdf pdfminer.six pyyaml`（`openpyxl` 为既有依赖，无需重装）。
>   装包步骤、`aCRF OK` 验证、自检 `[8/8] import` 均同步加入。
> - **部门侧前置（一次性）**：annodraft 工具包须已部署到
>   `Z:\projects\Z_PYTHON\aCRF\autoanno_draft\`（由部门管理员维护，跨项目共享）。
>   测试用户无需自行部署，但若该目录不可达，CRF Annotation 会在运行时报「annodraft 包未找到」。
> - 缺这 3 个包时 SPAhub 主体仍能启动、其它模块照常；**仅 aCRF · 03 CRF Annotation 草标**
>   会失败并提示安装。其它模式（SDTM / ADaM / TFLs / aCRF 其余步骤）不受影响。
>
> **v1.3 → v1.4 更新**（明确 Java 的唯一获取渠道）：
> - ⚠ **Java 唯一来源 = 公司软件中心（Software Center）**。机器缺 Java 时，一律到
>   软件中心搜索 "Java" 安装；**禁止从外网自行下载 JRE / JDK 安装包**（Temurin /
>   Corretto / Oracle 等一律不允许），**禁止手工配置 `JAVA_HOME` / 改 PATH 来"修"**。
> - **共享盘便携 jre 方案废弃**：`Z:\projects\Z_PYTHON\SPAhub\sas_engine\jre\` **不部署、
>   不作兜底**。`sas_engine/sascfg.py` 的 `_get_java_path()` 第一优先级会查该目录，
>   故管理员侧需保证该目录**不存在**，让探测自然兜底到系统 PATH 中软件中心安装的 java。
> - 前置清单 Java 行、Q5 排查、自检 `[9/9]` FAIL 提示、第六节 AI 模板硬约束同步改写。
>
> **v1.2 → v1.3 更新**（修复"缺 Java 仍能部署通过"的盲点）：
> - ⚠ **新增 Java/JRE 前置要求**：saspy 连 IOM 服务器（`winiomIWA`）建会话时需要
>   Java，缺 Java 时 `import saspy` 照样通过、但任何 SAS 都跑不起来。前置清单补
>   Java 一行。
> - **自检清单新增 `[9/9] SAS 会话可建` 门禁**：把原 Q5 的真连接测试提升为强制项。
>   `import saspy` 只证明包能导入、**不代表 SAS 能跑**；`[9/9]` 直接建一次会话跑
>   `proc options`，缺 Java / 服务器不可达 / 凭据问题会当场 FAIL（这正是以前漏掉、
>   导致"装包全绿但 SAS 跑不动"的地方）。AI 指令模板（第六节）同步加 `[9/9]`。
>   **该连接命令必须带 `cfgname='winiomIWA'` + `cfgfile=…\\sas_engine\\sascfg.py`，与
>   SPAhub 内部 `run_sas` 一致**；裸 `saspy.SASsession()` 会找不到配置而误报 FAIL
>   （即便本机 Java/SAS 正常）。
> - **Q5 更正**：saspy 配置文件名由 `sascfg_personal.py` 更正为
>   `C:\\Python_396\\Lib\\site-packages\\saspy\\sascfg.py`（实际由 `sas_engine/sascfg.py`
>   的 `_get_java_path()` 定位 java）。
> - **torch + transformers 由"可选"更正为"必装"**：TFL Metadata 的 Shell-to-Demo 用
>   bge 模型做语义匹配，是标准流程会用到的功能。装包步骤、`ML OK` 验证、自检 `[8/8]`
>   import、第六节 AI 模板均同步改为必装；去掉无用的 `sentence-transformers` /
>   `FlagEmbedding`（当前 shell_to_demo 用 transformers 直接加载 bge，不需要）。
>
> **v1.1 → v1.2 更新**（基于 SPA Platform v12.10.75 整体改名）：
> - 产品整体改名 **SPAhub → SPA Platform**：窗口标题、桌面快捷方式名改为 **SPA Platform**
>   （桌面图标文件由 `SPAhub.lnk` 改为 `SPA Platform.lnk`）。
> - ⚠ **程序文件夹路径与内部文件名不变**：`Z:\projects\Z_PYTHON\SPAhub\`、
>   `%LOCALAPPDATA%\SPAhub\`、`SPAhub.bat`、`spahub.ico` 一律保持原样，本指南中所有
>   这些路径 / 文件名照旧使用，**不要重命名文件夹**。改名仅影响"产品显示名 + 桌面快捷方式名"。
>
> **v1.0 → v1.1 更新**（基于 SPAhub v12.10.48 启动光标优化）：
> - 桌面快捷方式 target 从 `SPAhub.bat` 改为 `pythonw.exe + main.py`，双击后鼠标立即出现等待动画
> - 步骤 2 中 `SPAhub.bat` copy 变为**可选**（仍保留作为开发者 cmd / IDE 启动入口）
> - 步骤 3 输出格式更新；步骤 4 增加"光标动画"验证项
> - Q1 排查更新（启动链路不再依赖 SPAhub.bat）

---

## ⚠️ 重要前提：阅读须知

> **如果你打算让 ChatGPT / Claude 等 AI 助手帮你执行下面的步骤，请把这一节连同整个文档一起喂给它。**

### 1. SPAhub 不能用 venv / virtualenv / conda 环境

SPAhub 启动器写死了用 **`C:\Python_396\pythonw.exe`** 启动。
任何放在 venv 里的包它都看不见。

**所以禁止以下做法**（AI 助手常会自作主张做这些，请阻止）：

- ❌ 在 `Z:\projects\Z_PYTHON\SPAhub\` 下面建 `venv\` / `.venv\` / `env\`
- ❌ `python -m venv ...` 后在虚拟环境里 `pip install`
- ❌ 修改任何 `.bat` 让它指向虚拟环境的 python
- ❌ 在 SPAhub 文件夹里建任何新文件夹或文件
- ❌ 修改 SPAhub 文件夹里的任何 `.py` / `.bat` / `.ico` / `.png` 文件
- ❌ 在 SPAhub 下创建 `requirements.txt` 然后 pip install -r

### 2. 正确做法

- ✅ 用**全局 / 用户级**的 Python 安装：`C:\Python_396\Scripts\pip.exe install <包名>`
- ✅ 包装到 `C:\Python_396\Lib\site-packages\` （这是启动器唯一会读的地方）
- ✅ SPAhub 文件夹**只读**：不要建子目录，不要改任何文件，把它当成"应用程序文件"
- ✅ 本地可信启动器放在 `%LOCALAPPDATA%\SPAhub\`，不放在 Z 盘

### 3. 网络盘只读注意

`Z:\projects\Z_PYTHON\SPAhub\` 通常是只读共享，本来也写不进去。
如果不小心拿到了写权限并被 AI 改了文件，整个团队都会受影响。**严禁修改 SPAhub 目录内容**。

---

## 一、前置要求清单

| 条目 | 要求 | 验证命令 |
|---|---|---|
| 操作系统 | Windows 10/11 | `winver` |
| Python | **3.9.6** 安装在 `C:\Python_396\` | `dir C:\Python_396\pythonw.exe` |
| 网络盘 | `Z:\` 已挂载且可读 | `dir Z:\projects\Z_PYTHON\SPAhub` |
| SAS Enterprise Guide | 已安装（推荐 8.x） | 开始菜单可搜到 "SAS Enterprise Guide" |
| **Java / JRE** | **saspy 能找到可用 java**（连 IOM 建会话必需；缺 Java 时 `import saspy` 仍通过但 SAS 跑不起来）。**未安装时：到公司软件中心（Software Center）搜索 "Java" 安装，这是唯一允许的获取渠道** | 跑下方"唯一权威检查"命令 ↓ |

**Java / SAS 可运行性——唯一权威检查**（前置表与自检 `[9/9]` 共用这一条，全文只此一处）：

```cmd
C:\Python_396\python.exe -c "import saspy,sys; s=saspy.SASsession(cfgname='winiomIWA', cfgfile=r'Z:\projects\Z_PYTHON\SPAhub\sas_engine\sascfg.py'); log=s.submit('proc options;run;')['LOG']; s.endsas(); sys.exit(0 if 'NOTE:' in log else 1)" 2>nul && echo SAS session OK || echo FAIL: cannot run SAS - install Java from Software Center, or check server/credentials
```

- 输出 `SAS session OK` → SAS 能真正跑（Java、服务器、凭据都就绪）。
- 输出 `FAIL` → **最常见是缺 Java**（saspy 启动不了 IOM 桥）：到**软件中心安装 Java**，
  装完**重开一个 cmd**（让 PATH 生效）再跑本命令；其次服务器不可达 / 凭据问题，排查见 Q5。
  **FAIL 时不要让用户使用**。
- ❌ **禁止从外网下载 JRE/JDK 安装包、禁止手工配 `JAVA_HOME`/PATH 来绕过**——Java 的
  唯一来源是软件中心。
- 首次运行可能弹 SAS 凭据输入、或耗时几秒，属正常。

> ⚠ **命令必须带 `cfgname='winiomIWA'` 和 `cfgfile=...`，与 SPAhub 内部 `run_sas` 完全一致。**
> 别图省事改成裸 `saspy.SASsession()`——那样 saspy 找不到 `winiomIWA` 配置（会去翻
> saspy 包目录里并不存在的默认 `sascfg_personal.py`），即便本机 Java/SAS 都正常也会
> **误报 FAIL**。java 路径、IOM 主机、SSPI 全在 `sas_engine/sascfg.py` 里，必须经 `cfgfile`
> 指过去。若 SPAhub 源码不在默认 `Z:\projects\Z_PYTHON\SPAhub\`，把 `cfgfile` 路径改成
> 实际位置即可。

> ⚠ **关键提醒**：SAS Enterprise Guide 虽自带 JRE，但**不要把它当 Java 来源**——saspy
> 是否可用取决于 `sas_engine/sascfg.py` 的 `_get_java_path()` 能否定位到一个可用 java，
> 标准部署中它兜底取系统 PATH 里**软件中心安装的 java**。**只确认"装了 SAS EG"不等于
> "saspy 找得到 java"**——一律以上面这条命令为准（`where java` 之类只看 PATH，不可靠，
> 故不再作为验证手段）。共享盘 `Z:\projects\Z_PYTHON\SPAhub\sas_engine\jre\` 已废弃、
> 不部署，不要往该目录放任何 jre。

### 装 Python 包（关键步骤）

打开 cmd（**不要用 PowerShell，避免编码 / 执行策略问题**），**逐字复制**这一条命令（用清华镜像，国内网速 5-10 倍）：

```cmd
C:\Python_396\Scripts\pip.exe install -i https://pypi.tuna.tsinghua.edu.cn/simple/ PySide6 openpyxl pandas pyreadstat sas7bdat saspy pywin32 python-docx
```

**关键参数说明**：

- `-i https://pypi.tuna.tsinghua.edu.cn/simple/` — 清华大学 PyPI 镜像，**国内强烈推荐**。如果走默认 PyPI 国外源，可能要十几分钟，还容易超时
- `C:\Python_396\Scripts\pip.exe` 必须是绝对路径，**不要直接打 `pip`** —— 系统里可能有别的 Python，pip 会装到错地方
- 不要先 `cd Z:\projects\Z_PYTHON\SPAhub`，那个目录是只读的
- 不要建虚拟环境，**重要的事说三遍**：
  - 不要 `python -m venv .venv`
  - 不要 `python -m venv env`
  - 不要 conda create

#### 必装：TFL Metadata（Shell-to-Demo）语义匹配依赖 torch + transformers

SPAhub 的 **TFL Metadata** 模块里"基于 Shell DOCX 自动推断 PDT 元数据"（Shell-to-Demo）用 BGE 模型做语义匹配，依赖 **torch + transformers**。这是标准流程会用到的功能，**必须安装**（不是可选项）：

```cmd
C:\Python_396\Scripts\pip.exe install -i https://pypi.tuna.tsinghua.edu.cn/simple/ torch transformers
```

> 说明：当前版本 `shell_to_demo.py` 直接用 `transformers` 的 `AutoModel` 加载 bge-small-zh，
> 不依赖 `sentence-transformers` / `FlagEmbedding`，故无需安装这两个（旧指南里多列了，已去掉）。

**关于 torch / pytorch 是否需要去官方源**：

- 清华镜像上有 **CPU-only 的 torch**（约 200MB），SPAhub 的 NLP 用量极小（一次解析一个 docx），CPU 版本完全够用，**不需要去 download.pytorch.org**
- 只有以下情况才需要去 pytorch 官方源：
  - 你需要 GPU 加速（SPAhub 不需要）
  - 清华镜像缓存的 torch 版本和 transformers 不兼容（极罕见）
  - 万一遇到这种情况，备用命令：

    ```cmd
    C:\Python_396\Scripts\pip.exe install torch --index-url https://download.pytorch.org/whl/cpu
    ```

#### 必装：aCRF 模块本机 Python 依赖 pymupdf + pdfminer.six + pyyaml + PyPDF2

自 SPAhub **v12.10.99** 起，aCRF · 03/04 CRF Annotation 的「22 Draft Annotation（草标）」由 SAS 改为**本机 Python** 调部门 annodraft 工具包（`autoanno_study_draft`）；自 **v12.10.125** 起，aCRF 又新增 **05 aCRF Update** 步骤，其引擎用 **PyPDF2** 读 CRF 书签。这些是标准 aCRF 流程会用到的功能，**必须安装**：

```cmd
C:\Python_396\Scripts\pip.exe install -i https://pypi.tuna.tsinghua.edu.cn/simple/ pymupdf pdfminer.six pyyaml PyPDF2
```

> 说明：
> - 导入名与包名不同——`pymupdf` 导入名是 `fitz`，`pdfminer.six` 导入名是 `pdfminer`，
>   `pyyaml` 导入名是 `yaml`；`PyPDF2` 导入名就是 `PyPDF2`（验证命令里按导入名写）。
>   `openpyxl` 工具也会用到，但它是 SPAhub 既有依赖（前面已装），无需重装。
> - **部门侧前置（一次性，由管理员维护）**：aCRF 模块依赖两个外部包，均跨项目共享、
>   测试用户无需自己部署，但目录不可达时对应步骤会在运行时报「包未找到」：
>   - `Z:\projects\Z_PYTHON\aCRF\autoanno_draft\` —— 草标 / 补白工具包（03/04/05 都用）。
>   - `Z:\projects\Z_PYTHON\aCRF\acrf_update_spahub\` —— 05 aCRF Update 的引擎与逻辑包
>     （v12.10.125 新增，与 autoanno_draft 平级）。
> - 缺 `PyPDF2` **仅影响 05 aCRF Update**；缺 `pymupdf`/`pdfminer.six`/`pyyaml` **仅影响
>   03/04 CRF Annotation 草标**。都**不影响** SPAhub 启动与其它模块。

#### 验证安装

包装好之后，验证：

```cmd
C:\Python_396\python.exe -c "import PySide6, pandas, openpyxl, pyreadstat, saspy; print('Core OK')"
```

输出 `Core OK` 即核心包装对了；任何 ImportError 说明上一步有问题，重做。

验证 aCRF 依赖（必跑）：

```cmd
C:\Python_396\python.exe -c "import fitz, pdfminer, yaml, PyPDF2; print('aCRF OK')"
```

输出 `aCRF OK` 即 pymupdf / pdfminer.six / pyyaml / PyPDF2 四个包都装对了。

> ⚠ **注意**：`Core OK` 只代表 **Python 包能 import**，**不代表 SAS 能跑**。
> `import saspy` 不需要 Java——缺 Java 时这条照样输出 `Core OK`。"SAS 能不能真正
> 跑起来"必须由下方自检清单的 **`[9/9]` 连接测试**确认。

验证 torch + transformers（必跑）：

```cmd
C:\Python_396\python.exe -c "import torch, transformers; print('ML OK', torch.__version__)"
```

#### 内网无外网怎么办

让管理员从内部 PyPI 镜像（如果公司有）或离线 wheel 安装。命令模板：

```cmd
:: 内部镜像
C:\Python_396\Scripts\pip.exe install -i http://内部镜像地址/simple/ <包名> --trusted-host 内部镜像地址

:: 离线 wheel（管理员先下载到 D:\wheels\）
C:\Python_396\Scripts\pip.exe install --no-index --find-links D:\wheels\ <包名>
```

---

## 二、部署 SPAhub（5 分钟，全部 cmd 命令，零手动 GUI 操作）

> **AI 助手执行契约（必读）**
>
> 这一节的全部 4 步操作都是确定性的 cmd 命令。AI 助手必须**逐字执行**，
> **不要改写、不要"优化"、不要替代**。具体硬约束：
>
> | 不要做 | 应该做 |
> |---|---|
> | 用 PowerShell 跑命令 | 全程用 cmd（Win+R → cmd） |
> | `(echo ...) > file.bat` 自己拼 bat | `copy` 模板（步骤 2） |
> | `New-Object -ComObject WScript.Shell` 创建快捷方式 | 跑 `create_shortcut.py`（步骤 3） |
> | 在 SPAhub 文件夹里建 venv / 子目录 | Python 包全装到 `C:\Python_396\Lib\site-packages\` |
> | 修改 SPAhub 文件夹里任何文件 | SPAhub 文件夹只读，不要碰 |
> | 让用户右键属性手动改图标 | `create_shortcut.py` 自动生成正确图标 |
> | 用 `del`、`rd /s` 清理 SPAhub 残留 | 不需要，每步都是幂等的 |
>
> **核心思路：本地可信启动器方案**
>
> 直接从 Z 盘网络共享启动 `.bat` 会触发 Windows 安全警告弹窗，且 GPO 策略会阻止
> 从网络路径加载 `.ico` 图标（导致桌面图标变白纸）。
>
> 解决方案：在本地 `%LOCALAPPDATA%\SPAhub\` 下放一个**轻量启动器** `SPAhub.bat`
> 和图标 `spahub.ico`，桌面快捷方式指向这个本地启动器。整个启动链路全部在 C 盘本地：
>
> ```
> 桌面 SPA Platform.lnk → C:\...\AppData\Local\SPAhub\SPAhub.bat → C:\Python_396\pythonw.exe → Z:\...\main.py
> ```
>
> - ✅ 不弹安全警告（本地可信 bat）
> - ✅ 图标正常显示（本地可信 ico）
> - ✅ Z 盘零修改

### 步骤 1 — 验证 SPAhub 源文件存在

```cmd
dir Z:\projects\Z_PYTHON\SPAhub\main.py
dir Z:\projects\Z_PYTHON\SPAhub\resources\spahub.ico
dir Z:\projects\Z_PYTHON\SPAhub\resources\create_shortcut.py
```

上面 3 个**必需**文件都存在 → 进步骤 2。

可选验证（仅当后续步骤 2 想 copy `SPAhub.bat` 兼容入口时检查）：

```cmd
dir Z:\projects\Z_PYTHON\SPAhub\launcher.bat
dir Z:\projects\Z_PYTHON\SPAhub\resources\SPAhub_local_launcher.bat
```

任何**必需**文件 `找不到` → 联系管理员重新部署 `Z:\projects\Z_PYTHON\SPAhub\`。
**绝对不要自己尝试创建或修改这些文件**。

### 步骤 2 — 本地化图标 + 启动器（必需 + 可选）

```cmd
mkdir %LOCALAPPDATA%\SPAhub 2>nul
copy /Y Z:\projects\Z_PYTHON\SPAhub\resources\spahub.ico %LOCALAPPDATA%\SPAhub\spahub.ico
```

上面 2 条**必须**跑（图标在桌面快捷方式里用）。

> **v12.10.48 起 SPAhub.bat 改为可选**
>
> 桌面快捷方式现在直接指向 `C:\Python_396\pythonw.exe + Z:\...\main.py`，
> **不再依赖** `SPAhub.bat`。但 `SPAhub.bat` 仍保留作为开发者从 cmd 启动 /
> IDE 调试的备用入口。
>
> 如需保留 .bat 兼容入口，再跑下面这条（**可选**）：
>
> ```cmd
> copy /Y Z:\projects\Z_PYTHON\SPAhub\resources\SPAhub_local_launcher.bat %LOCALAPPDATA%\SPAhub\SPAhub.bat
> ```

验证：

```cmd
dir %LOCALAPPDATA%\SPAhub\spahub.ico
```

应该看到 ico 文件（约 40KB）。如果跑了可选的 .bat copy，再 `type %LOCALAPPDATA%\SPAhub\SPAhub.bat` 确认。

### 步骤 3 — 创建桌面快捷方式（1 条 python）

```cmd
C:\Python_396\python.exe Z:\projects\Z_PYTHON\SPAhub\resources\create_shortcut.py
```

输出长这样即成功（v12.10.48 新格式）：

```
OK: SPA Platform desktop shortcut created.
  Path:     C:\Users\<你>\Desktop\SPA Platform.lnk
  Target:   C:\Python_396\pythonw.exe
  Args:     "Z:\projects\Z_PYTHON\SPAhub\main.py"
  Icon:     C:\Users\<你>\AppData\Local\SPAhub\spahub.ico
  WorkDir:  Z:\projects\Z_PYTHON\SPAhub
  WinStyle: 1 (Normal, pythonw 无 console 窗口)

v12.10.48 优化：双击图标后鼠标右侧会显示等待动画，
直到 SPAhub splash 出现（或 5 秒超时），双击不再"看似没反应"。
```

> **这个脚本做了什么？**
>
> 用 pywin32 的 `WScript.Shell.CreateShortcut` 在桌面写入 `SPA Platform.lnk`，
> target 是本地 `pythonw.exe`，Arguments 是 Z 盘 `main.py`。
> 因为 target 是 GUI subsystem 应用（pythonw 而不是 cmd），Windows shell
> 双击时会自动显示 IDC_APPSTARTING 等待光标，体感反馈显著改善。
>
> 报错时常见原因：
> - `pywin32 not installed` → 第一节装包步骤漏了 pywin32，重跑 pip install
> - `Python not found: C:\Python_396\pythonw.exe` → Python 没装在标准位置
> - `SPAhub main.py not found: Z:\...` → Z 盘连接异常，先 `net use Z:` 重连
> - `Icon not found` → 步骤 2 的 ico copy 没成功，先回去查
> - `Desktop folder not found` → 公司把桌面重定向到 OneDrive 等异常位置，
>   联系 IT

### 步骤 4 — 首次启动验证

**AI 助手验证方式**（一条命令启动 + 一条命令查进程）：

```cmd
start "" "%USERPROFILE%\Desktop\SPA Platform.lnk"
```

等 5-15 秒（首次冷启动 .pyc 缓存），然后查进程：

```cmd
tasklist /FI "IMAGENAME eq pythonw.exe"
```

如果输出里有 `pythonw.exe` 进程在跑，说明启动成功；同时用户应该能看到 SPAhub 主窗口出现，左上角和任务栏都是 SPAhub 的 hub 图标。

**手动验证方式**（用户自己确认）：

双击桌面 `SPA Platform`：

- ✅ **双击后鼠标光标右侧立即出现旋转动画**（v12.10.48 新效果）
- **不会弹出安全警告**（target 是本地 pythonw.exe + 网络 .py 不触发 MotW）
- **首次启动 5-15 秒**（Python 在编译 `.pyc` 缓存到 `%LOCALAPPDATA%\SPAhub\pycache\`）
- **后续启动 < 3 秒**
- 看到带 SPAhub logo 的启动画面 → 主窗口出现 → 部署完成 ✅

> ⚠️ 等待光标在 5 秒后会消失（Windows 默认超时），冷态启动 splash 可能要
> 15-20 秒。这是 Defender 实时扫描每个 .py 文件的开销，不是 v12.10.48 的
> bug。如需进一步加速冷启动，让 IT 加 Defender 排除（参考诊断报告 v1.5）。

> **三种启动方式对比**（v12.10.48 起）
>
> | | 桌面 SPA Platform.lnk | 本地 SPAhub.bat | Z 盘 launcher.bat |
> |---|---|---|---|
> | 位置 | `~/Desktop/` | `%LOCALAPPDATA%\SPAhub\`（可选） | `Z:\projects\Z_PYTHON\SPAhub\` |
> | 用途 | **用户标准启动方式** | cmd / IDE 调试备用 | 开发者 / 旧方案兼容 |
> | Target 链路 | `pythonw + main.py` | `cmd → start pythonw + main.py` | 同左 |
> | 等待光标动画 | ✅ 有 | ❌ 无 | ❌ 无 |
> | 安全警告 | ✅ 不弹 | ✅ 不弹 | ⚠️ 每次弹 |
> | 图标加载 | ✅ 正常 | ✅ 正常 | ❌ GPO 拦截 |

---

## 三、常见问题与处理

### Q1：双击快捷方式没反应 / 闪了一下就关

**排查 1 — Python 路径**：

```cmd
dir C:\Python_396\pythonw.exe
```

不存在 → Python 没装在标准位置。让管理员从 `\\网络共享\Python_396` 拷一份到 `C:\` 根目录。

**排查 2 — 看 crash log**：

```cmd
type %LOCALAPPDATA%\SPAhub\logs\crash.log
```

> v12.10.47 起 crash.log 写到本地 `%LOCALAPPDATA%\SPAhub\logs\`（用户自己有写权限），
> 不再写 Z 盘。看不到这个文件说明从来没崩溃过，或 SPAhub 没启动起来过。

最近一次崩溃的 traceback 在末尾。常见错误：

- `ModuleNotFoundError: No module named 'PySide6'` → 缺包，回到第一节 **`C:\Python_396\Scripts\pip.exe install ...`** 装包（**不要建 venv！**）
- `ImportError: DLL load failed` → Python 解释器架构不匹配（32 vs 64-bit），重装 Python 3.9.6 64-bit
- `PermissionError: [WinError 5]` → 个别工作目录写权限不足，让管理员授权或换工作目录

**排查 3 — 用 python.exe 跑 main.py 看错误**：

桌面快捷方式用的是 `pythonw.exe`（无 console 模式），即使 main.py 报错也看不到任何输出。要排错请用 `python.exe`（带 console）直接跑：

```cmd
cd /d Z:\projects\Z_PYTHON\SPAhub
C:\Python_396\python.exe main.py
```

任何 Python 错误都会显示在 cmd 终端里。看到 traceback 就能定位是缺包、import 错、还是路径问题。

**排查 4 — 快捷方式 target 是否正确**（v12.10.48 改动后）：

```cmd
:: 看快捷方式的 target / args 是不是新版
powershell -NoProfile -Command "(New-Object -ComObject WScript.Shell).CreateShortcut('%USERPROFILE%\Desktop\SPA Platform.lnk') | Select TargetPath, Arguments | Format-List"
```

新版正确输出：
```
TargetPath : C:\Python_396\pythonw.exe
Arguments  : "Z:\projects\Z_PYTHON\SPAhub\main.py"
```

如果还是旧的（target = SPAhub.bat），跑步骤 3 重新生成快捷方式。

**排查 5 — Z 盘可达**（v12.10.48 起快捷方式直读 Z 盘 main.py）：

```cmd
dir Z:\projects\Z_PYTHON\SPAhub\main.py
```

如果 `找不到` → Z 盘未挂载，跑 `net use Z:` 重连后再双击桌面图标。

### Q2：桌面图标显示成白纸

**原因**：快捷方式的图标路径指向了 Z 盘网络路径（GPO 拦截），或本地 ico 文件丢失。

**全自动修复**（一条命令重跑即可）：

```cmd
copy /Y Z:\projects\Z_PYTHON\SPAhub\resources\spahub.ico %LOCALAPPDATA%\SPAhub\spahub.ico
C:\Python_396\python.exe Z:\projects\Z_PYTHON\SPAhub\resources\create_shortcut.py
```

第 1 行确保本地 ico 在；第 2 行重新生成快捷方式（自动覆盖旧的，并把 IconLocation 指向本地 ico）。

如果跑完图标还是白纸：

```cmd
dir %LOCALAPPDATA%\SPAhub\spahub.ico
```

不存在 → step 2 的 copy 没成功，可能 Z 盘断连或权限问题，先 `dir Z:\projects\Z_PYTHON\SPAhub\resources\spahub.ico` 验证源文件，再回到 step 2。

### Q3：任务栏图标显示成 python 蛇头

**症状**：SPAhub 窗口标题栏左上角和任务栏图标都是 Python 默认图标。

**原因**：v12.10.41 之前的旧版本没有 AppUserModelID 修复。

**解决方案**：让管理员把 `Z:\projects\Z_PYTHON\SPAhub\` 升级到 v12.10.41 或更新版本。

### Q4：PowerShell 报错

**症状**：脚本无法加载 / 中文 ParserError / cp936 编码问题。

**解决方案**：**永远用 cmd，不用 PowerShell**。本文档所有命令都给的 cmd 写法。

### Q5：模块运行时报 saspy 相关错误，或 `[9/9]` 连接测试 FAIL

**排查**（这条就是自检的 `[9/9]`，可单独跑）：

```cmd
C:\Python_396\python.exe -c "import saspy; sas=saspy.SASsession(cfgname='winiomIWA', cfgfile=r'Z:\projects\Z_PYTHON\SPAhub\sas_engine\sascfg.py'); print(sas.submit('proc options;run;')['LOG'][:500])"
```

- **`SASsession()` 直接报错 / 找不到 java / 卡住起不来** → 最常见是**缺 Java**。saspy 连
  IOM（`winiomIWA`）要靠 `sas_engine/sascfg.py` 的 `_get_java_path()` 定位一个可用 java；
  机器上没有可达的 Java 就会失败。**唯一处置方式：到公司软件中心（Software Center）
  搜索 "Java" 安装**，装完**重开一个 cmd**（让 PATH 生效）再重跑本命令。
  - ❌ 禁止从外网下载任何 JRE/JDK 安装包（Temurin / Corretto / Oracle 等一律不允许）；
  - ❌ 禁止手工配置 `JAVA_HOME` 或改 PATH 指向其它 java；
  - ❌ 禁止往 `Z:\projects\Z_PYTHON\SPAhub\sas_engine\jre\` 放便携 jre（该方案已废弃）。
- **能连上但日志异常 / 提交报错** → 服务器或凭据问题，联系 SAS 管理员。

saspy 配置文件在 `C:\Python_396\Lib\site-packages\saspy\sascfg.py`（项目侧由
`sas_engine/sascfg.py` 提供，内含 `_get_java_path()` 的 java 探测逻辑）。

> 提示：自 SPAhub v12.10.61 起，缺 Java（或任何"SAS 没真正跑"）时，模块运行结果会
> 明确显示**红色"SAS 未返回有效日志"**而不再误报成功——若你看到这条红字，按上面
> 排查 Java 即可。

### Q6：TOC 扫描显示"部分前置字典文件未找到"

```cmd
dir Z:\projects\<protocol>\<study>\<csr>\utility\metadata\edcdef_*.sas7bdat
```

5 个文件都得在：`edcdef_casebook / edcdef_code / edcdef_ecrf / edcdef_embedded / edcdef_visit`。

缺失 → 数据管理负责人没把 EDC 字典 dump 到该目录。

### Q7：跑 PDT / Batch Run 时卡死

`🟥 中止` 按钮点一下，5 秒内必恢复 UI（v12.10.38+ 的 taskkill /T 修复）。

### Q8：TOC 模块右侧日志出现 "⚠️ 检测到 TX.Type 列中含非预设阶段值"

例如显示 `⚠️ ... 含非预设阶段值：安全性分析 / 前导期`。

**说明**：你的项目 TDM 的 TX.Type 列里有不在 `{SAD, MAD, FE, BE, MB}` 里的文案。SPAhub 不会自动把它当成研究阶段，但会保留其他正常识别到的阶段（比如 `SAD`、`FE`）。

**操作**：人工到 **问题1** 里确认勾选是否正确（系统会自动勾选已识别到的部分，未识别的不会自动勾选）。

---

## 四、菜单的反馈通道

主界面右键 → `📂 打开 SPAhub 日志目录` 会直接打开本地日志目录 `%LOCALAPPDATA%\SPAhub\logs\`。

`crash.log` 文件位于该目录，记录所有未捕获异常的 traceback。v12.10.47 起 crash.log 和反馈邮件的附件采集都走**本地路径**，不依赖 Z 盘写权限，普通测试用户也能正常使用。

反馈邮件功能（主界面右键 → `🐛 反馈问题`）会：
1. 自动读取 `%LOCALAPPDATA%\SPAhub\logs\crash.log` 末尾 200KB 内容
2. 调 Outlook COM 创建邮件，收件人 = 开发者，主题 / 正文已填好
3. 显示邮件供用户审阅，**不自动发送**

---

## 五、一键自检清单

复制下面命令到 **cmd**（不是 PowerShell）一次性跑完：

```cmd
@echo off
if exist "C:\Python_396\pythonw.exe" (echo [1/8] Python OK) else (echo [1/8] FAIL: Python missing)
if exist "Z:\projects\Z_PYTHON\SPAhub\main.py" (echo [2/8] SPAhub source OK) else (echo [2/8] FAIL: SPAhub source missing)
if exist "Z:\projects\Z_PYTHON\SPAhub\resources\create_shortcut.py" (echo [3/8] Helper OK) else (echo [3/8] FAIL: create_shortcut.py missing)
if exist "Z:\projects\Z_PYTHON\SPAhub\resources\spahub.ico" (echo [4/8] Source icon OK) else (echo [4/8] FAIL: source icon missing)
if exist "%LOCALAPPDATA%\SPAhub\SPAhub.bat" (echo [5/8] Local launcher OK - optional, for cmd/IDE compat) else (echo [5/8] SKIP: Local SPAhub.bat absent - OK since v12.10.48, only needed if you start from cmd)
if exist "%LOCALAPPDATA%\SPAhub\spahub.ico" (echo [6/8] Local icon OK) else (echo [6/8] FAIL: local icon missing - run step 2)
if exist "%USERPROFILE%\Desktop\SPA Platform.lnk" (echo [7/8] Shortcut OK) else (echo [7/8] FAIL: desktop shortcut missing - run step 3)
C:\Python_396\python.exe -c "import PySide6, pandas, openpyxl, pyreadstat, saspy, torch, transformers, fitz, pdfminer, yaml, PyPDF2" 2>nul && echo [8/8] Python packages OK || echo [8/8] FAIL: missing packages, run pip install command
C:\Python_396\python.exe -c "import saspy,sys; s=saspy.SASsession(cfgname='winiomIWA', cfgfile=r'Z:\projects\Z_PYTHON\SPAhub\sas_engine\sascfg.py'); log=s.submit('proc options;run;')['LOG']; s.endsas(); sys.exit(0 if 'NOTE:' in log else 1)" 2>nul && echo [9/9] SAS session OK || echo [9/9] FAIL: cannot run SAS - install Java from Software Center, or check server/credentials
```

`[1/8]`~`[7/8]` 中 7 个 OK（`[5/8]` 可 SKIP，是 v12.10.48 起的兼容性选项）、
`[8/8] Packages OK`、且 **`[9/9] SAS session OK`** 才算部署完成。

> ⚠ **`[9/9]` 是决定性的一项**（即前置要求里的"唯一权威检查"，同一条命令，全文只此一种）：它真的去建一次 SAS 会话并跑 `proc options`。
> - FAIL 最常见是 **缺 Java**（saspy 启动不了 IOM 桥）：到**软件中心安装 Java**，
>   重开 cmd 后再跑；**禁止从外网下载 JRE/JDK**。其次是服务器不可达 / 凭据问题。
> - 这条 FAIL 时**不要让用户用**——前面 8 项即便全绿，也只是"程序能起、包能导入"，
>   SAS 实际跑不动。缺 Java 的排查见 Q5。
> - 首次运行可能弹 SAS 凭据输入、或耗时几秒，属正常。

---

## 六、给 AI 助手的指令模板（推荐 AI 直接执行）

把下面这段贴给 AI（ChatGPT / Claude 等）：

> 我要在 Windows 10/11 上部署一个叫 SPA Platform 的 Python 桌面工具（程序文件夹仍叫 SPAhub）。SPAhub 源码位于 `Z:\projects\Z_PYTHON\SPAhub\`，是只读的网络共享。请用 cmd（**不是 PowerShell**）按顺序执行下面的命令，**不要自己改写命令、不要用 GUI 操作、不要用 PowerShell 自己拼快捷方式**。
>
> **硬约束**：
> - ❌ 不要在 SPAhub 文件夹里建 venv / 子目录 / 任何文件
> - ❌ 不要修改 SPAhub 文件夹里任何文件
> - ❌ 不要用 PowerShell（cmd 语法和 PS 语法在某些命令上冲突）
> - ❌ 不要用 `(echo ...) > file.bat` 拼 bat（用 copy 模板）
> - ❌ 不要用 `New-Object -ComObject WScript.Shell` 创建快捷方式（用 create_shortcut.py）
> - ❌ **检测到缺 Java 时，不要提供任何下载链接 / 安装包来源 / 手动配置 `JAVA_HOME` 或
>   改 PATH 的方案，也不要往共享盘放便携 jre——只能提示我"到公司软件中心（Software
>   Center）搜索 Java 安装，装完重开 cmd 重跑检查"**
> - ✅ 全程用 `C:\Python_396\Scripts\pip.exe` 和 `C:\Python_396\python.exe` 绝对路径
>
> **第一步：装包**（一条命令，清华镜像）
>
> ```
> C:\Python_396\Scripts\pip.exe install -i https://pypi.tuna.tsinghua.edu.cn/simple/ PySide6 openpyxl pandas pyreadstat sas7bdat saspy pywin32 python-docx
> ```
>
> 接着装 TFL Metadata（Shell-to-Demo）必需的 torch + transformers（标准流程会用到，必装）：
>
> ```
> C:\Python_396\Scripts\pip.exe install -i https://pypi.tuna.tsinghua.edu.cn/simple/ torch transformers
> ```
>
> 不需要 sentence-transformers / FlagEmbedding（当前 shell_to_demo 用 transformers 直接加载 bge）。
>
> 再装 aCRF 模块必需的 pymupdf + pdfminer.six + pyyaml + PyPDF2（v12.10.99 起草标走本机 Python、v12.10.125 起新增 05 aCRF Update，必装）：
>
> ```
> C:\Python_396\Scripts\pip.exe install -i https://pypi.tuna.tsinghua.edu.cn/simple/ pymupdf pdfminer.six pyyaml PyPDF2
> ```
>
> 导入名分别是 fitz / pdfminer / yaml / PyPDF2（验证：`import fitz, pdfminer, yaml, PyPDF2`）。部门外部包须已部署到 `Z:\projects\Z_PYTHON\aCRF\autoanno_draft\`（草标/补白，03/04/05 用）与 `Z:\projects\Z_PYTHON\aCRF\acrf_update_spahub\`（05 aCRF Update 引擎，v12.10.125 起）——均管理员侧一次性维护。
>
> **第二步：本地化图标 + 可选启动器**（2 条必需 + 1 条可选）
>
> ```
> mkdir %LOCALAPPDATA%\SPAhub 2>nul
> copy /Y Z:\projects\Z_PYTHON\SPAhub\resources\spahub.ico %LOCALAPPDATA%\SPAhub\spahub.ico
> ```
>
> 上面 2 条必须跑。下面这条**可选**（仅需要 cmd / IDE 启动入口时跑）：
>
> ```
> copy /Y Z:\projects\Z_PYTHON\SPAhub\resources\SPAhub_local_launcher.bat %LOCALAPPDATA%\SPAhub\SPAhub.bat
> ```
>
> v12.10.48 起桌面快捷方式直接调用 pythonw.exe，**不再依赖 SPAhub.bat**。
>
> **第三步：创建桌面快捷方式**（一条命令）
>
> ```
> C:\Python_396\python.exe Z:\projects\Z_PYTHON\SPAhub\resources\create_shortcut.py
> ```
>
> 输出 `OK: SPA Platform desktop shortcut created.` + Target = `C:\Python_396\pythonw.exe` 就成功了。
>
> **第四步：自检**（一段 cmd，应输出 7 个 OK + 1 个 SKIP/OK）
>
> ```
> @echo off
> if exist "C:\Python_396\pythonw.exe" (echo [1/8] Python OK) else (echo [1/8] FAIL)
> if exist "Z:\projects\Z_PYTHON\SPAhub\main.py" (echo [2/8] Source OK) else (echo [2/8] FAIL)
> if exist "Z:\projects\Z_PYTHON\SPAhub\resources\create_shortcut.py" (echo [3/8] Helper OK) else (echo [3/8] FAIL)
> if exist "Z:\projects\Z_PYTHON\SPAhub\resources\spahub.ico" (echo [4/8] Source icon OK) else (echo [4/8] FAIL)
> if exist "%LOCALAPPDATA%\SPAhub\SPAhub.bat" (echo [5/8] Local launcher OK - optional^) else (echo [5/8] SKIP: SPAhub.bat absent OK since v12.10.48^)
> if exist "%LOCALAPPDATA%\SPAhub\spahub.ico" (echo [6/8] Local icon OK) else (echo [6/8] FAIL)
> if exist "%USERPROFILE%\Desktop\SPA Platform.lnk" (echo [7/8] Shortcut OK) else (echo [7/8] FAIL)
> C:\Python_396\python.exe -c "import PySide6, pandas, openpyxl, pyreadstat, saspy, torch, transformers, fitz, pdfminer, yaml, PyPDF2" 2>nul && echo [8/8] Packages OK || echo [8/8] FAIL
> C:\Python_396\python.exe -c "import saspy,sys; s=saspy.SASsession(cfgname='winiomIWA', cfgfile=r'Z:\projects\Z_PYTHON\SPAhub\sas_engine\sascfg.py'); log=s.submit('proc options;run;')['LOG']; s.endsas(); sys.exit(0 if 'NOTE:' in log else 1)" 2>nul && echo [9/9] SAS session OK || echo [9/9] FAIL: cannot run SAS - install Java from Software Center, or check server/credentials
> ```
>
> 7 个 OK + 1 个 SKIP/OK + **`[9/9] SAS session OK`** 才算部署完成。`[9/9]` FAIL（多半缺
> Java）时**不要让用户用**——前 8 项全绿只代表程序能起、包能导入，SAS 实际跑不动。
> 缺 Java 的**唯一处置**是提示用户到软件中心安装 Java（重开 cmd 后重跑 `[9/9]`），
> **不要给下载链接、不要配 `JAVA_HOME`**。
> 确认 `[9/9]` 通过后，再让用户双击桌面 SPA Platform 图标启动。
> **预期效果**：双击后鼠标光标右侧出现旋转动画（v12.10.48 新增），随后看到 SPAhub splash。

---

**有疑问联系开发者：peilin.liu.pl71@hengrui.com**
                            