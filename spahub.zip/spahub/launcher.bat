@echo off
REM ============================================================================
REM SPAhub launcher.bat
REM ============================================================================
REM Place this in SPAhub project root (next to main.py).
REM Desktop shortcut points to this file.
REM
REM What it does:
REM   1. Redirect .pyc cache to user-local %LOCALAPPDATA% to avoid Z:\ multi-user
REM      __pycache__ races / permission issues
REM   2. Launch main.py via pythonw.exe (no console window)
REM   3. Working directory is set to this .bat's folder (SPAhub project root)

set "PYTHONPYCACHEPREFIX=%LOCALAPPDATA%\SPAhub\pycache"

REM v12.10.48: skip user site-packages scan — shaves ~50ms off cold start
REM (SPAhub only uses C:\Python_396\Lib\site-packages, never per-user site)
set "PYTHONNOUSERSITE=1"

REM TFL_metadata is in a sibling folder - add to PYTHONPATH as a safety net
REM (main.py also does sys.path.insert internally; this is just backup)
set "PYTHONPATH=%~dp0;%~dp0..\TFL_metadata"

cd /d "%~dp0"

REM pythonw.exe = windowless Python (for GUI apps)
start "" "C:\Python_396\pythonw.exe" "%~dp0main.py"
