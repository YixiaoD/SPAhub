# -*- coding: utf-8 -*-
"""
gui/tfls_stepper.py
===================
TFLs 五步导航器（01 PDT Gen / 02 Metadata Setup / 03 Initial PGM /
                04 Batch Run / 05 TFLs Combine）。

职责：
- 顶部步骤栏（可点击切换，运行中显示 ⏳，完成后显示 ✅ / ⚠️ / ❌ / 🟥）
- 左侧：承载各模块的业务表单（PDTForm / MetadataForm / InitPgmForm / ...）
- 右侧：每个模块独立的运行日志面板（含 归档 / 合并日志 / 导出日志 按钮）
- 信号总线：将各模块 Form 的 sig_log / sig_status / sig_step_update
          / sig_run_started 统一路由到对应右侧日志面板
- 四下拉框未齐全时：广播 set_wait_hint(True)，让各 Form 显示左上角等待提示
- 提供运行耗时计时（sig_run_started → on_execute_finished）
- 提供每个日志面板的"导出为 .txt"功能
"""
import os
import time
from datetime import datetime

from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                               QStackedWidget, QTextEdit, QFrame, QFileDialog, QCheckBox,
                               QTabWidget)
from PySide6.QtCore import Qt, QTimer, QThread, Signal
from PySide6.QtGui import QTextOption

from modules.tfls_pdt import PDTForm
from modules.tfls_metadata import MetadataForm
from modules.tfls_init_pgm import InitPgmForm
# v12.10.31：Initial PGM 右侧 Tab 2（Git 暂存面板）
from modules.tfls_init_pgm_gitlab import GitStashPanel
from ui_utils import show_dialog, scan_status_lbl_style, log_textedit_style, ChevronStepBar, StepProxy
from gui.log_search import attach_log_search  # v12.10.102：日志框内 Ctrl+F 搜索

try:
    from modules.tfls_batch_run import BatchRunForm
except ImportError:
    BatchRunForm = None

try:
    from modules.tfls_combine import TFLsCombineForm
except ImportError:
    TFLsCombineForm = None


# ============================================================================
# 后台刷新工作线程
# ============================================================================
class _RefreshWorker(QThread):
    """
    刷新源文件时在子线程中调用模块的 update_paths()。

    使用场景：Metadata Setup 需读 setup.xlsx 做宏变量解析，
              在主线程执行会导致 UI 卡顿，因此移到子线程。
    对于仅检验路径存在性的模块（PDT Gen / Initial PGM / Batch Run / Combine），
    同步调用即可，但统一走本线程也无害。
    """
    finished = Signal(str)

    def __init__(self, step_name, refresh_func):
        super().__init__()
        self.step_name = step_name
        self._refresh_func = refresh_func

    def run(self):
        try:
            self._refresh_func()
        finally:
            # 成功或失败都必须 emit，否则 UI 会卡在"正在刷新..."
            self.finished.emit(self.step_name)


# ============================================================================
# TFLsWidget 主类
# ============================================================================
class TFLsWidget(QWidget):
    """TFLs 五步导航容器：步骤栏 + 左右分栏"""

    # ----------------------------- 初始化 -----------------------------
    def __init__(self):
        super().__init__()
        self.base_path = ""
        self.p3 = ""
        self.p4 = ""

        # 步骤清单（顺序决定步骤栏展示顺序）
        self.steps = ["PDT Gen", "Metadata Setup", "Initial PGM", "Batch Run", "TFLs Combine"]
        self.step_original_texts = {step: f"0{i + 1} {step}" for i, step in enumerate(self.steps)}

        # 步骤 → UI 控件 / 状态 的映射表
        self.step_btns = {}          # 步骤栏按钮
        self.log_texts = {}          # 右侧日志 QTextEdit
        self.log_status_lbls = {}    # 右侧底部状态 QLabel
        self.archive_btns = {}       # 右侧 "📂 归档路径" 按钮
        self.log_action_btns = {}    # 右侧 "📄 打开合并日志" 按钮（Initial PGM 专用）
        self.export_btns = {}        # 右侧 "📋 导出日志" 按钮
        # v12.10.11：Log/Compare Check 完成后显示的两个文件夹按钮（Batch Run 专用）
        self.check_logs_btns = {}    # "📂 07_logs"
        self.check_doc_btns = {}     # "📂 utility/documentation"
        # v12.10.13：日志过滤功能 — 每步独立维护原始日志条目 + 三级过滤状态
        # _log_entries[step] = [(level, msg), ...]    level: "NOTE"/"WARNING"/"ERROR"
        # _log_filters[step] = {"NOTE": bool, "WARNING": bool, "ERROR": bool}
        self._log_entries = {}
        self._log_filters = {}
        self._log_filter_chks = {}   # step -> dict(level -> QCheckBox)

        # 运行耗时跟踪：步骤 → {"start": ts}
        self._run_start_times = {}
        # 耗时缓存：步骤 → 上次写入 QLabel 的文本（避免重复 setText 触发布局重算）
        self._elapsed_label_cache = {}

        # 耗时刷新定时器：运行中每 2s 更新状态标签尾部的"(耗时: Xs)"
        self._elapsed_timer = QTimer(self)
        self._elapsed_timer.setInterval(2000)
        self._elapsed_timer.timeout.connect(self._tick_running_elapsed)

        self._setup_ui()
        self._connect_components()

    # ------------------------- UI 构造 -------------------------
    def _setup_ui(self):
        """搭建顶部步骤栏 + 左右分栏布局"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # --- 顶部步骤栏 ---
        stepper_frame = QFrame()
        stepper_frame.setStyleSheet("background-color: #FFFFFF; border: 1px solid #E4E7ED; border-radius: 6px;")
        stepper_layout = QHBoxLayout(stepper_frame)
        stepper_layout.setContentsMargins(10, 8, 10, 8)

        # v12.10.90：步骤栏改 chevron 箭头管道（方案B）。点击任一段切换步骤、整块显色。
        self.step_bar = ChevronStepBar(self.steps, self.step_original_texts)
        self.step_bar.step_clicked.connect(self.switch_step)
        stepper_layout.addWidget(self.step_bar)
        # 兼容：旧代码 self.step_btns[step].setText/.setChecked 经 StepProxy 转发到 step_bar
        self.step_btns = {s: StepProxy(self.step_bar, s) for s in self.steps}

        layout.addWidget(stepper_frame)
        layout.addSpacing(10)

        # --- 左右分栏 ---
        from PySide6.QtWidgets import QSplitter
        self.splitter = QSplitter(Qt.Horizontal)
        self.splitter.setStyleSheet("QSplitter::handle { background-color: #EBEEF5; width: 4px; }")

        self.left_stack = QStackedWidget()
        self.right_stack = QStackedWidget()
        self.right_stack.setStyleSheet("background-color: #FFFFFF; border: 1px solid #E4E7ED; border-radius: 6px;")

        self.splitter.addWidget(self.left_stack)
        self.splitter.addWidget(self.right_stack)
        self.splitter.setStretchFactor(0, 4)
        self.splitter.setStretchFactor(1, 6)
        layout.addWidget(self.splitter, 1)

        # --- 各模块表单（左侧）+ 对应日志面板（右侧）---
        self.pdt_form = PDTForm()
        self.meta_form = MetadataForm()
        self.init_pgm_form = InitPgmForm()

        self.left_stack.addWidget(self.pdt_form)
        self.right_stack.addWidget(self._create_right_log_panel("PDT Gen"))

        self.left_stack.addWidget(self.meta_form)
        self.right_stack.addWidget(self._create_right_log_panel("Metadata Setup"))

        self.left_stack.addWidget(self.init_pgm_form)
        # v12.10.31：Initial PGM 右侧改为 QTabWidget。Tab1 = 原日志面板（不动逻辑、
        # _create_right_log_panel 仍负责创建 + 把 QTextEdit 注册到 self.log_texts），
        # Tab2 = GitStashPanel（独立组件）。其余 step 的右侧保持单 QFrame，不受影响。
        self.right_stack.addWidget(self._build_initial_pgm_right_tabs())

        if BatchRunForm:
            self.batch_run_form = BatchRunForm()
            self.left_stack.addWidget(self.batch_run_form)
            self.right_stack.addWidget(self._create_right_log_panel("Batch Run"))
            start_idx = 4
        else:
            start_idx = 3

        if TFLsCombineForm and "TFLs Combine" in self.steps[start_idx:]:
            self.tfls_combine_form = TFLsCombineForm()
            self.left_stack.addWidget(self.tfls_combine_form)
            self.right_stack.addWidget(self._create_right_log_panel("TFLs Combine"))
            start_idx += 1

        # 未实现的模块占位
        for step in self.steps[start_idx:]:
            w = QWidget()
            l = QVBoxLayout(w)
            lbl = QLabel(f"【{step}】独立组件开发中...")
            lbl.setAlignment(Qt.AlignCenter)
            lbl.setStyleSheet("color: #909399; font-size: 16px;")
            l.addWidget(lbl)
            self.left_stack.addWidget(w)
            self.right_stack.addWidget(self._create_right_log_panel(step))

        self.switch_step("PDT Gen")

    def _build_initial_pgm_right_tabs(self):
        """
        v12.10.31：Initial PGM 步骤的右侧面板 = QTabWidget。

        Tab 1: 📄 运行日志（复用 _create_right_log_panel("Initial PGM") — 完全等价于
               其它 step，所以 sig_log / status / filter / 计时器全部自动兼容）
        Tab 2: 🔀 Git 暂存（GitStashPanel — 由 init_pgm_form 通过 sig_gitlab_*
               信号驱动）

        放在这个方法里、而不是直接写在 _setup_ui 里，是为了把"特殊面板的构造"
        与"通用步骤注册"两件事解耦，方便后续 ADaM stepper 复用时只挑日志 tab。
        """
        tabs = QTabWidget()
        tabs.setStyleSheet(
            "QTabWidget::pane { border: 1px solid #E4E7ED; border-radius: 6px; "
            "background-color: #FFFFFF; top: -1px; }"
            "QTabBar::tab { background: #F5F7FA; color: #606266; "
            "padding: 6px 16px; margin-right: 2px; "
            "border: 1px solid #E4E7ED; border-bottom: none; "
            "border-top-left-radius: 4px; border-top-right-radius: 4px; }"
            "QTabBar::tab:selected { background: #FFFFFF; color: #409EFF; "
            "font-weight: bold; }"
            "QTabBar::tab:hover:!selected { background: #ECF5FF; }"
        )

        # Tab 1：原通用日志面板（继续注册到 self.log_texts["Initial PGM"]）
        log_panel = self._create_right_log_panel("Initial PGM")
        tabs.addTab(log_panel, "📄 运行日志")

        # Tab 2：Git 暂存面板
        self.gitlab_stash_panel = GitStashPanel()
        tabs.addTab(self.gitlab_stash_panel, "🔀 Git 暂存")

        # 保留 tabs 引用，方便失败时自动切换到 Tab 2
        self._initial_pgm_tabs = tabs
        return tabs

    def _create_right_log_panel(self, step_name):
        """为指定步骤创建右侧日志面板（标题栏 + 日志文本 + 状态标签）"""
        rw = QFrame()
        rl = QVBoxLayout(rw)
        rl.setContentsMargins(10, 10, 10, 10)

        # 标题栏：📄 XX 运行日志 + 右侧按钮簇
        log_header = QHBoxLayout()
        title_lbl = QLabel(f"📄 {step_name} 运行日志")
        title_lbl.setStyleSheet("font-size: 13px; font-weight: bold; color: #606266; border: none;")
        log_header.addWidget(title_lbl)
        log_header.addStretch()

        btn_container = QHBoxLayout()
        btn_container.setSpacing(8)

        # [归档路径] 按钮 —— 仅 PDT Gen 触发历史归档时会显示
        arc_btn = QPushButton("📂 归档路径")
        arc_btn.setStyleSheet("""
            QPushButton { background-color: #FEF0F0; color: #F56C6C; border: 1px solid #FBC4C4; padding: 4px 10px; border-radius: 4px; font-size:12px;}
            QPushButton:hover { background-color: #F56C6C; color: #FFFFFF; }
        """)
        arc_btn.setVisible(False)
        self.archive_btns[step_name] = arc_btn
        btn_container.addWidget(arc_btn)

        # [自定义动作] 按钮 —— Initial PGM 用它承载"打开合并日志"
        act_btn = QPushButton()
        act_btn.setStyleSheet("""
            QPushButton { background-color: #F0F2F5; color: #606266; border: 1px solid #DCDFE6; padding: 4px 10px; border-radius: 4px; font-size:12px; font-weight:bold;}
            QPushButton:hover { background-color: #E4E7ED; }
        """)
        act_btn.setVisible(False)
        self.log_action_btns[step_name] = act_btn
        btn_container.addWidget(act_btn)

        # v12.10.12：原右上角的「📂 07_logs」+「📂 utility/documentation」按钮已迁移到
        # batch_run_form 左侧 footer（紧邻"运行 Log/Compare Check"按钮），
        # 因为用户反馈右上角离运行按钮太远，且名字应该叫 "Log/Compare Check Results"。
        # 这里保留 check_logs_btns / check_doc_btns 字典定义为空，避免 update_path 中
        # 引用 KeyError。

        # [导出日志] 按钮 —— 所有步骤通用
        exp_btn = QPushButton("📋 导出日志")
        exp_btn.setStyleSheet("""
            QPushButton { background-color: #ECF5FF; color: #409EFF; border: 1px solid #B3D8FF; padding: 4px 10px; border-radius: 4px; font-size:12px; font-weight:bold;}
            QPushButton:hover { background-color: #409EFF; color: #FFFFFF; }
        """)
        exp_btn.clicked.connect(lambda checked, s=step_name: self._export_log(s))
        self.export_btns[step_name] = exp_btn
        btn_container.addWidget(exp_btn)

        log_header.addLayout(btn_container)
        rl.addLayout(log_header)

        # v12.10.13：过滤行（单独一行 — 不与按钮区混用）
        # 仅 3 个 toggle，灰色细字，不抢眼；默认全选
        filter_row = QHBoxLayout()
        filter_row.setContentsMargins(0, 0, 0, 4)
        filter_lbl = QLabel("过滤：")
        filter_lbl.setStyleSheet("color: #909399; font-size: 11px; border: none;")
        filter_row.addWidget(filter_lbl)

        # v12.10.108：筛选语义改为「正向选择」——两框默认不勾选 = 全展示；
        # 勾 WARNING 只看 WARNING，勾 ERROR 只看 ERROR（NOTE 不进筛选）。
        self._log_filters[step_name] = {"WARNING": False, "ERROR": False}
        self._log_filter_chks[step_name] = {}

        for level, label, color in [
            ("WARNING", "⚠ WARNING", "#E6A23C"),
            ("ERROR", "❌ ERROR", "#F56C6C"),
        ]:
            chk = QCheckBox(label)
            chk.setChecked(False)
            chk.setStyleSheet(
                f"QCheckBox {{ color: {color}; font-size: 11px; border: none; spacing: 4px; }}"
                f"QCheckBox::indicator {{ width: 12px; height: 12px; border: 1px solid #DCDFE6; border-radius: 2px; background-color: #FFFFFF; }}"
                f"QCheckBox::indicator:hover {{ border: 1px solid {color}; }}"
                f"QCheckBox::indicator:checked {{ background-color: {color}; border: 1px solid {color}; }}"
            )
            chk.toggled.connect(
                lambda checked, s=step_name, lv=level: self._on_log_filter_toggled(s, lv, checked)
            )
            self._log_filter_chks[step_name][level] = chk
            filter_row.addWidget(chk)

        filter_row.addStretch()
        rl.addLayout(filter_row)

        # 日志文本区
        txt = QTextEdit()
        txt.setReadOnly(True)
        attach_log_search(txt)  # v12.10.102：日志框内 Ctrl+F 搜索
        # v11.4：强制按部件宽度自动换行，超长行不撑出横向滚动条；
        # ScrollBarAlwaysOff 关闭横向滚动条，避免极长 batch= 字符串把右栏视觉撑爆
        txt.setLineWrapMode(QTextEdit.WidgetWidth)
        txt.setWordWrapMode(QTextOption.WrapAnywhere)
        txt.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        txt.setStyleSheet(
            log_textedit_style(with_padding=True))
        rl.addWidget(txt)

        # 底部状态标签
        stat = QLabel("就绪")
        stat.setAlignment(Qt.AlignCenter)
        stat.setStyleSheet("font-size: 13px; font-weight: bold; color: #909399; padding-top: 5px;")
        rl.addWidget(stat)

        self.log_texts[step_name] = txt
        self.log_status_lbls[step_name] = stat
        return rw

    def _clear_log_for_step(self, step):
        """v12.10.13：清空指定 step 的日志面板（同时清原始条目存储 — 避免过滤切换时残留）。"""
        txt = self.log_texts.get(step)
        if txt is not None:
            txt.clear()
        self._log_entries[step] = []

    # ------------------------- 日志辅助 -------------------------
    @staticmethod
    def _classify_msg_level(msg):
        """v12.10.13：按 HTML 颜色 / 关键字推断日志条目级别。"""
        if not msg:
            return "NOTE"
        upper = msg.upper()
        # 红色 / ❌ / ERROR → ERROR
        if "#F56C6C" in msg or "❌" in msg or " ERROR" in upper or upper.startswith("ERROR") or "ERROR:" in upper:
            return "ERROR"
        # 黄色 / ⚠ / WARNING → WARNING
        if "#E6A23C" in msg or "⚠" in msg or "WARNING" in upper:
            return "WARNING"
        return "NOTE"

    def _should_show(self, step, level):
        """v12.10.108：正向筛选。无勾选 → 全展示；有勾选 → 仅展示被勾选的级别。"""
        f = self._log_filters.get(step, {})
        active = [lv for lv in ("WARNING", "ERROR") if f.get(lv)]
        if not active:
            return True
        return level in active

    def _append_and_scroll(self, step, msg):
        """追加日志行并滚到底部（v12.10.13：先存原始条目 + 按过滤决定是否渲染）"""
        level = self._classify_msg_level(msg)
        self._log_entries.setdefault(step, []).append((level, msg))
        if not self._should_show(step, level):
            return
        txt_widget = self.log_texts[step]
        txt_widget.append(msg)
        QTimer.singleShot(10, lambda: txt_widget.verticalScrollBar().setValue(txt_widget.verticalScrollBar().maximum()))

    def _on_log_filter_toggled(self, step, level, checked):
        """v12.10.13：用户切换过滤 checkbox → 重渲该 step 的日志面板。"""
        self._log_filters.setdefault(step, {"WARNING": False, "ERROR": False})[level] = checked
        self._rerender_log(step)

    def _rerender_log(self, step):
        """v12.10.13：根据当前 _log_filters 重新渲染该 step 的 QTextEdit。"""
        txt_widget = self.log_texts.get(step)
        if txt_widget is None:
            return
        txt_widget.clear()
        for lvl, msg in self._log_entries.get(step, []):
            if self._should_show(step, lvl):
                txt_widget.append(msg)
        QTimer.singleShot(
            10, lambda: txt_widget.verticalScrollBar().setValue(txt_widget.verticalScrollBar().maximum())
        )

    def _export_log(self, step_name):
        """v12.10.60：导出改为「汇总」——把面板日志全文追加到团队共享
        使用反馈.xlsx（Z:\\projects\\Z_PYTHON\\SPAhub\\），不再写本地 99_archive txt。"""
        from modules.log_summary import append_log_summary
        txt_widget = self.log_texts.get(step_name)
        if txt_widget is None:
            return
        content = txt_widget.toPlainText().strip()
        if not content:
            show_dialog(self, "提示", "日志为空，没有可汇总的内容。", "warning")
            return

        project = self.base_path or "(未选择项目)"  # base_path 即四级目录拼接全路径
        res = append_log_summary(
            project=project, module="tfls", step=step_name, log_text=content)
        if res.get("ok"):
            show_dialog(
                self, "已汇总到反馈簿",
                f"日志已汇总到团队《使用反馈》第 {res['row']} 行。\n"
                f"提交人：{res['submitter']}　模块：tfls　步骤：{step_name}",
                "info", path=res["path"])
        else:
            show_dialog(
                self, "汇总失败（已暂存本地）",
                f"{res.get('error', '未知错误')}\n\n本地暂存：{res.get('path', '(无)')}",
                "warning", path=res.get("path") or None)

    # ------------------------- 运行耗时 -------------------------
    def _start_elapsed(self, step_name):
        """sig_run_started 触发：记录开始时间并启动刷新定时器"""
        self._run_start_times[step_name] = {"start": time.time()}
        self._elapsed_label_cache.pop(step_name, None)
        if not self._elapsed_timer.isActive():
            self._elapsed_timer.start()

    def _stop_elapsed(self, step_name):
        """on_execute_finished 触发：定格耗时并追加到状态标签尾部"""
        if step_name not in self._run_start_times:
            return
        elapsed = time.time() - self._run_start_times[step_name]["start"]
        del self._run_start_times[step_name]
        self._elapsed_label_cache.pop(step_name, None)
        if not self._run_start_times:
            self._elapsed_timer.stop()

        # 在当前状态标签末尾补上最终耗时
        stat = self.log_status_lbls.get(step_name)
        if stat is not None:
            cur = stat.text()
            if "(耗时:" not in cur:
                stat.setText(f"{cur}  (耗时: {self._format_elapsed(elapsed)})")

    def _tick_running_elapsed(self):
        """每 2s tick：仅当文本有变化时才调用 setText（避免冗余布局重算）"""
        for step_name, rec in list(self._run_start_times.items()):
            elapsed = time.time() - rec["start"]
            stat = self.log_status_lbls.get(step_name)
            if stat is None:
                continue
            cur_text = stat.text()
            base_text = cur_text.split("  (耗时:")[0] if "(耗时:" in cur_text else cur_text
            new_text = f"{base_text}  (耗时: {self._format_elapsed(elapsed)})"
            # 仅当文本确实变化时才写入（避免每次 tick 都触发 QLabel 布局重算）
            if self._elapsed_label_cache.get(step_name) != new_text:
                stat.setText(new_text)
                self._elapsed_label_cache[step_name] = new_text

    @staticmethod
    def _format_elapsed(sec):
        """耗时格式化：<60s 显示 Xs，>=60s 显示 MmSs"""
        if sec < 60:
            return f"{sec:.1f}s"
        m, s = divmod(int(sec), 60)
        return f"{m}m{s}s"

    # ------------------------- 刷新源文件 -------------------------
    def _refresh_step(self, step_name):
        """左侧刷新按钮入口：按模块分派刷新逻辑"""
        if not self.base_path:
            return
        form = self._get_form(step_name)
        if form and hasattr(form, 'scan_lbl'):
            form.scan_lbl.setText("正在刷新...")
            form.scan_lbl.setStyleSheet(scan_status_lbl_style("#409EFF"))

        p3, p4 = self.p3, self.p4
        base_path = self.base_path
        toc_path = os.path.join(base_path, "utility", "documentation", "03_statistics", "TOC.xlsx")
        pdt_path = os.path.join(base_path, "utility", "documentation",
                                f"{p3}_{p4}_PDT.xlsx" if (p3 or p4) else "项目层面_PDT.xlsx")

        def _do():
            if step_name == "PDT Gen":
                self.pdt_form.update_paths(base_path, toc_path, pdt_path)
            elif step_name == "Metadata Setup":
                self.meta_form.update_paths(base_path, pdt_path)
            elif step_name == "Initial PGM":
                self.init_pgm_form.update_paths(base_path, pdt_path)
            elif step_name == "Batch Run" and hasattr(self, 'batch_run_form'):
                self.batch_run_form.update_paths(base_path)
            elif step_name == "TFLs Combine" and hasattr(self, 'tfls_combine_form'):
                self.tfls_combine_form.update_paths(base_path, p3 or "", p4 or "")

        # Metadata 读 Excel 耗时，放子线程；其余同步即可
        if step_name == "Metadata Setup":
            self._refresh_thread = _RefreshWorker(step_name, _do)
            self._refresh_thread.finished.connect(self._on_refresh_done)
            self._refresh_thread.start()
        else:
            _do()
            self._on_refresh_done(step_name)

    def _on_refresh_done(self, step_name):
        """刷新完成：更新 scan_lbl 为 ✅ 刷新完成"""
        form = self._get_form(step_name)
        if form and hasattr(form, 'scan_lbl'):
            form.scan_lbl.setText("✅ 刷新完成")
            form.scan_lbl.setStyleSheet(scan_status_lbl_style("#67C23A"))

    def _get_form(self, step_name):
        """根据步骤名取到对应的 Form 实例"""
        mapping = {
            "PDT Gen": self.pdt_form,
            "Metadata Setup": self.meta_form,
            "Initial PGM": self.init_pgm_form,
        }
        if hasattr(self, 'batch_run_form'):
            mapping["Batch Run"] = self.batch_run_form
        if hasattr(self, 'tfls_combine_form'):
            mapping["TFLs Combine"] = self.tfls_combine_form
        return mapping.get(step_name)

    def _get_all_forms(self):
        """返回所有已创建的子表单列表"""
        forms = [self.pdt_form, self.meta_form, self.init_pgm_form]
        if hasattr(self, 'batch_run_form'):
            forms.append(self.batch_run_form)
        if hasattr(self, 'tfls_combine_form'):
            forms.append(self.tfls_combine_form)
        return forms

    # ------------------------- 信号连接 -------------------------
    def _connect_components(self):
        """将各 Form 的运行信号统一路由到对应右侧日志面板"""

        # 运行中 → 步骤栏文字追加 ⏳
        def _set_running_icon(step):
            original = self.step_original_texts[step]
            self.step_btns[step].setText(f"{original}  ⏳")

        # 给每个模块的刷新按钮绑定回调（模块里只负责 UI，事件由本控件统一处理）
        for form in self._get_all_forms():
            if hasattr(form, 'refresh_btn') and hasattr(form, '_step_name'):
                form.refresh_btn.clicked.connect(lambda checked, s=form._step_name: self._refresh_step(s))

        # ----- 01 PDT Gen -----
        self.pdt_form.sig_run_started.connect(lambda: self._clear_log_for_step("PDT Gen"))
        self.pdt_form.sig_run_started.connect(lambda: _set_running_icon("PDT Gen"))
        self.pdt_form.sig_run_started.connect(lambda: self._start_elapsed("PDT Gen"))
        self.pdt_form.sig_log.connect(lambda msg: self._append_and_scroll("PDT Gen", msg))
        self.pdt_form.sig_status.connect(lambda msg, color: self._set_status("PDT Gen", msg, color))
        self.pdt_form.sig_step_update.connect(lambda txt: (
            self.step_btns["PDT Gen"].setText(txt), self._stop_elapsed("PDT Gen")))

        # PDT Gen 专有：归档目录按钮
        self._pdt_archive_path = ""
        def _on_pdt_archive_show(show, path):
            self._pdt_archive_path = path
            self.archive_btns["PDT Gen"].setVisible(show)
        self.pdt_form.sig_show_archive.connect(_on_pdt_archive_show)
        self.archive_btns["PDT Gen"].clicked.connect(
            lambda: os.startfile(self._pdt_archive_path) if self._pdt_archive_path and os.path.exists(self._pdt_archive_path) else None)

        # ----- 02 Metadata Setup -----
        self.meta_form.sig_run_started.connect(lambda: self._clear_log_for_step("Metadata Setup"))
        self.meta_form.sig_run_started.connect(lambda: _set_running_icon("Metadata Setup"))
        self.meta_form.sig_run_started.connect(lambda: self._start_elapsed("Metadata Setup"))
        self.meta_form.sig_log.connect(lambda msg: self._append_and_scroll("Metadata Setup", msg))
        self.meta_form.sig_status.connect(lambda msg, color: self._set_status("Metadata Setup", msg, color))
        self.meta_form.sig_step_update.connect(lambda txt: (
            self.step_btns["Metadata Setup"].setText(txt), self._stop_elapsed("Metadata Setup")))

        # ----- 03 Initial PGM -----
        self.init_pgm_form.sig_run_started.connect(lambda: self._clear_log_for_step("Initial PGM"))
        self.init_pgm_form.sig_run_started.connect(lambda: _set_running_icon("Initial PGM"))
        self.init_pgm_form.sig_run_started.connect(lambda: self._start_elapsed("Initial PGM"))
        self.init_pgm_form.sig_log.connect(lambda msg: self._append_and_scroll("Initial PGM", msg))
        self.init_pgm_form.sig_status.connect(lambda msg, color: self._set_status("Initial PGM", msg, color))
        self.init_pgm_form.sig_step_update.connect(lambda txt: (
            self.step_btns["Initial PGM"].setText(txt), self._stop_elapsed("Initial PGM")))

        # Initial PGM 专有：打开合并日志按钮
        btn_init = self.log_action_btns["Initial PGM"]
        btn_init.setText("📄 打开合并日志")
        btn_init.setVisible(True)
        btn_init.clicked.connect(self._open_init_merged_log)

        # v12.10.31：Initial PGM 专有 — Git 暂存面板（Tab 2）信号路由
        # Form → Panel：仓库信息 / 推送结果
        self.init_pgm_form.sig_gitlab_repo_info.connect(
            self.gitlab_stash_panel.update_repo_info)
        self.init_pgm_form.sig_gitlab_push_done.connect(
            self._on_gitlab_push_done_route)
        # Panel → Form：用户点"🔁 重试推送"
        self.gitlab_stash_panel.sig_retry_push.connect(
            self.init_pgm_form.trigger_gitlab_push)

        # ----- 04 Batch Run -----
        if BatchRunForm and hasattr(self, 'batch_run_form'):
            # v12.3：日志面板只在"生成批处理脚本"时清空（sig_clear_log），
            # 其他运行动作（前置备份 / 单脚本 ▶ / Log Check / Compare Check）一律累加。
            # 旧实现把 clear 接在 sig_run_started 上，每次运行都会洗掉上一段日志，
            # 导致跑完 Log Check 后看不到之前的单脚本运行历史。
            self.batch_run_form.sig_clear_log.connect(lambda: self._clear_log_for_step("Batch Run"))
            self.batch_run_form.sig_run_started.connect(lambda: _set_running_icon("Batch Run"))
            self.batch_run_form.sig_run_started.connect(lambda: self._start_elapsed("Batch Run"))
            self.batch_run_form.sig_log.connect(lambda msg: self._append_and_scroll("Batch Run", msg))
            self.batch_run_form.sig_status.connect(lambda msg, color: self._set_status("Batch Run", msg, color))
            self.batch_run_form.sig_step_update.connect(lambda txt: (
                self.step_btns["Batch Run"].setText(txt), self._stop_elapsed("Batch Run")))
            # v12.2：Log/Compare Check 与 跑批前置 完成时不打"步骤完成✅"标记，但需要停计时
            self.batch_run_form.sig_run_finished.connect(lambda: self._stop_elapsed("Batch Run"))
            # v12.10.12：sig_show_check_paths 不再使用（results 按钮已迁到 form 内部 footer）

        # ----- 05 TFLs Combine -----
        if TFLsCombineForm and hasattr(self, 'tfls_combine_form'):
            self.tfls_combine_form.sig_run_started.connect(lambda: self._clear_log_for_step("TFLs Combine"))
            self.tfls_combine_form.sig_run_started.connect(lambda: _set_running_icon("TFLs Combine"))
            self.tfls_combine_form.sig_run_started.connect(lambda: self._start_elapsed("TFLs Combine"))
            self.tfls_combine_form.sig_log.connect(lambda msg: self._append_and_scroll("TFLs Combine", msg))
            self.tfls_combine_form.sig_status.connect(lambda msg, color: self._set_status("TFLs Combine", msg, color))
            self.tfls_combine_form.sig_step_update.connect(lambda txt: (
                self.step_btns["TFLs Combine"].setText(txt), self._stop_elapsed("TFLs Combine")))

    def _set_status(self, step, msg, color):
        """
        更新右侧底部状态标签。
        运行中每 1s 由 _tick_running_elapsed 追加耗时；
        此处只负责"基文本 + 颜色"设置，耗时由 tick 或 _stop_elapsed 追加。
        """
        lbl = self.log_status_lbls[step]
        lbl.setText(msg)
        lbl.setStyleSheet(f"font-size: 13px; font-weight: bold; color: {color}; padding-top: 5px;")

    def _open_init_merged_log(self):
        """Initial PGM：用系统默认程序打开合并日志文件"""
        log_path = os.path.join(self.base_path, "utility", "tools", "91_initial_pgm_call.log")
        if os.path.exists(log_path):
            os.startfile(log_path)
        else:
            self.log_texts["Initial PGM"].append(
                "<span style='color:#E6A23C;'>⚠️ 找不到合并日志文件 (91_initial_pgm_call.log)，可能尚未运行。</span>")

    def _on_gitlab_push_done_route(self, success: bool, summary: str, status_dict: dict):
        """v12.10.31：把 push 结果转发给 Stash Panel。失败时自动切到 Tab 2 提示用户。

        设计取舍：
          - 成功不切 tab，让用户继续看 Tab 1 日志流（push 摘要也已在日志里）。
          - 失败 / stash pop 失败 / merge 冲突 — 切到 Tab 2，让用户立即看到 commit
            列表和恢复操作；这种情况留在 Tab 1 容易被日志冲掉而错过 commit 信息。
        """
        # 1. 转发给 Stash Panel 刷新摘要 + commit 列表
        if hasattr(self, 'gitlab_stash_panel') and self.gitlab_stash_panel is not None:
            self.gitlab_stash_panel.update_after_push(success, summary, status_dict)

        # 2. 失败时自动切 Tab 2
        need_switch = (not success) or status_dict.get("stash_pop_failed") \
                      or status_dict.get("merge_conflict")
        if need_switch and hasattr(self, '_initial_pgm_tabs'):
            try:
                self._initial_pgm_tabs.setCurrentIndex(1)  # Tab 2
            except Exception:
                pass

    def _show_check_paths_for_batch_run(self, logs_dir, doc_dir):
        """v12.10.11：Log/Compare Check 完成后绑定两个文件夹按钮的 click + 显示。

        与"打开合并日志"区别：log/compare check 会产生多个 .xml 比较文件，
        所以打开的是文件夹（让用户浏览全部），不是单一文件。
        """
        btn_logs = self.check_logs_btns.get("Batch Run")
        btn_doc = self.check_doc_btns.get("Batch Run")

        def _open_dir(path):
            try:
                if path and os.path.isdir(path):
                    os.startfile(path)
                else:
                    self.log_texts["Batch Run"].append(
                        f"<span style='color:#E6A23C;'>⚠️ 文件夹不存在：{path}</span>"
                    )
            except Exception as e:
                self.log_texts["Batch Run"].append(
                    f"<span style='color:#F56C6C;'>❌ 打开文件夹失败：{e}</span>"
                )

        if btn_logs is not None:
            try: btn_logs.clicked.disconnect()
            except Exception: pass
            btn_logs.clicked.connect(lambda checked=False, p=logs_dir: _open_dir(p))
            btn_logs.setVisible(True)

        if btn_doc is not None:
            try: btn_doc.clicked.disconnect()
            except Exception: pass
            btn_doc.clicked.connect(lambda checked=False, p=doc_dir: _open_dir(p))
            btn_doc.setVisible(True)

    # ------------------------- 切换 / 路径更新 -------------------------
    def switch_step(self, step_name):
        """切换到指定步骤（步骤栏按钮选中 + 左右栈同步切换）"""
        for name, btn in self.step_btns.items():
            btn.setChecked(name == step_name)
        if step_name in self.steps:
            idx = self.steps.index(step_name)
            self.left_stack.setCurrentIndex(idx)
            self.right_stack.setCurrentIndex(idx)
            # v11.3：根据当前步骤动态调整左右分栏比例。
            # Batch Run 步骤会出现一行行的脚本矩阵（含勾选 + 状态 + 多个按钮），
            # 用默认 4:6 时左侧会被挤到只能露出名字而省略状态/按钮，体验差；
            # 切到 Batch Run 后改为 6:4，确保左侧矩阵行能完整展示。
            self._apply_splitter_ratio_for_step(step_name)

    def _apply_splitter_ratio_for_step(self, step_name):
        """根据步骤名应用左右分栏的目标像素宽度。
        总宽以 splitter.width() 为准；首次绘制前 width 可能为 0，遇此情况跳过，
        让 Qt 走 stretchFactor 默认布局，下次 resize/show 时仍会重新触发。"""
        total = self.splitter.width()
        if total <= 0:
            return
        # Batch Run：左 60%，让脚本矩阵行能完整露出（含勾选 / 状态 / 按钮）
        # 其他步骤：维持 4:6（左 40%），日志面板更宽便于查看 SAS 输出
        left_pct = 0.60 if step_name == "Batch Run" else 0.40
        left_w = int(total * left_pct)
        right_w = total - left_w
        self.splitter.setSizes([left_w, right_w])

    def update_path(self, base_path, p3, p4):
        """
        由主控（下拉框变化时）调用：推送路径到所有子模块。
        若四下拉框未齐全：各 Form 显示等待提示并清空输入。

        路径去重：当 (base_path, p3, p4) 与上次推送完全一致时，不重复刷新各 Form
        （避免页面切换时重复触发 update_paths 的 IO）。
        """
        # 与上次相同则直接返回（首次时 _last_pushed_path 不存在，正常下推）
        new_key = (base_path, p3, p4)
        if getattr(self, "_last_pushed_path", None) == new_key:
            return
        self._last_pushed_path = new_key

        self.base_path = base_path
        self.p3 = p3
        self.p4 = p4

        # 路径是否齐全：base_path 相对 Z:\ 至少 4 层
        try:
            rel = os.path.relpath(base_path, "Z:\\")
            levels = [x for x in rel.split(os.sep) if x and x != ".."]
            paths_complete = len(levels) >= 4
        except Exception:
            paths_complete = False

        if not paths_complete:
            # 未齐全：清空各步骤的状态 + 输入
            # v12.2：同时清空所有耗时计时状态，避免切项目后旧定时器仍在 tick 把"就绪"改成"就绪 (耗时: Xs)"
            self._run_start_times.clear()
            self._elapsed_label_cache.clear()
            if self._elapsed_timer.isActive():
                self._elapsed_timer.stop()
            for step in self.steps:
                self._clear_log_for_step(step)
                self.log_status_lbls[step].setText("就绪")
                self.log_status_lbls[step].setStyleSheet("font-size: 13px; font-weight: bold; color: #909399; padding-top: 5px;")
                self.step_btns[step].setText(self.step_original_texts[step])
                self.archive_btns[step].setVisible(False)
                # v12.10.11：切项目时隐藏 check 文件夹按钮（防止 stale 指向上个项目）
                if step in self.check_logs_btns:
                    self.check_logs_btns[step].setVisible(False)
                if step in self.check_doc_btns:
                    self.check_doc_btns[step].setVisible(False)
            for form in self._get_all_forms():
                if hasattr(form, 'set_wait_hint'):
                    form.set_wait_hint(True)
            self._clear_all_subform_inputs()
            return

        # 齐全：隐藏等待提示 + 推送真实路径
        # v12.2：齐全分支也复位耗时状态（防止用户在 Log Check 跑完前就切项目导致旧条目残留）
        self._run_start_times.clear()
        self._elapsed_label_cache.clear()
        if self._elapsed_timer.isActive():
            self._elapsed_timer.stop()

        for form in self._get_all_forms():
            if hasattr(form, 'set_wait_hint'):
                form.set_wait_hint(False)

        toc_path = os.path.join(base_path, "utility", "documentation", "03_statistics", "TOC.xlsx")
        pdt_path = os.path.join(base_path, "utility", "documentation",
                                f"{p3}_{p4}_PDT.xlsx" if (p3 or p4) else "项目层面_PDT.xlsx")

        self.pdt_form.update_paths(base_path, toc_path, pdt_path)
        self.meta_form.update_paths(base_path, pdt_path)
        self.init_pgm_form.update_paths(base_path, pdt_path)
        if BatchRunForm and hasattr(self, 'batch_run_form'):
            self.batch_run_form.update_paths(base_path)
        if hasattr(self, 'tfls_combine_form'):
            self.tfls_combine_form.update_paths(base_path, p3 or "", p4 or "")

        # 所有步骤重置为"就绪"
        for step in self.steps:
            self._clear_log_for_step(step)
            self.log_status_lbls[step].setText("就绪")
            self.log_status_lbls[step].setStyleSheet("font-size: 13px; font-weight: bold; color: #909399; padding-top: 5px;")
            self.step_btns[step].setText(self.step_original_texts[step])
            self.archive_btns[step].setVisible(False)
            # v12.10.11：切项目时隐藏 check 文件夹按钮（防止 stale 指向上个项目）
            if step in self.check_logs_btns:
                self.check_logs_btns[step].setVisible(False)
            if step in self.check_doc_btns:
                self.check_doc_btns[step].setVisible(False)

    def _clear_all_subform_inputs(self):
        """路径未齐全时清空各 Form 的输入框，避免展示残缺路径"""
        if hasattr(self.pdt_form, 'toc_entry'):
            self.pdt_form.toc_entry.clear()
            self.pdt_form.base_path = ""
            self.pdt_form.toc_path = ""
            self.pdt_form.pdt_path = ""
            self.pdt_form.edit_btn.setVisible(False)
        if hasattr(self.meta_form, 'meta_shell_entry'):
            self.meta_form.meta_shell_entry.clear()
            self.meta_form.meta_adam_entry.clear()
            self.meta_form.meta_sdtm_entry.clear()
            self.meta_form.meta_ecrf_entry.clear()
            self.meta_form.meta_code_entry.clear()
            # 任务2（v10）：同步清空 Metadata Setup 新增的 PDT XLSX 输入框
            if hasattr(self.meta_form, 'meta_pdt_entry'):
                self.meta_form.meta_pdt_entry.clear()
            self.meta_form.base_path = ""
        if hasattr(self.init_pgm_form, 'sas_91_entry'):
            self.init_pgm_form.sas_91_entry.clear()
        if hasattr(self.init_pgm_form, 'sas_61_entry'):
            self.init_pgm_form.sas_61_entry.clear()
        self.init_pgm_form.base_path = ""
        if hasattr(self, 'batch_run_form') and hasattr(self.batch_run_form, 'sas_92_entry'):
            self.batch_run_form.sas_92_entry.clear()
            # 任务1：同步清空 BatchRun 新增的 PDT XLSX 输入框，避免残缺路径
            if hasattr(self.batch_run_form, 'pdt_entry'):
                self.batch_run_form.pdt_entry.clear()
            # 任务4（v10）：同步清空跑批前置脚本路径只读显示
            if hasattr(self.batch_run_form, 'pre_path_entry'):
                self.batch_run_form.pre_path_entry.clear()
            self.batch_run_form.base_path = ""
        if hasattr(self, 'tfls_combine_form'):
            self.tfls_combine_form.clear_inputs()

    # ============================================================================
    # 全局快捷键路由：F5 / Ctrl+Enter 由主窗口转发到当前 step 的对应 form
    # ============================================================================
    def _current_step_form(self):
        """返回当前 step 对应的 form 实例（无则 None）"""
        idx = self.left_stack.currentIndex()
        if 0 <= idx < len(self.steps):
            return self._get_form(self.steps[idx])
        return None

    def showEvent(self, event):
        """v11.3：首次绘制后应用一次分栏比例。
        __init__ 阶段 splitter.width() 为 0，setSizes 无效；这里在 widget 真正
        被显示后再补一次，确保 Batch Run / 其他步骤的目标比例被正确施加。"""
        super().showEvent(event)
        idx = self.left_stack.currentIndex()
        if 0 <= idx < len(self.steps):
            self._apply_splitter_ratio_for_step(self.steps[idx])

    def action_refresh(self):
        """F5 → 委派到当前 step 的 form.action_refresh()（即点击其 🔄 刷新源文件）"""
        form = self._current_step_form()
        if form is not None:
            fn = getattr(form, "action_refresh", None)
            if callable(fn):
                fn()

    def action_run(self):
        """
        Ctrl+Enter → 委派到当前 step 的 form.action_run()。

        说明：
          - PDT Gen / Metadata Setup / TFLs Combine 三个 step 实现了 action_run
            （单一明确的运行按钮）。
          - Initial PGM 有两个运行按钮（91/61），Batch Run 是按脚本逐行运行，
            语义不明确，因此这两个 step 的 form 不实现 action_run，按下 Ctrl+Enter
            自动空操作（不会报错也不会误触发）。
          - 运行中按钮处于 disabled 或 hidden，click() 自动空操作，无需额外判断。
        """
        form = self._current_step_form()
        if form is not None:
            fn = getattr(form, "action_run", None)
            if callable(fn):
                fn()
