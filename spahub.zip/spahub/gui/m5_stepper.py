# -*- coding: utf-8 -*-
"""
gui/m5_stepper.py
=================
M5 两步导航器（01 PDS for vars / 02 PDS for Codelist）。

设计原则：仿 adam_stepper / sdtm_stepper 的容器结构（步骤栏 + 左右分栏 4:6 +
右侧日志面板）。

模块结构：
  - 顶部步骤栏（ChevronStepBar：01 PDS for vars / 02 PDS for Codelist）
  - 左侧：PdsForDefineForm（步骤 01）/ PdsForCodelistForm（步骤 02），各自包 QScrollArea
  - 右侧：每步独立日志面板（标题栏 + 过滤 + 日志文本 + 状态标签 + 导出）
  - 路径变化时统一推送到各 form

v12.10.106：恢复 M5 模块，新增步骤 01 PDS for Define。
v12.10.112：步骤 01 更名为「PDS for vars」；新增步骤 02「PDS for Codelist」(crt_codelist)。
v12.10.131：新增顶部「数据类型」总开关（SDTM / ADaM）。三步各自原有的 inlib / libname
            下拉隐藏，改由该总开关统一驱动 —— 切换一次即联动全部步骤的 inlib/libname 及其
            派生的输入/输出库、XPT 目录、spec/define 路径等，用户无感切换后可直接运行。
            实现：M5Widget 持有 self.data_type，切换 → 广播 form.set_data_type(t)；各 form 的
            set_data_type 复用既有下拉的联动信号（不重写派生逻辑）。update_path 后重新广播，
            避免切项目把类型重置回各 form 默认值。
v12.10.132：步骤导航由横向 chevron 改为左侧竖排 step rail（VerticalStepBar，本文件内定义）。
            原因：横向 chevron 等宽分槽，步骤一多就挤/截断；竖排天然放得下多步骤 + 完整中文标签
            + 状态 emoji，为后续 M5 扩到多步骤预留空间。VerticalStepBar 对外暴露与 ChevronStepBar
            相同的接口（step_clicked 信号 + set_active/active_step/set_label/get_label），因此
            StepProxy / switch_step / _connect_components 全部零改动复用。布局：顶部「数据类型」
            总开关（全宽）不变；其下改为 [竖排 rail | 表单 | 日志] 三列（rail 固定宽，表单:日志 5:5）。
v12.10.133：布局微调 —— ①「数据类型」开关从顶部整条并入左侧导航列顶部（与步骤栏同处一个白底
            描边面板，中间加分隔线），不再单独占一条；②去掉开关旁的说明文字；③表单:日志由 5:5
            改为 6:4，表单更宽以完整展示操作面板按钮。VerticalStepBar 改为无边框透明底以融入面板。
"""
import os
import time

from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                               QStackedWidget, QTextEdit, QFrame, QSplitter, QCheckBox,
                               QScrollArea, QButtonGroup)
from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QTextOption

from ui_utils import show_dialog, log_textedit_style, StepProxy
from gui.log_search import attach_log_search

from modules.m5_convert2xpt import Convert2XptForm
from modules.m5_pds_for_define import PdsForDefineForm
from modules.m5_pds_codelist import PdsForCodelistForm


# ============================================================================
# v12.10.132：VerticalStepBar —— 左侧竖排步骤栏
# ----------------------------------------------------------------------------
# 替代 M5 顶部横向 ChevronStepBar。每个步骤是一行可点按钮，竖直堆叠；当前步整行
# 皇家蓝 #4A6FA5 + 白字，其余透明底 + 灰字，hover 浅蓝。点击 emit step_clicked(step)。
# 对外接口刻意与 ui_utils.ChevronStepBar 保持一致（step_clicked 信号 +
# set_active / active_step / set_label / get_label），故 StepProxy 及 stepper 里
# switch_step / _connect_components 全部无需改动即可复用。
# 竖排相比横向 chevron 的好处：步骤一多也放得下、中文标签不截断、可挂状态 emoji。
# ============================================================================
class VerticalStepBar(QFrame):
    step_clicked = Signal(str)

    _BTN_QSS = (
        "QPushButton { text-align:left; padding:10px 12px; border:none; border-radius:6px; "
        "background:transparent; color:#606266; font-size:13px; font-weight:bold; }"
        "QPushButton:hover { background:#EEF2FB; color:#4A6FA5; }"
        "QPushButton:checked { background:#4A6FA5; color:#FFFFFF; }"
    )

    def __init__(self, steps, labels, parent=None):
        super().__init__(parent)
        self.setObjectName("StepRail")
        # v12.10.133：改为无边框透明底 —— 并入左侧导航面板 left_nav，由该面板统一描边，避免双重边框
        self.setStyleSheet("#StepRail { background-color: transparent; border: none; }")
        self._steps = list(steps)
        self._btns = {}
        self._group = QButtonGroup(self)
        self._group.setExclusive(True)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(6)

        hdr = QLabel("步骤")
        hdr.setStyleSheet("border:none; color:#909399; font-size:12px; font-weight:bold; padding:0 4px 4px 4px;")
        lay.addWidget(hdr)

        for s in self._steps:
            b = QPushButton(labels.get(s, s))
            b.setCheckable(True)
            b.setCursor(Qt.PointingHandCursor)
            b.setStyleSheet(self._BTN_QSS)
            b.clicked.connect(lambda checked=False, ss=s: self.step_clicked.emit(ss))
            self._group.addButton(b)
            self._btns[s] = b
            lay.addWidget(b)

        # v12.10.133：内部不再 addStretch —— 顶部对齐交由外层 left_nav 统一处理
        if self._steps:
            self._btns[self._steps[0]].setChecked(True)

    # ---- 与 ChevronStepBar 同名接口（供 StepProxy 转发）----
    def set_active(self, step):
        b = self._btns.get(step)
        if b is not None and not b.isChecked():
            b.setChecked(True)   # 互斥组自动取消其它选中

    def active_step(self):
        for s, b in self._btns.items():
            if b.isChecked():
                return s
        return self._steps[0] if self._steps else None

    def set_label(self, step, text):
        b = self._btns.get(step)
        if b is not None:
            b.setText(text)

    def get_label(self, step):
        b = self._btns.get(step)
        return b.text() if b is not None else ""


class M5Widget(QWidget):
    """M5 两步导航容器：步骤栏 + 左右分栏（仿 AdamWidget 简化版）"""

    # v12.10.131：顶部「数据类型」分段开关的样式（雾蓝石板主题：选中 #4A6FA5 白字）。
    # 这是自定义分段控件，非标准按钮，故本地 QSS 常量（与 ChevronStepBar 自持配色同理）。
    _TYPE_BTN_QSS = (
        "QPushButton { background-color:#EDF2FA; color:#8A94A6; border:1px solid #D6DEEA; "
        "padding:6px 20px; border-radius:5px; font-weight:bold; font-size:13px; }"
        "QPushButton:hover { background-color:#E1E8F6; color:#4A6FA5; }"
        "QPushButton:checked { background-color:#4A6FA5; color:#FFFFFF; border:1px solid #4A6FA5; }"
    )

    def __init__(self):
        super().__init__()
        self.base_path = ""
        self.p3 = ""
        self.p4 = ""

        # v12.10.131：M5 全局数据类型（sdtm / adam），由顶部总开关驱动、广播到三步各 form
        self.data_type = "sdtm"
        self._type_btns = {}

        # v12.10.116：新增步骤 01 Convert2XPT，原 01/02 顺延为 02/03
        self.steps = ["Convert2XPT", "PDS for vars", "PDS for Codelist"]
        self.step_original_texts = {step: f"0{i + 1} {step}" for i, step in enumerate(self.steps)}

        self.forms = {}
        self.step_btns = {}
        self.log_texts = {}
        self.log_status_lbls = {}
        self.export_btns = {}
        # 日志过滤
        self._log_entries = {}
        self._log_filters = {}
        self._log_filter_chks = {}

        # 运行耗时跟踪
        self._run_start_times = {}
        self._elapsed_label_cache = {}
        self._elapsed_timer = QTimer(self)
        self._elapsed_timer.setInterval(2000)
        self._elapsed_timer.timeout.connect(self._tick_running_elapsed)

        self._setup_ui()
        self._connect_components()

    # ------------------------- UI 构造 -------------------------
    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # v12.10.132/133：主体 [左侧导航列 | 表单 | 日志] 三列。
        # v12.10.133：数据类型开关并入左侧导航列顶部，不再单独占顶部整条。
        content_row = QHBoxLayout()
        content_row.setContentsMargins(0, 0, 0, 0)
        content_row.setSpacing(10)

        # 左侧导航列：白底描边面板 = 「数据类型」开关 + 分隔线 + 竖排步骤栏
        left_nav = QFrame()
        left_nav.setObjectName("M5LeftNav")
        left_nav.setStyleSheet(
            "#M5LeftNav { background-color: #FFFFFF; border: 1px solid #E4E7ED; border-radius: 6px; }")
        left_nav.setFixedWidth(220)
        nav_layout = QVBoxLayout(left_nav)
        nav_layout.setContentsMargins(10, 12, 10, 12)
        nav_layout.setSpacing(8)

        # 数据类型开关（紧凑竖版，无描述）
        nav_layout.addWidget(self._build_type_toggle())

        # 分隔线
        divider = QFrame()
        divider.setFrameShape(QFrame.HLine)
        divider.setStyleSheet("border:none; background-color:#EBEEF5; min-height:1px; max-height:1px;")
        nav_layout.addWidget(divider)

        # 竖排步骤栏（无边框，融入本面板）
        self.step_bar = VerticalStepBar(self.steps, self.step_original_texts)
        self.step_bar.step_clicked.connect(self.switch_step)
        self.step_btns = {s: StepProxy(self.step_bar, s) for s in self.steps}
        nav_layout.addWidget(self.step_bar)
        nav_layout.addStretch(1)   # 顶部对齐，余量留底部

        content_row.addWidget(left_nav)

        # 右侧：表单 | 日志（6:4，尽量给表单更多宽度完整展示操作面板）
        self.splitter = QSplitter(Qt.Horizontal)
        self.splitter.setStyleSheet("QSplitter::handle { background-color: #EBEEF5; width: 4px; }")

        self.left_stack = QStackedWidget()
        self.right_stack = QStackedWidget()
        self.right_stack.setStyleSheet("background-color: #FFFFFF; border: 1px solid #E4E7ED; border-radius: 6px;")

        self.splitter.addWidget(self.left_stack)
        self.splitter.addWidget(self.right_stack)
        # v12.10.133：表单:日志 5:5 → 6:4（表单更宽，操作面板按钮完整可见）
        self.splitter.setStretchFactor(0, 6)
        self.splitter.setStretchFactor(1, 4)
        content_row.addWidget(self.splitter, 1)

        layout.addLayout(content_row, 1)

        # 两步表单（各自包一层 QScrollArea；内容超高出现垂直滚动条，参考 toc_gen）
        self.forms["Convert2XPT"] = Convert2XptForm()
        self.forms["PDS for vars"] = PdsForDefineForm()
        self.forms["PDS for Codelist"] = PdsForCodelistForm()
        self._scrolls = {}
        for step in self.steps:
            scroll = QScrollArea()
            scroll.setWidget(self.forms[step])
            scroll.setWidgetResizable(True)
            scroll.setFrameShape(QFrame.NoFrame)
            scroll.setStyleSheet(
                "QScrollArea { background: transparent; border: none; }"
                "QScrollBar:vertical { background: #F5F7FA; width: 10px; }"
                "QScrollBar::handle:vertical { background: #C0C4CC; border-radius: 5px; min-height: 20px; }"
                "QScrollBar::handle:vertical:hover { background: #909399; }"
                "QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }"
            )
            self._scrolls[step] = scroll
            self.left_stack.addWidget(scroll)
            self.right_stack.addWidget(self._create_right_log_panel(step))

        # 兼容旧引用
        self.pds_form = self.forms["PDS for vars"]

        self.switch_step("Convert2XPT")

        # v12.10.131：初始把当前数据类型广播给三步，保证 form 状态与总开关一致
        self._broadcast_data_type()

    # ------------------------- 数据类型总开关 -------------------------
    def _build_type_toggle(self):
        """v12.10.131/133：构造「数据类型」分段开关（SDTM / ADaM），互斥可选。
        v12.10.133：并入左侧导航列，改为紧凑竖版（标题在上，两按钮平分一行），去掉右侧描述文字。"""
        wrap = QWidget()
        v = QVBoxLayout(wrap)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(6)

        lbl = QLabel("数据类型")
        lbl.setStyleSheet("border:none; color:#909399; font-size:12px; font-weight:bold; padding:0 4px;")
        v.addWidget(lbl)

        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(6)
        self._type_group = QButtonGroup(self)
        self._type_group.setExclusive(True)
        for t, text in (("sdtm", "SDTM"), ("adam", "ADaM")):
            b = QPushButton(text)
            b.setCheckable(True)
            b.setCursor(Qt.PointingHandCursor)
            b.setStyleSheet(self._TYPE_BTN_QSS)
            b.clicked.connect(lambda checked=False, tt=t: self._on_type_changed(tt))
            self._type_group.addButton(b)
            self._type_btns[t] = b
            row.addWidget(b, 1)   # 两按钮平分一行
        self._type_btns[self.data_type].setChecked(True)
        v.addLayout(row)
        return wrap

    def _on_type_changed(self, data_type):
        """总开关点击：更新 self.data_type 并广播到三步各 form。"""
        dt = (data_type or "sdtm").strip().lower()
        if dt not in ("sdtm", "adam"):
            dt = "sdtm"
        self.data_type = dt
        btn = self._type_btns.get(dt)
        if btn is not None and not btn.isChecked():
            btn.setChecked(True)
        self._broadcast_data_type()

    def _broadcast_data_type(self):
        """把当前数据类型下发给三步各 form（form 内部复用既有下拉联动逻辑重填）。"""
        for form in self._get_all_forms():
            fn = getattr(form, "set_data_type", None)
            if callable(fn):
                try:
                    fn(self.data_type)
                except Exception:
                    pass

    def _create_right_log_panel(self, step_name):
        """与 adam/tfls stepper 风格一致的日志面板（含过滤 + 导出按钮）"""
        rw = QFrame()
        rl = QVBoxLayout(rw)
        rl.setContentsMargins(10, 10, 10, 10)

        log_header = QHBoxLayout()
        title_lbl = QLabel(f"📄 {step_name} 运行日志")
        title_lbl.setStyleSheet("font-size: 13px; font-weight: bold; color: #606266; border: none;")
        log_header.addWidget(title_lbl)
        log_header.addStretch()

        btn_container = QHBoxLayout()
        btn_container.setSpacing(8)
        exp_btn = QPushButton("📋 导出日志")
        exp_btn.setStyleSheet("""
            QPushButton { background-color: #ECF5FF; color: #409EFF; border: 1px solid #B3D8FF; padding: 4px 10px; border-radius: 4px; font-size:12px; font-weight:bold;}
            QPushButton:hover { background-color: #409EFF; color: #FFFFFF; }
        """)
        exp_btn.clicked.connect(lambda checked, s=step_name: self._export_log(s))
        self.export_btns[step_name] = exp_btn
        btn_container.addWidget(exp_btn)

        log_header.addLayout(btn_container)
        rl.addLayout(log_header)

        # 过滤行（仅 WARNING / ERROR 可过滤，与 adam_stepper 同款）
        filter_row = QHBoxLayout()
        filter_row.setContentsMargins(0, 0, 0, 4)
        filter_lbl = QLabel("过滤：")
        filter_lbl.setStyleSheet("color: #909399; font-size: 11px; border: none;")
        filter_row.addWidget(filter_lbl)

        # v12.10.108：筛选语义改为「正向选择」——两框默认不勾选 = 全展示；
        # 勾 WARNING 只看 WARNING，勾 ERROR 只看 ERROR（NOTE 不进筛选）。
        self._log_filters[step_name] = {"WARNING": False, "ERROR": False}
        self._log_filter_chks[step_name] = {}

        for level, label, color in [
            ("WARNING", "⚠ WARNING", "#E6A23C"),
            ("ERROR", "❌ ERROR", "#F56C6C"),
        ]:
            chk = QCheckBox(label)
            chk.setChecked(False)
            chk.setStyleSheet(
                f"QCheckBox {{ color: {color}; font-size: 11px; border: none; spacing: 4px; }}"
                f"QCheckBox::indicator {{ width: 12px; height: 12px; border: 1px solid #DCDFE6; border-radius: 2px; background-color: #FFFFFF; }}"
                f"QCheckBox::indicator:hover {{ border: 1px solid {color}; }}"
                f"QCheckBox::indicator:checked {{ background-color: {color}; border: 1px solid {color}; }}"
            )
            chk.toggled.connect(
                lambda checked, s=step_name, lv=level: self._on_log_filter_toggled(s, lv, checked)
            )
            self._log_filter_chks[step_name][level] = chk
            filter_row.addWidget(chk)

        filter_row.addStretch()
        rl.addLayout(filter_row)

        txt = QTextEdit()
        txt.setReadOnly(True)
        attach_log_search(txt)
        txt.setLineWrapMode(QTextEdit.WidgetWidth)
        txt.setWordWrapMode(QTextOption.WrapAnywhere)
        txt.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        txt.setStyleSheet(log_textedit_style(with_padding=True))
        rl.addWidget(txt)

        stat = QLabel("就绪")
        stat.setAlignment(Qt.AlignCenter)
        stat.setStyleSheet("font-size: 13px; font-weight: bold; color: #909399; padding-top: 5px;")
        rl.addWidget(stat)

        self.log_texts[step_name] = txt
        self.log_status_lbls[step_name] = stat
        return rw

    # ------------------------- 信号联通 -------------------------
    def _connect_components(self):
        def _set_running_icon(step_name):
            cur = self.step_btns[step_name].text()
            base = self.step_original_texts[step_name]
            if "⏳" not in cur:
                self.step_btns[step_name].setText(f"{base} ⏳")

        for step in self.steps:
            form = self.forms[step]
            form.sig_run_started.connect(lambda s=step: self._clear_log_for_step(s))
            form.sig_run_started.connect(lambda s=step: _set_running_icon(s))
            form.sig_run_started.connect(lambda s=step: self._start_elapsed(s))
            form.sig_log.connect(lambda msg, s=step: self._append_and_scroll(s, msg))
            form.sig_status.connect(lambda msg, color, s=step: self._set_status(s, msg, color))
            form.sig_step_update.connect(lambda txt, s=step: (
                self.step_btns[s].setText(txt), self._stop_elapsed(s)))
            form.sig_run_finished.connect(lambda s=step: self._stop_elapsed(s))

    # ------------------------- 工具函数 -------------------------
    def _set_status(self, step, msg, color):
        lbl = self.log_status_lbls[step]
        lbl.setText(msg)
        lbl.setStyleSheet(f"font-size: 13px; font-weight: bold; color: {color}; padding-top: 5px;")

    @staticmethod
    def _classify_msg_level(msg):
        if not msg:
            return "NOTE"
        upper = msg.upper()
        if "#F56C6C" in msg or "❌" in msg or " ERROR" in upper or upper.startswith("ERROR") or "ERROR:" in upper:
            return "ERROR"
        if "#E6A23C" in msg or "⚠" in msg or "WARNING" in upper:
            return "WARNING"
        return "NOTE"

    def _should_show(self, step, level):
        """v12.10.108：正向筛选。无勾选 → 全展示；有勾选 → 仅展示被勾选的级别。"""
        f = self._log_filters.get(step, {})
        active = [lv for lv in ("WARNING", "ERROR") if f.get(lv)]
        if not active:
            return True
        return level in active

    def _append_and_scroll(self, step, msg):
        level = self._classify_msg_level(msg)
        self._log_entries.setdefault(step, []).append((level, msg))
        if not self._should_show(step, level):
            return
        txt_widget = self.log_texts[step]
        txt_widget.append(msg)
        QTimer.singleShot(10, lambda: txt_widget.verticalScrollBar().setValue(txt_widget.verticalScrollBar().maximum()))

    def _on_log_filter_toggled(self, step, level, checked):
        self._log_filters.setdefault(step, {"WARNING": False, "ERROR": False})[level] = checked
        self._rerender_log(step)

    def _rerender_log(self, step):
        txt_widget = self.log_texts.get(step)
        if txt_widget is None:
            return
        txt_widget.clear()
        for lvl, msg in self._log_entries.get(step, []):
            if self._should_show(step, lvl):
                txt_widget.append(msg)
        QTimer.singleShot(
            10, lambda: txt_widget.verticalScrollBar().setValue(txt_widget.verticalScrollBar().maximum())
        )

    def _clear_log_for_step(self, step):
        txt = self.log_texts.get(step)
        if txt is not None:
            txt.clear()
        self._log_entries[step] = []

    def _export_log(self, step_name):
        """与 adam_stepper 同款：把面板日志汇总到团队《使用反馈》。"""
        from modules.log_summary import append_log_summary
        txt_widget = self.log_texts.get(step_name)
        if txt_widget is None or not txt_widget.toPlainText().strip():
            show_dialog(self, "提示", "当前日志为空，无法汇总。", "info")
            return
        content = txt_widget.toPlainText().strip()
        project = self.base_path or "(未选择项目)"
        res = append_log_summary(
            project=project, module="m5", step=step_name, log_text=content)
        if res.get("ok"):
            show_dialog(
                self, "已汇总到反馈簿",
                f"日志已汇总到团队《使用反馈》第 {res['row']} 行。\n"
                f"提交人：{res['submitter']}　模块：m5　步骤：{step_name}",
                "info", path=res["path"])
        else:
            show_dialog(
                self, "汇总失败（已暂存本地）",
                f"{res.get('error', '未知错误')}\n\n本地暂存：{res.get('path', '(无)')}",
                "warning", path=res.get("path") or None)

    # ------------------------- 计时器 -------------------------
    def _start_elapsed(self, step_name):
        self._run_start_times[step_name] = {"start": time.time()}
        self._elapsed_label_cache.pop(step_name, None)
        if not self._elapsed_timer.isActive():
            self._elapsed_timer.start()

    def _stop_elapsed(self, step_name):
        if step_name not in self._run_start_times:
            return
        elapsed = time.time() - self._run_start_times[step_name]["start"]
        del self._run_start_times[step_name]
        self._elapsed_label_cache.pop(step_name, None)
        if not self._run_start_times:
            self._elapsed_timer.stop()
        stat = self.log_status_lbls.get(step_name)
        if stat is not None:
            cur_text = stat.text()
            base_text = cur_text.split("  (耗时:")[0] if "(耗时:" in cur_text else cur_text
            stat.setText(f"{base_text}  (耗时: {self._format_elapsed(elapsed)})")

    def _tick_running_elapsed(self):
        for step_name, rec in list(self._run_start_times.items()):
            elapsed = time.time() - rec["start"]
            stat = self.log_status_lbls.get(step_name)
            if stat is None:
                continue
            cur_text = stat.text()
            base_text = cur_text.split("  (耗时:")[0] if "(耗时:" in cur_text else cur_text
            new_text = f"{base_text}  (耗时: {self._format_elapsed(elapsed)})"
            if self._elapsed_label_cache.get(step_name) != new_text:
                stat.setText(new_text)
                self._elapsed_label_cache[step_name] = new_text

    @staticmethod
    def _format_elapsed(sec):
        if sec < 60:
            return f"{sec:.1f}s"
        m, s = divmod(int(sec), 60)
        return f"{m}m{s}s"

    # ------------------------- 切换 / 路径更新 -------------------------
    def switch_step(self, step_name):
        for name, btn in self.step_btns.items():
            btn.setChecked(name == step_name)
        if step_name in self.steps:
            idx = self.steps.index(step_name)
            self.left_stack.setCurrentIndex(idx)
            self.right_stack.setCurrentIndex(idx)
            try:
                total = sum(self.splitter.sizes()) or 1200
                # v12.10.133：表单:日志 6:4
                self.splitter.setSizes([int(total * 6 / 10), int(total * 4 / 10)])
            except Exception:
                pass

    def _get_all_forms(self):
        return [self.forms[s] for s in self.steps]

    def update_path(self, base_path, p3, p4):
        """主控推送 4 级路径到 M5 模块各 form（与 AdamWidget 同款语义）"""
        self.base_path = base_path
        self.p3 = p3
        self.p4 = p4

        try:
            rel = os.path.relpath(base_path, "Z:\\")
            levels = [x for x in rel.split(os.sep) if x and x != ".."]
            paths_complete = len(levels) >= 4
        except Exception:
            paths_complete = False

        self._run_start_times.clear()
        self._elapsed_label_cache.clear()
        if self._elapsed_timer.isActive():
            self._elapsed_timer.stop()

        if not paths_complete:
            for step in self.steps:
                self._clear_log_for_step(step)
                self.log_status_lbls[step].setText("就绪")
                self.log_status_lbls[step].setStyleSheet(
                    "font-size: 13px; font-weight: bold; color: #909399; padding-top: 5px;")
                self.step_btns[step].setText(self.step_original_texts[step])
            for form in self._get_all_forms():
                if hasattr(form, 'set_wait_hint'):
                    form.set_wait_hint(True)
            return

        for form in self._get_all_forms():
            if hasattr(form, 'set_wait_hint'):
                form.set_wait_hint(False)

        for form in self._get_all_forms():
            form.update_paths(base_path)

        # v12.10.131：路径填充后重新广播当前数据类型，避免切项目把类型重置回各 form 默认值
        self._broadcast_data_type()

        for step in self.steps:
            self._clear_log_for_step(step)
            self.log_status_lbls[step].setText("就绪")
            self.log_status_lbls[step].setStyleSheet(
                "font-size: 13px; font-weight: bold; color: #909399; padding-top: 5px;")
            self.step_btns[step].setText(self.step_original_texts[step])

    def refresh_caches(self):
        """主控通知：项目路径已切换，主动刷新 form 缓存。"""
        for form in self._get_all_forms():
            fn = getattr(form, "action_refresh", None)
            if callable(fn):
                try:
                    fn()
                except Exception:
                    pass
