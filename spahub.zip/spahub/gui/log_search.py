# -*- coding: utf-8 -*-
"""
gui/log_search.py
=================
日志框内 Ctrl+F 文本搜索浮层（v12.10.102 新增）。

设计要点（为什么这样写，避免和现有快捷键/线程撞车）：
  - **不注册 QShortcut**：主窗口的 F5 / Ctrl+Enter 都是 Qt.ApplicationShortcut（全应用级）。
    若把 Ctrl+F 也注册成 QShortcut，而每个 stepper 有多个日志面板各注册一个，Qt 会报
    "Ambiguous shortcut overload" 且谁都不可靠触发。本模块改用 **eventFilter 装在目标
    QTextEdit 上**，天然按焦点作用域：只有当前有焦点的日志框响应 Ctrl+F，跨面板不打架。
  - **纯 GUI 线程内存操作**：搜索就是 QTextEdit 文档的 QTextCursor.find / setExtraSelections，
    不碰 saspy / 子进程 / Runner 线程，瞬时完成，不阻塞，不和"调用 SAS"那条链交互。
  - **不改日志框只读性**：目标 QTextEdit 仍是 setReadOnly(True)；eventFilter 只截 Ctrl+F
    （以及搜索框可见时输入框内的 Enter/Esc），其余按键一律放行，正常滚动/选择/复制不受影响。

用法（在各 stepper 的日志 QTextEdit 创建处加一行）：
    from gui.log_search import attach_log_search
    txt = QTextEdit(); txt.setReadOnly(True)
    attach_log_search(txt)          # ← 仅此一行

交互：
    Ctrl+F           打开/聚焦搜索框（再次按定位到搜索框）
    Enter / ↓        下一个匹配（循环）
    Shift+Enter / ↑  上一个匹配（循环）
    Esc              关闭搜索框
    搜索默认大小写不敏感。
"""
from PySide6.QtCore import Qt, QObject, QEvent, QRect
from PySide6.QtGui import QColor, QTextCursor, QTextCharFormat, QTextDocument
from PySide6.QtWidgets import (
    QFrame, QHBoxLayout, QLineEdit, QLabel, QToolButton, QTextEdit,
)

# 高亮配色（与项目视觉系一致：橙=当前命中、淡黄=其它命中）
_HL_ALL = QColor("#FFF1A8")      # 全部命中底色（淡黄）
_HL_CURRENT = QColor("#E6A23C")  # 当前命中底色（橙，项目"警告"主色）


class _LogSearchController(QObject):
    """挂在单个 QTextEdit 上的搜索控制器（每个日志框一个，互不干扰）。"""

    def __init__(self, text_edit: QTextEdit):
        super().__init__(text_edit)   # parent=text_edit → 生命周期随之回收
        self.edit = text_edit
        self._matches = []            # list[(start_pos, end_pos)]
        self._cur = -1                # 当前命中索引

        self._build_bar()

        # eventFilter 装在日志框 + 搜索输入框上（同一个 controller 处理两个来源）
        self.edit.installEventFilter(self)
        self.input.installEventFilter(self)

    # ---------------------------------------------------------------- UI
    def _build_bar(self):
        # 浮层作为 text_edit 的子部件，悬浮在右上角，随日志一起在面板内
        self.bar = QFrame(self.edit)
        self.bar.setObjectName("logSearchBar")
        self.bar.setStyleSheet(
            "#logSearchBar { background: #FFFFFF; border: 1px solid #DCDFE6; "
            "border-radius: 6px; }"
        )
        lay = QHBoxLayout(self.bar)
        lay.setContentsMargins(6, 3, 6, 3)
        lay.setSpacing(4)

        self.input = QLineEdit(self.bar)
        self.input.setPlaceholderText("查找日志…")
        self.input.setFixedWidth(180)
        self.input.setStyleSheet(
            "QLineEdit { border: 1px solid #DCDFE6; border-radius: 4px; "
            "padding: 2px 6px; font-size: 12px; }"
            "QLineEdit:focus { border-color: #409EFF; }"
        )
        self.input.textChanged.connect(self._on_text_changed)
        lay.addWidget(self.input)

        self.count_lbl = QLabel("", self.bar)
        self.count_lbl.setStyleSheet("color: #909399; font-size: 11px; min-width: 44px;")
        self.count_lbl.setAlignment(Qt.AlignCenter)
        lay.addWidget(self.count_lbl)

        self.btn_prev = self._mk_btn("▲", "上一个 (Shift+Enter)")
        self.btn_prev.clicked.connect(self.find_prev)
        lay.addWidget(self.btn_prev)

        self.btn_next = self._mk_btn("▼", "下一个 (Enter)")
        self.btn_next.clicked.connect(self.find_next)
        lay.addWidget(self.btn_next)

        self.btn_close = self._mk_btn("✕", "关闭 (Esc)")
        self.btn_close.clicked.connect(self.hide_bar)
        lay.addWidget(self.btn_close)

        self.bar.adjustSize()
        self.bar.hide()

    def _mk_btn(self, text: str, tip: str) -> QToolButton:
        b = QToolButton(self.bar)
        b.setText(text)
        b.setToolTip(tip)
        b.setCursor(Qt.PointingHandCursor)
        b.setStyleSheet(
            "QToolButton { border: none; color: #606266; font-size: 12px; "
            "padding: 2px 5px; border-radius: 4px; }"
            "QToolButton:hover { background: #ECF5FF; color: #409EFF; }"
        )
        return b

    # ----------------------------------------------------------- 显隐 / 定位
    def show_bar(self):
        self._reposition()
        self.bar.show()
        self.bar.raise_()
        self.input.setFocus()
        self.input.selectAll()
        if self.input.text():
            self._do_search(self.input.text())

    def hide_bar(self):
        self.bar.hide()
        self._clear_highlights()
        self._matches = []
        self._cur = -1
        self.edit.setFocus()

    def toggle(self):
        if self.bar.isVisible():
            # 已开着：把焦点拉回搜索框（再次按 Ctrl+F 的常见预期）
            self.input.setFocus()
            self.input.selectAll()
        else:
            self.show_bar()

    def _reposition(self):
        # 贴右上角，避开纵向滚动条宽度
        margin = 8
        sb = self.edit.verticalScrollBar()
        sb_w = sb.width() if sb and sb.isVisible() else 0
        w = self.bar.sizeHint().width()
        h = self.bar.sizeHint().height()
        x = max(margin, self.edit.viewport().width() - sb_w - w - margin)
        self.bar.setGeometry(QRect(x, margin, w, h))

    # ----------------------------------------------------------- 搜索逻辑
    def _on_text_changed(self, text: str):
        self._do_search(text)

    def _do_search(self, text: str):
        self._matches = []
        self._cur = -1
        if not text:
            self._clear_highlights()
            self.count_lbl.setText("")
            return

        doc: QTextDocument = self.edit.document()
        cursor = QTextCursor(doc)
        flags = QTextDocument.FindFlags()  # 大小写不敏感（默认不带 FindCaseSensitively）
        while True:
            cursor = doc.find(text, cursor, flags)
            if cursor.isNull():
                break
            self._matches.append((cursor.selectionStart(), cursor.selectionEnd()))

        if self._matches:
            self._cur = 0
            self._refresh_highlights()
            self._scroll_to_current()
        else:
            self._clear_highlights()
        self._update_count()

    def find_next(self):
        if not self._matches:
            return
        self._cur = (self._cur + 1) % len(self._matches)
        self._refresh_highlights()
        self._scroll_to_current()
        self._update_count()

    def find_prev(self):
        if not self._matches:
            return
        self._cur = (self._cur - 1) % len(self._matches)
        self._refresh_highlights()
        self._scroll_to_current()
        self._update_count()

    def _refresh_highlights(self):
        doc = self.edit.document()
        selections = []
        for i, (start, end) in enumerate(self._matches):
            sel = QTextEdit.ExtraSelection()
            fmt = QTextCharFormat()
            fmt.setBackground(_HL_CURRENT if i == self._cur else _HL_ALL)
            if i == self._cur:
                fmt.setForeground(QColor("#FFFFFF"))
            sel.format = fmt
            c = QTextCursor(doc)
            c.setPosition(start)
            c.setPosition(end, QTextCursor.KeepAnchor)
            sel.cursor = c
            selections.append(sel)
        self.edit.setExtraSelections(selections)

    def _scroll_to_current(self):
        if not (0 <= self._cur < len(self._matches)):
            return
        start, _ = self._matches[self._cur]
        nav = QTextCursor(self.edit.document())
        nav.setPosition(start)          # 不带选区，避免和 extraSelection 配色打架
        self.edit.setTextCursor(nav)
        self.edit.ensureCursorVisible()

    def _clear_highlights(self):
        self.edit.setExtraSelections([])

    def _update_count(self):
        if not self._matches:
            self.count_lbl.setText("无结果" if self.input.text() else "")
        else:
            self.count_lbl.setText(f"{self._cur + 1}/{len(self._matches)}")

    # ----------------------------------------------------------- 事件过滤
    def eventFilter(self, obj, event):
        et = event.type()

        # 日志框：Ctrl+F 开搜索；尺寸变化时重定位浮层
        if obj is self.edit:
            if et == QEvent.KeyPress:
                if (event.key() == Qt.Key_F
                        and (event.modifiers() & Qt.ControlModifier)):
                    self.toggle()
                    return True
            elif et == QEvent.Resize:
                if self.bar.isVisible():
                    self._reposition()
                # 不消费 Resize，让日志框正常重排
                return False

        # 搜索输入框：Enter=下一个 / Shift+Enter=上一个 / Esc=关闭
        elif obj is self.input:
            if et == QEvent.KeyPress:
                key = event.key()
                if key in (Qt.Key_Return, Qt.Key_Enter):
                    if event.modifiers() & Qt.ShiftModifier:
                        self.find_prev()
                    else:
                        self.find_next()
                    return True
                if key == Qt.Key_Escape:
                    self.hide_bar()
                    return True
                if key == Qt.Key_Down:
                    self.find_next()
                    return True
                if key == Qt.Key_Up:
                    self.find_prev()
                    return True

        return super().eventFilter(obj, event)


def attach_log_search(text_edit: QTextEdit) -> "_LogSearchController":
    """给一个日志 QTextEdit 挂上 Ctrl+F 搜索浮层。返回 controller（一般无需持有）。

    幂等：同一个 text_edit 重复调用只会装一次（靠属性标记）。
    """
    if getattr(text_edit, "_log_search_attached", False):
        return getattr(text_edit, "_log_search_ctl", None)
    ctl = _LogSearchController(text_edit)
    text_edit._log_search_attached = True
    text_edit._log_search_ctl = ctl
    return ctl
