# -*- coding: utf-8 -*-
"""
gui/tdm_page.py
===============
TDM 模块（侧边栏第 3 位，介于 aCRF 与 TOC 之间）。

两块功能：
  1) 启动 TDM Pipeline —— 拉起用户桌面上部署的 TDM Pipeline 工具（与 SPAhub 同样部署到
     桌面）。用工具完成 ta / te / ti / tv / ts 等 sheet 的填写。
       · 为什么启动**桌面副本**而不是实体共享目录 Z:\\projects\\Z_PYTHON\\TDM\\tdm_automation：
         TDM 工具的字典缓存（tdm_lib/.cache/MEDRT.txt）是相对包目录写盘的，直接从只读
         共享盘调起会写缓存失败/多用户冲突；桌面副本是每用户私有拷贝，缓存落在自己那份里，
         与工具设计一致（其 user_state 也走 %LOCALAPPDATA%）。
       · 桌面路径**动态解析**（USERPROFILE + SHGetFolderPathW 兜底），不硬编码任何用户名。
  2) TX sheet 编辑器 —— 展示 <base>/00_source_data/<项目名>_Trial_Design_Model.xlsx 里的
     `TX` sheet：只展示**前 5 列**，**首行作为列名（表头，不可编辑）**，数据行可改，
     右上角「💾 保存文件」把（列名行 + 数据行）整体写回。

openpyxl 读/写走 QThread（沿用 aCRF annomap 编辑器的做法；TX 只有几行，无需子进程）。

信号：本页自带状态标签，不接 stepper 日志总线。update_path 由 main_window 推送。

v12.10.117：新增 TDM 侧边栏模块。
v12.10.118：① 启动改用 os.startfile（与用户双击等价，消除因子进程环境继承导致的启动变慢）；
            ② TX 编辑器只展示前 5 列 + 首行作列名（不可编辑）。
v12.10.120：TX sheet 旁增加「📖 使用说明」按钮，打开 TDM 侧填写指南 HTML。
v12.10.121：TX sheet 列名（表头）加粗。
v12.10.122：① TX 表格列宽按内容自适应+余量、可横向滚动、悬停显示完整内容、竖向分隔线加清晰、
            去掉列名描述文字；② 文件解析(glob 网络盘)+载入全部移入子线程，消除进入页面的迟滞。
v12.10.123：TX 表格 —— 表头/正文竖线粗细统一 1px；开自动换行+行高自适应彻底消除省略号
            （单元格含换行长文本）；最长列 Stretch 撑满整表宽度、消除右侧空白。
v12.10.124：TX 表格竖线彻底对齐 —— 关 gridline，表头/正文统一用 border-right 画竖线。
"""
import os
import glob

from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                               QFrame, QTableWidget, QTableWidgetItem, QAbstractItemView,
                               QHeaderView)
from PySide6.QtCore import Qt, QThread, Signal

from ui_utils import (show_dialog, primary_btn_style, success_btn_style,
                      scan_status_lbl_style)

# 桌面上部署的 TDM Pipeline（文件夹或 .lnk），文件夹内入口 vbs 的相对位置
_DESKTOP_ITEM_NAME = "TDM Pipeline"
_LAUNCH_VBS_REL = os.path.join("launcher", "tdm_pipeline_launch.vbs")
_TDM_XLSX_GLOB = "*_Trial_Design_Model.xlsx"   # <base>/00_source_data/ 下按此匹配
_TX_SHEET = "TX"
# v12.10.120：TX sheet 填写指南（外部 TDM 工具资源，位于 TDM 家目录下，单一常量登记）。
_TX_GUIDE_HTML = r"Z:\projects\Z_PYTHON\TDM\TX_Sheet_填写指南.html"


# =============================================================================
# 桌面路径解析（动态，不硬编码用户名）
# =============================================================================
def _resolve_desktop_dir():
    """返回当前用户桌面目录；优先 USERPROFILE\\Desktop，失败用 Win32 CSIDL 兜底。"""
    up = os.environ.get("USERPROFILE")
    candidate = os.path.join(up, "Desktop") if up else ""
    if candidate and os.path.isdir(candidate):
        return candidate
    # OneDrive 重定向等情况：走 SHGetFolderPathW
    try:
        import ctypes
        from ctypes import wintypes
        CSIDL_DESKTOPDIRECTORY = 0x0010
        buf = ctypes.create_unicode_buffer(wintypes.MAX_PATH)
        ctypes.windll.shell32.SHGetFolderPathW(None, CSIDL_DESKTOPDIRECTORY, None, 0, buf)
        if buf.value and os.path.isdir(buf.value):
            return buf.value
    except Exception:
        pass
    return candidate


# =============================================================================
# 启动线程（QThread + os.startfile，绝不在主线程阻塞；不在线程内调 UI）
# =============================================================================
class _TdmLaunchThread(QThread):
    status_signal = Signal(str)                 # 提示文本
    error_signal = Signal(str, str)             # 标题, 详情

    def run(self):
        desktop = _resolve_desktop_dir()
        item = os.path.join(desktop, _DESKTOP_ITEM_NAME)
        lnk = item + ".lnk"

        # 候选（按"最像用户理解的快捷方式"排序）
        # v12.10.118：全部改用 os.startfile（= ShellExecute，与用户双击完全一致）。
        #   旧版文件夹分支用 subprocess.Popen(["wscript","//B",vbs], creationflags=CREATE_NO_WINDOW)，
        #   会把 TDM GUI 作为 SPAhub 的子进程拉起 —— 继承 SPAhub 的进程环境（含可能的代理设置）
        #   与"无窗/分离"标志，跟用户手动双击时的干净环境不一致，导致启动明显更慢
        #   （TDM GUI 启动即联网查字典版本，MED-RT 探测超时 60s；环境不同会决定是"秒失败"还是
        #   "挂满超时"）。os.startfile 走系统默认处理器（.lnk→快捷方式解析、.vbs→wscript），
        #   与双击同路径同环境，从而与手动启动同速。
        try:
            # 1) 桌面上的 .lnk 快捷方式
            if os.path.isfile(lnk):
                os.startfile(lnk)  # type: ignore[attr-defined]
                self.status_signal.emit("✅ 已下发 TDM Pipeline 启动命令，窗口出现前请稍候…")
                return
            # 2) 桌面上的文件夹（部署副本）→ 找 launcher/tdm_pipeline_launch.vbs
            if os.path.isdir(item):
                vbs = os.path.join(item, _LAUNCH_VBS_REL)
                if not os.path.isfile(vbs):
                    hits = glob.glob(os.path.join(item, "**", "tdm_pipeline_launch.vbs"),
                                     recursive=True)
                    vbs = hits[0] if hits else ""
                if vbs and os.path.isfile(vbs):
                    os.startfile(vbs)  # type: ignore[attr-defined]  # = 双击 .vbs（ShellExecute→wscript）
                    self.status_signal.emit("✅ 已下发 TDM Pipeline 启动命令，窗口出现前请稍候…")
                    return
                # 找不到 vbs → 退而打开文件夹
                os.startfile(item)  # type: ignore[attr-defined]
                self.status_signal.emit("⚠ 未找到启动脚本，已为你打开 TDM Pipeline 目录。")
                return
            # 3) 桌面上是个文件（如重命名的 .vbs/.bat）
            if os.path.isfile(item):
                os.startfile(item)  # type: ignore[attr-defined]
                self.status_signal.emit("✅ 已下发 TDM Pipeline 启动命令，窗口出现前请稍候…")
                return
        except Exception as e:
            self.error_signal.emit("启动失败", f"拉起 TDM Pipeline 失败：{e}\n位置：{item}")
            return

        self.error_signal.emit(
            "未找到 TDM Pipeline",
            "在桌面上没找到 TDM Pipeline（文件夹或快捷方式）。\n"
            f"已检查：\n  {item}\n  {lnk}\n\n"
            "请确认已把 TDM Pipeline 部署到桌面（与 SPAhub 同样的部署方式）。")


# =============================================================================
# TX sheet 读 / 写线程（openpyxl）
# =============================================================================
class _TxLoadThread(QThread):
    finished_signal = Signal(bool, object)   # ok, payload(dict)

    def __init__(self, base_path, parent=None):
        super().__init__(parent)
        self.base_path = base_path

    def run(self):
        # v12.10.122：解析 TDM xlsx（在 00_source_data 网络盘 glob）+ 载入 TX，全部放子线程，
        # 避免"进入 TDM 页 / 切项目"时在主线程做网络盘 IO 造成轻微迟滞。
        try:
            if not self.base_path or not os.path.isdir(self.base_path):
                self.finished_signal.emit(False, {"reason": "no_base"})
                return
            src = os.path.join(self.base_path, "00_source_data")
            if not os.path.isdir(src):
                self.finished_signal.emit(False, {"reason": "no_file"})
                return
            hits = [h for h in glob.glob(os.path.join(src, _TDM_XLSX_GLOB))
                    if not os.path.basename(h).startswith("~$")]
            if not hits:
                self.finished_signal.emit(False, {"reason": "no_file"})
                return
            xlsx = hits[0]

            import openpyxl
            wb = openpyxl.load_workbook(xlsx, data_only=True, read_only=True)
            if _TX_SHEET not in wb.sheetnames:
                wb.close()
                self.finished_signal.emit(False, {"reason": "no_sheet", "xlsx": xlsx})
                return
            ws = wb[_TX_SHEET]
            rows = [list(r) for r in ws.iter_rows(values_only=True)]
            wb.close()
            # 去掉尾部全空行
            while rows and all(c is None or str(c).strip() == "" for c in rows[-1]):
                rows.pop()
            max_col = max((len(r) for r in rows), default=1)
            grid = [["" if (j >= len(r) or r[j] is None) else str(r[j]) for j in range(max_col)]
                    for r in rows]
            self.finished_signal.emit(True, {"grid": grid, "max_col": max_col, "xlsx": xlsx})
        except Exception as e:
            self.finished_signal.emit(False, {"reason": "error", "msg": str(e)})


class _TxSaveThread(QThread):
    finished_signal = Signal(bool, str)      # ok, 错误信息

    def __init__(self, path, grid, parent=None):
        super().__init__(parent)
        self.path = path
        self.grid = grid

    def run(self):
        try:
            import openpyxl
            wb = openpyxl.load_workbook(self.path)   # 保留其它 sheet 与公式
            if _TX_SHEET not in wb.sheetnames:
                wb.close()
                self.finished_signal.emit(False, f"该 TDM 文件里没有名为「{_TX_SHEET}」的 sheet。")
                return
            ws = wb[_TX_SHEET]
            # 先清空原 TX 已用区域的值，再整体写回（值覆盖；不动其它 sheet）
            for row in ws.iter_rows():
                for cell in row:
                    cell.value = None
            for i, r in enumerate(self.grid):
                for j, v in enumerate(r):
                    ws.cell(row=i + 1, column=j + 1).value = (v if v != "" else None)
            wb.save(self.path)
            wb.close()
        except PermissionError:
            self.finished_signal.emit(False, "文件被占用（可能正在 Excel 中打开），请关闭后重试。")
            return
        except Exception as e:
            self.finished_signal.emit(False, str(e))
            return
        self.finished_signal.emit(True, "")


# =============================================================================
# 主页面
# =============================================================================
class TDMWidget(QWidget):
    """TDM 页：上=启动 TDM Pipeline，下=TX sheet 编辑器。"""

    def __init__(self):
        super().__init__()
        self.base_path = ""
        self._tdm_xlsx = ""       # 解析到的 TDM 文件绝对路径
        self._tx_headers = []     # v12.10.118：TX 首行=列名（表头，不参与编辑），保存时原样写回
        self._load_thread = None
        self._save_thread = None
        self._launch_thread = None
        self._setup_ui()

    def _show_msg(self, title, text, msg_type="info", path=None):
        return show_dialog(self, title, text, msg_type, path=path)

    # ------------------------- UI -------------------------
    def _setup_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(10)

        # ---------- 上：启动区 ----------
        launch_frame = QFrame()
        launch_frame.setStyleSheet(
            "background-color: #FFFFFF; border: 1px solid #E4E7ED; border-radius: 6px;")
        ll = QVBoxLayout(launch_frame)
        ll.setContentsMargins(18, 16, 18, 16)
        ll.setSpacing(10)

        row = QHBoxLayout()
        self.launch_btn = QPushButton("📂 打开 TDM Pipeline")
        self.launch_btn.setStyleSheet(primary_btn_style())
        self.launch_btn.setCursor(Qt.PointingHandCursor)
        self.launch_btn.clicked.connect(self._on_launch)
        row.addWidget(self.launch_btn)
        self.launch_status = QLabel("")
        self.launch_status.setStyleSheet(scan_status_lbl_style(color="#409EFF"))
        row.addWidget(self.launch_status)
        row.addStretch()
        ll.addLayout(row)

        desc = QLabel("使用 TDM Pipeline 工具完成 ta、te、ti、tv、ts sheet 的填写。")
        desc.setStyleSheet("color: #606266; font-size: 13px; border: none;")
        desc.setWordWrap(True)
        ll.addWidget(desc)

        root.addWidget(launch_frame)

        # ---------- 下：TX 编辑器 ----------
        editor_frame = QFrame()
        editor_frame.setStyleSheet(
            "background-color: #FFFFFF; border: 1px solid #E4E7ED; border-radius: 6px;")
        el = QVBoxLayout(editor_frame)
        el.setContentsMargins(18, 14, 18, 14)
        el.setSpacing(8)

        head = QHBoxLayout()
        title = QLabel("📋 TDM · TX sheet")
        title.setStyleSheet("font-size: 14px; font-weight: bold; color: #303133; border: none;")
        head.addWidget(title)
        self.path_lbl = QLabel("(未选择完整项目路径)")
        self.path_lbl.setStyleSheet("color: #909399; font-size: 12px; border: none;")
        head.addWidget(self.path_lbl)
        head.addStretch()
        # v12.10.120：TX sheet 旁「使用说明」——打开 TDM 侧的填写指南 HTML（外部 TDM 工具资源，
        # 路径作为单一常量登记，同 crt_vars/TDM 家目录的外部耦合约定；os.startfile 交默认浏览器）。
        self.guide_btn = QPushButton("📖 使用说明")
        self.guide_btn.setStyleSheet(
            "QPushButton{background:#F0F9EB; color:#67C23A; border:1px solid #C2E7B0; "
            "padding:4px 10px; border-radius:4px; font-size:12px; font-weight:bold;}"
            "QPushButton:hover{background:#67C23A; color:#FFFFFF;}")
        self.guide_btn.setCursor(Qt.PointingHandCursor)
        self.guide_btn.setToolTip("打开 TX sheet 填写指南：\n" + _TX_GUIDE_HTML)
        self.guide_btn.clicked.connect(self._open_tx_guide)
        head.addWidget(self.guide_btn)
        self.reload_btn = QPushButton("🔄 重新载入")
        self.reload_btn.setStyleSheet(scan_status_lbl_style())
        self.reload_btn.setStyleSheet(
            "QPushButton{background:#ECF5FF; color:#409EFF; border:1px solid #B3D8FF; "
            "padding:4px 10px; border-radius:4px; font-size:12px; font-weight:bold;}"
            "QPushButton:hover{background:#409EFF; color:#FFFFFF;}")
        self.reload_btn.clicked.connect(self._reload)
        head.addWidget(self.reload_btn)
        self.save_btn = QPushButton("💾 保存文件")
        self.save_btn.setStyleSheet(success_btn_style())
        self.save_btn.setCursor(Qt.PointingHandCursor)
        self.save_btn.clicked.connect(self._on_save)
        head.addWidget(self.save_btn)
        el.addLayout(head)

        self.table = QTableWidget()
        # v12.10.124：彻底对齐竖线 —— 关闭内置 gridline，表头与正文都用 border-right
        # 画竖线（同一盒模型、同一列右边缘），不再出现 gridline 与 border-right 差 1px 的错位；
        # 正文另加浅色 border-bottom 作行分隔。
        self.table.setShowGrid(False)
        self.table.setStyleSheet(
            "QTableWidget{background:#FFFFFF; border:1px solid #E4E7ED; border-radius:4px;}"
            "QTableWidget::item{color:#303133; border-right:1px solid #C0C4CC; "
            "border-bottom:1px solid #EBEEF5;}"
            "QTableWidget::item:selected{background:#C6E2FF; color:#303133;}"
            "QHeaderView::section{background:#F5F7FA; color:#606266; border:none; "
            "border-right:1px solid #C0C4CC; border-bottom:1px solid #C0C4CC; padding:4px; font-weight:bold;}")
        self.table.setEditTriggers(
            QAbstractItemView.DoubleClicked | QAbstractItemView.SelectedClicked
            | QAbstractItemView.EditKeyPressed | QAbstractItemView.AnyKeyPressed)
        # v12.10.123：开自动换行 —— TX 单元格含换行/长文本（如 Shell_Title 一格两行），
        # 配合行高自适应完整显示，不再省略号。列宽策略在 _on_tx_loaded 里按内容分配。
        self.table.setWordWrap(True)
        self.table.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.table.verticalHeader().setVisible(True)
        el.addWidget(self.table, 1)

        self.status_lbl = QLabel("就绪")
        self.status_lbl.setStyleSheet("font-size: 12px; color: #909399; border: none;")
        el.addWidget(self.status_lbl)

        root.addWidget(editor_frame, 1)

        self._set_editor_enabled(False)

    def _set_editor_enabled(self, on):
        self.table.setEnabled(on)
        self.save_btn.setEnabled(on)
        self.reload_btn.setEnabled(on)

    # ------------------------- 启动 TDM Pipeline -------------------------
    def _on_launch(self):
        if self._launch_thread is not None and self._launch_thread.isRunning():
            self._show_msg("提示", "TDM Pipeline 正在启动中，请稍候…", "info")
            return
        self.launch_status.setText("⏳ 正在启动 TDM Pipeline…")
        th = _TdmLaunchThread()
        th.status_signal.connect(self._on_launch_status)
        th.error_signal.connect(self._on_launch_error)
        th.finished.connect(lambda: setattr(self, "_launch_thread", None))
        self._launch_thread = th
        th.start()

    def _on_launch_status(self, msg):
        self.launch_status.setText(msg)

    def _on_launch_error(self, title, detail):
        self.launch_status.setText("")
        self._show_msg(title, detail, "warning")

    # ------------------------- 路径推送 / 载入 -------------------------
    def update_path(self, base_path, p3=None, p4=None):
        self.base_path = base_path or ""
        self._resolve_and_load()

    def refresh_caches(self):
        self._resolve_and_load()

    def _resolve_and_load(self):
        self.table.clearContents()
        self.table.setRowCount(0)
        self.table.setColumnCount(0)
        self._tx_headers = []
        self._tdm_xlsx = ""
        self._set_editor_enabled(False)

        if not self.base_path:
            self.path_lbl.setText("(未选择完整项目路径)")
            self.status_lbl.setText("就绪")
            return
        # 已有载入线程在跑就不重复启动
        if self._load_thread is not None and self._load_thread.isRunning():
            return

        # v12.10.122：解析（glob 网络盘）+ 载入全部交子线程，主线程不做网络 IO
        self.path_lbl.setText("(正在查找 TDM 文件…)")
        self.status_lbl.setText("⏳ 正在查找并载入 TX sheet…")
        th = _TxLoadThread(self.base_path)
        th.finished_signal.connect(self._on_tx_loaded)
        th.finished.connect(lambda: setattr(self, "_load_thread", None))
        self._load_thread = th
        th.start()

    def _open_tx_guide(self):
        # v12.10.120：打开 TX sheet 填写指南 HTML（默认浏览器）。文件不在时给出清晰提示。
        if os.path.isfile(_TX_GUIDE_HTML):
            try:
                os.startfile(_TX_GUIDE_HTML)  # type: ignore[attr-defined]
            except Exception as e:
                self._show_msg("打开失败", f"无法打开使用说明：{e}\n{_TX_GUIDE_HTML}", "error")
        else:
            self._show_msg("未找到使用说明",
                           "没找到 TX sheet 填写指南文件：\n" + _TX_GUIDE_HTML +
                           "\n\n请确认 TDM 工具目录下已放置该 HTML。", "warning")

    def _reload(self):
        if self._save_thread is not None and self._save_thread.isRunning():
            self._show_msg("提示", "正在保存，请稍候…", "info")
            return
        self._resolve_and_load()

    def _on_tx_loaded(self, ok, payload):
        if not ok:
            reason = payload.get("reason") if isinstance(payload, dict) else None
            if reason == "no_base":
                self.path_lbl.setText("(未选择完整项目路径)")
                self.status_lbl.setText("就绪")
                return
            if reason == "no_file":
                self.path_lbl.setText("(未找到 TDM 文件)")
                self.status_lbl.setText("未在 00_source_data 下找到 *_Trial_Design_Model.xlsx。")
                return
            if reason == "no_sheet":
                self._tdm_xlsx = payload.get("xlsx", "")
                self.path_lbl.setText(os.path.basename(self._tdm_xlsx) if self._tdm_xlsx else "(未找到 TX)")
                self.status_lbl.setText(f"该 TDM 文件里没有名为「{_TX_SHEET}」的 sheet。")
                return
            msg = payload.get("msg", "载入失败") if isinstance(payload, dict) else str(payload)
            self.status_lbl.setText(f"❌ 载入失败：{msg}")
            self._show_msg("载入失败", str(msg), "error")
            return

        self._tdm_xlsx = payload.get("xlsx", "")
        self.path_lbl.setText(os.path.basename(self._tdm_xlsx) if self._tdm_xlsx else "")
        grid = payload.get("grid", [])
        # v12.10.118：只展示前 5 列；首行作为列名（表头，不可编辑），数据从第 2 行起。
        MAX_COLS = 5
        if not grid:
            self.table.setColumnCount(0)
            self.table.setRowCount(0)
            self._tx_headers = []
            self.status_lbl.setText("⚠ TX sheet 为空。")
            return
        n_col = min(max((len(r) for r in grid), default=1), MAX_COLS)
        # 首行 → 列名
        self._tx_headers = [(grid[0][j] if j < len(grid[0]) else "") for j in range(n_col)]
        data_rows = grid[1:]
        self.table.setColumnCount(n_col)
        self.table.setRowCount(len(data_rows))
        self.table.setHorizontalHeaderLabels(
            [h if str(h).strip() else self._col_letter(j)
             for j, h in enumerate(self._tx_headers)])
        for i, r in enumerate(data_rows):
            for j in range(n_col):
                val = r[j] if j < len(r) else ""
                it = QTableWidgetItem(val)
                it.setToolTip(val)          # v12.10.122：悬停显示完整内容
                self.table.setItem(i, j, it)
        # v12.10.123：内容最长的一列 Stretch 撑满剩余宽度（消除右侧空白），其余按内容自适应；
        # 行高自适应 —— 配合自动换行让含换行/长文本的单元格完整显示，不再省略号。
        hdr = self.table.horizontalHeader()
        if data_rows:
            col_len = [max((len(self.table.item(i, j).text()) if self.table.item(i, j) else 0)
                           for i in range(len(data_rows))) for j in range(n_col)]
            stretch_col = max(range(n_col), key=lambda j: col_len[j])
        else:
            stretch_col = n_col - 1
        for j in range(n_col):
            hdr.setSectionResizeMode(
                j, QHeaderView.Stretch if j == stretch_col else QHeaderView.ResizeToContents)
        self.table.resizeRowsToContents()
        self._set_editor_enabled(True)
        # v12.10.122：去掉列名描述性文字，只报行数
        self.status_lbl.setText(f"✅ 已载入 {len(data_rows)} 行数据。")

    @staticmethod
    def _col_letter(idx0):
        s = ""
        n = idx0 + 1
        while n > 0:
            n, r = divmod(n - 1, 26)
            s = chr(65 + r) + s
        return s

    # ------------------------- 保存 -------------------------
    def _grid_from_table(self):
        rows = self.table.rowCount()
        cols = self.table.columnCount()
        grid = []
        for i in range(rows):
            row = []
            for j in range(cols):
                it = self.table.item(i, j)
                row.append(it.text() if it is not None else "")
            grid.append(row)
        return grid

    def _on_save(self):
        if not self._tdm_xlsx or not os.path.isfile(self._tdm_xlsx):
            self._show_msg("错误", "TDM 文件不存在或未载入，无法保存。", "error")
            return
        if self._save_thread is not None and self._save_thread.isRunning():
            self._show_msg("提示", "正在保存，请稍候…", "info")
            return

        # v12.10.118：表格里只有数据行（首行列名不在表内），写回时把列名行拼回最前面
        grid = [list(self._tx_headers)] + self._grid_from_table()
        self.save_btn.setEnabled(False)
        self.status_lbl.setText("⏳ 正在写回 TX sheet…")
        th = _TxSaveThread(self._tdm_xlsx, grid)
        th.finished_signal.connect(self._on_tx_saved)
        th.finished.connect(lambda: setattr(self, "_save_thread", None))
        self._save_thread = th
        th.start()

    def _on_tx_saved(self, ok, err):
        self.save_btn.setEnabled(True)
        if ok:
            self.status_lbl.setText("✅ 已整体写回 TX sheet。")
            self._show_msg("已保存", f"TX sheet 已写回：\n{self._tdm_xlsx}", "info",
                           path=self._tdm_xlsx)
        else:
            self.status_lbl.setText(f"❌ 保存失败：{err}")
            self._show_msg("保存失败", str(err), "error")
