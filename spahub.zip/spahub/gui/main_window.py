# -*- coding: utf-8 -*-

"""
gui/main_window.py
==================
主窗口 SASEGGUI 以及 SAS Enterprise Guide / VS Code 启动辅助。

职责划分：
  - 左侧侧边栏：页面路由（Home / aCRF / TOC / SDTM / ADaM / TFLs / M5 / Shortcut）
  - 顶部：四级项目路径下拉框（projects → 项目 → 子项目 → 运行目录）+ Clear
          + 🚀 Launch SAS EG + 💻 Launch VS Code
  - 中央 QStackedWidget：按侧边栏选中项切换不同页面控件
  - Home 页：根据已选路径，在网格中展示每个子目录的文件清单
  - 底部状态栏：状态文本

主要辅助函数：
  - _find_saseg_exe()            定位 SEGuide.exe
  - _find_code_exe()             v12.10.55 新增：定位 VS Code (Code.exe)
  - _saseg_is_running()          tasklist 查询 EG 是否运行
  - open_with_saseg_or_default() Home 页文件点击入口（.sas7bdat 走 EG，其他走系统默认）
  - LaunchSASEGThread            子线程拉起 EG（避免阻塞主线程）
  - LaunchVSCodeThread           v12.10.55 新增：子线程拉起 VS Code 并打开当前 csr 工作区

变更摘要 — v12.10.51 / v12.10.52 / v12.10.53 / v12.10.54 / v12.10.55：
  - v12.10.51（已撤）：LaunchSASEGThread 加 base_path 参数,扫 06_programs 下最新 .sas
    传给 SEGuide.exe，意图让 EG 启动后"服务器文件"面板自动展开到该目录。
  - v12.10.52（已撤）：picked_sas 传给 EG 前转 Linux 路径,意图让 EG 走 SAS Server 通道。
  - v12.10.53（已撤）：SDTM 模块同步 v12.10.52 路径转换。
  - v12.10.54：实测发现 SEGuide.exe 命令行参数无论传 Z:\\ 还是 /u01/.../ Linux 路径
    都走 **Windows 客户端通道**，"服务器文件"面板不会真正展开（仅"跳动一下"然后
    停在最上级）。撤销 v12.10.51 ~ v12.10.53 的所有 EG 改动，回到光秃秃启动行为
    + 保留"不短路"逻辑（EG 已运行时再点按钮会激活主窗口到前台）。

  - v12.10.55（当前）：新增「💻 Launch VS Code」按钮，与「🚀 Launch SAS EG」并排。
    4 级路径齐全时把 csr 路径作为 VS Code 工作区打开（`code <csr_path>`）— 左侧
    Explorer 立即展开到完整目录树（含 06_programs/061_data 多层子目录）。用户可
    在 VS Code 内激活 SAS 扩展走 §7 工作流（Sign In + Ctrl+Alt+U）。详 vscode-sas-setup
    skill §14。

  - v12.10.73：Home 页顶部新增恒瑞品牌 banner（_HomeBannerWidget）。
    * 背景图 resources/home_banner.png（恒瑞 banner 裁切到"杰出雇主"红牌左侧，
      保留实验场景 + 科技 HUD），固定 150px 高，cover 缩放居中裁切铺满、不变形。
    * 左上角叠 resources/home_logo.png 白色恒瑞 logo（独立 QLabel 浮层，固定 240px
      宽，不随背景拉伸糊化）。
    * 插在 Home 页文件网格上方；资源走 bundle_root()/resources/，图缺失时 banner
      自动隐藏，不影响 Home 页其余功能。

  - v12.10.74（当前）：三项 UI 调整。
    1) banner 升级为「所有页面共享」的顶部 header（_HeaderBanner 取代 _HomeBannerWidget）：
       banner 作背景，恒瑞 logo 在上、四级下拉框 + Clear + Launch 按钮整行嵌在 logo
       下方（背景嵌在控制行后面）；header 位于 stack 之上 → 切到任何模块都常驻可见。
       原白色 #TopBar 取消。
    2) 隐藏 M5 模块（从 self.pages 移除；侧边栏与 stack 同步不再生成）。
    3) 高对比「蓝 / 白」配色：侧边栏改深海军蓝实底 + 浅色字 + 亮蓝选中（左侧高亮条），
       解决低分屏上侧边栏与主内容糊成一片、选中浅蓝近乎白的问题。详 _apply_global_style。

  - v12.10.75（当前）：
    * 整体改名 SPAhub → SPA Platform（窗口标题；桌面快捷方式见 resources/create_shortcut.py）。
    * 配色再调：侧边栏改「浅蓝铺底 + 深蓝选中」（v12.10.74 深海军蓝偏暗），浅蓝底 +
      2px 蓝右边框与主内容分隔；选中深蓝实底 + 白字 + 亮蓝左条。
    * 顶部两个 Launch 按钮改深蓝实底 + 半透明白描边，叠在蓝色 banner 上对比更强、不重合。

  - v12.10.76（当前）：
    * 配色定为「C · 钢蓝沉稳」（用户从 4 套预览选定）：主内容冷中性灰 #EDF1F5（去掉"粉白"），
      侧栏哑光钢蓝 #DCE6F1，选中 / Launch / 强调钢蓝 #3D6489。详 _apply_global_style。
    * Shortcuts 应用按钮长名称折两行显示（_wrap_btn_label，按钮 96×100），不再截断；
      Pinnacle 21 Enterprise 图标换最新 png。
    * 开屏 splash 重设计为 SPA Platform（深蓝版，六边形标 + Automation 全称），见
      resources/splash.png；快捷方式描述同步 Analytics→Automation。

  - v12.10.77（当前）：顶部 banner 四边羽化。
    * _HeaderBanner.paintEvent 改为：cover 图画进透明缓冲后，用四边 alpha 线性渐变
      （DestinationIn）把上下左右边缘淡出，再叠到页面底色上 → banner 不再是生硬矩形，
      边缘柔和溶入背景、像向外延展。羽化宽度 FEATHER_X=48 / FEATHER_Y=30，淡出底色
      feather_bg 默认 #EDF1F5（与 scheme C 主内容一致）。logo / 控制行是上层子控件，
      不受羽化影响仍清晰。

  - v12.10.78（当前）：侧边栏配色改「皇家蓝·深选中」，与顶部 banner 同源（banner 主蓝
    ~#2555D1）。原 v12.10.76 钢蓝偏灰、与饱和蓝 banner 不统一；现侧栏浅蓝紫底 #DEE7F8 +
    藏皇家蓝选中 #4A6FA5 + 白字，Launch/强调同族 #4A6FA5。主内容仍 #EDF1F5。详 _apply_global_style。

  - v12.10.79（当前）：协调性收尾三项。
    1) Home 操作按钮归入主题：系统文件复制→皇家蓝实底主按钮 #4A6FA5；刷新文件清单→
       同族皇家蓝描边幽灵按钮；详情→收敛琥珀 #C49A4A（唯一暖色提示）。去掉原蓝/绿/橘散色。
    2) 顶部四级下拉框由写死 180px 改弹性宽度（min 120 + 横向 Expanding），避免总宽超出
       banner 把「Launch VS Code」挤截断；宽屏自适应、窄屏收缩，两个 Launch 始终完整。
    3) 侧边栏关闭横向滚动条（ScrollBarAlwaysOff），去掉底部多余的横向滚动条。

  - v12.10.80（当前）：
    1) 顶部 header 重排：两个 Launch 按钮上移到 logo 行右侧（与 logo 同高），下方控制行整行
       让给 4 个下拉框 + Clear；下拉框改 Expanding（min140/max360）平均铺满、舒展不再被挤压。
       _HeaderBanner 暴露 self.logo_row 供外部添加按钮。
    2) 四级路径记忆：_save_last_selection / _load_last_selection / _apply_restore_selection，
       选择写入 %LOCALAPPDATA%\\SPAhub\\logs\\last_selection.json；启动第 1 级就绪后
       （_on_dropdown_scanned 末尾）逐级回放上次选择，目录已不存在则在该层停止。Clear 会
       重置记忆为仅 projects。

  - v12.10.82（当前）：合并交付包（含 v80 的 header 重排 + 四级路径记忆、v81 的全局按钮统一）。
    本文件内容同 v80；另随包含 ui_utils.py（按钮统一，success 绿由 #348A60 调亮为 #3F9A6E）
    与 7 个模块。确保 #1（Launch 上移/下拉框舒展）、#3（目录记忆）、#2（按钮统一）一次覆盖到位。

  - v12.10.83（当前）：修复"目录记忆重开仍回到 projects"。
    根因：启动时自动选 projects → _on_combo_activated(0) → 末尾 _save_last_selection() 先把
    磁盘记忆覆盖成 ["projects"]，之后 _apply_restore_selection() 才去读磁盘 → 读到的已是
    projects，回放不出更深层级。
    修法：在 __init__（任何 combo 级联之前）就把记忆预读进内存 self._restore_pending；
    _apply_restore_selection() 改用内存值而非重读磁盘，绕过启动覆盖。已用模拟级联单测验证：
    会话1 存 projects/HRS9821_102/csr_01，会话2 重开回放定位到同一 csr。

  - v12.10.84（当前）：配色微调（全局）。
    1) 主体皇家蓝由偏暗 navy #2C3848 调亮为 #4A6FA5（hover #6385B6 / pressed #3A5687），
       同步应用到按钮、Launch、侧栏选中、Home 按钮、对话框，整体更接近正统皇家蓝。
    2) 绿色统一：所有"运行脚本"按钮取消蓝绿奇偶交替，与全局"打开/成功"绿统一为 #3F9A6E；
       GitLab 对话框等内联绿按钮一并归一（详见 ui_utils success + 各模块）。

  - v12.10.85（当前）：应用户要求，侧栏选中项与 Launch SAS EG / VS Code 按钮**保持上一版深 navy
    #2C3848**（不跟随 v84 的调亮）；其余主体按钮（运行/推送/Home/对话框等）仍用新皇家蓝 #4A6FA5、
    成功/打开/运行脚本仍用统一绿 #3F9A6E。仅改 _apply_global_style 的 item:selected 与 #LaunchBtn。

  - v12.10.86（当前）：侧栏选中色加深为 #1F2933；功能界面按钮整体调浅一档
    （主体皇家蓝 base #3A5687→#4A6FA5 / hover #6385B6 / pressed #3A5687），全局生效；
    Launch SAS EG / VS Code 仍 #2C3848 不动。层次："侧栏最深 #1F2933 → Launch navy #2C3848
    → 功能按钮更浅 #4A6FA5"。

  - v12.10.97（当前）：应用户要求，Launch SAS EG / VS Code 两按钮由深 navy #2C3848 改为
    **白底**（#FFFFFF / 文字 #303841 / 边框 #CBD2DC / hover 皇家蓝 #4A6FA5），与 Clear 及
    顶部其它按钮统一。仅改 _apply_global_style 的 #LaunchBtn。
    （同版另含 setup.xlsx 补行改"按 setup_template 模板位置插入"，见 modules/sdtm_common.py 等。）

  - v12.10.98（当前）：修复"首次进入 TFLs 模块卡顿 1s+"。根因是懒加载触发后同一帧内串行
    完成 ①TFLsWidget 构造 5 个 form ②update_path 触发的网络盘同步 IO（meta_form 读
    setup.xlsx + 各 form glob/listdir/git）。两段叠加在网络盘环境冻结主线程 1s+。
    修法（1+3 组合）：
      ③ _switch_page 的 TFLs 分支改为"下一帧构造"——先显示"⏳ 正在加载"占位（点击即时
         响应），再用 QTimer.singleShot(0) 把 TFLsWidget() 构造 + update_path 推到下一帧
         （新增 _build_tfls_widget_deferred）。
      ① TFLsWidget.update_path 把 5 个 form 的 update_paths 由"同帧串行"改为"逐帧分散
         调度"（gui/tfls_stepper.py 新增 _dispatch_form_updates + token 失效保护）：
         默认步骤 PDT 当帧填充，其余 4 个 form 跨帧逐个填充，帧间让事件循环喘气。
      各 form 内部逻辑零改动（其 IO 与 setText 深度交织，移子线程会违反"QThread 不碰
      UI"红线），仅把"一次性冻结"打散为"渐进填充"，总 IO 时间不变但 UI 不再假死。
      用户感知：点 TFLs 秒开 + 路径渐进填充，第二次进入仍是纯切栈。

  - v12.10.89（当前）：①Banner 羽化宽度减半（FEATHER_X 48→24 / FEATHER_Y 30→15），
    虚化边缘更利落。②4 级路径下拉框字号 13→15px，与步骤名称（stepper 15px）相近。

  - v12.10.91（当前）：①Banner 羽化再减半（FEATHER_X 24→12 / FEATHER_Y 15→7）。
    ②4 级下拉框字号 15→16px，与步骤名"01 PDT Gen"视觉等大。
    ③chevron 步骤条改"等宽分槽 + 横向占满"（ui_utils.ChevronStepBar 改 Expanding；
    各 stepper 去掉步骤条后的 addStretch），各段等间隔铺满整栏，与旧版一致。


  - v12.10.92：侧边栏改"深色效果"——深 navy 竖向渐变底（#2D3748→#1A202C）+ 浅色文字
    #CBD5E0；选中项"点击变浅"为亮皇家蓝 #4A6FA5 + 白字 + 浅蓝左条 #8AA3C9；hover #3A4759。
    侧栏宽度 160→210px（约 +4% 窗宽占比）。仅改 _apply_global_style 的 QListWidget 段 + setFixedWidth。


  - v12.10.93：全局轻度降饱和（×0.70）。主蓝族/侧栏族/Launch/成功绿族/危险红·警告橙
    按钮 + banner 兜底色统一按 HSL 饱和度×0.70 调柔（如 #3A61D8→#4A6FA5、#4CAF6E→#3F9A6E、
    #C0392B→#B85450、侧栏 #26396E→#2D3748 等）；banner 图用 ImageEnhance.Color(0.70) 同步降饱和。
    日志语义色（执行中/成功/警告/错误文字 #409EFF/#67C23A/#E6A23C/#F56C6C 及浅底高亮）与中性灰白不变。

  - v12.10.94：主页面蓝按钮 / chevron 选中 / 侧栏选中统一为灰蓝 #4A6FA5
    （hover #6385B6 / pressed #3A5687）。原 v93 的 #526DC0 在白底上视觉偏亮，本次再向"灰"
    推一档，与深色侧栏选中观感一致。Launch 仍 navy #2C3848；绿/红/警告橙、banner 与日志语义色不变。

  - v12.10.95：整体配色改"方案B · 雾蓝/石板"。主蓝 #4A6FA5、Launch #2C3848、
    侧栏底 #2D3748→#1A202C、文字 #CBD5E0、左条 #8AA3C9、hover #3A4759；
    成功绿 #3F9A6E、危险红 #B85450、警告橙 #C49A4A。各色族 hover/pressed 同步成新族。
    banner 图保留 v93 降饱和版（本次不重新发图）。日志语义色与中性灰白不变。
  - v12.10.96（当前）：侧边栏改回"浅底深字、深蓝选中"，配色采用方案B 雾蓝家族保持协调：
    底色 #DDE5EF（浅雾蓝）、文字 #2C3848（深石板）、选中 #3A5687（深蓝）+ 白字 +
    左条 #6385B6；hover #CFDAE8；右侧细分隔线 #C5CDD8。其他配色（按钮/chevron/banner）
    沿用 v95 方案B 不变。
"""
import sys
import os
import subprocess
from PySide6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                               QLabel, QPushButton, QComboBox, QStackedWidget,
                               QListWidget, QListWidgetItem, QScrollArea, QGridLayout, QFrame,
                               QCompleter, QSizePolicy)
from PySide6.QtCore import Qt, QSize, QThread, Signal, QTimer
from PySide6.QtGui import QPixmap, QPainter, QPainterPath, QColor, QLinearGradient, QBrush  # v12.10.73/74/77：顶部 banner（cover 绘制 + 四边羽化）

from modules.toc_gen import TOCGenWidget
from gui.shortcuts import ShortcutWidget
from gui.tfls_stepper import TFLsWidget
from gui.acrf_stepper import aCRFWidget
from gui.sdtm_stepper import SdtmWidget
from ui_utils import show_dialog, scan_status_lbl_style


# ============================================================================
# SAS EG 启动子线程
# ============================================================================
class LaunchSASEGThread(QThread):
    """后台启动 SAS EG，避免阻塞主线程。

    v12.10.54：撤销 v12.10.51~v12.10.53 的"传 .sas 文件让 EG 服务器面板自动
    展开"尝试。实测结论（用户实机验证）：SEGuide.exe 命令行参数无论收
    Z:\\ 还是 /u01/.../ Linux 路径，都走 **Windows 客户端通道**打开文件，
    EG 内部"服务器文件"面板**不会**真正展开到该路径对应的服务器目录 —
    只会"跳动一下"（解析失败），仍停在最上级。这与 v12.10.3 注释里的描述
    不符。

    要让 EG 服务器面板展开到指定 Linux 目录，必须从 EG 内部「服务器→
    浏览」手工操作；命令行无法触发同样的代码路径。

    本版回退后行为：
      - 光秃秃启动 EG 主窗口（不传任何文件参数）
      - 保留 v12.10.51 引入的"不短路"逻辑：EG 已运行时再次点按钮也 Popen，
        single-instance 模式会把现有 EG 窗口激活到前台，便于用户切回。
    """
    status_signal = Signal(str)
    error_signal = Signal(str)

    def run(self):
        target_exe = _find_saseg_exe()
        already_running = _saseg_is_running()

        try:
            if target_exe:
                subprocess.Popen([target_exe], shell=False)
            else:
                subprocess.Popen("SEGuide.exe", shell=True)
        except Exception as e:
            self.error_signal.emit(
                "启动 SAS EG 失败: " + str(e) + chr(10) + "请检查软件是否已正确安装。"
            )
            return

        if already_running:
            self.status_signal.emit("🚀 SAS EG 已在后台运行；已激活主窗口到前台。")
        elif target_exe:
            self.status_signal.emit("🚀 已发起 SAS EG 启动指令（约 5-10s 后显示主窗口）。")
        else:
            self.status_signal.emit("尝试通过系统环境变量启动 SAS Enterprise Guide。")


# ============================================================================
# v12.10.55 新增：VS Code 启动子线程
# ============================================================================
class LaunchVSCodeThread(QThread):
    """后台启动 VS Code 并将 csr 路径作为工作区打开，避免阻塞主线程。

    v12.10.55 设计要点：
      - VS Code 命令行 `code <folder>` 是稳定接口（与 SEGuide.exe 不同），传入
        文件夹路径会作为工作区打开，左侧 Explorer 自动展开到该目录。
      - 本线程只做"打开工作区"这一件事 — SAS 扩展的 Sign In / Ctrl+Alt+U 加载
        autorun 等动作由用户在 VS Code 内手工完成（见 vscode-sas-setup skill §7
        工作流）。SPAhub 不试图替代或自动化那些步骤（IOM 协议限制）。
      - 多次点击 = 多个 VS Code 窗口（每个对应一个 csr 工作区）。已存在相同
        工作区时 VS Code 会激活已有窗口（VS Code 内置去重）。

    工作区路径来源：
      - 4 级路径齐全（base_path != ""）→ 传 base_path 作为工作区
      - 否则不传参数，VS Code 以默认状态启动（最近项目列表）
    """
    status_signal = Signal(str)
    error_signal = Signal(str)

    def __init__(self, base_path: str = "", parent=None):
        super().__init__(parent)
        self.base_path = base_path or ""

    def run(self):
        target_exe = _find_code_exe()

        if not target_exe:
            # 兜底：靠系统 PATH 中的 `code` 命令（VS Code 安装时勾选"Add to PATH"）
            try:
                if self.base_path:
                    cmd_str = 'code "' + self.base_path + '"'
                else:
                    cmd_str = "code"
                # shell=True 让 Windows 解析 PATH（code 实际是 .cmd 脚本）
                subprocess.Popen(cmd_str, shell=True)
                if self.base_path:
                    short = os.sep.join(self.base_path.rstrip(os.sep).split(os.sep)[-2:])
                    self.status_signal.emit(
                        "💻 已通过系统 PATH 启动 VS Code，工作区：" + short
                    )
                else:
                    self.status_signal.emit("💻 已通过系统 PATH 启动 VS Code（未选定项目）")
            except Exception as e:
                NL = chr(10)
                # 错误提示里用正斜杠避免 escape 麻烦（Windows 也认正斜杠）
                self.error_signal.emit(
                    "启动 VS Code 失败: " + str(e) + NL
                    + '请确认已安装 VS Code，且安装时勾选了 "Add to PATH" 选项；' + NL
                    + "或将 VS Code 装到默认路径 C:/Users/<user>/AppData/Local/Programs/Microsoft VS Code/。"
                )
            return

        # 找到 exe — 直接 Popen（shell=False 更安全）
        cmd = [target_exe]
        if self.base_path:
            cmd.append(self.base_path)

        try:
            subprocess.Popen(cmd, shell=False)
            if self.base_path:
                short = os.sep.join(self.base_path.rstrip(os.sep).split(os.sep)[-2:])
                self.status_signal.emit(
                    "💻 已发起 VS Code 启动指令，工作区：" + short
                )
            else:
                self.status_signal.emit("💻 已发起 VS Code 启动指令（未选定项目，VS Code 默认状态）")
        except Exception as e:
            self.error_signal.emit(
                "启动 VS Code 失败: " + str(e) + chr(10) + "请检查软件是否已正确安装。"
            )


# ============================================================================
# SAS EG 路径/状态 / 文件打开辅助
# ============================================================================
def _find_saseg_exe():
    """定位 SAS Enterprise Guide 可执行文件路径（按候选路径依次探测）"""
    candidates = [
        r'C:\Program Files\SaS\SASHome\SASEnterpriseGuide\8\SEGuide.exe',
        r'C:\Program Files\SASHome\SASEnterpriseGuide\8\SEGuide.exe',
        r'C:\Program Files (x86)\SASHome\SASEnterpriseGuide\8\SEGuide.exe',
        r'C:\Program Files\SASHome\SASEnterpriseGuide\7.1\SEGuide.exe',
        r'C:\Program Files (x86)\SASHome\SASEnterpriseGuide\7.1\SEGuide.exe',
    ]
    return next((p for p in candidates if os.path.exists(p)), None)


def _saseg_is_running():
    """通过 tasklist 检测 SAS EG 是否已启动"""
    if os.name != 'nt':
        return False
    try:
        output = subprocess.check_output(
            'tasklist /FI "IMAGENAME eq SEGuide.exe" /NH',
            shell=True, creationflags=0x08000000
        ).decode('utf-8', 'ignore')
        return "SEGuide.exe" in output
    except Exception:
        return False


def _find_code_exe():
    """v12.10.55：定位 VS Code 可执行文件路径（按候选位置依次探测）。

    候选按概率排序：
      1. user 安装（最常见）   C:\\Users\\<user>\\AppData\\Local\\Programs\\Microsoft VS Code\\Code.exe
      2. system 安装           C:\\Program Files\\Microsoft VS Code\\Code.exe
      3. system 安装 (x86)     C:\\Program Files (x86)\\Microsoft VS Code\\Code.exe
      4. 便携版/其它           — 命中不到时返回 None，外层走 PATH 兜底

    返回找到的路径或 None。
    """
    if os.name != 'nt':
        return None
    user_home = os.environ.get('USERPROFILE') or os.path.expanduser('~')
    candidates = [
        os.path.join(user_home, r'AppData\Local\Programs\Microsoft VS Code\Code.exe'),
        r'C:\Program Files\Microsoft VS Code\Code.exe',
        r'C:\Program Files (x86)\Microsoft VS Code\Code.exe',
    ]
    return next((p for p in candidates if os.path.exists(p)), None)


def open_with_saseg_or_default(file_path, status_callback=None):
    """
    若是 .sas7bdat 数据集：始终通过 SEGuide.exe 打开（每次启动一个 EG 窗口打开一个数据集）。
    非 .sas7bdat 文件：直接 os.startfile 走系统默认程序（最快路径）。

    v12.10.34：去掉入口的 os.path.exists 校验。
      历史 v12.10.31 在这里加了 os.path.exists，叠加 safe_startfile 内部又一次
      os.path.exists，加上 ShellExecute 内部的 stat — 网络盘上 3 次 SMB stat
      串行起来明显拖慢 Excel 启动（每次 stat ~10-50ms，3 次累计 30-150ms）。
      路径不存在的话 ShellExecute 自己会失败 / 返回错误，外层校验是冗余。
    """
    if not file_path:
        return
    ext = os.path.splitext(file_path)[1].lower()
    if ext != '.sas7bdat':
        # 非 sas7bdat：直接 os.startfile，最快路径
        # frozen 模式下被 main.py 全局 monkey-patch 接管走 cmd /c start 委托
        # dev 模式下是原生 ShellExecuteEx，无额外 stat
        try:
            os.startfile(file_path)
        except OSError:
            pass  # 文件不存在 / 无关联程序等 — ShellExecute 自带错误处理，吞掉即可
        return

    exe = _find_saseg_exe()
    if exe:
        try:
            subprocess.Popen([exe, file_path], shell=False, creationflags=0x00000008)
            if status_callback:
                status_callback(f"已通过 SAS EG 打开: {os.path.basename(file_path)}")
            return
        except Exception:
            pass
    # 降级：直接 os.startfile 走系统注册表关联
    try:
        os.startfile(file_path)
        if status_callback:
            status_callback(f"已打开: {os.path.basename(file_path)}")
    except Exception:
        pass


# ============================================================================
# v12.10.74：共享顶部 banner（恒瑞品牌横幅 + 四级路径控制行）
# ----------------------------------------------------------------------------
# v12.10.73 把 banner 只放在 Home 页内容区顶部；v12.10.74 改造为「所有页面共享」的
# 顶部 header：banner 作背景，恒瑞 logo 在上方，四级下拉框 + Clear + Launch 按钮
# 整行嵌在 banner 里（logo 下方）。header 位于 QStackedWidget 之上 → 切到任何模块都
# 始终可见、风格统一。
# 设计：
#   - 固定高度 BANNER_HEIGHT，背景图 cover 缩放（KeepAspectRatioByExpanding + 居中
#     裁切）铺满整条不变形、不留白；v12.10.77 起四边 alpha 羽化淡出到页面底色，
#     不再是生硬矩形，视觉上向外延展溶入背景（取代原 6px 圆角裁切）。
#   - logo 用 QLabel（固定像素宽，不随背景拉伸糊化）置于顶部一行。
#   - 控制行（combos / 按钮）由外部 _setup_ui 往 self.controls_layout 里添加，控件
#     自身是实底白/蓝背景 → 叠在 banner 上仍清晰可读。
#   - 资源经 bundle_root()/resources/ 解析（不硬编码绝对路径）；背景图缺失时退化为
#     深蓝纯色（header 仍成立，控制行照常工作），不影响任何功能。
# ============================================================================
class _HeaderBanner(QFrame):
    """共享顶部品牌横幅：banner 背景图（四边羽化）+ 顶部 logo + 下方四级路径控制行。"""

    BANNER_HEIGHT = 152          # 固定高度（px）
    LOGO_WIDTH = 230             # logo 缩放后宽度（px），高度按原比例
    FEATHER_X = 12               # 左右羽化宽度（px）— v12.10.91：再减半（v89 为 24）
    FEATHER_Y = 7                # 上下羽化宽度（px）— v12.10.91：再减半（v89 为 15）
    FALLBACK_COLOR = "#2C3848"   # 背景图缺失时的兜底深蓝

    def __init__(self, banner_path: str = "", logo_path: str = "", feather_bg: str = "#EDF1F5", parent=None):
        super().__init__(parent)
        self.setFixedHeight(self.BANNER_HEIGHT)
        # v12.10.77：四边羽化时淡出到的页面底色（默认与主内容 #EDF1F5 一致，无缝融入）
        self._feather_bg = feather_bg or "#EDF1F5"

        # 背景图：原图 pixmap，paintEvent 时按当前尺寸 cover 缩放
        self._bg_pixmap = QPixmap(banner_path) if banner_path and os.path.exists(banner_path) else QPixmap()

        outer = QVBoxLayout(self)
        outer.setContentsMargins(26, 14, 18, 14)
        outer.setSpacing(12)

        # ── logo 行（顶部，左对齐）──
        self.logo_lbl = QLabel()
        if logo_path and os.path.exists(logo_path):
            logo_pix = QPixmap(logo_path)
            if not logo_pix.isNull():
                self.logo_lbl.setPixmap(
                    logo_pix.scaledToWidth(self.LOGO_WIDTH, Qt.SmoothTransformation)
                )
        self.logo_lbl.setStyleSheet("background: transparent; border: none;")
        # v12.10.80：logo 行暴露为 self.logo_row —— 外部 _setup_ui 把两个 Launch 按钮加到
        #            右侧（addStretch 之后），使其与 logo 同高（顶部），把下方控制行整行让给
        #            4 个下拉框 + Clear 舒展铺开（解决下拉框被 Launch 挤压变窄的问题）。
        self.logo_row = QHBoxLayout()
        self.logo_row.setContentsMargins(0, 0, 0, 0)
        self.logo_row.addWidget(self.logo_lbl)
        self.logo_row.addStretch()
        outer.addLayout(self.logo_row)

        # ── 控制行（logo 下方）：外部把 4 个 combo + Clear + Launch 按钮加进来 ──
        self.controls_layout = QHBoxLayout()
        self.controls_layout.setContentsMargins(0, 0, 0, 0)
        self.controls_layout.setSpacing(10)
        outer.addLayout(self.controls_layout)

        outer.addStretch()  # 余下空间留在底部，露出 banner 图下半部

    def paintEvent(self, event):
        rect = self.rect()
        w, h = rect.width(), rect.height()
        if w <= 0 or h <= 0:
            return

        painter = QPainter(self)
        painter.setRenderHint(QPainter.SmoothPixmapTransform, True)

        if self._bg_pixmap.isNull():
            # 兜底：深蓝纯色，header 仍然成立，控制行照常可用
            painter.fillRect(rect, QColor(self.FALLBACK_COLOR))
            return

        # ── 1) 把 cover 缩放后的图画进透明缓冲，再用四边 alpha 渐变把边缘"淡出" ──
        target = self.size()
        scaled = self._bg_pixmap.scaled(target, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
        ox = (scaled.width() - w) // 2
        oy = (scaled.height() - h) // 2

        buf = QPixmap(target)
        buf.fill(Qt.transparent)
        bp = QPainter(buf)
        bp.setRenderHint(QPainter.SmoothPixmapTransform, True)
        bp.drawPixmap(0, 0, scaled, ox, oy, w, h)
        # 用 DestinationIn 把目标 alpha 乘以"边缘→0、内部→1"的渐变 → 四边羽化
        bp.setCompositionMode(QPainter.CompositionMode_DestinationIn)
        fx = min(self.FEATHER_X, w // 2)
        fy = min(self.FEATHER_Y, h // 2)
        opaque = QColor(0, 0, 0, 255)
        clear = QColor(0, 0, 0, 0)
        edges = []
        if fx > 0:
            gl = QLinearGradient(0, 0, fx, 0); gl.setColorAt(0.0, clear); gl.setColorAt(1.0, opaque); edges.append(gl)
            gr = QLinearGradient(w, 0, w - fx, 0); gr.setColorAt(0.0, clear); gr.setColorAt(1.0, opaque); edges.append(gr)
        if fy > 0:
            gt = QLinearGradient(0, 0, 0, fy); gt.setColorAt(0.0, clear); gt.setColorAt(1.0, opaque); edges.append(gt)
            gb = QLinearGradient(0, h, 0, h - fy); gb.setColorAt(0.0, clear); gb.setColorAt(1.0, opaque); edges.append(gb)
        for g in edges:
            bp.fillRect(0, 0, w, h, QBrush(g))
        bp.end()

        # ── 2) 先铺页面底色，再把羽化后的图叠上去 → 边缘无缝融入页面，不再生硬 ──
        painter.fillRect(rect, QColor(self._feather_bg))
        painter.drawPixmap(0, 0, buf)


# ============================================================================
# 主窗口 SASEGGUI
# ============================================================================
class SASEGGUI(QMainWindow):
    """
    应用主窗口：侧边栏 + 顶部路径栏 + 中央页面栈 + 底部状态栏。

    核心状态：
      - self.z_drive            根目录（通常 Z:\\）
      - self.selected_paths[0..3] 四级路径选择值
      - self.grid_timer         防抖定时器（下拉框快速切换时合并刷新）
    """

    # ------------------------- 初始化 -------------------------
    def __init__(self, _minimal=False):
        """
        构造主窗口。

        参数:
            _minimal (bool): 若为 True，仅搭建 UI 骨架，跳过任何会触发网络盘
                IO 的工作（如顶层目录扫描）。配合外部 QTimer.singleShot 调用
                _post_init() 在主窗口显示后再做完整初始化，避免冷启动阻塞。
                默认 False 保持向后兼容（直接 new 时一步到位）。
        """
        super().__init__()
        self.setWindowTitle("SPA Platform")  # v12.10.75：整体改名 SPAhub → SPA Platform
        # v12.8：固定窗口尺寸 + 强约束最小尺寸。
        # 之前 03 CRF Annotation 切换到 annomap 编辑 tab 时，QTableWidget 的 sizeHint 会
        # 推动 splitter 重新分配宽度，进而把整个 QMainWindow 按列宽撑大 — 用户报告 launch
        # SAS EG 按钮被推到屏幕外。修法：固定主窗口大小（不可被子部件撑大），
        # 内部由 QSplitter 比例分配。
        self.resize(1400, 860)
        self.setMinimumSize(1300, 800)

        self.z_drive = "Z:\\"
        self.selected_paths = [""] * 4
        # v12.10.83：在任何 combo 级联（含启动自动选 projects → _on_combo_activated → 覆盖记忆）
        #            之前，先把上次记忆读进内存，回放时用内存值，避免被启动写入覆盖导致回放失效。
        try:
            self._restore_pending = self._load_last_selection()
        except Exception:
            self._restore_pending = []
        # v12.10.11：跟踪上一次"4 级齐全"的项目路径，用于路径切换时弹窗告警
        self._last_complete_path = ""

        self.grid_timer = QTimer(self)
        self.grid_timer.setSingleShot(True)
        self.grid_timer.timeout.connect(self._actual_update_grid)

        self._setup_ui()
        self._apply_global_style()
        self._setup_global_shortcuts()

        # _minimal=True 模式：跳过 refresh_first_dropdown（含 listdir Z:\），
        # 由外部在主窗口显示后通过 _post_init 触发，让用户立即看到 UI。
        if not _minimal:
            self.refresh_first_dropdown()

    def _post_init(self):
        """
        延迟初始化：主窗口 show() 之后由 QTimer.singleShot(0, ...) 调用。
        负责执行所有"会阻塞 UI 但又不是首屏渲染必需"的工作：
          - crash.log 自动归档（v12.10.13）
          - 顶层目录扫描（refresh_first_dropdown → os.listdir(Z:\\)）
          - 模块预加载（v12.10.13 — 后台 import 各 stepper 模块）

        本方法是幂等的，重复调用安全（_populate_combo 内部 blockSignals 会处理）。

        v12.10.31：把 refresh_first_dropdown（含 listdir Z:\\）从主线程剥到后台。
        根因（Issue 1）：
          原 _post_init 内同步调 refresh_first_dropdown → listdir(Z:\\) → 网络盘
          在公司内网延迟 0.5~3s/次，且若 projects 目录扫到，还会级联 _on_combo_activated(0)
          → 再 listdir(Z:\\projects) → 又 0.5~3s。
          冷启动时 Defender 还在扫 frozen exe，叠加后用户感知 5~30s 才有可用 UI。
        修法：把 listdir 包在 QThread，UI 立即可用；扫到结果用 emit 回主线程填 combo。
        """
        # v12.10.13：crash.log 大小检查 + 自动归档
        try:
            self._archive_crash_log_if_large()
        except Exception:
            pass

        # v12.10.31：dropdown 异步刷新（不再阻塞主线程）
        try:
            self._start_async_dropdown_refresh()
        except Exception as e:
            # 不让 _post_init 异常拖累整个 app；记日志即可
            import logging
            logging.error(f"_post_init 异步刷新失败: {e}")
            # 兜底：退回同步刷新（保证至少能用，只是慢）
            try:
                self.refresh_first_dropdown()
            except Exception:
                pass

        # v12.10.13：后台预加载 stepper 模块（仅 import 缓存，不构造 widget）
        try:
            self._start_module_preload()
        except Exception:
            pass

    def _start_async_dropdown_refresh(self):
        """v12.10.31：把第 1 级 listdir(Z:\\) 推到子线程。
        扫描完成后回主线程 _populate_combo + 自动选中 'projects'。
        """
        from PySide6.QtCore import QThread, Signal as _Signal

        class _DropdownScanThread(QThread):
            scanned = _Signal(list, bool)  # items, has_projects

            def __init__(self_inner, z_drive, get_dirs_fn):
                super().__init__()
                self_inner._z_drive = z_drive
                self_inner._get_dirs = get_dirs_fn

            def run(self_inner):
                try:
                    dirs = self_inner._get_dirs(self_inner._z_drive) or []
                except Exception:
                    dirs = []
                self_inner.scanned.emit(dirs, "projects" in dirs)

        # 进度提示（在主 UI 线程）
        try:
            self.update_status("⏳ 正在扫描 Z:\\ 目录...")
        except Exception:
            pass

        self._dropdown_scan_thread = _DropdownScanThread(
            self.z_drive, self.get_directories
        )
        self._dropdown_scan_thread.scanned.connect(self._on_dropdown_scanned)
        self._dropdown_scan_thread.start()

    def _on_dropdown_scanned(self, dirs, has_projects):
        """v12.10.31：后台 listdir(Z:\\) 完成 → 主线程填 combo + 自动选 projects。

        与原 refresh_first_dropdown 行为对齐：
          - 把 dirs 灌进 combos[0]
          - 若含 'projects' → 默认选中并触发 _on_combo_activated(0) 做 2 级 listdir。
            这一步级联仍是同步的（短，因为已知 Z:\\projects 子目录数量有限），
            但发生在主 UI 已可见之后，不再阻塞冷启动。
        """
        try:
            self._populate_combo(self.combos[0], dirs)
            if has_projects:
                combo = self.combos[0]
                combo.blockSignals(True)
                idx = combo.findText("projects")
                if idx >= 0:
                    combo.setCurrentIndex(idx)
                combo.blockSignals(False)
                self._on_combo_activated(0)
            # v12.10.80：第 1 级就绪后，回放上次记忆的 2~4 级选择（类似"收藏定位"）
            self._apply_restore_selection()
            self.update_status("✅ 已就绪")
        except Exception as e:
            import logging
            logging.error(f"_on_dropdown_scanned 填充 combo 失败: {e}")

    # ------------------------- v12.10.80：四级路径记忆 -------------------------
    @staticmethod
    def _selection_store_path():
        """记忆文件路径：%LOCALAPPDATA%\\SPAhub\\logs\\last_selection.json（logs_dir 会自建）。"""
        from app_paths import logs_dir as _ld
        return os.path.join(_ld(), "last_selection.json")

    def _save_last_selection(self):
        """把当前 4 级选择（去掉尾部空值）写入 json。任何异常静默忽略，绝不影响主流程。"""
        try:
            import json
            toks = list(getattr(self, "selected_paths", []) or [])
            while toks and not toks[-1]:
                toks.pop()
            with open(self._selection_store_path(), "w", encoding="utf-8") as f:
                json.dump({"selected_paths": toks}, f, ensure_ascii=False)
        except Exception:
            pass

    def _load_last_selection(self):
        """读取上次记忆的 token 列表；读不到返回 []。"""
        try:
            import json
            with open(self._selection_store_path(), "r", encoding="utf-8") as f:
                data = json.load(f)
            toks = data.get("selected_paths", [])
            return [str(t) for t in toks] if isinstance(toks, list) else []
        except Exception:
            return []

    def _apply_restore_selection(self):
        """第 1 级就绪后回放记忆：逐级 findText→选中→级联；某级目录已不存在则停。只回放一次。"""
        if getattr(self, "_restore_done", False):
            return
        self._restore_done = True
        # v12.10.83：用 __init__ 时预读进内存的记忆（此刻磁盘文件可能已被启动自动选 projects 覆盖）
        toks = list(getattr(self, "_restore_pending", []) or [])
        if not toks:
            return
        try:
            for lvl in range(min(4, len(toks))):
                tok = (toks[lvl] or "").strip()
                if not tok:
                    break
                combo = self.combos[lvl]
                idx = combo.findText(tok)
                if idx < 0:
                    break  # 该层目录已不存在 → 停止回放
                # 已是该值（如第 1 级 projects 已自动选中）→ 跳过，继续下一层
                if combo.currentText() == tok and self.selected_paths[lvl] == tok:
                    continue
                combo.blockSignals(True)
                combo.setCurrentIndex(idx)
                combo.blockSignals(False)
                self._on_combo_activated(lvl)  # 触发本层级联，填充下一层
        except Exception as e:
            import logging
            logging.error(f"回放上次路径选择失败: {e}")

    def _archive_crash_log_if_large(self):
        """v12.10.13：crash.log 超过 10MB 自动归档为 crash_<日期>.log，新建空文件继续写。

        放在 _post_init 头部一次性检查 — 不影响主线程渲染（_post_init 本身就是
        QTimer.singleShot(0) 推到下一帧的）。
        归档失败不抛异常（盘满 / 权限），仅记日志。
        """
        import os as _os
        from app_paths import logs_dir as _ld
        crash_log = _os.path.join(_ld(), "crash.log")
        if not _os.path.isfile(crash_log):
            return
        try:
            sz = _os.path.getsize(crash_log)
        except Exception:
            return
        THRESHOLD = 10 * 1024 * 1024  # 10MB
        if sz < THRESHOLD:
            return
        # 归档：crash.log → crash_2026-05-06_HHMMSS.log
        try:
            from datetime import datetime
            stamp = datetime.now().strftime("%Y-%m-%d_%H%M%S")
            archived = _os.path.join(_os.path.dirname(crash_log), f"crash_{stamp}.log")
            _os.rename(crash_log, archived)
            # 新建空文件，写入归档说明
            with open(crash_log, "w", encoding="utf-8") as f:
                f.write(
                    f"[{datetime.now().isoformat(timespec='seconds')}] "
                    f"crash.log 已归档（原文件 {sz/1024/1024:.1f} MB）→ "
                    f"{_os.path.basename(archived)}\n"
                )
        except Exception as e:
            import logging
            logging.error(f"归档 crash.log 失败: {e}")

    def _start_module_preload(self):
        """v12.10.13：后台 import stepper 模块，缩短首次切换页面的延迟。
        v12.10.100：额外预热 TFL Metadata 重依赖（torch / transformers / shell_to_demo +
        3 个 metadata 子模块）并预加载 BGE 模型，消除"首次运行 Metadata 卡 ~2 分钟"。

        策略：
          - 子线程仅做 import + 模型预加载（不创建 QWidget — Qt 跨线程构造 widget 不安全）
          - import 缓存命中后，主线程懒加载时只剩 widget 构造，速度提升 30-50%
          - 重依赖（torch/transformers）首次 import 很慢，挪到开机后台（低优先级）完成，
            首次点 Metadata 不再付这笔 ~2 分钟成本（同进程第二次本就快）
          - 即使预加载失败也不影响 app 运行，懒加载 / 首次运行会自然 retry
        """
        from PySide6.QtCore import QThread

        class _PreloadThread(QThread):
            def run(self_inner):
                # 仅 import — 不实例化任何 widget
                # 顺序按用户最常用的优先（aCRF / SDTM 优先于 ADaM / TFLs）
                module_list = [
                    "gui.acrf_stepper",
                    "gui.sdtm_stepper",
                    "gui.tfls_stepper",
                    "gui.adam_stepper",
                    "gui.m5_stepper",   # v12.10.106
                    "gui.tdm_page",     # v12.10.117
                ]
                for mod_name in module_list:
                    try:
                        __import__(mod_name)
                    except Exception:
                        pass  # 单模块失败不影响其他

                # v12.10.100：预热 TFL Metadata 的重依赖，消除"首次运行 Metadata 卡 ~2 分钟"。
                # 根因：MetadataRunner.run() 里 `import torch` + `import shell_to_demo`
                #   （后者顶层 from transformers import AutoTokenizer, AutoModel）首次 import
                #   极慢；同进程第二次运行因 sys.modules 已缓存只需 ~30s。这里把这笔 import
                #   成本挪到开机后台（低优先级线程）完成，第一次点 Metadata 就快。
                # 前提：上面已 import gui.tfls_stepper → 它 `from modules.tfls_metadata import
                #   MetadataForm` → modules.tfls_metadata 顶层把 TFL_metadata 目录 append 进
                #   sys.path，故下面 import shell_to_demo / tfls_metadata_* 可直接命中。
                # 全部 best-effort：任何一步失败都不影响 app（首次运行时会自然 retry）。
                try:
                    import modules.tfls_metadata  # noqa: F401  防御：确保 TFL_metadata 路径已注册
                except Exception:
                    pass
                heavy_list = [
                    "torch",
                    "transformers",
                    "tfls_metadata_tadsl_disp",
                    "tfls_metadata_tadsl_pop",
                    "tfls_metadata_tadae_over",
                    "shell_to_demo",
                ]
                for mod_name in heavy_list:
                    try:
                        __import__(mod_name)
                    except Exception:
                        pass

                # 预热 BGE 模型到进程内缓存（仅当本地模型存在；绝不在启动时触发 HuggingFace 下载）。
                # 命中 shell_to_demo v12.10.79 的 _BGE_MODEL_CACHE，首次 demo_shell 即可省去模型加载。
                try:
                    import shell_to_demo as _s2d
                    _lm = _s2d._find_local_bge_model()
                    if _lm:
                        import torch as _t
                        if _t.cuda.is_available():
                            _dev = _t.device("cuda")
                        elif hasattr(_t.backends, "mps") and _t.backends.mps.is_available():
                            _dev = _t.device("mps")
                        else:
                            _dev = _t.device("cpu")
                        _s2d._get_bge_model(_lm, _dev)
                except Exception:
                    pass

        self._preload_thread = _PreloadThread(self)
        # v12.10.100：低优先级启动 —— 重依赖预热不与启动期 UI 交互抢 CPU/GIL。
        try:
            self._preload_thread.start(QThread.LowPriority)
        except Exception:
            self._preload_thread.start()

    # ------------------------- Home 页网格 -------------------------
    def update_grid_display(self):
        """防抖处理：避免用户快速连续切换下拉框导致主线程卡顿"""
        self.grid_timer.start(250)

    def _on_refresh_home_clicked(self):
        """v12.10.20: 用户主动点 🔄 刷新文件清单 → 显示 ⏳ → 刷新 → 比对前后 hash → 反馈

        与"切换下拉框自动触发的刷新"区分：那条路径走 update_grid_display() 直接进
        防抖队列，不走本方法、不显示反馈（避免刷屏式弹提示）。
        本方法仅在用户**主动点击**时给出明确视觉反馈，因为按钮没反馈用户会怀疑是否生效。
        """
        # ⏳ 刷新中
        self.refresh_status_lbl.setText("⏳ 刷新中...")
        self.refresh_status_lbl.setStyleSheet(
            "color: #909399; font-size: 12px; border: none; padding-left: 6px;")

        # 抓刷新前的 grid 内容快照
        self._refresh_before_hash = self._compute_grid_signature()
        # token：用单调递增 counter，重复点击递增防抢占（id(object()) 在 GC 复用内存时有重号风险）
        self._refresh_pending_token = getattr(self, "_refresh_pending_token", 0) + 1

        # 触发刷新（防抖 250ms 后执行 _actual_update_grid）
        self.update_grid_display()

        # 防抖 250ms + 给主线程 ~350ms 重建 grid，再比对（总 600ms 余量充足）
        token = self._refresh_pending_token
        QTimer.singleShot(600, lambda: self._refresh_status_after(token))

    def _refresh_status_after(self, token):
        """v12.10.20: 刷新完成后比对前后 grid signature → 显示反馈"""
        # token 不一致 → 用户在等候期间又点了一次，让最新那次接管
        if getattr(self, "_refresh_pending_token", None) != token:
            return
        after = self._compute_grid_signature()
        from datetime import datetime
        ts = datetime.now().strftime("%H:%M:%S")
        if after == getattr(self, "_refresh_before_hash", None):
            self.refresh_status_lbl.setText(f"ℹ️ 无文件变化 ({ts})")
            self.refresh_status_lbl.setStyleSheet(
                "color: #909399; font-size: 12px; border: none; padding-left: 6px;")
        else:
            self.refresh_status_lbl.setText(f"✅ 已刷新 ({ts})")
            self.refresh_status_lbl.setStyleSheet(
                "color: #67C23A; font-size: 12px; border: none; padding-left: 6px; font-weight: bold;")
        # 4 秒后清空（除非期间又点了一次刷新）
        QTimer.singleShot(4000, lambda t=token: self._refresh_status_clear_if(t))

    def _refresh_status_clear_if(self, token):
        if getattr(self, "_refresh_pending_token", None) == token:
            self.refresh_status_lbl.setText("")

    def _compute_grid_signature(self):
        """对当前 home grid 中所有 widget 文字做排序拼接 → 当作内容签名。

        为啥不用文件系统直接扫：grid 由 _actual_update_grid 渲染，已包含全部子目录
        文件清单 + 分组按钮，签名等价于"用户视角看到的内容"。文件系统重扫一次还要
        重新走 listdir + 网络盘 IO，成本高且与 grid 显示可能短暂不一致。
        """
        items = []
        try:
            for i in range(self.grid_layout.count()):
                it = self.grid_layout.itemAt(i)
                if it is None:
                    continue
                w = it.widget()
                if w is not None and hasattr(w, "text"):
                    items.append(w.text() or "")
        except Exception:
            pass
        return hash(tuple(sorted(items)))

    def _actual_update_grid(self):
        """真实的网格渲染逻辑（下拉框齐全时按列展示子目录文件列表）"""
        while self.grid_layout.count():
            child = self.grid_layout.takeAt(0)
            if child.widget(): child.widget().deleteLater()

        base_path = self.get_current_path()
        p2 = self.selected_paths[1]
        p3 = self.selected_paths[2]
        p4 = self.selected_paths[3]

        if hasattr(self, 'toc_widget'):
            self.toc_widget.update_path(base_path, p2, p3)

        if hasattr(self, 'tfls_widget'):
            self.tfls_widget.update_path(base_path, p3, p4)

        if hasattr(self, 'acrf_widget'):
            self.acrf_widget.update_path(base_path, p3, p4)

        if hasattr(self, 'sdtm_widget'):
            self.sdtm_widget.update_path(base_path, p3, p4)

        if hasattr(self, 'adam_widget'):
            self.adam_widget.update_path(base_path, p3, p4)

        if hasattr(self, 'm5_widget'):
            self.m5_widget.update_path(base_path, p3, p4)

        if hasattr(self, 'tdm_widget'):
            self.tdm_widget.update_path(base_path, p3, p4)

        if sum(1 for p in self.selected_paths if p) < 4:
            if hasattr(self, 'home_wait_lbl'):
                self.home_wait_lbl.setVisible(True)
            return

        if hasattr(self, 'home_wait_lbl'):
            self.home_wait_lbl.setVisible(False)

        if not os.path.exists(base_path): return

        # v12.10.11：4 级路径齐全且与上一次不同时，弹窗告知用户项目已切换
        # 同时通知所有 form 主动刷新缓存（PDS Watcher / annomap 待加载等）— 不再静默
        # 例外：首次进入（_last_complete_path 为空）不弹窗，避免应用启动就弹
        if self._last_complete_path and self._last_complete_path != base_path:
            try:
                show_dialog(
                    self, "项目路径已切换",
                    f"已成功更改项目路径：\n\n{base_path}\n\n各模块缓存正在后台刷新…",
                    "info"
                )
            except Exception:
                pass
            # 通知各 widget 主动刷新缓存（如 PDS Watcher 重新扫描、annomap 待加载标记重置）
            for attr in ("acrf_widget", "sdtm_widget", "tfls_widget", "adam_widget", "m5_widget", "tdm_widget"):
                w = getattr(self, attr, None)
                if w is None:
                    continue
                # 优先调用 widget 自带的 refresh 方法（如有）
                for m in ("refresh_caches", "action_refresh"):
                    fn = getattr(w, m, None)
                    if callable(fn):
                        try:
                            fn()
                        except Exception:
                            pass
                        break
        self._last_complete_path = base_path

        # 00_source_data 需要展示；保留不展示的归档/中转目录
        excluded = ["91_export", "92_import", "99_archive"]
        try:
            subfolders = sorted([d for d in os.listdir(base_path)
                                 if os.path.isdir(os.path.join(base_path, d))
                                 and d not in excluded
                                 and not d.startswith('.')])

            # 设置横向滚动条（列多时可横向滚动）
            self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
            # 让内部容器宽度随内容伸展，而不是被视口压扁
            self.scroll_area.setWidgetResizable(True)

            from PySide6.QtGui import QFontMetrics
            # 使用稳定一致的字体度量，按列内最长文件名计算列宽
            font = self.scroll_content.font()
            fm = QFontMetrics(font)
            min_col_width = 140
            max_col_width = 360
            padding = 40  # 边距 + 图标空间

            for col_idx, folder in enumerate(subfolders):
                folder_path = os.path.join(base_path, folder)

                try:
                    items = sorted([f for f in os.listdir(folder_path) if not f.startswith('.')])
                except Exception:
                    items = []

                # 按列内最长文件名计算列宽
                widest_text = folder
                for itm in items[:50]:
                    if len(itm) > len(widest_text):
                        widest_text = itm
                content_width = fm.horizontalAdvance(widest_text) + padding
                col_width = max(min_col_width, min(content_width, max_col_width))

                header_btn = QPushButton(folder)
                header_btn.setFixedWidth(col_width)
                header_btn.setStyleSheet("""
                    background-color: #ECF5FF; border: 1px solid #B3D8FF; 
                    color: #409EFF; font-weight: bold; border-radius: 4px; padding: 6px;
                    text-align: left;
                """)
                header_btn.clicked.connect(lambda checked, p=folder_path: os.startfile(p))
                self.grid_layout.addWidget(header_btn, 0, col_idx)

                display_items = items[:50]
                for row_idx, item in enumerate(display_items, start=1):
                    item_path = os.path.join(folder_path, item)
                    btn = QPushButton(item)
                    btn.setFixedWidth(col_width)
                    btn.setStyleSheet("""
                        text-align: left; border: none; background: transparent; 
                        color: #606266; padding: 4px 6px;
                    """)
                    btn.setCursor(Qt.PointingHandCursor)
                    # 所有 .sas7bdat 统一走 SAS EG；其余文件走系统默认程序
                    btn.clicked.connect(lambda checked, p=item_path: open_with_saseg_or_default(p, self.update_status))
                    self.grid_layout.addWidget(btn, row_idx, col_idx)

                if len(items) > 50:
                    more_btn = QPushButton(f"... (还有 {len(items) - 50} 个文件)")
                    more_btn.setFixedWidth(col_width)
                    more_btn.setStyleSheet(
                        "text-align: left; border: none; background: transparent; color: #909399; padding: 4px 6px; font-style: italic;")
                    more_btn.setCursor(Qt.PointingHandCursor)
                    more_btn.clicked.connect(lambda checked, p=folder_path: os.startfile(p))
                    self.grid_layout.addWidget(more_btn, len(display_items) + 1, col_idx)

        except Exception as e:
            self.status_label.setText(f"网格加载错误: {e}")

    # ------------------------- 弹窗 -------------------------
    def _show_msg(self, title, text, msg_type="info"):
        return show_dialog(self, title, text, msg_type)

    # ------------------------- UI 搭建 -------------------------
    def _setup_ui(self):
        """组装主窗口：侧边栏 + 顶部路径栏 + 中央页面栈 + 底部状态栏"""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        self.sidebar = QListWidget()
        self.sidebar.setFixedWidth(210)   # v12.10.92：加宽（160→210，约 +4% 窗宽占比）
        # v12.10.79：关掉横向滚动条（item 宽度贴近 160 时 Qt 会误显示一条多余横向滚动条）
        self.sidebar.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        # v12.10.106：恢复 M5 模块（置于 TFLs 之后、Shortcuts 之前）
        # v12.10.117：侧边栏第 3 位新增 TDM 模块（介于 aCRF 与 TOC 之间）
        self.pages = ["Home", "aCRF", "TDM", "TOC", "SDTM", "ADaM", "TFLs", "M5", "Shortcuts"]
        for page in self.pages:
            item = QListWidgetItem(page)
            item.setSizeHint(QSize(160, 48))
            item.setTextAlignment(Qt.AlignVCenter | Qt.AlignLeft)
            self.sidebar.addItem(item)
        self.sidebar.setCurrentRow(0)
        self.sidebar.currentRowChanged.connect(self._switch_page)
        main_layout.addWidget(self.sidebar)

        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        right_layout.setContentsMargins(15, 15, 15, 15)
        right_layout.setSpacing(12)
        main_layout.addWidget(right_widget, 1)

        # v12.10.74：顶部改为「banner 背景 + logo + 控制行」的共享 header。
        # banner/logo 资源经 bundle_root()/resources/ 解析；缺图时 _HeaderBanner 退化深蓝兜底。
        try:
            from app_paths import bundle_root as _bundle_root
            _res_dir = os.path.join(_bundle_root(), "resources")
            _banner_p = os.path.join(_res_dir, "home_banner.png")
            _logo_p = os.path.join(_res_dir, "home_logo.png")
        except Exception:
            _banner_p = _logo_p = ""
        self.header = _HeaderBanner(banner_path=_banner_p, logo_path=_logo_p, feather_bg="#EDF1F5")
        # 四级下拉框 + Clear + Launch 按钮统一加到 banner 内的控制行
        top_layout = self.header.controls_layout

        self.combos = []
        for i in range(4):
            combo = QComboBox()
            # v12.10.80：Launch 按钮已上移到 logo 行，控制行整行让给 4 个下拉框 + Clear。
            #            下拉框改 Expanding 平均铺满整行（舒展），min 140 保证可读、max 360 防过宽。
            combo.setMinimumWidth(140)
            combo.setMaximumWidth(360)
            combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            combo.setEditable(True)
            combo.setInsertPolicy(QComboBox.NoInsert)

            completer = QCompleter(combo.model(), combo)
            completer.setFilterMode(Qt.MatchContains)
            completer.setCaseSensitivity(Qt.CaseInsensitive)
            completer.setCompletionMode(QCompleter.PopupCompletion)
            combo.setCompleter(completer)

            def on_completer_activated(text, c=combo, lvl=i):
                idx = c.findText(text, Qt.MatchFixedString)
                if idx >= 0:
                    c.setCurrentIndex(idx)
                    self._on_combo_activated(lvl)

            completer.activated.connect(on_completer_activated)

            def on_return_pressed(c=combo, lvl=i):
                comp = c.completer()
                text = c.lineEdit().text().strip()
                if not text: return
                if comp and comp.popup().isVisible():
                    if comp.completionCount() == 1:
                        match_text = comp.currentCompletion()
                        comp.popup().hide()
                        idx = c.findText(match_text, Qt.MatchFixedString)
                        if idx >= 0:
                            c.setCurrentIndex(idx)
                            c.lineEdit().setText(match_text)
                            self._on_combo_activated(lvl)
                    else:
                        return
                else:
                    idx = c.findText(text, Qt.MatchFixedString)
                    if idx >= 0:
                        c.setCurrentIndex(idx)
                        self._on_combo_activated(lvl)
                    else:
                        c.setCurrentIndex(-1)
                        c.lineEdit().clear()

            combo.lineEdit().returnPressed.connect(on_return_pressed)
            combo.activated.connect(lambda index, lvl=i: self._on_combo_activated(lvl))

            self.combos.append(combo)
            top_layout.addWidget(combo)

        clear_btn = QPushButton("Clear")
        clear_btn.setObjectName("ClearBtn")
        clear_btn.setFixedWidth(80)
        clear_btn.clicked.connect(self.clear_selections)
        top_layout.addWidget(clear_btn)

        # v12.10.80：两个 Launch 按钮上移到 logo 行右侧（与 logo 同高），不再占用下拉框所在行。
        launch_btn = QPushButton("🚀 Launch SAS EG")
        launch_btn.setObjectName("LaunchBtn")
        launch_btn.setToolTip("启动 SAS Enterprise Guide（光秃秃启动；服务器面板需手动浏览）")
        launch_btn.clicked.connect(self.launch_saseg)
        self.header.logo_row.addWidget(launch_btn)

        # v12.10.55：并排新增「💻 Launch VS Code」按钮
        # 与 EG 按钮同款样式（共用 LaunchBtn objectName 让 QSS 主题统一）
        launch_vscode_btn = QPushButton("💻 Launch VS Code")
        launch_vscode_btn.setObjectName("LaunchBtn")
        launch_vscode_btn.setToolTip(
            "启动 VS Code,以当前 csr 路径作为工作区打开\n"
            "(SAS 扩展 Sign In + Ctrl+Alt+U 加载 autorun 由用户在 VS Code 内手工完成)"
        )
        launch_vscode_btn.clicked.connect(self.launch_vscode)
        self.header.logo_row.addWidget(launch_vscode_btn)

        right_layout.addWidget(self.header)

        self.stack = QStackedWidget()
        right_layout.addWidget(self.stack, 1)

        self.home_widget = QWidget()
        home_layout = QVBoxLayout(self.home_widget)
        home_layout.setContentsMargins(0, 0, 0, 0)
        home_layout.setSpacing(8)

        # 任务2：Home 页操作栏（位于文件树上方，承载"系统文件复制"按钮 + 详情）
        # 设计：与顶部 #TopBar 一致的白底圆角，避免视觉割裂；按钮风格与
        # 其他模块的次级动作按钮（如 TFLs 日志面板的 "📋 导出日志"）保持同色系。
        # 完成后不做自动弹窗，详情按钮由用户主动点击查看完整输出。
        home_action_bar = QFrame()
        home_action_bar.setObjectName("HomeActionBar")
        home_action_bar.setStyleSheet(
            "#HomeActionBar { background-color: #FFFFFF; border: 1px solid #E4E7ED; border-radius: 6px; }"
        )
        action_lay = QHBoxLayout(home_action_bar)
        action_lay.setContentsMargins(12, 8, 12, 8)
        action_lay.setSpacing(10)

        self.copy_files_btn = QPushButton("📁 系统文件复制")
        self.copy_files_btn.setStyleSheet("""
            QPushButton { background-color: #4A6FA5; color: white; border: none; padding: 6px 14px; border-radius: 4px; font-weight: bold; }
            QPushButton:hover { background-color: #6385B6; }
            QPushButton:disabled { background-color: #F5F7FA; color: #C0C4CC; }
        """)
        self.copy_files_btn.setCursor(Qt.PointingHandCursor)
        self.copy_files_btn.setToolTip(
            r"运行 <项目>\utility\tools\dir_bat_create_copy_files.py，按映射规则批量复制项目文件（后台执行）"
        )
        self.copy_files_btn.clicked.connect(self.run_copy_files_script)
        action_lay.addWidget(self.copy_files_btn)

        # 复制状态指示标签：实时反映"运行中 / 完成 / 失败"，不抢主操作焦点
        self.copy_status_lbl = QLabel("")
        self.copy_status_lbl.setStyleSheet("color: #909399; font-size: 12px; border: none;")
        action_lay.addWidget(self.copy_status_lbl)

        # 详情按钮：默认隐藏，复制完成（不论成败）后才显示，由用户主动点击查看完整输出
        self.copy_detail_btn = QPushButton("📋 详情")
        self.copy_detail_btn.setStyleSheet("""
            QPushButton { background-color: #FBF1E2; color: #C49A4A; border: 1px solid #ECD3A8; padding: 6px 14px; border-radius: 4px; font-weight: bold; }
            QPushButton:hover { background-color: #C49A4A; color: white; border-color: #C49A4A; }
        """)
        self.copy_detail_btn.setCursor(Qt.PointingHandCursor)
        self.copy_detail_btn.setVisible(False)
        self.copy_detail_btn.clicked.connect(self._show_copy_detail)
        action_lay.addWidget(self.copy_detail_btn)

        # v12.10.18：手动刷新源文件清单按钮。
        #   场景：用户在其他模块（aCRF/SDTM/TFLs/ADaM）跑完导致源目录文件
        #   增删后，希望立刻在 Home 页看到最新文件列表，而不必切换路径触发刷新。
        #   实现：直接复用 update_grid_display() — 已有 250ms 防抖 + 同时调
        #   各 widget.update_path()，等价于"重扫源目录 + 通知所有模块刷新缓存"。
        self.refresh_home_btn = QPushButton("🔄 刷新文件清单")
        self.refresh_home_btn.setStyleSheet("""
            QPushButton { background-color: #FFFFFF; color: #4A6FA5; border: 1px solid #C0CAE1; padding: 6px 14px; border-radius: 4px; font-weight: bold; }
            QPushButton:hover { background-color: #4A6FA5; color: white; border-color: #4A6FA5; }
            QPushButton:disabled { background-color: #F5F7FA; color: #C0C4CC; border-color: #E4E7ED; }
        """)
        self.refresh_home_btn.setCursor(Qt.PointingHandCursor)
        self.refresh_home_btn.setToolTip(
            "重新扫描各源目录文件清单（其他模块修改文件后，可在此手动刷新本页显示）"
        )
        self.refresh_home_btn.clicked.connect(self._on_refresh_home_clicked)
        action_lay.addWidget(self.refresh_home_btn)

        # v12.10.20: 刷新状态反馈标签（在按钮右侧，与"复制状态指示标签"一致风格）
        # 显示 ⏳ 刷新中... → ✅ 已刷新（HH:MM:SS） / ℹ️ 无文件变化
        # 数秒后自动清空，避免常驻占视觉空间
        self.refresh_status_lbl = QLabel("")
        self.refresh_status_lbl.setStyleSheet("color: #909399; font-size: 12px; border: none; padding-left: 6px;")
        action_lay.addWidget(self.refresh_status_lbl)

        action_lay.addStretch()

        home_layout.addWidget(home_action_bar)

        # 缓存最近一次复制脚本的完整输出，供"详情"按钮回看
        self._copy_last_output = ""
        self._copy_last_title = ""

        # 任务2：Home页等待提示
        self.home_wait_lbl = QLabel("⏳ 等待填写完整路径...")
        self.home_wait_lbl.setStyleSheet(scan_status_lbl_style("#E6A23C"))
        self.home_wait_lbl.setVisible(True)
        home_layout.addWidget(self.home_wait_lbl)

        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setObjectName("MainScroll")
        self.scroll_content = QWidget()
        self.scroll_content.setStyleSheet("background-color: #FFFFFF;")
        self.grid_layout = QGridLayout(self.scroll_content)
        self.grid_layout.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.grid_layout.setSpacing(8)
        self.scroll_area.setWidget(self.scroll_content)
        home_layout.addWidget(self.scroll_area)
        self.stack.addWidget(self.home_widget)

        # --- 各模块页面 ---

        # Shortcut 页（轻量，直接创建）
        self.shortcut_widget = ShortcutWidget(self)

        # TOC / TFLs / aCRF / SDTM / ADaM 页采用懒加载：先放占位 QWidget，首次切换时才真正构造
        self._toc_placeholder = QWidget()
        self._tfls_placeholder = QWidget()
        self._acrf_placeholder = QWidget()
        self._sdtm_placeholder = QWidget()
        self._adam_placeholder = QWidget()
        self._m5_placeholder = QWidget()   # v12.10.106：M5 懒加载占位
        self._tdm_placeholder = QWidget()  # v12.10.117：TDM 懒加载占位
        # v12.10.98：给 TFLs 占位页加「加载中」提示。首次点 TFLs 时先显示此占位（点击即时响应），
        # 真正的 TFLsWidget 构造 + 路径分发推迟到下一帧执行，消除「点了没反应」的假死感。
        _tfls_ph_lay = QVBoxLayout(self._tfls_placeholder)
        _tfls_ph_lbl = QLabel("⏳ 正在加载 TFLs 模块...")
        _tfls_ph_lbl.setAlignment(Qt.AlignCenter)
        _tfls_ph_lbl.setStyleSheet("color: #909399; font-size: 16px;")
        _tfls_ph_lay.addWidget(_tfls_ph_lbl)
        self._toc_loaded = False
        self._tfls_loaded = False
        self._acrf_loaded = False
        self._sdtm_loaded = False
        self._adam_loaded = False
        self._m5_loaded = False   # v12.10.106
        self._tdm_loaded = False  # v12.10.117

        for page in self.pages[1:]:
            if page == "TOC":
                self.stack.addWidget(self._toc_placeholder)
            elif page == "TFLs":
                self.stack.addWidget(self._tfls_placeholder)
            elif page == "aCRF":
                self.stack.addWidget(self._acrf_placeholder)
            elif page == "SDTM":
                self.stack.addWidget(self._sdtm_placeholder)
            elif page == "ADaM":
                self.stack.addWidget(self._adam_placeholder)
            elif page == "M5":
                self.stack.addWidget(self._m5_placeholder)
            elif page == "TDM":
                self.stack.addWidget(self._tdm_placeholder)
            elif page == "Shortcuts":
                self.stack.addWidget(self.shortcut_widget)
            else:
                w = QWidget()
                l = QVBoxLayout(w)
                lbl = QLabel(f"【{page}】\n业务表单开发中...")
                lbl.setAlignment(Qt.AlignCenter)
                lbl.setStyleSheet("color: #999; font-size: 16px;")
                l.addWidget(lbl)
                self.stack.addWidget(w)

        self.status_label = QLabel("就绪")
        self.status_label.setStyleSheet("color: #606266; padding: 2px 10px; font-size: 12px;")
        # stretch=1 让 status_label 占据状态栏整个可用宽度，避免长文案被截断
        # （如 Shortcut 启动 toast：含"首次加载约 20-30 秒"提示）
        self.statusBar().addWidget(self.status_label, 1)

    # ------------------------- 全局样式 -------------------------
    def _apply_global_style(self):
        """统一主窗口全局样式。

        v12.10.78：侧边栏改「皇家蓝·深选中」，与顶部 banner 同源（banner 主蓝约 #2555D1）。
        原 v12.10.76「钢蓝沉稳」侧栏偏灰，与饱和蓝 banner 色调不统一；现把侧栏拉进 banner
        的皇家蓝家族：浅蓝紫底 + 藏蓝选中 + 白字，整体蓝调一致。主内容仍冷中性 #EDF1F5
        （不发"粉白"，且与 banner 四边羽化淡出底色一致）。
        色板：
          #EDF1F5 主内容底   #FFFFFF 卡片白
          #DEE7F8 侧栏底（banner 蓝浅紫色调）  #CBD9F3 hover  #BFCFEE 右分隔边框
          #1E3A74 侧栏未选中字（深皇家蓝）
          #4A6FA5 主体按钮/强调（皇家蓝，v84 调亮）   #3A5687 pressed 更深   #6385B6 控件 focus
          #2C3848 侧栏选中 / Launch（保持上一版深 navy，v84.1 应用户要求未跟随调亮）   #5B82E0 选中左高亮条
        """
        self.setStyleSheet("""
            QMainWindow { background-color: #EDF1F5; }

            /* 侧边栏 v12.10.96：浅雾蓝底 + 深蓝选中（方案B 雾蓝家族，回到浅/深对比） */
            QListWidget { border: none; border-right: 1px solid #C5CDD8;
                          outline: none; font-size: 14px; font-weight: bold;
                          color: #2C3848; background-color: #DDE5EF; }
            QListWidget::item { padding-left: 18px; border-left: 4px solid transparent; color: #2C3848; }
            QListWidget::item:hover:!selected { background-color: #CFDAE8; color: #1F2933; }
            QListWidget::item:selected { background-color: #3A5687; color: #FFFFFF;
                                         border-left: 4px solid #6385B6; }

            /* 顶部控制行控件（叠在 banner 上，实底保证可读） */
            QComboBox { border: 1px solid #CBD2DC; border-radius: 4px; padding: 5px 10px;
                        background: #FFFFFF; color: #303841; font-size: 16px; }
            QComboBox:hover, QComboBox:focus { border-color: #6385B6; }
            QComboBox QAbstractItemView { background: #FFFFFF; color: #303841;
                                          selection-background-color: #4A6FA5; selection-color: #FFFFFF; }

            QPushButton { background-color: #FFFFFF; border: 1px solid #CBD2DC; border-radius: 4px;
                          padding: 6px 14px; color: #303841; font-size: 13px; font-weight: bold; }
            QPushButton:hover { background-color: #4A6FA5; border-color: #4A6FA5; color: #FFFFFF; }
            /* v12.10.97：Launch 按钮改白底（应用户要求，原深 navy 太深）— 与 Clear / 顶部按钮统一，hover 蓝 */
            #LaunchBtn { background-color: #FFFFFF; color: #303841; border: 1px solid #CBD2DC; }
            #LaunchBtn:hover { background-color: #4A6FA5; color: #FFFFFF; border-color: #4A6FA5; }
            #ClearBtn { background-color: #FFFFFF; color: #303841; }
            #ClearBtn:hover { background-color: #4A6FA5; color: #FFFFFF; border-color: #4A6FA5; }

            #MainScroll { border: 1px solid #D7DEEA; border-radius: 6px; background: #FFFFFF; }
            QScrollBar:vertical { border: none; background: #EDF1F5; width: 10px; border-radius: 5px; }
            QScrollBar::handle:vertical { background: #AFC0DE; border-radius: 5px; }
            QScrollBar::handle:vertical:hover { background: #8298C4; }
        """)

    # ------------------------- 页面路由 -------------------------
    def _switch_page(self, row):
        """侧边栏切换页面（含懒加载 TOC / TFLs）"""
        page_name = self.pages[row] if row < len(self.pages) else ""

        # 懒加载 TOC
        if page_name == "TOC" and not self._toc_loaded:
            self._toc_loaded = True
            self.toc_widget = TOCGenWidget(self)
            idx = self.stack.indexOf(self._toc_placeholder)
            self.stack.insertWidget(idx, self.toc_widget)
            self.stack.removeWidget(self._toc_placeholder)
            self._toc_placeholder.deleteLater()
            # 推送当前路径
            base_path = self.get_current_path()
            self.toc_widget.update_path(base_path, self.selected_paths[1], self.selected_paths[2])

        # 懒加载 TFLs
        # v12.10.98：改为「下一帧构造」。先把当前页切到带「⏳ 正在加载」的占位（点击即时响应、
        # 侧栏高亮立刻生效），再用 QTimer.singleShot(0) 把重活（TFLsWidget() 构造 5 个 form +
        # update_path 触发的网络盘 IO）推到下一帧。否则这些同帧串行操作会让点击瞬间「假死」1s+。
        if page_name == "TFLs" and not self._tfls_loaded:
            self._tfls_loaded = True
            # 先显示占位（此时 setCurrentIndex 在方法末尾统一执行，占位已在 stack 中）
            QTimer.singleShot(0, self._build_tfls_widget_deferred)

        # 懒加载 aCRF
        if page_name == "aCRF" and not self._acrf_loaded:
            self._acrf_loaded = True
            self.acrf_widget = aCRFWidget()
            idx = self.stack.indexOf(self._acrf_placeholder)
            self.stack.insertWidget(idx, self.acrf_widget)
            self.stack.removeWidget(self._acrf_placeholder)
            self._acrf_placeholder.deleteLater()
            # 推送当前路径（与 TFLs 一致：以 (p3, p4) 表征 csr 子项目层）
            base_path = self.get_current_path()
            self.acrf_widget.update_path(base_path, self.selected_paths[2], self.selected_paths[3])

        # 懒加载 SDTM
        if page_name == "SDTM" and not self._sdtm_loaded:
            self._sdtm_loaded = True
            self.sdtm_widget = SdtmWidget()
            idx = self.stack.indexOf(self._sdtm_placeholder)
            self.stack.insertWidget(idx, self.sdtm_widget)
            self.stack.removeWidget(self._sdtm_placeholder)
            self._sdtm_placeholder.deleteLater()
            base_path = self.get_current_path()
            self.sdtm_widget.update_path(base_path, self.selected_paths[2], self.selected_paths[3])

        # 懒加载 ADaM（v12.10.11 新增）
        if page_name == "ADaM" and not self._adam_loaded:
            self._adam_loaded = True
            from gui.adam_stepper import AdamWidget
            self.adam_widget = AdamWidget()
            idx = self.stack.indexOf(self._adam_placeholder)
            self.stack.insertWidget(idx, self.adam_widget)
            self.stack.removeWidget(self._adam_placeholder)
            self._adam_placeholder.deleteLater()
            base_path = self.get_current_path()
            self.adam_widget.update_path(base_path, self.selected_paths[2], self.selected_paths[3])

        # 懒加载 M5（v12.10.106 恢复）
        if page_name == "M5" and not self._m5_loaded:
            self._m5_loaded = True
            from gui.m5_stepper import M5Widget
            self.m5_widget = M5Widget()
            idx = self.stack.indexOf(self._m5_placeholder)
            self.stack.insertWidget(idx, self.m5_widget)
            self.stack.removeWidget(self._m5_placeholder)
            self._m5_placeholder.deleteLater()
            base_path = self.get_current_path()
            self.m5_widget.update_path(base_path, self.selected_paths[2], self.selected_paths[3])

        # 懒加载 TDM（v12.10.117）
        if page_name == "TDM" and not self._tdm_loaded:
            self._tdm_loaded = True
            from gui.tdm_page import TDMWidget
            self.tdm_widget = TDMWidget()
            idx = self.stack.indexOf(self._tdm_placeholder)
            self.stack.insertWidget(idx, self.tdm_widget)
            self.stack.removeWidget(self._tdm_placeholder)
            self._tdm_placeholder.deleteLater()
            base_path = self.get_current_path()
            self.tdm_widget.update_path(base_path, self.selected_paths[2], self.selected_paths[3])

        self.stack.setCurrentIndex(row)
        # v12.10.13：切页后立即把焦点转给当前页 widget（避免 focus 留在 sidebar
        # 导致 F5/Ctrl+Enter 被 sidebar 吃掉）
        try:
            cur = self.stack.currentWidget()
            if cur is not None:
                cur.setFocus()
        except Exception:
            pass

    def _build_tfls_widget_deferred(self):
        """v12.10.98：在下一帧真正构造 TFLsWidget 并替换占位页。

        由 _switch_page 的 TFLs 分支通过 QTimer.singleShot(0) 调度。此时「⏳ 正在加载」
        占位已显示、侧栏已高亮，用户已得到即时反馈；这里再付构造 + 路径分发的成本。
        构造完成后把占位换成真正的 widget；若用户此刻仍停在 TFLs 页，同步切换 currentIndex。
        """
        # 防御：占位可能已被替换（极端情况下重复调度）
        if getattr(self, "tfls_widget", None) is not None:
            return
        try:
            self.tfls_widget = TFLsWidget()
        except Exception:
            import logging
            logging.exception("TFLsWidget 构造失败")
            self._tfls_loaded = False  # 允许下次重试
            return

        idx = self.stack.indexOf(self._tfls_placeholder)
        was_current = (self.stack.currentWidget() is self._tfls_placeholder)
        self.stack.insertWidget(idx, self.tfls_widget)
        self.stack.removeWidget(self._tfls_placeholder)
        self._tfls_placeholder.deleteLater()
        self._tfls_placeholder = None

        # 若用户仍停留在 TFLs 页，切到真正的 widget（中途切走则不抢焦点）
        if was_current:
            self.stack.setCurrentWidget(self.tfls_widget)
            try:
                self.tfls_widget.setFocus()
            except Exception:
                pass

        # 推送当前路径（update_path 内部已做逐帧分散调度，不会阻塞本帧）
        base_path = self.get_current_path()
        self.tfls_widget.update_path(base_path, self.selected_paths[2], self.selected_paths[3])

    # ------------------------- 下拉框 / 路径管理 -------------------------
    def _populate_combo(self, combo, items):
        """填充下拉框选项并重置状态"""
        combo.blockSignals(True)
        combo.clear()
        combo.addItems(items)
        combo.setCurrentIndex(-1)
        combo.lineEdit().clear()
        if combo.completer():
            combo.completer().setModel(combo.model())
        combo.blockSignals(False)

    def get_directories(self, path):
        """列出目录下的一级子目录（排除 00_source_data 等归档/中转/隐藏目录）"""
        try:
            if not os.path.exists(path): return []
            excluded = ["00_source_data", "91_export", "92_import", "99_archive"]
            return sorted([d for d in os.listdir(path)
                           if os.path.isdir(os.path.join(path, d))
                           and not d.startswith('.')
                           and d not in excluded])
        except Exception:
            return []

    def refresh_first_dropdown(self):
        """v12.9.8：第一级默认填入 projects（约 90% 场景），用户打开应用即可直接进入 2 级。
        若 Z:\\ 下不存在 projects（边缘场景，如本地测试机），保持原行为不预填。"""
        dirs = self.get_directories(self.z_drive)
        self._populate_combo(self.combos[0], dirs)
        if "projects" in dirs:
            combo = self.combos[0]
            combo.blockSignals(True)
            idx = combo.findText("projects")
            if idx >= 0:
                combo.setCurrentIndex(idx)
            combo.blockSignals(False)
            # 触发 2 级填充（不能直接 emit activated，blockSignals 已恢复，但需要走完整级联逻辑）
            self._on_combo_activated(0)

    def _on_combo_activated(self, level):
        combo = self.combos[level]
        text = combo.currentText()
        if not text: return

        if getattr(self, 'selected_paths', None) and self.selected_paths[level] == text:
            return

        self.selected_paths[level] = text

        for i in range(level + 1, 4):
            self._populate_combo(self.combos[i], [])
            self.selected_paths[i] = ""

        current_path = self.get_current_path(up_to=level)
        if level < 3:
            dirs = self.get_directories(current_path)
            self._populate_combo(self.combos[level + 1], dirs)

        self.update_grid_display()
        # v12.10.80：记忆当前选择，下次启动回放
        self._save_last_selection()

    def get_current_path(self, up_to=3):
        """根据已选路径层级拼接完整路径"""
        path = self.z_drive
        for i in range(up_to + 1):
            if self.selected_paths[i]:
                path = os.path.join(path, self.selected_paths[i])
        return path

    def clear_selections(self):
        """清空所有下拉框，恢复到初始状态"""
        for i in range(4):
            self._populate_combo(self.combos[i], [])
            self.selected_paths[i] = ""
        self.refresh_first_dropdown()
        self.update_grid_display()

    # ------------------------- 外部程序启动 -------------------------
    def launch_saseg(self):
        """顶部"🚀 Launch SAS EG"按钮的入口。

        v12.10.54：回退到光秃秃启动 EG 主窗口的行为（不再尝试通过命令行
        参数定位服务器面板，见 LaunchSASEGThread 的 docstring）。
        """
        self.update_status("正在检查 SAS Enterprise Guide 状态...")
        self.saseg_thread = LaunchSASEGThread(parent=self)
        self.saseg_thread.status_signal.connect(self.update_status)
        self.saseg_thread.error_signal.connect(lambda e: self._show_msg("错误", e, "error"))
        self.saseg_thread.start()

    def launch_vscode(self):
        """顶部"💻 Launch VS Code"按钮的入口（v12.10.55 新增）。

        4 级路径齐全时把 csr 路径作为 VS Code 工作区打开（`code <csr_path>`）；
        否则光秃秃启动 VS Code（默认显示最近项目列表）。

        说明：VS Code 内的 SAS 扩展 Sign In / Ctrl+Alt+U 加载 autorun 等动作由
        用户在 VS Code 内手工完成（IOM 协议限制，每次 session 都需输密码）。
        详 vscode-sas-setup skill §14（SPAhub 集成调用）。
        """
        self.update_status("正在启动 VS Code...")
        base_path = self.get_current_path(up_to=3) if all(self.selected_paths) else ""
        self.vscode_thread = LaunchVSCodeThread(base_path=base_path, parent=self)
        self.vscode_thread.status_signal.connect(self.update_status)
        self.vscode_thread.error_signal.connect(lambda e: self._show_msg("错误", e, "error"))
        self.vscode_thread.start()

    def launch_external_app(self, exe_path, app_name):
        """
        后台线程启动外部 exe（避免网络盘 exe 创建进程时阻塞主线程）。
        多并发安全：每次调用都创建独立线程，通过 finished 信号清理。
        """
        from gui.shortcuts import AppLaunchThread
        if not hasattr(self, '_app_threads'):
            self._app_threads = []

        thread = AppLaunchThread(exe_path, app_name, parent=self)
        thread.status_signal.connect(self.update_status)
        thread.error_signal.connect(lambda t, m: self._show_msg(t, m, "error"))
        thread.finished.connect(lambda t=thread: self._on_app_thread_finished(t))

        self._app_threads.append(thread)
        thread.start()

    def _on_app_thread_finished(self, thread):
        """启动线程结束回调：从持有列表移除并请求 deleteLater"""
        try:
            self._app_threads.remove(thread)
        except ValueError:
            pass
        thread.deleteLater()

    # ------------------------- 任务2：项目文件复制（系统文件复制） -------------------------
    def run_copy_files_script(self):
        """
        点击 Home 页"📁 系统文件复制"按钮：
        在后台线程运行 <项目>/utility/tools/dir_bat_create_copy_files.py，
        不弹控制台、不自动弹窗，状态由顶部状态栏 + 操作栏标签反馈，
        完整输出缓存到 self._copy_last_output，由"详情"按钮主动展开。

        校验：4 级路径必须填全，否则脚本无法解析 proj/prot/ra 上下文。
        """
        if sum(1 for p in self.selected_paths if p) < 4:
            self._show_msg(
                "提示",
                "请先填写完整的 4 级项目路径后再执行系统文件复制。",
                "warning",
            )
            return

        base_path = self.get_current_path()
        script_path = os.path.join(base_path, "utility", "tools", "dir_bat_create_copy_files.py")

        if not os.path.exists(script_path):
            self._show_msg(
                "错误",
                f"找不到脚本：\n{script_path}\n\n请确认 utility\\tools 目录下已部署 dir_bat_create_copy_files.py。",
                "error",
            )
            return

        # 防重入：上一次还在跑就不再下发，避免双线程操作同一脚本
        if getattr(self, "_copy_thread", None) is not None and self._copy_thread.isRunning():
            self.update_status("⏳ 系统文件复制仍在运行，请稍候...")
            return

        # UI 进入"运行中"态：禁用入口按钮、隐藏旧的详情按钮、提示状态
        self.copy_files_btn.setEnabled(False)
        self.copy_detail_btn.setVisible(False)
        self.copy_status_lbl.setText("⏳ 正在后台复制...")
        self.copy_status_lbl.setStyleSheet("color: #409EFF; font-size: 12px; border: none; font-weight: bold;")
        self.update_status("📁 已下发系统文件复制（后台执行中）...")

        from ui_utils import ScriptRunnerThread
        # cwd 设为脚本所在目录，与脚本内 Path(__file__).resolve().parent 推导上下文一致
        self._copy_thread = ScriptRunnerThread(
            script_path=script_path,
            cwd=os.path.dirname(script_path),
            stdin_text="",
            parent=self,
        )
        # 实时输出 → 状态栏（取最近一行的简短版本）
        self._copy_thread.line_signal.connect(self._on_copy_line)
        self._copy_thread.finished_signal.connect(self._on_copy_finished)
        self._copy_thread.start()

    def _on_copy_line(self, line):
        """ScriptRunnerThread 每行回调：截短后写到状态栏，给用户活性反馈"""
        if not line:
            return
        snippet = line if len(line) <= 80 else (line[:77] + "...")
        self.update_status(f"📁 {snippet}")

    def _on_copy_finished(self, return_code, full_output):
        """ScriptRunnerThread 结束回调：恢复按钮、设标签、亮起详情按钮"""
        self.copy_files_btn.setEnabled(True)

        # 缓存输出供"详情"按钮回看
        self._copy_last_output = full_output or "(无输出)"
        from datetime import datetime
        self._copy_last_title = f"系统文件复制日志 — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"

        if return_code == 0:
            self.copy_status_lbl.setText("✅ 完成")
            self.copy_status_lbl.setStyleSheet("color: #67C23A; font-size: 12px; border: none; font-weight: bold;")
            self.update_status("✅ 系统文件复制已完成（点击「📋 详情」查看完整摘要）")
        else:
            self.copy_status_lbl.setText(f"❌ 失败（rc={return_code}）")
            self.copy_status_lbl.setStyleSheet("color: #F56C6C; font-size: 12px; border: none; font-weight: bold;")
            self.update_status(f"❌ 系统文件复制失败（rc={return_code}），请点击「📋 详情」查看输出")

        self.copy_detail_btn.setVisible(True)

        # v11.9：QThread 释放安全模式 —— 把 deleteLater 挂到 finished 信号，避免在
        # worker run() 还未返回时主动 deleteLater 触发 Qt qFatal "Destroyed while
        # thread is still running"（曾在 Log Check 路径上观测到此类无痕闪退）。
        thread_ref = self._copy_thread
        self._copy_thread = None
        if thread_ref is not None:
            try:
                thread_ref.finished.connect(thread_ref.deleteLater)
            except Exception:
                pass

    def _show_copy_detail(self):
        """点击 Home 页"📋 详情"：弹只读对话框展示最近一次复制的完整输出"""
        from ui_utils import ScriptOutputDialog
        dlg = ScriptOutputDialog(
            title=self._copy_last_title or "系统文件复制日志",
            log_text=self._copy_last_output or "(尚未运行)",
            parent=self,
        )
        dlg.exec()

    def update_status(self, msg):
        """底部状态栏文本刷新"""
        self.status_label.setText(msg)

    # ============================================================================
    # 全局快捷键：F5 = 刷新当前页源文件 / Ctrl+Enter = 触发当前页运行按钮
    # ============================================================================
    def _setup_global_shortcuts(self):
        """
        注册全局快捷键。

        路由原则：
          - F5 / Ctrl+Enter 不直接绑定到具体按钮，而是路由到 stack 当前页面
            widget 上的 action_refresh() / action_run() 接口。
          - 各页面 widget 自行决定如何响应（可能调用 refresh_btn.click()，
            也可能委派到子组件如 TFLs Stepper 的当前 step）。
          - 没有定义这些方法的 widget 自动忽略，无需在主窗口里维护页面白名单。

        v12.10.13：
          - context 从默认的 WindowShortcut 改为 ApplicationShortcut，避免 sidebar
            QListWidget 在获得 focus 时把 F5 吃掉切换列表项（之前用户反馈"按 F5 在切换面板"
            就是这个原因 — 焦点在 sidebar 时 F5 被 list 视为 KeyPress 用作导航）。
          - 同时在用户点击 sidebar 后立即把 focus 转给 stack.currentWidget()，
            让 F5/Ctrl+Enter 永远落到当前页面 widget。
        """
        from PySide6.QtGui import QShortcut, QKeySequence

        sc_refresh = QShortcut(QKeySequence("F5"), self)
        sc_refresh.setContext(Qt.ApplicationShortcut)  # v12.10.13 关键修复
        sc_refresh.activated.connect(self._kbd_refresh)

        # Ctrl+Enter：主键盘 Return 与小键盘 Enter 都需绑定
        sc_run_main = QShortcut(QKeySequence("Ctrl+Return"), self)
        sc_run_main.setContext(Qt.ApplicationShortcut)
        sc_run_main.activated.connect(self._kbd_run)
        sc_run_enter = QShortcut(QKeySequence("Ctrl+Enter"), self)
        sc_run_enter.setContext(Qt.ApplicationShortcut)
        sc_run_enter.activated.connect(self._kbd_run)

    def _kbd_refresh(self):
        """F5 → 当前页面 widget.action_refresh()（如果有）"""
        w = self.stack.currentWidget()
        fn = getattr(w, "action_refresh", None)
        if callable(fn):
            try:
                fn()
            except Exception as e:
                import logging
                logging.error(f"action_refresh 失败: {e}")

    def _kbd_run(self):
        """Ctrl+Enter → 当前页面 widget.action_run()（如果有）"""
        w = self.stack.currentWidget()
        fn = getattr(w, "action_run", None)
        if callable(fn):
            try:
                fn()
            except Exception as e:
                import logging
                logging.error(f"action_run 失败: {e}")

    # ============================================================================
    # 右键菜单（v12.10.13）— Windows 风格，类似系统右键菜单
    # ============================================================================
    def contextMenuEvent(self, event):
        """主窗口级别捕获右键 — 弹出对当前页面有效的操作菜单。

        设计原则：
          - 仅显示对当前页面**实际可用**的操作（探测 widget 是否定义了对应方法）
          - 显示快捷键提示（与 _setup_global_shortcuts 注册的一致）
          - 菜单项点击后焦点回到 stack.currentWidget()，让后续 F5/Ctrl+Enter 顺畅工作

        触发：在主窗口任何空白处右键即可（QListWidget / QPushButton 等控件
        默认会消耗右键事件，所以右键菜单主要在中间内容区生效；用户在标签/分隔等
        非交互区域右键也能召出此菜单）。
        """
        from PySide6.QtWidgets import QMenu
        from PySide6.QtGui import QAction
        menu = QMenu(self)
        w = self.stack.currentWidget()

        # 刷新源文件（F5）
        if w is not None and callable(getattr(w, "action_refresh", None)):
            act_refresh = QAction("🔄 刷新源文件\tF5", self)
            act_refresh.triggered.connect(self._kbd_refresh)
            menu.addAction(act_refresh)

        # 运行（Ctrl+Enter）
        if w is not None and callable(getattr(w, "action_run", None)):
            act_run = QAction("▶ 运行当前步骤\tCtrl+Enter", self)
            act_run.triggered.connect(self._kbd_run)
            menu.addAction(act_run)

        if menu.actions():
            menu.addSeparator()

        # 通用：清空所有四级路径下拉
        act_clear = QAction("🧹 清空项目路径选择", self)
        act_clear.triggered.connect(self.clear_selections)
        menu.addAction(act_clear)

        # 通用：拉起 SAS EG（与右上角按钮同源）
        act_eg = QAction("🚀 启动 SAS EG", self)
        act_eg.triggered.connect(self.launch_saseg)
        menu.addAction(act_eg)

        menu.addSeparator()

        # 通用：反馈问题（v12.10.13 新增）
        act_fb = QAction("🐛 反馈问题（自动收集 crash.log）", self)
        act_fb.triggered.connect(self._open_feedback_email)
        menu.addAction(act_fb)

        # 通用：打开 SASEG 应用日志目录
        act_logs = QAction("📂 打开 SPAhub 日志目录", self)
        act_logs.triggered.connect(self._open_app_logs_dir)
        menu.addAction(act_logs)

        if menu.actions():
            menu.exec(event.globalPos())
            # 菜单关闭后焦点交回当前页
            try:
                if w is not None:
                    w.setFocus()
            except Exception:
                pass

    def _open_app_logs_dir(self):
        """打开 SPAhub 程序自身的 logs 目录（含 crash.log）。
        v12.10.47：用 logs_dir() — 优先 %LOCALAPPDATA%\\SPAhub\\logs\\，
        Z 盘只读用户也能正常使用。"""
        import os as _os
        from app_paths import logs_dir as _ld
        ld = _ld()
        try:
            if _os.path.isdir(ld):
                _os.startfile(ld)
            else:
                _os.makedirs(ld, exist_ok=True)
                _os.startfile(ld)
        except Exception as e:
            import logging
            logging.error(f"打开应用日志目录失败: {e}")

    # ============================================================================
    # 反馈问题（v12.10.13）— 优先用 Outlook COM 创建邮件 + 自动加附件 + 显示但不发送
    # ============================================================================
    def _open_feedback_email(self):
        """
        创建一封带 crash.log 附件的反馈邮件，发送给开发者：
            收件人 peilin.liu.pl71@hengrui.com
            抄送   yu.li@hengrui.com   ← v12.10.59 新增

        策略（按优先级）：
          1. 优先用 win32com 调 Outlook COM API：
             - 创建邮件（CreateItem(0)）
             - 自动添加 crash.log 附件（最近 200KB 截取）
             - 自动填好 To / CC / Subject / Body 含项目元信息
             - .Display() 显示邮件供用户审阅，**不自动发送**
          2. fallback：用 mailto 协议（不带附件，提示用户手动附加）
             - mailto 协议规范不支持附件，浏览器/邮件客户端会忽略 attachment 参数
             - CC 通过 mailto 的 &cc= 参数传递
             - 显示弹窗告知用户 crash.log 路径，让用户手动拖到邮件里
        """
        import os as _os
        DEV_EMAIL = "peilin.liu.pl71@hengrui.com"
        CC_EMAIL = "yu.li@hengrui.com"  # v12.10.59：抄送
        SUBJECT = "SPAhub 反馈 - 请描述问题"

        # 收集附件 + 元信息
        from app_paths import app_root as _ar, logs_dir as _ld
        spahub_dir = _ar()
        crash_log_path = _os.path.join(_ld(), "crash.log")  # v12.10.47: 本地 logs
        crash_log_excerpt = ""
        crash_log_full_size = 0
        try:
            if _os.path.isfile(crash_log_path):
                crash_log_full_size = _os.path.getsize(crash_log_path)
                # 取末尾 200KB（最近的崩溃信息）
                with open(crash_log_path, "r", encoding="utf-8", errors="replace") as f:
                    if crash_log_full_size > 200 * 1024:
                        f.seek(crash_log_full_size - 200 * 1024)
                        f.readline()  # 丢弃半截行
                    crash_log_excerpt = f.read()
        except Exception:
            pass

        # 当前项目元信息
        cur_proj = self.get_current_path() if self.selected_paths[0] else "(未选择)"
        body_lines = [
            "（请在此处描述您遇到的问题）",
            "",
            "",
            "---- 请勿删除以下信息（开发者排查用）----",
            f"SPAhub 路径：{spahub_dir}",
            f"当前项目：{cur_proj}",
            f"crash.log 完整大小：{crash_log_full_size} 字节",
            f"crash.log 路径：{crash_log_path}",
        ]
        body_text = "\n".join(body_lines)

        # 优先尝试 Outlook COM
        outlook_ok = self._try_outlook_compose(
            to=DEV_EMAIL, subject=SUBJECT, body=body_text,
            attachment_path=crash_log_path if _os.path.isfile(crash_log_path) else None,
            cc=CC_EMAIL,  # v12.10.59
        )
        if outlook_ok:
            return

        # Fallback：mailto（无附件）
        from urllib.parse import quote
        mailto_url = (
            f"mailto:{DEV_EMAIL}"
            f"?cc={quote(CC_EMAIL)}"  # v12.10.59
            f"&subject={quote(SUBJECT)}"
            f"&body={quote(body_text)}"
        )
        try:
            _os.startfile(mailto_url)
            show_dialog(
                self, "已打开邮件",
                f"已通过默认邮件客户端打开反馈邮件。\n\n"
                f"⚠️ mailto 协议不支持自动附加文件，请您手动将 crash.log 拖入邮件附件：\n"
                f"{crash_log_path}",
                "info"
            )
        except Exception as e:
            show_dialog(
                self, "无法打开邮件客户端",
                f"系统未能调起默认邮件客户端：{e}\n\n"
                f"请手动发邮件给：{DEV_EMAIL}（抄送 {CC_EMAIL}）\n"
                f"附件位置：{crash_log_path}",
                "warning"
            )

    def _try_outlook_compose(self, to, subject, body, attachment_path=None, cc=None):
        """用 Outlook COM API 创建并显示邮件。返回 True 表示成功，False 表示需走 mailto fallback。

        v12.10.59：新增 cc 参数（抄送）。

        要求:
          - Windows + 已安装 Outlook
          - 项目内已含 pywin32（PDT 后处理就用了 win32com.client）

        显示但不发送：用 .Display() 而不是 .Send()，让用户审阅后手动点发送。
        """
        try:
            import win32com.client
        except ImportError:
            return False
        try:
            # 0 = olMailItem
            outlook = win32com.client.Dispatch("Outlook.Application")
            mail = outlook.CreateItem(0)
            mail.To = to
            if cc:  # v12.10.59：设置抄送
                mail.CC = cc
            mail.Subject = subject
            mail.Body = body
            if attachment_path:
                import os as _os
                if _os.path.isfile(attachment_path):
                    mail.Attachments.Add(attachment_path)
            mail.Display(False)  # False = 非模态，让用户能继续操作 SASEG
            return True
        except Exception as e:
            import logging
            logging.error(f"Outlook COM 调用失败，将走 mailto fallback: {e}")
            return False
              