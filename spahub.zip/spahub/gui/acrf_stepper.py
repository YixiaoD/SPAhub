# -*- coding: utf-8 -*-
"""
gui/acrf_stepper.py
===================
aCRF 四步导航器（01 Unzip Source / 02 EDC Data Recode / 03 Import EDC Definition / 04 CRF Annotation）。

v12.10.34：原 SDTM-01 Import EDC Definition 转移到本 stepper 的 03 位置，原 03 CRF Annotation
顺移到 04。转移原因：TOC 生成依赖 EDCDEF 文件，把 EDC 定义导入归到 aCRF 后段更合理；
SDTM 模块只保留 PDT Gen / SDTM Gen / Batch Run 三步（顺移到 01/02/03）。

布局 / 风格对齐 TFLsWidget：
  - 顶部步骤栏（可点击切换；运行中 ⏳；完成 ✅ / ⚠️ / 🟥）
  - 左：业务表单（UnzipSourceForm / EdcRecodeForm / ImportEdcdefForm / CrfAnnotationForm）
  - 右：每步独立的运行日志面板（含 📋 导出日志 按钮）
  - 信号总线：sig_log / sig_status / sig_step_update / sig_run_started / sig_run_finished
  - 路径未齐全：广播 set_wait_hint(True) 给各 Form 让其显示等待提示

aCRF 模块的运行行为：
  - 与 04 Batch Run 不同，aCRF 每个 step 只有一个明确的运行入口（▶ 运行 …），
    且日志面板需求是"每次运行清空旧日志重头记录"（不像 batch 那样要累加），
    因此沿用 TFLs 默认套路：sig_run_started → log_texts.clear() + ⏳ + 计时。

v12.10.116：04 CRF Annotation 的 annomap 编辑器新增「📝 批量赋值」——选中多行后统一赋
  同一个 standard 值。位于 annomap 编辑 Tab 第 2 行（左侧按钮 + 「仅填充空白行」勾选框）。
  实现：只改内存里的 STANDARD combo（复用单格的标蓝逻辑 + 新增 combo._apply_value_programmatic
  程序化设值入口，同步 confirmed 状态避免批量后失焦误弹确认），不写盘；写回仍走原
  「💾 保存并重跑」子线程。覆盖已有非空值时弹一次汇总确认（与单格覆盖同语义）；勾选
  「仅填充空白行」则跳过已有值的行。性能：combo 在加载时已建好，批量赋值不创建控件、
  不碰磁盘，1000 行实测 ~3ms + 单次重绘（setUpdatesEnabled 包裹）。

v12.10.117：批量赋值的两处改进——
  ① 移除「仅填充空白行」勾选框，改为 STANDARD 表头右侧的 Excel 式行筛选 ▽（自定义
     _FilterHeaderView）：显示全部 / 仅未填 / 仅已填，真正隐藏不符合的行（setRowHidden）。
     "只填空白"= 筛选到"仅未填" + 选行赋值；批量赋值跳过被筛选隐藏的行（isRowHidden），
     即使 Ctrl+A 全选也不会动到隐藏的已填行。筛选纯视图层，不影响保存（仍遍历全部行写回）。
     筛选下批量赋值后会重应用筛选（刚填好的行从"仅未填"消失）+ 清选择，形成逐批消化工作流。
  ② 未选行 / 选中行都被筛选隐藏 → 由 info 提示改为 warning 告警，提示至少选一行。

v12.10.118：批量赋值"必须显式选行"修复 + 弹窗展示选中行——
  ① 修 bug：未选任何行点批量赋值时，因 Qt 填表后的"幽灵选择/当前格"使 selectedIndexes()
     非空，guard 失效 → 内置选一行就赋值。修法：(a) _on_annomap_loaded 加载后 clearSelection
     + setCurrentCell(-1,-1) 清幽灵选择；(b) 收集选中行时只统计**非 STANDARD 列**（PAGE/
     ORIGIN）的选中 —— 点 STANDARD combo 落到占位选择不算选行；(c) 每次赋值后清空选择。
     于是必须显式点选 PAGE/ORIGIN 单元格（或点行号选整行）才会赋值，否则 warning 告警。
  ② 取值弹窗顶部新增选中行预览列表（PAGE | ORIGIN → 当前 standard，只读、可滚动、最多
     200 行），让用户赋值前核对将影响哪些行。
"""
import os
import sys
import time
import subprocess
from datetime import datetime

from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                               QStackedWidget, QTextEdit, QFrame, QFileDialog,
                               QDialog, QScrollArea, QSizePolicy)
from PySide6.QtCore import Qt, QTimer, Signal, QThread
from PySide6.QtGui import QTextOption, QColor

from modules.acrf_unzip import UnzipSourceForm
from modules.acrf_edc_recode import EdcRecodeForm
from modules.acrf_import_edcdef import ImportEdcdefForm
from modules.acrf_crf_annotation import CrfAnnotationForm
from modules.acrf_annotation_update import AcrfUpdateForm  # v12.10.118：05 aCRF Update
from ui_utils import show_dialog, show_choice_dialog, scan_status_lbl_style, log_textedit_style, ChevronStepBar, StepProxy
from gui.log_search import attach_log_search  # v12.10.102：日志框内 Ctrl+F 搜索


# ============================================================================
# 工具：用 Excel 打开 log_chk 输出的 .xml
# ============================================================================
def _open_with_excel(file_path: str):
    """
    优先用 Excel 拉起目标文件；失败时回退系统默认关联。

    背景：%log_chk 宏输出的 .xml 是 Microsoft Excel XML Spreadsheet 格式。
    Windows 上若用户已把 .xml 默认关联改成浏览器（Chrome / Edge），os.startfile
    会以浏览器打开，文件会被渲染成 XML 树而非表格。这里显式 'start excel' 让 Excel
    接管，绕开默认关联问题。

    返回 (ok: bool, note: str)：
      ok=True   成功拉起（note 可能为空，或包含"用系统默认程序"提示）
      ok=False  完全失败（note 为错误信息）
    """
    if not os.path.exists(file_path):
        return False, "文件不存在"

    # Windows 优先 'start "" excel "<file>"'：
    #   - cmd 'start' 第一个空字符串是窗口标题占位，避免被当成文件路径
    #   - creationflags=CREATE_NO_WINDOW (0x08000000) 阻止 cmd 的黑窗口闪屏
    if os.name == "nt":
        try:
            subprocess.Popen(
                ['cmd', '/c', 'start', '', 'excel', file_path],
                creationflags=0x08000000,
            )
            return True, ""
        except Exception:
            pass

    # 兜底：系统默认关联
    try:
        if os.name == "nt":
            os.startfile(file_path)
        else:
            subprocess.Popen(['xdg-open', file_path])
        return True, "（已用系统默认程序打开）"
    except Exception as e:
        return False, str(e)



# ============================================================================
# annomap 保存后台线程（v12.9.5）
# ============================================================================
class _AnnomapSaveThread(QThread):
    """v12.9.5：把 annomap.xlsx 的 standard 列写回放到子线程，主线程立即响应。

    根因：openpyxl.load_workbook + wb.save 对 200 行级别的 xlsx 也要 ~1-2s（zip 压缩 + xml 重写），
    在主线程跑 → 按钮点击后明显卡顿。子线程写盘后通过 finished_signal 通知主线程继续。

    线程参数：
      - path: annomap.xlsx 绝对路径
      - col_1based: standard 列 1-based 列号
      - updates: [(src_row_1based, new_value), ...]
    """
    finished_signal = Signal(bool, str)  # ok, err_msg

    def __init__(self, path, col_1based, updates, parent=None):
        super().__init__(parent)
        self.path = path
        self.col = col_1based
        self.updates = updates  # 已经在主线程取好的 (row, value) 列表

    def run(self):
        try:
            import openpyxl
            wb = openpyxl.load_workbook(self.path)
            ws = wb.active
            for src_row, new_val in self.updates:
                ws.cell(row=src_row, column=self.col).value = (new_val or None)
            wb.save(self.path)
            wb.close()
        except Exception as e:
            self.finished_signal.emit(False, str(e))
            return
        self.finished_signal.emit(True, "")


# ============================================================================
# annomap 专用 QComboBox（v12.9.7：禁滚轮防误改）
# ============================================================================
from PySide6.QtWidgets import QComboBox

class _NoWheelComboBox(QComboBox):
    """v12.9.7：禁用 QComboBox 的滚轮事件，把它冒泡到父级（QTableWidget）滚动表格。

    根因：annomap 表格行多，用户滚动表格时鼠标常飘过 standard 列上方的 QComboBox。
    QComboBox 默认的 wheelEvent 会改 currentIndex → 用户在不知情下滚一下就改了好几个 cell
    的 standard 值，频繁误改。

    修法：重写 wheelEvent 调 event.ignore()，让事件继续向上冒泡到 QTableWidget，
    实现"鼠标在 combo 上滚动也只滚动表格，不改值"。改值只能通过：
      1. 点击下拉箭头展开候选列表
      2. 在 lineEdit 中键盘输入做模糊筛选

    v12.10.18：彻底禁右键菜单（三重防线）。
      v12.10.16 仅在外部 _make_standard_combo() 里给 lineEdit 设 NoContextMenu，
      但右键打在 QComboBox 非 lineEdit 区域（下拉箭头/padding/边框）时事件不走 lineEdit
      → 仍弹 Qt 内置编辑菜单（Image 1 现象）。修法：
        ① __init__ 里 self.setContextMenuPolicy(NoContextMenu) — 拦 QComboBox 本体
        ② 重写 setEditable() — 切到可编辑后立即给新 lineEdit 设 NoContextMenu，不依赖外部时序
        ③ 重写 contextMenuEvent() → event.ignore()  — 最终兜底，任何遗漏路径都被拦下
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # 防线 ①：QComboBox 本体不弹任何上下文菜单
        self.setContextMenuPolicy(Qt.NoContextMenu)

    def setEditable(self, editable):
        super().setEditable(editable)
        # 防线 ②：lineEdit 一旦存在立刻同步策略，确保即便 Qt 重建 lineEdit 也覆盖到
        le = self.lineEdit()
        if le is not None:
            le.setContextMenuPolicy(Qt.NoContextMenu)

    def wheelEvent(self, event):
        event.ignore()

    def contextMenuEvent(self, event):
        # 防线 ③：兜底 — 任何路径冒泡到此都直接吞掉，绝不弹菜单
        event.ignore()


# ============================================================================
# v12.10.117：annomap STANDARD 列 Excel 式行筛选表头
# ============================================================================
from PySide6.QtWidgets import QHeaderView as _QHeaderView
from PySide6.QtGui import QPainter, QPolygon
from PySide6.QtCore import QRect, QPoint


class _FilterHeaderView(_QHeaderView):
    """在指定列（STANDARD）的表头右侧画一个 ▽ 筛选按钮，点击发 filter_clicked 信号。

    设计：
      - paintSection：先画默认表头，再在筛选列右侧叠一个小圆角按钮 + 三角（active 时变蓝）。
      - mousePressEvent：命中按钮矩形 → emit filter_clicked + 吞掉事件（不触发排序）；
        否则交给基类（拖动调列宽等正常工作）。
      - set_filter_column / set_filter_active 由外部（加载后 / 筛选切换时）更新。
    """
    filter_clicked = Signal(int)

    def __init__(self, orientation, parent=None):
        super().__init__(orientation, parent)
        self._filter_col = -1      # 显示筛选按钮的逻辑列；-1=不显示
        self._filter_active = False
        self.setSectionsClickable(True)

    def set_filter_column(self, col):
        if col != self._filter_col:
            self._filter_col = col
            self.viewport().update()

    def set_filter_active(self, active):
        active = bool(active)
        if active != self._filter_active:
            self._filter_active = active
            self.viewport().update()

    @staticmethod
    def _glyph_rect(section_rect):
        """筛选按钮矩形：贴 section 右缘、垂直居中的 16x16 小方块。"""
        sz = 16
        x = section_rect.right() - sz - 5
        y = section_rect.center().y() - sz // 2
        return QRect(x, y, sz, sz)

    def paintSection(self, painter, rect, logicalIndex):
        super().paintSection(painter, rect, logicalIndex)
        if logicalIndex != self._filter_col or rect.width() < 60:
            return
        gr = self._glyph_rect(rect)
        painter.save()
        painter.setRenderHint(QPainter.Antialiasing, True)
        active = self._filter_active
        # 按钮底 + 边
        painter.setBrush(QColor("#409EFF") if active else QColor("#FFFFFF"))
        painter.setPen(QColor("#409EFF") if active else QColor("#C0C4CC"))
        painter.drawRoundedRect(gr, 3, 3)
        # 下三角（▽）
        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor("#FFFFFF") if active else QColor("#606266"))
        cx, cy = gr.center().x(), gr.center().y()
        tri = QPolygon([QPoint(cx - 4, cy - 2), QPoint(cx + 4, cy - 2), QPoint(cx, cy + 3)])
        painter.drawPolygon(tri)
        painter.restore()

    def mousePressEvent(self, event):
        if self._filter_col >= 0:
            try:
                pos = event.position().toPoint()   # PySide6 6.x
            except AttributeError:
                pos = event.pos()
            logical = self.logicalIndexAt(pos.x())
            if logical == self._filter_col:
                x = self.sectionViewportPosition(logical)
                w = self.sectionSize(logical)
                section_rect = QRect(x, 0, w, self.height())
                if self._glyph_rect(section_rect).contains(pos):
                    self.filter_clicked.emit(logical)
                    return  # 吞掉，不触发排序/默认行为
        super().mousePressEvent(event)


# ============================================================================
# v12.10.14：annomap PAGE / ORIGIN 列双击进入 read-only 编辑态（允许选字符复制）
# ============================================================================
from PySide6.QtWidgets import QStyledItemDelegate, QLineEdit, QStyleOptionViewItem, QStyle, QApplication
from PySide6.QtGui import QPalette


class _ReadOnlyEditDelegate(QStyledItemDelegate):
    """双击 cell 进入编辑态，但 editor 是 read-only QLineEdit。

    设计目标：
      - 双击 PAGE / ORIGIN 列 → 弹出文本框，文本默认全选 → 用户可拖鼠标选字符 → Ctrl+C 复制
      - ESC / 失焦 / 回车 → 退出编辑态，cell 内容**不写回**（read-only）

    v12.10.18：加 paint() 接管 hover/selection 渲染 — 彻底修"鼠标悬停字消失"。

    替代方案对比：
      - v12.10.13 用的是右键菜单"复制部分文本"+ 弹窗 — 操作多一步，且 menu.exec 阻塞期间
        会触发 QTableWidget 重绘怪异（用户报"右键点选项后整行字消失"）
      - 双击进编辑态是 Qt 表格交互的标准范式，体感与 Excel 一致
    """

    def createEditor(self, parent, option, index):
        editor = QLineEdit(parent)
        editor.setReadOnly(True)
        # 视觉上区分编辑态（淡蓝边框，便于用户感知"现在能选字符"）
        editor.setStyleSheet(
            "QLineEdit { border: 1px solid #409EFF; background-color: #FFFFFF; "
            "padding: 2px 4px; color: #303133; }"
        )
        return editor

    def setEditorData(self, editor, index):
        """从 model 把文本灌进 editor，默认全选便于立即 Ctrl+C 复制全文。"""
        text = index.data(Qt.DisplayRole) or ""
        editor.setText(text)
        editor.selectAll()

    def setModelData(self, editor, model, index):
        """read-only 编辑器：失焦 / 回车时**不写回 model**，保证数据不被意外修改。"""
        pass

    def paint(self, painter, option, index):
        """v12.10.18：接管 paint 解决"鼠标悬停字符消失"。

        根因分析（v12.10.14~17 三次失败的真相）：
          1. 渲染逻辑给每个 cell 都 setBackground(QColor) 把 xlsx 里的浅色背景塞进 BackgroundRole
             （annomap.xlsx 实际：formmap 正文 #FFFFFF 纯白；anno 全表 #FAFBFE 近白）
          2. Qt model 数据角色（BackgroundRole）的优先级 **高于** stylesheet 的 ::item:hover/:selected —
             一旦 setBackground 调用过，stylesheet 里 :hover { background-color } / :selected { ... }
             **完全失效**。这是 v12.10.16/17 改 stylesheet 始终无效的原因。
          3. 而 hover 时 Windows native style（QWindowsVistaStyle）在 drawControl(CE_ItemViewItem) 里
             检测到 State_MouseOver flag 后，会进入"hot-item 绘制路径"，从系统主题取
             SystemColors.HotTrackText 作为文字色 —— Win11/10 浅色主题下这个值约等于 Highlight
             的反色 ≈ **白色**。stylesheet 的 :hover { color } 也压不过这一步（它发生在
             drawControl 内部，stylesheet style 触不到）。
          4. 最终：hover 时文字 = 白色 + cell 背景被 BackgroundRole 锁定为白 → **白字白底 → 字消失**。

        本方法的修法：
          - 复制一份 option，**剥离 State_MouseOver flag** → native style 不再走 hot-item 路径
            → 文字保留 ForegroundRole 默认（黑）
          - 强制 palette HighlightedText = #303133（兜底 selection 蓝底白字 — 之前 image 2 的问题）
          - 自己在 paint 末尾叠一层 α=25 的极淡蓝 overlay 提供 hover 视觉反馈（不掩盖文字）
        """
        # 复制 option（不能改 caller 的对象 — Qt 内部会复用）
        opt = QStyleOptionViewItem(option)
        self.initStyleOption(opt, index)

        is_hover = bool(option.state & QStyle.State_MouseOver)
        is_selected = bool(option.state & QStyle.State_Selected)

        # 关键 1：剥离 MouseOver flag → 阻止 native style 进入 hot-item 文字色覆盖
        opt.state &= ~QStyle.State_MouseOver

        # 关键 2：兜底 selection 文字色（防 Win11 默认 HighlightedText=white → 蓝底白字看不清）
        for grp in (QPalette.Active, QPalette.Inactive, QPalette.Disabled):
            opt.palette.setColor(grp, QPalette.HighlightedText, QColor("#303133"))

        # 让 style 正常画（含 BackgroundRole 浅色背景 + 文字 + selection 高亮）
        widget = opt.widget
        style = widget.style() if widget else QApplication.style()
        style.drawControl(QStyle.CE_ItemViewItem, opt, painter, widget)

        # 关键 3：仅 hover（非 selection）时叠浅蓝 overlay 提供视觉反馈
        # alpha=25/255≈10%，肉眼可见 hover 效果但不影响文字可读性
        if is_hover and not is_selected:
            painter.save()
            painter.fillRect(option.rect, QColor(64, 158, 255, 25))
            painter.restore()


# ============================================================================
# v12.10.12：annomap 加载到子线程 — 主线程只做轻量 setItem 渲染
# ============================================================================
class _AnnomapLoadThread(QThread):
    """把 annomap.xlsx 的 IO（openpyxl 读两次：data + style）整体放到子线程。

    历史问题（v12.10.6 修过部分）：
      - update_path 同步调 _load_annomap_into_table → 主线程开 ~1.5s 读 xlsx + ~1s
        构建 1000 个 QTableWidgetItem/QComboBox → 用户感知 >2s 卡顿
      - v12.10.6 用 QTimer.singleShot(0) 把它推到下一帧，仅是 UI"按钮先高亮"的视觉补偿，
        总耗时不变 — 用户切到 03 步骤后还是卡 >2s 才能看到表格

    新策略（v12.10.12）：
      - 子线程：openpyxl 双 wb 读 → 提取 (rows_data, max_col, max_row, cell_bg_map, ...)
        cell_bg_map 是预提取的 (row, col) -> QColor.rgb int 字典（QColor 不能跨线程传，
        所以子线程只算 RGB 整数，主线程再 QColor.fromRgb 包装）
      - 主线程：拿到结果只做 setItem + setCellWidget（≤500ms）
      - 子线程读 IO 期间用户可以自由切别的 step / 滚滚动条

    finished_signal 协议：
      ok       True/False
      payload  ok=True: dict 含 headers/std_options/visible_rows/rows_data/cell_bgs/std_col/page_col
               ok=False: error 字符串
    """
    finished_signal = Signal(bool, object)

    def __init__(self, path, parent=None):
        super().__init__(parent)
        self.path = path

    def run(self):
        import logging
        try:
            import openpyxl
            # 数据：read_only 容错读
            wb_data = openpyxl.load_workbook(self.path, data_only=True, read_only=True)
            ws_data = wb_data.active
            rows_data = []
            for row in ws_data.iter_rows(values_only=True):
                rows_data.append(list(row))
            wb_data.close()

            if not rows_data or len(rows_data) < 2:
                self.finished_signal.emit(True, {"empty": True})
                return

            max_col = max(len(r) for r in rows_data)
            max_row = len(rows_data)

            headers_row = rows_data[0]
            headers = []
            for j in range(max_col):
                v = headers_row[j] if j < len(headers_row) else None
                headers.append("" if v is None else str(v))
            headers_lower = [h.lower() for h in headers]
            try:
                page_col = headers_lower.index("page")
            except ValueError:
                page_col = -1
            try:
                std_col = headers_lower.index("standard")
            except ValueError:
                std_col = -1

            std_uniques = set()
            if std_col >= 0:
                for i in range(1, max_row):
                    row = rows_data[i]
                    if std_col < len(row):
                        v = row[std_col]
                        if v is not None:
                            s = str(v).strip()
                            if s:
                                std_uniques.add(s)
            std_options = [""] + sorted(std_uniques)

            # 收集 page 不为空的可见行
            visible_rows = []
            for i in range(1, max_row):
                row = rows_data[i]
                if page_col >= 0:
                    pv = row[page_col] if page_col < len(row) else None
                    if pv is None or not str(pv).strip():
                        continue
                visible_rows.append((i, i + 1))

            # 样式：单独 wb 扒背景色（容错；失败就放弃样式）
            # 子线程不能用 QColor — 把 RGB 拆成 (r, g, b) tuple，主线程组回 QColor
            cell_bgs = {}  # (visible_tr, col_j) -> (r, g, b)
            try:
                wb_style = openpyxl.load_workbook(self.path, data_only=True, read_only=False)
                ws_style = wb_style.active
                for tr, (data_idx, src_row) in enumerate(visible_rows):
                    for j in range(max_col):
                        if j == std_col:
                            continue  # standard 列是 QComboBox，不需要背景
                        try:
                            cell = ws_style.cell(row=src_row, column=j + 1)
                            rgb = self._extract_cell_bg_rgb(cell)
                            if rgb is not None:
                                cell_bgs[(tr, j)] = rgb
                        except Exception:
                            pass
                wb_style.close()
            except Exception as e:
                logging.error(f"_AnnomapLoadThread 样式 wb 加载失败：{e}")

            self.finished_signal.emit(True, {
                "empty": False,
                "headers": headers,
                "rows_data": rows_data,
                "max_col": max_col,
                "max_row": max_row,
                "std_col": std_col,
                "page_col": page_col,
                "std_options": std_options,
                "visible_rows": visible_rows,
                "cell_bgs": cell_bgs,
            })
        except Exception as e:
            logging.error(f"_AnnomapLoadThread 失败：{e}", exc_info=True)
            self.finished_signal.emit(False, str(e))

    @staticmethod
    def _extract_cell_bg_rgb(cell):
        """从 openpyxl cell 提取 RGB tuple；与 _extract_cell_bg_color 对齐但返回 (r,g,b) 不创 QColor。"""
        try:
            fill = cell.fill
            if fill is None or fill.fill_type not in ("solid",):
                return None
            color = fill.start_color
            if color is None:
                return None
            if color.type != "rgb" or not color.rgb:
                return None
            rgb_str = str(color.rgb)
            if len(rgb_str) == 8:  # AARRGGBB
                rgb_str = rgb_str[2:]
            if len(rgb_str) != 6:
                return None
            r = int(rgb_str[0:2], 16)
            g = int(rgb_str[2:4], 16)
            b = int(rgb_str[4:6], 16)
            # 白色 / 浅灰背景视为无样式（避免一片白覆盖默认主题）
            if r >= 240 and g >= 240 and b >= 240:
                return None
            return (r, g, b)
        except Exception:
            return None


# ============================================================================
# aCRFWidget 主类
# ============================================================================
class aCRFWidget(QWidget):
    """aCRF 两步导航容器：步骤栏 + 左右分栏（4:6）"""

    def __init__(self):
        super().__init__()
        self.base_path = ""
        self.p3 = ""
        self.p4 = ""

        # v12.10.34：steps 加 03 Import EDC Definition；原 03 CRF Annotation 顺移到 04
        self.steps = ["Unzip Source", "EDC Data Recode", "Import EDC Definition", "CRF Annotation", "aCRF Update"]
        self.step_original_texts = {step: f"0{i + 1} {step}" for i, step in enumerate(self.steps)}

        self.step_btns = {}
        self.log_texts = {}
        self.log_status_lbls = {}
        self.export_btns = {}
        # v12.10.123：运行日志 WARNING/ERROR 正向筛选（与 adam/tfls 同款）
        self._log_entries = {}       # step -> [(level, msg), ...]
        self._log_filters = {}       # step -> {"WARNING": bool, "ERROR": bool}
        self._log_filter_chks = {}   # step -> {level: QCheckBox}

        # 耗时跟踪
        self._run_start_times = {}
        self._elapsed_label_cache = {}
        self._elapsed_timer = QTimer(self)
        self._elapsed_timer.setInterval(2000)
        self._elapsed_timer.timeout.connect(self._tick_running_elapsed)

        self._setup_ui()
        self._connect_components()

    # ------------------------- UI -------------------------
    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # --- 顶部步骤栏 ---
        stepper_frame = QFrame()
        stepper_frame.setStyleSheet("background-color: #FFFFFF; border: 1px solid #E4E7ED; border-radius: 6px;")
        stepper_layout = QHBoxLayout(stepper_frame)
        stepper_layout.setContentsMargins(10, 8, 10, 8)

        # v12.10.90：步骤栏改 chevron 箭头管道（方案B）。
        self.step_bar = ChevronStepBar(self.steps, self.step_original_texts)
        self.step_bar.step_clicked.connect(self.switch_step)
        stepper_layout.addWidget(self.step_bar)
        self.step_btns = {s: StepProxy(self.step_bar, s) for s in self.steps}

        layout.addWidget(stepper_frame)
        layout.addSpacing(10)

        # --- 左右分栏 ---
        from PySide6.QtWidgets import QSplitter
        self.splitter = QSplitter(Qt.Horizontal)
        self.splitter.setStyleSheet("QSplitter::handle { background-color: #EBEEF5; width: 4px; }")
        self.splitter.setChildrenCollapsible(False)

        self.left_stack = QStackedWidget()
        self.right_stack = QStackedWidget()
        self.right_stack.setStyleSheet("background-color: #FFFFFF; border: 1px solid #E4E7ED; border-radius: 6px;")

        self.splitter.addWidget(self.left_stack)
        self.splitter.addWidget(self.right_stack)
        # v12.8：用 setSizes 给绝对像素初值，让 splitter 不被子部件 sizeHint 撑动。
        # 主窗口默认宽 1400 → 左 4 : 右 6 ≈ 480 : 720（去除侧栏与边距）。
        # 切换到 03 CRF Annotation 时由 _on_step_switched 调成 5:7（让 annomap 编辑空间稍大）。
        # v12.10.100：分栏拖动范围过小的根因 —— QStackedWidget 的最小宽度 = 其所有页面
        # （4 个 step 表单 / 4 个右侧日志面板，含 CRF 的 annomap 表格与复杂表单）里
        # minimumSizeHint 最大那一个；任何一页"天然较宽"就把整列下限抬高，handle 几乎拖不动。
        # 显式给两列设一个较小的 minimumWidth，覆盖内容驱动的 minimumSizeHint，
        # 让用户能在更大范围内自由调节左右比例（仍受 setChildrenCollapsible(False) 保护不塌成 0）。
        self.left_stack.setMinimumWidth(240)
        self.right_stack.setMinimumWidth(280)
        self.splitter.setStretchFactor(0, 4)
        self.splitter.setStretchFactor(1, 6)
        self.splitter.setSizes([480, 720])
        layout.addWidget(self.splitter, 1)

        # --- 各模块表单 ---
        self.unzip_form = UnzipSourceForm()
        self.edc_form = EdcRecodeForm()
        # v12.10.34：新增 03 Import EDC Definition（原 SDTM-01 转移过来）
        self.import_form = ImportEdcdefForm()
        self.crf_form = CrfAnnotationForm()

        self.left_stack.addWidget(self.unzip_form)
        self.right_stack.addWidget(self._create_right_log_panel("Unzip Source"))

        self.left_stack.addWidget(self.edc_form)
        self.right_stack.addWidget(self._create_right_log_panel("EDC Data Recode"))

        # v12.10.34：插入 03 Import EDC Definition 在 EDC Recode 之后、CRF Annotation 之前
        self.left_stack.addWidget(self.import_form)
        self.right_stack.addWidget(self._create_right_log_panel("Import EDC Definition"))

        self.left_stack.addWidget(self.crf_form)
        self.right_stack.addWidget(self._create_right_log_panel("CRF Annotation"))

        # v12.10.118：05 aCRF Update —— 表单自带右面板（日志 + 灰锁 annomap 编辑器），
        # 不复用 04 共享编辑器（隔离 04）。把表单自己的 log/status 控件登记进 log_texts /
        # log_status_lbls，让 stepper 里遍历 self.steps 清理/置就绪的通用循环不 KeyError。
        self.update_form = AcrfUpdateForm()
        _update_right = self.update_form.create_right_panel()
        self.log_texts["aCRF Update"] = self.update_form.log_text
        self.log_status_lbls["aCRF Update"] = self.update_form.right_status
        self.left_stack.addWidget(self.update_form)
        self.right_stack.addWidget(_update_right)

        self.switch_step("Unzip Source")

    def _create_right_log_panel(self, step_name):
        """对齐 TFLs 的日志面板：标题栏 + 日志文本 + 状态标签

        v12.5：EDC Data Recode 的标题栏额外多一个「📊 打开 log_chk」按钮 —
        点击时扫描 07_logs 下 edc_data_recode_log_chk*.xml 取 mtime 最新一份，
        强制用 Excel 打开（系统默认关联可能是浏览器）；找不到时弹提示。

        v12.6：CRF Annotation 步骤的右侧改用 QTabWidget — [运行日志] [📊 annomap 编辑]
        让用户能在面板内直接编辑 annomap.xlsx 而不必启动外部 Excel；其它步骤保持单 panel。
        """
        # CRF Annotation 走专属的 tab 化构造
        if step_name == "CRF Annotation":
            return self._create_crf_right_panel(step_name)

        rw = QFrame()
        rl = QVBoxLayout(rw)
        rl.setContentsMargins(10, 10, 10, 10)

        log_header = QHBoxLayout()
        title_lbl = QLabel(f"📄 {step_name} 运行日志")
        title_lbl.setStyleSheet("font-size: 13px; font-weight: bold; color: #606266; border: none;")
        log_header.addWidget(title_lbl)
        log_header.addStretch()

        # EDC Data Recode 专属：打开 07_logs 下最新的 edc_data_recode_log_chk*.xml
        if step_name == "EDC Data Recode":
            chk_btn = QPushButton("📊 打开 log_chk")
            chk_btn.setStyleSheet("""
                QPushButton { background-color: #FDF6EC; color: #E6A23C; border: 1px solid #F5DAB1; padding: 4px 10px; border-radius: 4px; font-size:12px; font-weight:bold;}
                QPushButton:hover { background-color: #E6A23C; color: #FFFFFF; }
            """)
            chk_btn.setToolTip(
                "打开 07_logs/edc_data_recode_log_chk*.xml 中时间戳最新的一份（用 Excel 打开）"
            )
            chk_btn.clicked.connect(self._open_latest_edc_log_chk)
            log_header.addWidget(chk_btn)

        exp_btn = QPushButton("📋 导出日志")
        exp_btn.setStyleSheet("""
            QPushButton { background-color: #ECF5FF; color: #409EFF; border: 1px solid #B3D8FF; padding: 4px 10px; border-radius: 4px; font-size:12px; font-weight:bold;}
            QPushButton:hover { background-color: #409EFF; color: #FFFFFF; }
        """)
        exp_btn.clicked.connect(lambda checked, s=step_name: self._export_log(s))
        self.export_btns[step_name] = exp_btn
        log_header.addWidget(exp_btn)
        rl.addLayout(log_header)
        self._add_log_filter_row(step_name, rl)

        txt = QTextEdit()
        txt.setReadOnly(True)
        attach_log_search(txt)  # v12.10.102：日志框内 Ctrl+F 搜索
        # 与 TFLs 日志面板一致：强制按部件宽度自动换行，关掉横向滚动条
        txt.setLineWrapMode(QTextEdit.WidgetWidth)
        txt.setWordWrapMode(QTextOption.WrapAnywhere)
        txt.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        txt.setStyleSheet(
            log_textedit_style(with_padding=True))
        rl.addWidget(txt)

        stat = QLabel("就绪")
        stat.setAlignment(Qt.AlignCenter)
        stat.setStyleSheet("font-size: 13px; font-weight: bold; color: #909399; padding-top: 5px;")
        rl.addWidget(stat)

        self.log_texts[step_name] = txt
        self.log_status_lbls[step_name] = stat
        return rw

    def _create_crf_right_panel(self, step_name):
        """v12.6：CRF Annotation 的右侧 — QTabWidget 容器
          Tab 1：运行日志 + 状态栏（沿用其它步骤的样式）
          Tab 2：annomap 编辑器（QTableWidget），加载 / 保存按钮
        """
        from PySide6.QtWidgets import QTabWidget, QTableWidget

        rw = QFrame()
        rl = QVBoxLayout(rw)
        rl.setContentsMargins(10, 10, 10, 10)
        rl.setSpacing(8)

        tabs = QTabWidget()
        tabs.setStyleSheet("""
            QTabWidget::pane { border: 1px solid #E4E7ED; border-radius: 4px; }
            QTabBar::tab { background: #F5F7FA; color: #606266; padding: 6px 14px; border: 1px solid #E4E7ED; border-bottom: none; border-top-left-radius: 4px; border-top-right-radius: 4px; }
            QTabBar::tab:selected { background: #FFFFFF; color: #409EFF; font-weight: bold; }
        """)

        # ----- Tab 1: 运行日志 -----
        tab_log = QFrame()
        tlay = QVBoxLayout(tab_log)
        tlay.setContentsMargins(8, 8, 8, 8)

        log_header = QHBoxLayout()
        title_lbl = QLabel(f"📄 {step_name} 运行日志")
        title_lbl.setStyleSheet("font-size: 13px; font-weight: bold; color: #606266; border: none;")
        log_header.addWidget(title_lbl)
        log_header.addStretch()
        exp_btn = QPushButton("📋 导出日志")
        exp_btn.setStyleSheet("""
            QPushButton { background-color: #ECF5FF; color: #409EFF; border: 1px solid #B3D8FF; padding: 4px 10px; border-radius: 4px; font-size:12px; font-weight:bold;}
            QPushButton:hover { background-color: #409EFF; color: #FFFFFF; }
        """)
        exp_btn.clicked.connect(lambda checked, s=step_name: self._export_log(s))
        self.export_btns[step_name] = exp_btn
        log_header.addWidget(exp_btn)
        tlay.addLayout(log_header)
        self._add_log_filter_row(step_name, tlay)

        txt = QTextEdit()
        txt.setReadOnly(True)
        attach_log_search(txt)  # v12.10.102：日志框内 Ctrl+F 搜索
        txt.setLineWrapMode(QTextEdit.WidgetWidth)
        txt.setWordWrapMode(QTextOption.WrapAnywhere)
        txt.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        txt.setStyleSheet(
            log_textedit_style(with_padding=True))
        tlay.addWidget(txt)

        stat = QLabel("就绪")
        stat.setAlignment(Qt.AlignCenter)
        stat.setStyleSheet("font-size: 13px; font-weight: bold; color: #909399; padding-top: 5px;")
        tlay.addWidget(stat)
        tabs.addTab(tab_log, "📄 运行日志")

        self.log_texts[step_name] = txt
        self.log_status_lbls[step_name] = stat

        # ----- Tab 2: annomap 编辑器 -----
        tab_map = QFrame()
        mlay = QVBoxLayout(tab_map)
        mlay.setContentsMargins(8, 8, 8, 8)

        # v12.9.4：右上 header 区
        # - 删除 "(仅 standard 列可改)" 提示文字（用户要求）
        # - 「保存并重跑 autoanno」自带独立的中止状态（不再联动左侧 btn_run_draft）
        # - 第二行加「📋 导出 xfdf」按钮（PyMuPDF 自动注入存在视觉差异，提供手动导入路径）
        # 第 1 行：标题 + 状态 + 💾 保存并重跑 autoanno / 🟥 中止 autoanno
        map_header_top = QHBoxLayout()
        map_title = QLabel("📊 annomap.xlsx 编辑")
        map_title.setStyleSheet("font-size: 13px; font-weight: bold; color: #606266; border: none;")
        map_header_top.addWidget(map_title)
        self.annomap_path_lbl = QLabel("")
        self.annomap_path_lbl.setStyleSheet("color: #909399; font-size: 11px; border: none;")
        map_header_top.addWidget(self.annomap_path_lbl)
        map_header_top.addStretch()

        self.btn_annomap_save_run = QPushButton("💾 保存并重跑 autoanno")
        self.btn_annomap_save_run.setStyleSheet("""
            QPushButton { background-color: #67C23A; color: white; border: none; padding: 4px 14px; border-radius: 4px; font-size:12px; font-weight:bold;}
            QPushButton:hover { background-color: #85CE61; }
            QPushButton:disabled { background-color: #C8E5BB; }
        """)
        self.btn_annomap_save_run.setToolTip(
            "把当前 standard 列下拉值写回 annomap.xlsx，然后立即跑 %autoanno_study_draft 重新生成 draft.xfdf。\n"
            "此按钮独立工作 — 不会影响左侧「首次运行」的锁死状态。"
        )
        self.btn_annomap_save_run.clicked.connect(self._save_annomap_and_rerun)
        map_header_top.addWidget(self.btn_annomap_save_run)

        # v12.9.4：保存并重跑专用中止按钮（运行期间替代上面的按钮显示，独立于左侧）
        self.btn_annomap_cancel = QPushButton("🟥 中止 autoanno")
        self.btn_annomap_cancel.setStyleSheet("""
            QPushButton { background-color: #FEF0F0; color: #F56C6C; border: 1px solid #FBC4C4; padding: 4px 14px; border-radius: 4px; font-size:12px; font-weight:bold;}
            QPushButton:hover { background-color: #F56C6C; color: #FFFFFF; }
        """)
        self.btn_annomap_cancel.setVisible(False)
        self.btn_annomap_cancel.setCursor(Qt.PointingHandCursor)
        self.btn_annomap_cancel.clicked.connect(self._cancel_annomap_rerun)
        map_header_top.addWidget(self.btn_annomap_cancel)
        mlay.addLayout(map_header_top)

        # 第 2 行：左侧 📝 批量赋值（v12.10.116）；右侧 📋 导入 xfdf
        # v12.10.117：原「仅填充空白行」勾选框移除 —— 改为 STANDARD 表头右侧的 Excel 式
        # 行筛选（显示全部 / 仅未填 / 仅已填）。"只填空白"靠"筛选到仅未填 + 选择"实现，
        # 批量赋值会跳过被筛选隐藏的行（详见 _batch_assign_standard / _apply_standard_filter）。
        map_header_bottom = QHBoxLayout()

        # v12.10.116：批量赋值 standard —— 选中多行后统一赋同一个 standard 值。
        # 仅改内存里的 combo（复用单格的标蓝逻辑），不写盘；用户检查后照常点「保存并重跑」。
        self.btn_batch_assign = QPushButton("📝 批量赋值")
        self.btn_batch_assign.setStyleSheet("""
            QPushButton { background-color: #ECF5FF; color: #409EFF; border: 1px solid #B3D8FF; padding: 4px 12px; border-radius: 4px; font-size:12px; font-weight:bold;}
            QPushButton:hover { background-color: #409EFF; color: #FFFFFF; }
            QPushButton:disabled { background-color: #F5F7FA; color: #C0C4CC; }
        """)
        self.btn_batch_assign.setCursor(Qt.PointingHandCursor)
        self.btn_batch_assign.setToolTip(
            "为选中的多行统一赋同一个 standard 值。\n"
            "  · 选行：点击左侧行号选整行，按住 Ctrl / Shift 可多选\n"
            "  · 只想填空白行：先点 STANDARD 表头的 ▽ 筛选「仅未填」，再选行赋值\n"
            "  · 覆盖已有非空值时会弹确认；赋值后蓝色高亮表示改动\n"
            "  · 仅改内存，需再点「💾 保存并重跑 autoanno」才生效"
        )
        self.btn_batch_assign.clicked.connect(self._batch_assign_standard)
        map_header_bottom.addWidget(self.btn_batch_assign)

        map_header_bottom.addStretch()

        # v12.9.5：原"导出 xfdf"逻辑改为"导入 xfdf"。
        # 实际工作流：autoanno 在 draft/ 下产出 draft.xfdf；ecrf.pdf 也在 draft/ 下（v12.9.5 新逻辑）。
        # 用户应在 Adobe 中打开 draft/ecrf.pdf → Comments → Import Comments → 选 draft/draft.xfdf → 保存。
        # PyMuPDF 自动注入因库限制（add_freetext_annot 不能还原 line/polygon/highlight 等）已完全删除。
        self.btn_import_xfdf = QPushButton("📋 导入 xfdf")
        self.btn_import_xfdf.setStyleSheet("""
            QPushButton { background-color: #ECF5FF; color: #409EFF; border: 1px solid #B3D8FF; padding: 4px 12px; border-radius: 4px; font-size:12px; font-weight:bold;}
            QPushButton:hover { background-color: #409EFF; color: #FFFFFF; }
            QPushButton:disabled { background-color: #F5F7FA; color: #C0C4CC; }
        """)
        self.btn_import_xfdf.setToolTip(
            "用 Adobe Acrobat 打开 draft/ecrf.pdf，并引导用户在 Adobe 中：\n"
            "  Comments → ⋮ → Import Comments → 选 draft/draft.xfdf\n"
            "  之后另存（用户自行调整 + 放到 final/ 后再跑 23 Final）。"
        )
        self.btn_import_xfdf.clicked.connect(self._import_xfdf_with_adobe)
        map_header_bottom.addWidget(self.btn_import_xfdf)
        mlay.addLayout(map_header_bottom)

        self.annomap_table = QTableWidget()
        self.annomap_table.setStyleSheet(
            "QTableWidget { background-color: #FFFFFF; border: 1px solid #E4E7ED; border-radius: 4px; gridline-color: #E4E7ED; }"
            "QHeaderView::section { background-color: #F5F7FA; padding: 4px; border: 1px solid #E4E7ED; font-weight: bold; }"
            # v12.10.17：明确 hover/selected 状态的颜色 — 之前用户报"鼠标悬停时字消失"的真正根因：
            # Windows 默认 QTableWidget item:hover 的处理是系统主题级（QStyle::drawPrimitive
            # 用 PE_PanelItemViewItem），会**强制覆盖前景色**为主题色（多数 Windows 11 主题
            # 是浅色甚至白色）→ 浅色前景 + 浅色 hover 背景 → 字符不可见。
            #
            # 通过 stylesheet 显式定义 :hover 规则强制保留前景：
            #   - hover 用极浅蓝 #F0F7FF（不抢眼）+ 显式黑前景 #303133
            #   - selected 浅蓝 #C6E2FF + 黑前景
            #   - 其他状态用 inherit 让 setBackground 设的原始 xlsx 颜色生效
            # !important 不能用（Qt stylesheet 不支持），但显式声明 color 已经够覆盖系统默认
            "QTableWidget::item { color: #303133; }"
            "QTableWidget::item:hover { background-color: #F0F7FF; color: #303133; }"
            "QTableWidget::item:selected { background-color: #C6E2FF; color: #303133; }"
            "QTableWidget::item:selected:hover { background-color: #B3D8FF; color: #303133; }"
        )
        self.annomap_table.setAlternatingRowColors(True)
        # v12.8：关键修复 — 防止 QTableWidget 的 sizeHint 把父 splitter/窗口撑大。
        # 默认 sizeAdjustPolicy=AdjustIgnored 但有些 Qt 版本下表格列宽变化仍会触发布局重算
        # 进而推动 QSplitter 重新分配 → 主窗口被拉宽 → SAS EG 按钮溢出屏幕。
        # 显式设三件套确保表格在 splitter 提供的固定区域内绘制：
        from PySide6.QtWidgets import QAbstractScrollArea, QSizePolicy
        self.annomap_table.setSizeAdjustPolicy(QAbstractScrollArea.AdjustIgnored)
        self.annomap_table.setHorizontalScrollMode(QTableWidget.ScrollPerPixel)
        self.annomap_table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        # v12.9.5：standard 列每个单元格都预设 QComboBox（带下拉箭头 + 模糊联想）。
        # 之前的延迟编辑模式（单击/双击进 QLineEdit）按用户反馈"缺下拉箭头"，恢复 v12.9 的
        # 全单元格 QComboBox 设计。其它列保持只读。
        # v12.10.14：PAGE / ORIGIN 列改为双击进入 read-only 编辑态（允许选字符复制）
        # standard 列由 cellWidget 占据，不受 setEditTriggers 影响（cellWidget 优先于 delegate）
        self.annomap_table.setEditTriggers(QTableWidget.DoubleClicked)
        # 装 read-only 编辑器 delegate（默认应用到所有列，但 standard cellWidget 会拦截）
        self._annomap_readonly_delegate = _ReadOnlyEditDelegate(self.annomap_table)
        self.annomap_table.setItemDelegate(self._annomap_readonly_delegate)
        # v12.9.8：page / origin 列虽然只读，但允许复制
        # 根因：QTableWidget 默认 Ctrl+C 行为依赖 selection — 但 standard 列被 cellWidget
        # 占据，常规鼠标点击会先到 combo 捕获事件，让用户感觉"点不到 cell 选不中"。
        # 修法：装右键菜单 + 显式 keyPressEvent 监听 Ctrl+C，把当前选中 cell 文本写剪贴板。
        self.annomap_table.setSelectionBehavior(QTableWidget.SelectItems)
        self.annomap_table.setSelectionMode(QTableWidget.ExtendedSelection)
        # v12.10.18：彻底关闭 annomap 所有列的右键菜单（用户要求）。
        #   - 之前：CustomContextMenu + "📋 复制整格" — 与 STANDARD 列 lineEdit 内置菜单
        #     不一致（image 1 现象），且菜单 exec 阻塞主循环时偶有 cell 重绘异常。
        #   - 现在：NoContextMenu + 不连 customContextMenuRequested 信号
        #   - 复制功能不受影响：
        #     ① 整格 / 多格复制 → Ctrl+C（eventFilter 监听，line ~1396）
        #     ② 部分字符复制 → 双击 ORIGIN/PAGE 列进入 _ReadOnlyEditDelegate 编辑态
        #        在 lineEdit 里选字符 Ctrl+C
        self.annomap_table.setContextMenuPolicy(Qt.NoContextMenu)
        # 安装 keyPressEvent 过滤器（不重写整个 QTableWidget，仅追加 Ctrl+C 处理）
        self.annomap_table.installEventFilter(self)
        # v12.10.13：列宽策略 — 让 STANDARD 列拉伸填满剩余空间，避免右侧出现大量空白
        # （之前用 Qt 默认每列等宽固定值，3 列只占左半部分，浪费右侧 50% 空间）
        # v12.10.117：换成自定义 _FilterHeaderView —— 在 STANDARD 表头右侧画 ▽ 筛选按钮
        # （Excel 式行筛选：显示全部 / 仅未填 / 仅已填）。filter_clicked 信号连到弹菜单。
        from PySide6.QtWidgets import QHeaderView
        h_header = _FilterHeaderView(Qt.Horizontal, self.annomap_table)
        self.annomap_table.setHorizontalHeader(h_header)
        h_header.setStretchLastSection(True)  # 最后一列（STANDARD）拉伸到面板右边
        h_header.filter_clicked.connect(self._on_standard_filter_clicked)
        self._std_filter_mode = "all"         # all / blank / filled
        mlay.addWidget(self.annomap_table)

        self._annomap_loaded_path = ""
        # v12.9.5：standard 列存储
        self._annomap_combo_widgets = {}      # tr -> QComboBox（每行一个）
        self._annomap_std_options = []        # 候选词列表
        self._annomap_original_values = {}    # tr -> 原始 standard 值（保存时用来判断是否被改过 → 标蓝）

        # v12.9.8：底部简略状态行（保存并重跑结束后显示成功/警告/错误），让用户停留在 annomap
        # tab 时也能感知运行结果，自行决定是否切到「运行日志」tab 看详情。
        self.annomap_status_lbl = QLabel("")
        self.annomap_status_lbl.setStyleSheet(
            "QLabel { padding: 6px 10px; font-size: 13px; }"
        )
        self.annomap_status_lbl.setWordWrap(True)
        self.annomap_status_lbl.hide()  # 默认隐藏，运行后才显示
        mlay.addWidget(self.annomap_status_lbl)

        tabs.addTab(tab_map, "📊 annomap 编辑")
        # v12.9.8：暂存 tabs 引用 — 让 sig_final_finished 切到 tab 0（运行日志）时能定位
        self._right_tabs = tabs

        rl.addWidget(tabs)
        return rw

    # ------------------------- annomap 编辑器辅助 -------------------------
    def _current_annomap_path(self):
        """从 crf_form 当前 base_path 推算 annomap.xlsx 位置"""
        if hasattr(self, 'crf_form') and self.crf_form.base_path:
            return self.crf_form._annomap_path()
        return ""

    def _load_annomap_into_table(self, path):
        """v12.10.12 重新设计：IO 完全到子线程，主线程只做 setItem 渲染（≤500ms）。

        历史时间分布（200 行 annomap.xlsx 测）：
          v12.9 同步：~1.5s 读 xlsx + ~1s setItem/setCellWidget = 2.5s 主线程冻结
          v12.10.6 QTimer 延迟：仍是 2.5s，只是按钮先响应再冻结
          v12.10.12 子线程：~1.5s 子线程读（不冻结） + ~0.4s 主线程渲染 = 0.4s 用户感知

        加 _annomap_loading 标志 + 双调用合并：进入 03 + 切到 03 重复触发不会双线程加载。
        """
        if not path or not os.path.isfile(path):
            self.annomap_path_lbl.setText("(未找到 annomap.xlsx — 请先生成 draft.xfdf)")
            self.annomap_path_lbl.setStyleSheet("color: #E6A23C; font-size: 11px; border: none;")
            self.annomap_table.setRowCount(0)
            self.annomap_table.setColumnCount(0)
            return

        # 已在加载同一个 path 就跳过
        if getattr(self, "_annomap_loading_path", None) == path:
            return

        self._annomap_loading_path = path
        self.annomap_path_lbl.setText(f"⏳ 正在加载 annomap.xlsx ...")
        self.annomap_path_lbl.setStyleSheet("color: #909399; font-size: 11px; border: none;")

        thread = _AnnomapLoadThread(path, parent=self)
        thread.finished_signal.connect(
            lambda ok, payload, p=path, t=thread: self._on_annomap_loaded(ok, payload, p, t)
        )
        thread.start()
        self._annomap_load_thread = thread

    def _on_annomap_loaded(self, ok, payload, path, thread_ref):
        """子线程加载完成回调（主线程执行）— 只做 setItem/setCellWidget 渲染。"""
        # 路径已变（用户切了项目）→ 丢弃此次结果
        if getattr(self, "_annomap_loading_path", None) != path:
            try:
                thread_ref.finished.connect(thread_ref.deleteLater)
            except Exception:
                pass
            return

        self._annomap_loading_path = None

        if not ok:
            self.annomap_path_lbl.setText("(annomap 加载失败，详见 crash.log)")
            self.annomap_path_lbl.setStyleSheet("color: #F56C6C; font-size: 11px; border: none;")
            self.annomap_table.setRowCount(0)
            self.annomap_table.setColumnCount(0)
            try:
                thread_ref.finished.connect(thread_ref.deleteLater)
            except Exception:
                pass
            return

        if payload.get("empty"):
            self.annomap_table.setRowCount(0)
            self.annomap_table.setColumnCount(0)
            self.annomap_path_lbl.setText("(annomap 为空)")
            self.annomap_path_lbl.setStyleSheet("color: #E6A23C; font-size: 11px; border: none;")
            try:
                thread_ref.finished.connect(thread_ref.deleteLater)
            except Exception:
                pass
            return

        # 渲染（主线程，≤500ms）
        from PySide6.QtWidgets import QTableWidgetItem
        from PySide6.QtGui import QColor

        headers = payload["headers"]
        rows_data = payload["rows_data"]
        max_col = payload["max_col"]
        std_col = payload["std_col"]
        std_options = payload["std_options"]
        visible_rows = payload["visible_rows"]
        cell_bgs = payload["cell_bgs"]

        self._annomap_row_map = [src_row for _, src_row in visible_rows]
        self._annomap_std_col = std_col
        self._annomap_combo_widgets = {}
        self._annomap_std_options = std_options
        self._annomap_original_values = {}

        # 关键性能优化：批量更新期间禁用刷新 + 关闭排序信号
        self.annomap_table.setUpdatesEnabled(False)
        was_sorting = self.annomap_table.isSortingEnabled()
        self.annomap_table.setSortingEnabled(False)
        try:
            self.annomap_table.clear()
            self.annomap_table.setColumnCount(max_col)
            self.annomap_table.setHorizontalHeaderLabels(headers)
            self.annomap_table.setRowCount(len(visible_rows))
            self.annomap_table.verticalHeader().setDefaultSectionSize(30)

            for tr, (data_idx, src_row) in enumerate(visible_rows):
                row = rows_data[data_idx]
                for j in range(max_col):
                    val = row[j] if j < len(row) else None
                    txt = "" if val is None else str(val)

                    if j == std_col:
                        self._annomap_original_values[tr] = txt
                        combo = self._make_standard_combo(tr, txt, std_options)
                        self.annomap_table.setCellWidget(tr, j, combo)
                        # 占位 item（cellWidget 不影响 item.value，但 setItem 让 row 计算行高对齐）
                        item = QTableWidgetItem("")
                        item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                        self.annomap_table.setItem(tr, j, item)
                    else:
                        item = QTableWidgetItem(txt)
                        # v12.10.14：保留 ItemIsEditable —— 让双击触发 _ReadOnlyEditDelegate
                        # 进入 read-only 编辑态。delegate 内部 setModelData() 是空操作，
                        # 用户即使敲键盘也不会修改 cell 内容（只能选字符复制）。
                        # 不需要再 & ~Qt.ItemIsEditable
                        rgb = cell_bgs.get((tr, j))
                        if rgb is not None:
                            bg = QColor(rgb[0], rgb[1], rgb[2])
                            item.setBackground(bg)
                            # v12.10.16 移除"深色背景 → 白前景"逻辑：
                            #   该逻辑会导致 cell 在被 selection 选中时文字消失 —
                            #   Qt selection 默认蓝色高亮 + 白前景 → 蓝底白字几乎不可见
                            #   （image 2 的根因 — 用户右键/单击 cell 后文字看不见）
                            #   保留默认黑色前景，即使原 xlsx 背景较深也仅是对比度略低，
                            #   selection 后浅蓝高亮覆盖 + 黑字仍清晰可读
                        self.annomap_table.setItem(tr, j, item)
        finally:
            self.annomap_table.setSortingEnabled(was_sorting)
            self.annomap_table.setUpdatesEnabled(True)

        # v12.10.13：渲染完后设置具体列宽 — PAGE 窄，ORIGIN 中等弹性，STANDARD 拉伸到右边
        try:
            from PySide6.QtWidgets import QHeaderView
            h_header = self.annomap_table.horizontalHeader()
            page_col_idx = -1
            origin_col_idx = -1
            for j, h in enumerate(headers):
                hl = (h or "").lower()
                if hl == "page":
                    page_col_idx = j
                elif hl == "origin":
                    origin_col_idx = j
            # 默认所有列 Interactive 模式（用户可拖动调整）
            for j in range(max_col):
                h_header.setSectionResizeMode(j, QHeaderView.Interactive)
            # PAGE 列固定 60px（页码通常 1-3 位数字）
            if page_col_idx >= 0:
                self.annomap_table.setColumnWidth(page_col_idx, 60)
            # ORIGIN 列预设 320px（项目表单名通常较长）
            if origin_col_idx >= 0:
                self.annomap_table.setColumnWidth(origin_col_idx, 320)
            # STANDARD 列（最后一列）由 setStretchLastSection(True) 自动拉伸到右边
            # v12.10.118：存列索引 —— 批量赋值弹窗用它取选中行的 PAGE/ORIGIN 做预览
            self._annomap_page_col = page_col_idx
            self._annomap_origin_col = origin_col_idx
        except Exception:
            pass

        # v12.10.117：把表头筛选按钮指到 STANDARD 列；重置筛选为"全部"（新表所有行默认可见）
        try:
            header = self.annomap_table.horizontalHeader()
            if hasattr(header, "set_filter_column"):
                header.set_filter_column(std_col)
                header.set_filter_active(False)
            self._std_filter_mode = "all"
            for tr in range(self.annomap_table.rowCount()):
                if self.annomap_table.isRowHidden(tr):
                    self.annomap_table.setRowHidden(tr, False)
        except Exception:
            pass

        # v12.10.118：加载后清空选择 + 当前单元格 —— 消除 Qt 填表后的"幽灵选择/当前格"，
        # 确保批量赋值的"必须显式选 PAGE/ORIGIN"前置条件成立（否则 selectedIndexes()
        # 会返回一个用户没主动选的行，guard 失效 → 内置选一行赋值）。
        try:
            self.annomap_table.clearSelection()
            self.annomap_table.setCurrentCell(-1, -1)
        except Exception:
            pass

        # 路径标签更新（成功）
        self.annomap_path_lbl.setText(
            f"已加载 {len(std_options) - 1} 个项目表单（共 {len(visible_rows)} 行）"
        )
        self.annomap_path_lbl.setStyleSheet("color: #67C23A; font-size: 11px; border: none;")

        # v12.10.13 修复：设置 _annomap_loaded_path — _save_annomap_and_rerun
        # 用此字段判断是否真加载完毕。v12.10.12 子线程化重写时漏设此字段，
        # 导致用户改完 annomap 点保存时弹"尚未加载 annomap.xlsx"误警告。
        self._annomap_loaded_path = path

        try:
            thread_ref.finished.connect(thread_ref.deleteLater)
        except Exception:
            pass

    @staticmethod
    def _extract_cell_bg_color(cell):
        """
        从 openpyxl cell 拿背景色 → 返回 QColor 或 None。

        openpyxl 的颜色模型有几种坑：
          1. cell.fill 可能是 PatternFill('none') —— 无色
          2. start_color.type == 'theme' / 'indexed' —— 不是直接 RGB，读起来要查表，简化处理时跳过
          3. start_color.rgb 通常是 'AARRGGBB' 8 位 hex 字符串；偶尔也会是 Color 对象
          4. 'FFFFFFFF' / '00000000' / None 一律视为无色
        """
        try:
            from PySide6.QtGui import QColor
            fill = cell.fill
            if fill is None or getattr(fill, "patternType", None) in (None, "none"):
                return None
            sc = fill.start_color
            if sc is None:
                return None
            rgb = sc.rgb
            # rgb 也可能是 RGB() 对象或 None
            if rgb is None:
                return None
            if not isinstance(rgb, str):
                rgb = str(rgb)
            rgb = rgb.upper()
            # 跳过白 / 透明 / theme 引用 / 异常长度
            if rgb in ("FFFFFFFF", "00000000", "FFFFFF", "000000"):
                return None
            if len(rgb) == 8:
                # AARRGGBB → RRGGBB
                rgb = rgb[2:]
            if len(rgb) != 6:
                return None
            try:
                int(rgb, 16)
            except ValueError:
                return None
            return QColor("#" + rgb)
        except Exception:
            return None

    def _save_annomap_and_rerun(self):
        """v12.9.5：异步安全的保存并重跑 + 防重入 + 多线程化。

        历史问题（crash.log v12.9.3 实证）：
          - 同步 openpyxl.load_workbook + wb.save 在主线程执行 → 用户感知 ~2s 卡顿
          - SAS 后台跑 autoanno 期间会写 annomap.xlsx；用户连点按钮 →
            BadZipFile / Permission Denied → SAS C 层崩溃 → 0xC0000409 闪退

        修复（v12.9.5 多线程化）：
          1. 入口防重入：crf_form._runner 还在跑 → 直接 return
          2. 立即 setEnabled(False) + 显示 "正在保存..."
          3. openpyxl 写盘放进 _AnnomapSaveThread 子线程；finished 后回主线程
          4. 主线程接 finished 信号 → 触发 _do_autoanno_only
          5. 顶部按钮的中止态由 sig_autoanno_started/finished 联动切换，独立工作
        """
        if not (hasattr(self, 'crf_form') and self.crf_form.base_path):
            show_dialog(self, "提示", "annomap 已保存，但当前未加载项目，无法重跑 autoanno。", "info")
            return

        # 防重入 1：autoanno 已在跑直接返回（不弹窗 — 按钮此时应已切到中止态）
        if self.crf_form._runner is not None and self.crf_form._runner.isRunning():
            return
        # 防重入 2：保存线程还在跑也直接返回
        if getattr(self, "_annomap_save_thread", None) is not None and self._annomap_save_thread.isRunning():
            return

        path = self._annomap_loaded_path
        if not path or not os.path.isfile(path):
            show_dialog(self, "提示", "尚未加载 annomap.xlsx。", "warning")
            return

        std_col = getattr(self, "_annomap_std_col", -1)
        row_map = getattr(self, "_annomap_row_map", [])

        if std_col < 0 or not row_map:
            show_dialog(self, "提示", "annomap 中找不到 standard 列或可见行，无法写回。", "warning")
            return

        # 防重入 3：立即禁用按钮（让短促双击的第二次 click 落空）
        self.btn_annomap_save_run.setEnabled(False)
        self.btn_annomap_save_run.setText("⏳ 正在保存...")

        # 收集 standard 列当前值（在主线程取，再传给 worker）— 避免子线程访问 widget
        updates = []  # [(src_row, new_value), ...]
        for tr, src_row in enumerate(row_map):
            new_val = self._get_standard_cell_value(tr)
            updates.append((src_row, new_val))

        # 启动后台 thread 写盘
        thread = _AnnomapSaveThread(path, std_col + 1, updates, parent=self)
        thread.finished_signal.connect(self._on_annomap_saved)
        self._annomap_save_thread = thread
        thread.start()

    def _on_annomap_saved(self, ok, err_msg):
        """v12.9.5：annomap 写盘 thread 完成回调（在主线程执行）

        v12.10.6 修复：写盘成功后调 _do_autoanno_only 前增加前置文件检查。
        历史问题：前置缺失时 _do_autoanno_only 内部弹"前置缺失"
        告警后直接 return，**没有 emit sig_autoanno_started/finished**，导致 stepper 端
        无法切换按钮状态 → 「💾 保存并重跑 autoanno」永久 disabled，刷新源文件也不解锁。

        修复：
          1. annomap 写盘结果保留（用户的 standard 列编辑不丢失）
          2. 在调 _do_autoanno_only 之前检查 coord 文件 → 缺失即弹窗 + setEnabled(True) + return
          3. 不调 _do_autoanno_only → 不会触发任何 sig_autoanno_xxx，按钮就回到可点击状态
        """
        # 恢复按钮文字（在 _on_autoanno_started 内会被切到「中止」按钮，这里只负责恢复"保存并重跑"文本）
        self.btn_annomap_save_run.setText("💾 保存并重跑 autoanno")

        # 清理 thread 引用
        thread_ref = self._annomap_save_thread
        self._annomap_save_thread = None
        if thread_ref is not None:
            try:
                thread_ref.finished.connect(thread_ref.deleteLater)
            except Exception:
                pass

        if not ok:
            self.btn_annomap_save_run.setEnabled(True)
            show_dialog(self, "保存失败", err_msg or "未知错误", "error")
            return

        # v12.10.6：写盘成功 → 调 _do_autoanno_only 之前先做前置文件检查
        # （之前在 _do_autoanno_only 内部检查 → 失败 return 时按钮永久锁死）
        # v12.10.99：22 线换本机 annodraft（Python）后，前置由 Coordination.txt
        # 改为 draft/ecrf.pdf（annodraft 内部用 pdfminer 直接读它抽坐标）。
        try:
            base_path = self.crf_form.base_path if hasattr(self, 'crf_form') else ""
            draft_ecrf = os.path.join(base_path, "utility", "documentation",
                                      "06_crt_preparation", "062_acrf", "draft", "ecrf.pdf")
            has_draft_ecrf = os.path.isfile(draft_ecrf) and os.path.getsize(draft_ecrf) > 0
        except Exception:
            has_draft_ecrf = False

        if not has_draft_ecrf:
            # 解锁按钮 → 弹窗 → return（不调 _do_autoanno_only）
            # annomap 写盘已成功（用户编辑不丢），仅 autoanno 跳过
            self.btn_annomap_save_run.setEnabled(True)
            show_dialog(
                self, "前置缺失",
                "annomap.xlsx 已保存。\n\n但 draft/ecrf.pdf 不存在或为空，跳过 autoanno 重跑。\n"
                "请在「22 Draft Annotation」步骤中先「首次运行」（会把源 eCRF 复制到 draft/）。",
                "warning"
            )
            return

        # 写盘成功 + coord 文件就绪 → 触发 form 的 autoanno_only 运行
        # 按钮状态会通过 sig_autoanno_started 切换（不必在这里 setEnabled(True)）
        self.crf_form._do_autoanno_only()

    def _make_standard_combo(self, tr, current_value, options):
        """v12.9.5：为 standard 列每行创建一个 QComboBox（带下拉箭头 + 模糊联想）。

        v12.9.7 新增：
          - 子类化 _NoWheelComboBox：禁用滚轮改值（事件 ignore 后冒泡到 QTableWidget 滚动表格）。
            根因：用户滚动表格时鼠标常飘过 standard 列上方，QComboBox 默认滚轮会改 currentIndex
            导致大量误改。禁用滚轮后只能通过点击下拉箭头或键盘输入来改值。
          - 默认值修改弹窗确认：原值非空时，提交（activated 选中下拉项 / lineEdit
            editingFinished 失焦）若值有变 → 弹 question 弹窗；用户取消 → setCurrentText 还原。
            currentTextChanged 仍即时标蓝/复白做视觉反馈，但确认在提交时刻进行（避免每按一键弹窗）。

        v12.10.56 关键修复（用户反馈："standard 没有联想，回车反而把输入词加入下拉菜单"）：
          ① 加 setInsertPolicy(QComboBox.NoInsert)：QComboBox 在可编辑态默认 insertPolicy
             = InsertAtBottom，用户在 lineEdit 中输入未匹配的字符串后按回车 → QComboBox
             自动把该字符串 addItem 到自己的 model 里（→ 下拉永久多一个垃圾项），同时
             setCurrentIndex 到新增项。"回车反而把输入词加入下拉" 就是此默认行为。
             NoInsert 后，回车只把 lineEdit 文字 commit 为 currentText，不污染下拉。
          ② QCompleter 改用 combo.model() 而非独立 string-list：与 main_window 4 级路径
             下拉同款写法，让 completer 与 combo 共享 model（独立 list 模式下 completer
             看到的候选 ≠ combo 看到的下拉项，"联想没生效" 的体感与此对齐）。
          ③ 显式 connect completer.activated 到 currentIndex 联动：避免用户用方向键 / 鼠标
             点击 popup 选项时 combo.currentIndex 未同步 → setStyleSheet 标蓝/复白丢失。

        设计：
          - setEditable(True) + setInsertPolicy(NoInsert) → 输入做模糊搜索，回车不污染下拉
          - completer setFilterMode=MatchContains → 支持子串匹配
        """
        from PySide6.QtWidgets import QCompleter

        combo = _NoWheelComboBox()  # v12.9.7：禁滚轮 QComboBox
        combo.setEditable(True)
        # v12.10.56：必须显式 NoInsert，否则用户回车会把 lineEdit 当前文字 addItem 进下拉
        # （QComboBox 默认 insertPolicy = InsertAtBottom）。详见函数 docstring。
        combo.setInsertPolicy(QComboBox.NoInsert)
        # v12.10.16：禁用 lineEdit 内置右键菜单（默认含 Undo/Cut/Paste/Delete 等
        # 可能误改 cell 内容的项；Image 1 就是用户右键 cell 触发的此菜单）。
        # 如需复制全文用 Ctrl+C；如需修改值，直接键盘输入或下拉选择。
        if combo.lineEdit() is not None:
            combo.lineEdit().setContextMenuPolicy(Qt.NoContextMenu)
        # 设候选词
        opts = [o for o in (options or []) if o]
        combo.addItems([""] + opts)
        # 设当前值（若原值不在候选里也直接显示，不强制清空）
        if current_value:
            idx = combo.findText(current_value)
            if idx >= 0:
                combo.setCurrentIndex(idx)
            else:
                combo.setEditText(current_value)

        # 模糊联想（v12.10.56：与 4 级路径下拉同款 — 用 combo.model() 共享 model，
        # 避免独立 string-list 与 combo 下拉项不一致的"联想看似失灵"现象）
        completer = QCompleter(combo.model(), combo)
        completer.setFilterMode(Qt.MatchContains)
        completer.setCaseSensitivity(Qt.CaseInsensitive)
        completer.setCompletionMode(QCompleter.PopupCompletion)
        combo.setCompleter(completer)

        # v12.10.56：completer 选项被点选 / Enter 提交时同步 currentIndex
        # 根因：QCompleter.activated 默认只更新 lineEdit 文字（QLineEdit 内部连接），
        # 不会把 combo 的 currentIndex 切到对应项 — 导致 maybe_confirm_change 里
        # state["confirmed"] 与 currentText 同步逻辑能拿到正确值，但若后续代码靠
        # currentIndex 读值（如 save 路径）会拿不到。显式 connect 保证一致。
        def _on_completer_activated(text):
            try:
                idx = combo.findText(text, Qt.MatchFixedString)
                if idx >= 0:
                    combo.setCurrentIndex(idx)
            except Exception:
                pass
        completer.activated.connect(_on_completer_activated)

        # v12.10.14：completer 筛选后只剩 1 个候选时自动 commit + 隐藏 popup
        # 解决用户反馈"下拉筛选后剩 1 项还得点一下提交"的问题。
        #
        # 实现：监听 lineEdit.textEdited（用户键入触发；setText 不触发，避免回环）
        # 用 QTimer.singleShot(0, ...) 延迟到下一帧 — 让 completer 先完成 model 筛选，
        # 然后再读 completionModel().rowCount()。如果直接同步检查会读到旧 row count。
        # （v12.10.13 用 completer.highlighted 信号，但该信号只在用户主动按方向键时触发，
        #  键盘筛选不触发 → 那次修复没生效）
        from PySide6.QtCore import QTimer as _QT

        def _try_auto_commit_single():
            try:
                popup = completer.popup()
                if popup is None or not popup.isVisible():
                    return
                model = completer.completionModel()
                if model is None or model.rowCount() != 1:
                    return
                idx = model.index(0, completer.completionColumn())
                if not idx.isValid():
                    return
                only_choice = model.data(idx)
                cur_text = combo.currentText()
                if not only_choice or only_choice == cur_text:
                    popup.hide()
                    return
                # 用 lineEdit.setText（避免 setCurrentText 触发再次模糊匹配 → 死循环）
                # 同时用 blockSignals 防再次 textEdited 触发
                if combo.lineEdit() is not None:
                    le = combo.lineEdit()
                    blocked = le.blockSignals(True)
                    le.setText(only_choice)
                    le.setCursorPosition(len(only_choice))
                    le.blockSignals(blocked)
                # 把 combo 的 currentIndex 也同步到该选项（让 commit 链路认它）
                idx_in_combo = combo.findText(only_choice)
                if idx_in_combo >= 0:
                    combo.setCurrentIndex(idx_in_combo)
                popup.hide()
            except Exception:
                pass

        if combo.lineEdit() is not None:
            combo.lineEdit().textEdited.connect(
                lambda _t: _QT.singleShot(0, _try_auto_commit_single)
            )

        # v12.9.6：默认样式（删除 drop-down 子选择器让系统主题原生绘制箭头；min-height 提到 24px）
        default_style = (
            "QComboBox { background: #FFFFFF; border: 1px solid #DCDFE6; "
            "border-radius: 3px; padding: 1px 4px; font-size: 12px; min-height: 24px; }"
        )
        combo.setStyleSheet(default_style)
        # 把"标蓝/默认"两套样式挂到 widget 上，commit 时切换用
        combo._sty_default = default_style
        combo._sty_dirty = (
            "QComboBox { background: #D6E8FF; border: 1px solid #409EFF; "
            "border-radius: 3px; padding: 1px 4px; font-size: 12px; min-height: 24px; "
            "color: #1F4E8F; font-weight: bold; }"
        )

        # 即时标蓝（视觉反馈）— 不在这里弹确认
        original = (current_value or "").strip()
        # 用 mutable 容器存"当前已确认值"，便于回滚时重置 — 防递归
        state = {"confirmed": original, "rolling_back": False}

        def on_text_changed(new_text):
            cur = (new_text or "").strip()
            if cur != original:
                combo.setStyleSheet(combo._sty_dirty)
            else:
                combo.setStyleSheet(combo._sty_default)
        combo.currentTextChanged.connect(on_text_changed)

        # v12.9.7：default 非空时才需要弹确认（首次填空白不弹）
        def maybe_confirm_change():
            """提交时检查：默认值是否被改？是 → 弹确认；取消则回滚

            v12.10.14：用时间戳防抖 — 避免 activated（点下拉项）后 editingFinished
            （popup 关闭使 lineEdit 失焦）连续触发，导致同一次提交弹两次确认。
            500ms 内的二次触发直接忽略。
            """
            if state["rolling_back"]:
                return
            import time
            now = time.time()
            last = state.get("last_confirm_at", 0.0)
            if now - last < 0.5:
                return
            state["last_confirm_at"] = now

            if not original:
                # 原值为空 — 用户首次填入，不弹确认
                state["confirmed"] = (combo.currentText() or "").strip()
                return
            new_val = (combo.currentText() or "").strip()
            if new_val == state["confirmed"]:
                return  # 没变，不弹
            # 默认值被改 → 弹确认
            ok = show_dialog(
                self, "确认修改默认 standard",
                f"该单元格已有默认值：\n  {original}\n\n"
                f"修改为：\n  {new_val or '(空)'}\n\n"
                f"修改后保存并重跑 autoanno 时生效。确定要修改吗？",
                "question"
            )
            if ok:
                state["confirmed"] = new_val
            else:
                # 回滚：临时关闭递归保护，setCurrentText 后再打开
                state["rolling_back"] = True
                try:
                    if state["confirmed"] in opts:
                        combo.setCurrentText(state["confirmed"])
                    else:
                        # 不在候选里就直接 setEditText
                        combo.lineEdit().setText(state["confirmed"])
                    combo.setStyleSheet(
                        combo._sty_dirty if state["confirmed"] != original
                        else combo._sty_default
                    )
                finally:
                    state["rolling_back"] = False

        # 提交时机：用户从下拉选中（activated）+ 输入完成失焦/回车（editingFinished）
        combo.activated.connect(lambda _i: maybe_confirm_change())
        if combo.lineEdit() is not None:
            combo.lineEdit().editingFinished.connect(maybe_confirm_change)

        # v12.10.116：程序化设值入口（批量赋值专用）。
        # setCurrentText 只触发 currentTextChanged（标蓝/复白），不触发 activated /
        # editingFinished → 不会弹单格确认弹窗；同时同步 state["confirmed"]，避免批量赋值
        # 后用户再碰一下该 combo 失焦时被 maybe_confirm_change 误判"又改了"而弹确认。
        def _apply_value_programmatic(value):
            v = (value or "").strip()
            combo.setCurrentText(v)   # 命中候选→选中；否则(可编辑)→设 editText；空串→选首项
            state["confirmed"] = v
        combo._apply_value_programmatic = _apply_value_programmatic

        # 存到字典供 _save_annomap_and_rerun 取值
        self._annomap_combo_widgets[tr] = combo
        return combo

    def _get_standard_cell_value(self, tr):
        """v12.9.5：保存时统一从 QComboBox 取当前 currentText（已经支持联想 / 直接输入）"""
        combo = self._annomap_combo_widgets.get(tr) if hasattr(self, "_annomap_combo_widgets") else None
        if combo is not None:
            return (combo.currentText() or "").strip()
        # 退路：从 item 取（理论上不会走到这里）
        std_col = getattr(self, "_annomap_std_col", -1)
        if std_col < 0:
            return ""
        item = self.annomap_table.item(tr, std_col)
        if item is None:
            return ""
        return (item.text() or "").strip()

    # ------------------------- 批量赋值 standard（v12.10.116） -------------------------
    def _batch_assign_standard(self):
        """v12.10.116 / 117 / 118：把当前选中的多行 standard 统一赋成同一个值。

        设计要点：
          - v12.10.118：**必须显式选中 PAGE / ORIGIN 列的单元格**才算选行 —— 只统计非
            STANDARD 列的选中（STANDARD 是 cellWidget，点 combo 落到占位选择不算选行）。
            配合 _on_annomap_loaded 里加载后 clearSelection，杜绝"幽灵选择导致内置选一行
            赋值"的问题。选整行（点行号）/ Ctrl / Shift 多选仍照常工作。
          - v12.10.117：跳过被 STANDARD 表头筛选隐藏的行（isRowHidden）。即使 Ctrl+A 全选，
            隐藏的已填行也绝不会被碰到。
          - v12.10.118：取值弹窗里列出选中行（PAGE | ORIGIN → 当前 standard）给用户核对。
          - 只改内存里的 combo（走 _apply_value_programmatic → 标蓝），不写盘；写回仍走原
            「💾 保存并重跑」（子线程）。覆盖非空值前弹一次汇总确认（与单格覆盖同语义）。
          - 未显式选行 / 选中行都被筛选隐藏 → warning 告警。
        """
        # 必须已加载完成
        if not getattr(self, "_annomap_combo_widgets", None):
            show_dialog(self, "批量赋值", "annomap 尚未加载完成，无法批量赋值。", "warning")
            return

        std_col = getattr(self, "_annomap_std_col", -1)

        # 1) 收集"显式选中 PAGE/ORIGIN 单元格"的行号（去重）。
        #    只认非 STANDARD 列的选中；跳过被筛选隐藏的行。
        sel = self.annomap_table.selectionModel()
        raw_rows, hidden_hit = set(), False
        if sel is not None:
            for idx in sel.selectedIndexes():
                if idx.column() == std_col:
                    continue  # STANDARD 占位列不算选行（combo 占据）
                r = idx.row()
                if self.annomap_table.isRowHidden(r):
                    hidden_hit = True
                    continue
                raw_rows.add(r)
        rows = sorted(raw_rows)
        if not rows:
            if hidden_hit:
                msg = ("当前选中的行已被 STANDARD 筛选隐藏，无法赋值。\n"
                       "请先在可见行中点选 PAGE 或 ORIGIN 单元格（或点 STANDARD 表头 ▽ 改筛选）。")
            else:
                msg = ("请先显式选中要赋值的行 —— 点选该行的 PAGE 或 ORIGIN 单元格：\n"
                       "  · 点 PAGE / ORIGIN 单元格选该行；点左侧行号选整行\n"
                       "  · 按住 Ctrl / Shift 可多选多行\n"
                       "（未选中任何 PAGE/ORIGIN 单元格时不会赋值）")
            show_dialog(self, "批量赋值", msg, "warning")
            return

        # 2) 组装选中行预览（PAGE | ORIGIN → 当前 standard）供弹窗核对
        preview = self._build_batch_preview(rows)

        # 3) 弹对话框：展示选中行 + 取统一 standard 值（可下拉选择 + 模糊联想）
        opts = [o for o in (getattr(self, "_annomap_std_options", None) or []) if o]
        value = self._prompt_batch_standard_value(opts, preview, len(rows))
        if value is None:
            return  # 用户取消
        value = value.strip()

        # 4) 计算真正需要修改的行 + 其中会覆盖非空值的行
        targets = []      # 需要改的行号
        overwrite = []    # 原值非空、将被覆盖的行号
        for tr in rows:
            combo = self._annomap_combo_widgets.get(tr)
            if combo is None:
                continue
            old = (combo.currentText() or "").strip()
            if old == value:
                continue           # 值未变：跳过（避免无谓标蓝）
            targets.append(tr)
            if old:
                overwrite.append(tr)

        if not targets:
            show_dialog(self, "批量赋值", "选中行的 standard 已经是该值，无需修改。", "info")
            return

        # 5) 覆盖非空值 → 弹一次汇总确认（与单格覆盖一致）
        if overwrite:
            ok = show_dialog(
                self, "确认覆盖 standard",
                f"将把选中的 {len(targets)} 行 standard 统一赋值为：\n"
                f"  {value or '(空)'}\n\n"
                f"其中 {len(overwrite)} 行已有非空值，将被覆盖。\n\n"
                f"保存并重跑 autoanno 后生效。确定要继续吗？",
                "question"
            )
            if not ok:
                return

        # 6) 批量写入：setUpdatesEnabled 包裹 → 单次重绘（与加载路径同款）
        self.annomap_table.setUpdatesEnabled(False)
        try:
            for tr in targets:
                combo = self._annomap_combo_widgets.get(tr)
                if combo is not None and hasattr(combo, "_apply_value_programmatic"):
                    combo._apply_value_programmatic(value)
        finally:
            self.annomap_table.setUpdatesEnabled(True)

        # 7) v12.10.117：筛选态下赋值后重应用筛选（刚填好的行从"仅未填"消失）。
        #    v12.10.118：无论是否筛选，赋值后都清空选择 —— 避免残留选择被下次误用，
        #    强制用户每次重新显式选行。
        if getattr(self, "_std_filter_mode", "all") != "all":
            self._apply_standard_filter(self._std_filter_mode, announce=False)
        sel2 = self.annomap_table.selectionModel()
        if sel2 is not None:
            sel2.clearSelection()
        self.annomap_table.setCurrentCell(-1, -1)

        # 8) 轻量反馈（蓝色高亮已是主要反馈；底部状态行给一句话提醒保存）
        self.annomap_status_lbl.setText(
            f"✅ 已批量赋值 {len(targets)} 行 → {value or '(空)'}　"
            f"（蓝色为改动，点「💾 保存并重跑 autoanno」生效）"
        )
        self.annomap_status_lbl.setStyleSheet(
            "QLabel { padding: 6px 10px; font-size: 13px; color: #67C23A; }"
        )
        self.annomap_status_lbl.show()

    def _build_batch_preview(self, rows):
        """v12.10.118：为选中行生成预览串列表 —— "PAGE | ORIGIN  →  当前: STANDARD"。"""
        page_col = getattr(self, "_annomap_page_col", -1)
        origin_col = getattr(self, "_annomap_origin_col", -1)
        std_col = getattr(self, "_annomap_std_col", -1)
        col_count = self.annomap_table.columnCount()
        lines = []
        for tr in rows:
            def _cell(c):
                if c is None or c < 0:
                    return ""
                it = self.annomap_table.item(tr, c)
                return (it.text() if it else "") or ""
            if page_col >= 0 or origin_col >= 0:
                left_parts = [t for t in (_cell(page_col), _cell(origin_col)) if t]
            else:
                # 退路：取所有非 STANDARD 列
                left_parts = [_cell(c) for c in range(col_count) if c != std_col]
                left_parts = [t for t in left_parts if t]
            left = " | ".join(left_parts) if left_parts else f"第 {tr + 1} 行"
            combo = self._annomap_combo_widgets.get(tr)
            cur = (combo.currentText() or "").strip() if combo is not None else ""
            lines.append(f"{left}　→　当前: {cur or '(空)'}")
        return lines

    def _prompt_batch_standard_value(self, opts, preview=None, total=0):
        """v12.10.116 / 118：批量赋值取值对话框 —— 可编辑 + 模糊联想下拉。
        v12.10.118：顶部列出选中行（PAGE | ORIGIN → 当前 standard）供用户核对。
        返回用户选定/输入的字符串；取消返回 None。
        """
        from PySide6.QtWidgets import QCompleter, QListWidget, QListWidgetItem, QAbstractItemView

        dlg = QDialog(self)
        dlg.setWindowTitle("批量赋值 standard")
        dlg.setMinimumWidth(460)
        lay = QVBoxLayout(dlg)
        lay.setContentsMargins(16, 14, 16, 14)
        lay.setSpacing(10)

        # v12.10.118：选中行预览 —— 让用户在赋值前看清楚将影响哪些行
        if preview:
            head = QLabel(f"将对以下 {total} 行赋值（请核对）：")
            head.setStyleSheet("font-size: 13px; color: #303133; border: none; font-weight: bold;")
            lay.addWidget(head)

            lst = QListWidget()
            lst.setSelectionMode(QAbstractItemView.NoSelection)
            lst.setFocusPolicy(Qt.NoFocus)
            lst.setStyleSheet(
                "QListWidget { background:#F8F9FB; border:1px solid #E4E7ED; border-radius:4px; "
                "font-size:12px; color:#606266; padding:2px; }"
                "QListWidget::item { padding:2px 4px; }"
            )
            MAX_SHOW = 200
            for line in preview[:MAX_SHOW]:
                lst.addItem(QListWidgetItem(line))
            if len(preview) > MAX_SHOW:
                lst.addItem(QListWidgetItem(f"… 还有 {len(preview) - MAX_SHOW} 行（已省略）"))
            # 高度自适应：最多 ~8 行高
            lst.setMaximumHeight(190)
            lst.setMinimumHeight(min(190, 24 * max(1, min(len(preview), 6)) + 8))
            lay.addWidget(lst)

        tip = QLabel("为选中行设置统一的 standard 值（可下拉选择，或输入做模糊联想）：")
        tip.setStyleSheet("font-size: 13px; color: #303133; border: none;")
        tip.setWordWrap(True)
        lay.addWidget(tip)

        combo = _NoWheelComboBox(dlg)  # 复用禁滚轮 combo，防误改
        combo.setEditable(True)
        combo.setInsertPolicy(QComboBox.NoInsert)  # 回车不污染下拉
        if combo.lineEdit() is not None:
            combo.lineEdit().setContextMenuPolicy(Qt.NoContextMenu)
        combo.addItems([""] + list(opts))
        completer = QCompleter(combo.model(), combo)
        completer.setFilterMode(Qt.MatchContains)
        completer.setCaseSensitivity(Qt.CaseInsensitive)
        completer.setCompletionMode(QCompleter.PopupCompletion)
        combo.setCompleter(completer)
        combo.setStyleSheet(
            "QComboBox { background:#FFFFFF; border:1px solid #DCDFE6; "
            "border-radius:3px; padding:3px 6px; font-size:13px; min-height:26px; }"
        )
        combo.setCurrentIndex(0)  # 默认空，提示用户主动选/输
        lay.addWidget(combo)

        btn_row = QHBoxLayout()
        btn_row.addStretch()
        btn_cancel = QPushButton("取消")
        btn_cancel.setStyleSheet(
            "QPushButton { background:#FFFFFF; color:#606266; border:1px solid #DCDFE6; "
            "padding:5px 16px; border-radius:4px; font-size:12px; }"
            "QPushButton:hover { background:#F5F7FA; border-color:#409EFF; color:#409EFF; }"
        )
        btn_cancel.setCursor(Qt.PointingHandCursor)
        btn_cancel.clicked.connect(dlg.reject)
        btn_ok = QPushButton("✅ 赋值")
        btn_ok.setStyleSheet(
            "QPushButton { background:#409EFF; color:#FFFFFF; border:none; "
            "padding:5px 18px; border-radius:4px; font-size:12px; font-weight:bold; }"
            "QPushButton:hover { background:#66B1FF; }"
        )
        btn_ok.setCursor(Qt.PointingHandCursor)
        btn_ok.clicked.connect(dlg.accept)
        btn_row.addWidget(btn_cancel)
        btn_row.addWidget(btn_ok)
        lay.addLayout(btn_row)

        combo.setFocus()
        if dlg.exec() == QDialog.Accepted:
            return combo.currentText()
        return None

    # ------------------------- STANDARD 列 Excel 式行筛选（v12.10.117） -------------------------
    def _on_standard_filter_clicked(self, section):
        """点击 STANDARD 表头 ▽ → 弹筛选菜单（显示全部 / 仅未填 / 仅已填）。"""
        from PySide6.QtWidgets import QMenu
        from PySide6.QtCore import QPoint
        cur = getattr(self, "_std_filter_mode", "all")
        menu = QMenu(self)
        items = [("显示全部", "all"), ("仅未填 (空白)", "blank"), ("仅已填", "filled")]
        act_map = {}
        for label, mode in items:
            act = menu.addAction(("● " if cur == mode else "○ ") + label)
            act_map[act] = mode
        header = self.annomap_table.horizontalHeader()
        # 菜单锚到该列右下角（▽ 按钮下方）
        x = header.sectionViewportPosition(section) + header.sectionSize(section) - 24
        gpos = header.mapToGlobal(QPoint(max(0, x), header.height()))
        chosen = menu.exec(gpos)
        if chosen in act_map:
            self._apply_standard_filter(act_map[chosen])

    def _apply_standard_filter(self, mode, announce=True):
        """按 mode 隐藏/显示行：blank=隐藏已填行，filled=隐藏空白行，all=全显示。

        说明：仅视图层 setRowHidden，不影响保存（保存仍遍历全部行写回）。批量赋值会
        跳过隐藏行，因此筛选到"仅未填"后即使 Ctrl+A 也不会动到已填行。
        """
        self._std_filter_mode = mode
        combos = getattr(self, "_annomap_combo_widgets", None) or {}
        shown = hidden = 0
        self.annomap_table.setUpdatesEnabled(False)
        try:
            for tr, combo in combos.items():
                val = (combo.currentText() or "").strip()
                if mode == "blank":
                    hide = bool(val)        # 已填 → 隐藏
                elif mode == "filled":
                    hide = not val          # 空白 → 隐藏
                else:
                    hide = False
                self.annomap_table.setRowHidden(tr, hide)
                hidden += 1 if hide else 0
                shown += 0 if hide else 1
        finally:
            self.annomap_table.setUpdatesEnabled(True)

        # 表头 ▽ 图标 active 态
        header = self.annomap_table.horizontalHeader()
        if hasattr(header, "set_filter_active"):
            header.set_filter_active(mode != "all")

        if announce and hasattr(self, "annomap_status_lbl"):
            label = {"all": "显示全部", "blank": "仅未填", "filled": "仅已填"}.get(mode, mode)
            if mode == "all":
                txt = f"🔄 筛选：{label}（共 {shown} 行）"
            else:
                txt = f"🔄 筛选：{label} —— 显示 {shown} 行，隐藏 {hidden} 行"
            self.annomap_status_lbl.setText(txt)
            self.annomap_status_lbl.setStyleSheet(
                "QLabel { padding: 6px 10px; font-size: 13px; color: #409EFF; }"
            )
            self.annomap_status_lbl.show()

    # ------------------------- autoanno_only 状态联动（v12.9.4） -------------------------
    def _on_autoanno_started(self):
        """form 端 autoanno_only 启动 → annomap tab 顶部按钮切到中止状态。
        独立于左侧 btn_run_draft — 后者保持锁死外观。"""
        self.btn_annomap_save_run.setVisible(False)
        self.btn_annomap_cancel.setVisible(True)
        self.btn_annomap_cancel.setEnabled(True)
        # v12.9.8：清空底部状态行（开始新一轮就抹掉上一轮的结果）
        if hasattr(self, "annomap_status_lbl"):
            self.annomap_status_lbl.setText("")
            self.annomap_status_lbl.hide()

    def _on_autoanno_finished(self, has_error=False, has_warning=False, summary=""):
        """v12.9.8：autoanno_only 完成（成功/失败/中止都会回调）→
          1. 顶部按钮恢复
          2. 底部状态行显示简略结果（成功/警告/错误），让用户停留在 annomap tab 时
             也能感知运行结果，自行决定是否切到「运行日志」tab 看详情。
        """
        self.btn_annomap_cancel.setVisible(False)
        self.btn_annomap_save_run.setVisible(True)
        self.btn_annomap_save_run.setEnabled(True)

        # 底部状态行
        if not hasattr(self, "annomap_status_lbl"):
            return
        suffix = f"  —  {summary}" if summary else ""
        if has_error:
            self.annomap_status_lbl.setText(
                f"❌ 重跑结束（含 ERROR）{suffix}　切到「运行日志」tab 查看详情。"
            )
            self.annomap_status_lbl.setStyleSheet(
                "QLabel { padding: 6px 10px; font-size: 13px; "
                "background: #FEF0F0; color: #F56C6C; border: 1px solid #FDE2E2; "
                "border-radius: 4px; font-weight: bold; }"
            )
        elif has_warning:
            self.annomap_status_lbl.setText(
                f"⚠ 重跑结束（含 WARNING）{suffix}　如需查看详情请切到「运行日志」tab。"
            )
            self.annomap_status_lbl.setStyleSheet(
                "QLabel { padding: 6px 10px; font-size: 13px; "
                "background: #FDF6EC; color: #E6A23C; border: 1px solid #F5DAB1; "
                "border-radius: 4px; font-weight: bold; }"
            )
        else:
            self.annomap_status_lbl.setText(
                f"✅ 重跑成功{suffix}　annomap 已根据新值更新。"
            )
            self.annomap_status_lbl.setStyleSheet(
                "QLabel { padding: 6px 10px; font-size: 13px; "
                "background: #F0F9EB; color: #67C23A; border: 1px solid #E1F3D8; "
                "border-radius: 4px; font-weight: bold; }"
            )
        self.annomap_status_lbl.show()

    def _on_final_finished_switch_log(self):
        """v12.9.8：Final 完成 → 自动切到「运行日志」tab（用户应该看输出而不是停在 annomap）"""
        try:
            if hasattr(self, "_right_tabs") and self._right_tabs is not None:
                self._right_tabs.setCurrentIndex(0)
        except Exception:
            pass

    # ------------------------- annomap 复制（v12.9.8） -------------------------
    def _show_annomap_ctx_menu(self, pos):
        """v12.10.14：右键菜单仅"复制整格"（部分文本现在通过双击 cell 进入 read-only
        编辑态实现 — 用户在编辑器里直接选字符 Ctrl+C，体验与 Excel 一致）。

        v12.10.13 的弹窗式"复制部分文本"已废弃 — menu.exec() 阻塞主循环期间触发的
        QTableWidget 重绘异常会让 cell 文字消失。
        """
        from PySide6.QtWidgets import QMenu
        item = self.annomap_table.itemAt(pos)
        if item is None:
            return
        menu = QMenu(self.annomap_table)
        act_copy = menu.addAction("📋 复制整格")
        chosen = menu.exec(self.annomap_table.viewport().mapToGlobal(pos))
        if chosen is act_copy:
            self._copy_annomap_selection()

    def _copy_annomap_selection(self):
        """把 QTableWidget 选中区域文本写剪贴板。

        策略：取所有选中 item，按 (row, col) 排序后用制表符 / 换行拼接（兼容 Excel 粘贴）。
        若没有选中，退化到 currentItem。standard 列由 cellWidget 占据，selectedItems 取不到 —
        若用户右键 standard cell 也能取 currentItem 的占位 item（但 standard 真正值在 combo 里，
        用户复制 standard 通常会直接在 combo 内 Ctrl+C，这里不专门处理）。
        """
        from PySide6.QtWidgets import QApplication
        items = self.annomap_table.selectedItems()
        if not items:
            cur = self.annomap_table.currentItem()
            if cur is None:
                return
            items = [cur]
        # 按 (row, col) 排序拼接
        items.sort(key=lambda it: (it.row(), it.column()))
        rows = {}
        for it in items:
            rows.setdefault(it.row(), {})[it.column()] = it.text()
        lines = []
        for r in sorted(rows.keys()):
            cols = rows[r]
            cmin, cmax = min(cols.keys()), max(cols.keys())
            line = "\t".join(cols.get(c, "") for c in range(cmin, cmax + 1))
            lines.append(line)
        QApplication.clipboard().setText("\n".join(lines))

    def eventFilter(self, obj, event):
        """v12.9.8：annomap_table 上 Ctrl+C 触发复制（默认行为有时被 cellWidget 截走）"""
        from PySide6.QtCore import QEvent
        if obj is getattr(self, "annomap_table", None) and event.type() == QEvent.KeyPress:
            if (event.key() == Qt.Key_C
                    and (event.modifiers() & Qt.ControlModifier)):
                self._copy_annomap_selection()
                return True
        return super().eventFilter(obj, event)

    def _cancel_annomap_rerun(self):
        """中止运行 — 转给 form 处理；UI 切换由 sig_autoanno_finished 回调做"""
        if hasattr(self, 'crf_form'):
            self.crf_form._on_cancel_run()

    # ------------------------- 导入 xfdf（v12.9.5） -------------------------
    def _import_xfdf_with_adobe(self):
        """用 Adobe Acrobat 打开 draft/ecrf.pdf，引导用户在 Adobe 内手动 Import Comments。

        v12.9.5：原"导出 xfdf"复制到桌面的逻辑已废弃。新工作流：
          - autoanno 在 062_acrf/draft/ 下产出 draft.xfdf
          - ecrf.pdf 也在 062_acrf/draft/ 下（v12.9.5 复制逻辑改动）
          - 两个文件已经在同一目录，无需复制到桌面
          - 用 Adobe 直接打开 draft/ecrf.pdf，让用户在 Adobe 内手动 Import Comments 选 draft.xfdf
          - 用户调整完成后另存为 acrf.pdf 放到 final/，再跑 23 Final
        """
        if not (hasattr(self, 'crf_form') and self.crf_form.base_path):
            show_dialog(self, "提示", "请先填写完整的 4 级项目路径。", "warning")
            return
        base = self.crf_form.base_path
        from modules.acrf_crf_annotation import _DRAFT_REL
        draft_dir = os.path.join(base, *_DRAFT_REL)
        if not os.path.isdir(draft_dir):
            show_dialog(self, "提示", f"找不到 draft 目录：\n{draft_dir}", "warning")
            return

        # 校验 draft/ecrf.pdf 与 draft/draft.xfdf 都存在
        ecrf_pdf = os.path.join(draft_dir, "ecrf.pdf")
        if not os.path.isfile(ecrf_pdf):
            show_dialog(
                self, "缺少 ecrf.pdf",
                f"找不到 draft/ecrf.pdf：\n{ecrf_pdf}\n\n请先运行 ▶ 首次运行 Draft Annotation。",
                "warning"
            )
            return

        # 找 draft 下最新 .xfdf
        cands = []
        for n in os.listdir(draft_dir):
            full = os.path.join(draft_dir, n)
            if os.path.isfile(full) and n.lower().endswith(".xfdf"):
                try:
                    cands.append((full, os.path.getmtime(full)))
                except OSError:
                    pass
        if not cands:
            show_dialog(
                self, "缺少 .xfdf",
                f"draft 目录下未找到 .xfdf：\n{draft_dir}\n\n请先运行 ▶ 首次运行 Draft Annotation。",
                "warning"
            )
            return
        cands.sort(key=lambda x: x[1], reverse=True)
        latest_xfdf = cands[0][0]

        # 用 Adobe 打开 ecrf.pdf（form 端已有 _find_adobe_exe 辅助）
        adobe_exe = self.crf_form._find_adobe_exe()
        try:
            if adobe_exe:
                subprocess.Popen([adobe_exe, ecrf_pdf], shell=False, creationflags=0x00000008)
            else:
                os.startfile(ecrf_pdf)
        except Exception as e:
            show_dialog(self, "打开失败", f"无法打开 PDF：\n{ecrf_pdf}\n\n{e}", "error")
            return

        show_dialog(
            self, "请在 Adobe 中导入 xfdf",
            f"已打开：\n  {ecrf_pdf}\n\n"
            f"如 Adobe 弹「AppContainer 在保护模式下不兼容」对话框：\n"
            f"  → 选「在停用保护模式的情况下通过 AppContainer 打开 Acrobat」点确定\n"
            f"  （这是 Adobe 在 Win11 / 企业受限环境下的常见提示，确认一次后下次不再弹出）\n\n"
            f"在 Adobe Acrobat 中：\n"
            f"  1. 点击右侧侧边栏中 💬（评论）按钮 → 再点击 ⋮（选项）按钮 → 选择「导入数据文件」\n"
            f"  2. 选择文件：{os.path.basename(latest_xfdf)}（位于同目录：draft/）\n"
            f"  3. 调整 / 校对完成后另存为 acrf.pdf，放到 062_acrf/final/\n\n"
            f"如系统未检测到 Adobe Acrobat，可能用了默认 PDF 应用打开 — 请用 Adobe 重新打开。",
            "info", align="right"
        )

    def _open_latest_edc_log_chk(self):
        """扫描 07_logs 下 edc_data_recode_log_chk*.xml 取最新，用 Excel 打开。

        命名规则示例：edc_data_recode_log_chk__liup71___2026-04-29T16-00_.xml
        后缀 `_(<user>)_(<timestamp>)` 由 %log_chk 宏运行时动态生成；这里用 glob
        匹配前缀 + .xml，按 mtime 排序取最新（避免依赖文件名内嵌的时间格式解析）。
        """
        if not self.base_path:
            show_dialog(self, "提示", "请先填写完整的 4 级项目路径。", "warning")
            return

        log_dir = os.path.join(self.base_path, "07_logs")
        if not os.path.isdir(log_dir):
            show_dialog(self, "未找到目录", f"找不到目录：\n{log_dir}", "warning")
            return

        import glob
        candidates = []
        try:
            for path in glob.glob(os.path.join(log_dir, "edc_data_recode_log_chk*.xml")):
                if os.path.isfile(path):
                    try:
                        candidates.append((path, os.path.getmtime(path)))
                    except OSError:
                        continue
        except Exception:
            pass

        if not candidates:
            show_dialog(
                self, "未找到 log_chk 文件",
                f"在 07_logs 下未找到匹配 edc_data_recode_log_chk*.xml 的文件。\n"
                f"请先运行 ▶ EDC Recode 生成 log 校验报告。",
                "warning"
            )
            return

        candidates.sort(key=lambda x: x[1], reverse=True)
        latest = candidates[0][0]

        # 强制用 Excel 拉起（默认关联可能是浏览器，会渲染成 XML 文档）
        opened, msg = _open_with_excel(latest)
        if opened:
            self.log_texts["EDC Data Recode"].append(
                f"<span style='color:#909399;'>📊 已用 Excel 打开 log_chk：{os.path.basename(latest)}{msg}</span>"
            )
        else:
            show_dialog(self, "打开失败", f"无法打开文件：\n{latest}\n\n{msg}", "error")

    # ------------------------- 日志辅助 -------------------------
    def _add_log_filter_row(self, step_name, target_layout):
        """在日志面板头下方加一行 WARNING/ERROR 正向筛选勾选框（与 adam/tfls 同款）。"""
        from PySide6.QtWidgets import QCheckBox, QHBoxLayout, QLabel
        filter_row = QHBoxLayout()
        filter_row.setContentsMargins(0, 0, 0, 4)
        filter_lbl = QLabel("过滤：")
        filter_lbl.setStyleSheet("color: #909399; font-size: 11px; border: none;")
        filter_row.addWidget(filter_lbl)
        self._log_filters[step_name] = {"WARNING": False, "ERROR": False}
        self._log_filter_chks[step_name] = {}
        for level, label, color in [("WARNING", "⚠ WARNING", "#E6A23C"), ("ERROR", "❌ ERROR", "#F56C6C")]:
            chk = QCheckBox(label)
            chk.setChecked(False)
            chk.setStyleSheet(
                f"QCheckBox {{ color: {color}; font-size: 11px; border: none; spacing: 4px; }}"
                f"QCheckBox::indicator {{ width: 12px; height: 12px; border: 1px solid #DCDFE6; border-radius: 2px; background-color: #FFFFFF; }}"
                f"QCheckBox::indicator:hover {{ border: 1px solid {color}; }}"
                f"QCheckBox::indicator:checked {{ background-color: {color}; border: 1px solid {color}; }}"
            )
            chk.toggled.connect(lambda checked, s=step_name, lv=level: self._on_log_filter_toggled(s, lv, checked))
            self._log_filter_chks[step_name][level] = chk
            filter_row.addWidget(chk)
        filter_row.addStretch()
        target_layout.addLayout(filter_row)

    @staticmethod
    def _classify_msg_level(msg):
        if not msg:
            return "NOTE"
        upper = msg.upper()
        if "#F56C6C" in msg or "❌" in msg or " ERROR" in upper or upper.startswith("ERROR") or "ERROR:" in upper:
            return "ERROR"
        if "#E6A23C" in msg or "⚠" in msg or "WARNING" in upper:
            return "WARNING"
        return "NOTE"

    def _should_show_log(self, step, level):
        f = self._log_filters.get(step, {})
        active = [lv for lv in ("WARNING", "ERROR") if f.get(lv)]
        if not active:
            return True
        return level in active

    def _append_and_scroll(self, step, msg):
        level = self._classify_msg_level(msg)
        self._log_entries.setdefault(step, []).append((level, msg))
        if not self._should_show_log(step, level):
            return
        txt_widget = self.log_texts[step]
        txt_widget.append(msg)
        QTimer.singleShot(10, lambda: txt_widget.verticalScrollBar().setValue(txt_widget.verticalScrollBar().maximum()))

    def _on_log_filter_toggled(self, step, level, checked):
        self._log_filters.setdefault(step, {"WARNING": False, "ERROR": False})[level] = checked
        self._rerender_log(step)

    def _rerender_log(self, step):
        txt_widget = self.log_texts.get(step)
        if txt_widget is None:
            return
        txt_widget.clear()
        for lvl, msg in self._log_entries.get(step, []):
            if self._should_show_log(step, lvl):
                txt_widget.append(msg)
        QTimer.singleShot(10, lambda: txt_widget.verticalScrollBar().setValue(txt_widget.verticalScrollBar().maximum()))

    def _clear_log_for_step(self, step):
        txt = self.log_texts.get(step)
        if txt is not None:
            txt.clear()
        self._log_entries[step] = []
        # 05 aCRF Update 表单自管日志条目，同步清
        if step == "aCRF Update" and hasattr(self, "update_form") and hasattr(self.update_form, "_clear_log"):
            self.update_form._clear_log()

    def _export_log(self, step_name):
        # v12.10.60：导出改为「汇总」——把面板日志全文追加到团队共享
        #   使用反馈.xlsx（Z:\projects\Z_PYTHON\SPAhub\），不再写本地 99_archive txt。
        from modules.log_summary import append_log_summary
        txt_widget = self.log_texts.get(step_name)
        if txt_widget is None:
            return
        content = txt_widget.toPlainText().strip()
        if not content:
            show_dialog(self, "提示", "日志为空，没有可汇总的内容。", "warning")
            return

        project = self.base_path or "(未选择项目)"  # base_path 即四级目录拼接全路径
        res = append_log_summary(
            project=project, module="acrf", step=step_name, log_text=content)
        if res.get("ok"):
            show_dialog(
                self, "已汇总到反馈簿",
                f"日志已汇总到团队《使用反馈》第 {res['row']} 行。\n"
                f"提交人：{res['submitter']}　模块：acrf　步骤：{step_name}",
                "info", path=res["path"])
        else:
            show_dialog(
                self, "汇总失败（已暂存本地）",
                f"{res.get('error', '未知错误')}\n\n本地暂存：{res.get('path', '(无)')}",
                "warning", path=res.get("path") or None)

    # ------------------------- 耗时计时 -------------------------
    def _start_elapsed(self, step_name):
        self._run_start_times[step_name] = {"start": time.time()}
        self._elapsed_label_cache.pop(step_name, None)
        if not self._elapsed_timer.isActive():
            self._elapsed_timer.start()

    def _stop_elapsed(self, step_name):
        if step_name not in self._run_start_times:
            return
        elapsed = time.time() - self._run_start_times[step_name]["start"]
        del self._run_start_times[step_name]
        self._elapsed_label_cache.pop(step_name, None)
        if not self._run_start_times:
            self._elapsed_timer.stop()

        stat = self.log_status_lbls.get(step_name)
        if stat is not None:
            cur = stat.text()
            if "(耗时:" not in cur:
                stat.setText(f"{cur}  (耗时: {self._format_elapsed(elapsed)})")

    def _tick_running_elapsed(self):
        for step_name, rec in list(self._run_start_times.items()):
            elapsed = time.time() - rec["start"]
            stat = self.log_status_lbls.get(step_name)
            if stat is None:
                continue
            cur_text = stat.text()
            base_text = cur_text.split("  (耗时:")[0] if "(耗时:" in cur_text else cur_text
            new_text = f"{base_text}  (耗时: {self._format_elapsed(elapsed)})"
            if self._elapsed_label_cache.get(step_name) != new_text:
                stat.setText(new_text)
                self._elapsed_label_cache[step_name] = new_text

    @staticmethod
    def _format_elapsed(sec):
        if sec < 60:
            return f"{sec:.1f}s"
        m, s = divmod(int(sec), 60)
        return f"{m}m{s}s"

    # ------------------------- 切换 / 路径推送 -------------------------
    def switch_step(self, step_name):
        for name, btn in self.step_btns.items():
            btn.setChecked(name == step_name)
        if step_name in self.steps:
            idx = self.steps.index(step_name)
            self.left_stack.setCurrentIndex(idx)
            self.right_stack.setCurrentIndex(idx)
            # v12.8：切到 CRF Annotation 时右侧给更大比例（annomap 表格列多）
            # 其它步骤恢复 4:6。基于当前 splitter 总宽算绝对像素，避免被 stretchFactor 干预。
            try:
                total = sum(self.splitter.sizes()) or 1200
                if step_name == "CRF Annotation":
                    self.splitter.setSizes([int(total * 5 / 12), int(total * 7 / 12)])
                else:
                    self.splitter.setSizes([int(total * 4 / 10), int(total * 6 / 10)])
            except Exception:
                pass

            # v12.10.5：切到 CRF Annotation 时 annomap 懒加载
            # 用 QTimer.singleShot(0) 推到下一事件循环 — UI 先把按钮高亮 + 面板切换渲染完，
            # 然后再开始 openpyxl + setCellWidget 等耗时操作。用户感觉切换瞬时响应。
            if step_name == "CRF Annotation" and getattr(self, "_annomap_pending_load", False):
                from PySide6.QtCore import QTimer as _QT
                self._annomap_pending_load = False
                _QT.singleShot(0, self._do_load_annomap_safely)

    def _do_load_annomap_safely(self):
        """切到 CRF Annotation 时延迟触发的 annomap 加载（带异常吞，与原 update_path
        中 try-except 等价语义）。"""
        try:
            if hasattr(self, 'crf_form') and self.crf_form.base_path:
                self._load_annomap_into_table(self.crf_form._annomap_path())
        except Exception:
            pass

    def update_path(self, base_path, p3, p4):
        """
        路径推送（与 TFLsWidget 同款语义 + 去重）。

        若四下拉框未齐全：广播 set_wait_hint(True) 让 Form 显示等待提示，并清空所有日志/状态。
        若齐全：推路径给两个 Form，并复位状态。
        """
        new_key = (base_path, p3, p4)
        if getattr(self, "_last_pushed_path", None) == new_key:
            return
        self._last_pushed_path = new_key

        self.base_path = base_path
        self.p3 = p3
        self.p4 = p4

        try:
            rel = os.path.relpath(base_path, "Z:\\")
            levels = [x for x in rel.split(os.sep) if x and x != ".."]
            paths_complete = len(levels) >= 4
        except Exception:
            paths_complete = False

        # v12.2 借鉴：项目切换时主动清空耗时计时状态，避免旧 tick 把"就绪"覆盖
        self._run_start_times.clear()
        self._elapsed_label_cache.clear()
        if self._elapsed_timer.isActive():
            self._elapsed_timer.stop()

        if not paths_complete:
            for step in self.steps:
                self._clear_log_for_step(step)
                self.log_status_lbls[step].setText("就绪")
                self.log_status_lbls[step].setStyleSheet(
                    "font-size: 13px; font-weight: bold; color: #909399; padding-top: 5px;")
                self.step_btns[step].setText(self.step_original_texts[step])
            for form in self._get_all_forms():
                if hasattr(form, 'set_wait_hint'):
                    form.set_wait_hint(True)
            self._clear_all_subform_inputs()
            return

        # 齐全：隐藏等待提示 + 推路径
        for form in self._get_all_forms():
            if hasattr(form, 'set_wait_hint'):
                form.set_wait_hint(False)

        self.unzip_form.update_paths(base_path)
        self.edc_form.update_paths(base_path)
        # v12.10.34：新增 03 Import EDC Definition 路径推送
        self.import_form.update_paths(base_path)
        self.crf_form.update_paths(base_path)
        self.update_form.update_paths(base_path)  # v12.10.118

        # v12.10.5：原版在此处同步调 _load_annomap_into_table 是主线程阻塞 ~3s 的真正源头
        # （openpyxl 加载 annomap.xlsx + 大量 QTableWidget setItem + setCellWidget(QComboBox)）。
        # 改为延迟加载：仅当用户切到 CRF Annotation 步骤时才触发（switch_step 内做），
        # 且用 QTimer.singleShot(0, ...) 推到下一帧让 UI 先响应再开始 IO。
        # 用户首次进入 aCRF 通常先点 Unzip Source 或 EDC Recode，annomap 是 03 步骤产物，
        # 路径切换时预加载没必要。
        # 标记 annomap 待加载，让 switch_step 切到 CRF Annotation 时触发
        self._annomap_pending_load = True

        for step in self.steps:
            self._clear_log_for_step(step)
            self.log_status_lbls[step].setText("就绪")
            self.log_status_lbls[step].setStyleSheet(
                "font-size: 13px; font-weight: bold; color: #909399; padding-top: 5px;")
            self.step_btns[step].setText(self.step_original_texts[step])

    def _clear_all_subform_inputs(self):
        """路径未齐全时清空 Form 输入"""
        # v12.10.34：加上 self.import_form（aCRF-03 Import EDC Definition）
        for form in (self.unzip_form, self.edc_form, self.import_form, self.crf_form, self.update_form):
            for attr in ("zip_entry", "sas_entry", "dir_entry", "setup_entry",
                         "ecrf_entry", "draft_pdf_entry", "final_pdf_entry",
                         "edcdef_edit",  # v12.10.34: 加 edcdef_edit (Import EDC Def 输入框)
                         "new_crf_entry", "old_crf_entry", "old_xfdf_entry"):  # v12.10.118: 05 输入框
                w = getattr(form, attr, None)
                if w is not None:
                    w.clear()
            macro_lbl = getattr(form, "macro_lbl", None)
            if macro_lbl is not None:
                macro_lbl.setText("(尚未读取)")
                macro_lbl.setStyleSheet(
                    "border: 1px solid #E4E7ED; background: #F8F9FA; color: #606266; padding: 6px 10px; border-radius: 4px;")
            # v12.10.34: ImportEdcdefForm 还有 edcdef_macro_lbl 也要清
            edcdef_macro_lbl = getattr(form, "edcdef_macro_lbl", None)
            if edcdef_macro_lbl is not None:
                edcdef_macro_lbl.setText("(尚未读取)")
                edcdef_macro_lbl.setStyleSheet(
                    "border: 1px solid #E4E7ED; background: #F8F9FA; color: #606266; padding: 6px 10px; border-radius: 4px;")
            form.base_path = ""
        # 同步清空 annomap 编辑器
        if hasattr(self, 'annomap_table'):
            self.annomap_table.setRowCount(0)
            self.annomap_table.setColumnCount(0)
            self.annomap_path_lbl.setText("(未加载)")
            self.annomap_path_lbl.setStyleSheet("color: #909399; font-size: 11px; border: none;")
            self._annomap_loaded_path = ""

    def _get_all_forms(self):
        # v12.10.34：加上 self.import_form（aCRF-03 Import EDC Definition）
        return [self.unzip_form, self.edc_form, self.import_form, self.crf_form, self.update_form]

    def _refresh_step(self, step_name):
        """左侧 🔄 刷新按钮入口：重读路径触发 update_paths"""
        if not self.base_path:
            return
        form = self._get_form(step_name)
        if form and hasattr(form, 'scan_lbl'):
            form.scan_lbl.setText("正在刷新...")
            form.scan_lbl.setStyleSheet(scan_status_lbl_style("#409EFF"))

        if step_name == "Unzip Source":
            self.unzip_form.update_paths(self.base_path)
        elif step_name == "EDC Data Recode":
            self.edc_form.update_paths(self.base_path)
        elif step_name == "Import EDC Definition":
            # v12.10.34: 新增 03 Import EDC Definition 刷新分支
            self.import_form.update_paths(self.base_path)
        elif step_name == "CRF Annotation":
            self.crf_form.update_paths(self.base_path)
            try:
                self._load_annomap_into_table(self.crf_form._annomap_path())
            except Exception:
                pass

        if form and hasattr(form, 'scan_lbl'):
            form.scan_lbl.setText("✅ 刷新完成")
            form.scan_lbl.setStyleSheet(scan_status_lbl_style("#67C23A"))

    def _get_form(self, step_name):
        return {
            "Unzip Source": self.unzip_form,
            "EDC Data Recode": self.edc_form,
            "Import EDC Definition": self.import_form,  # v12.10.34
            "CRF Annotation": self.crf_form,
            "aCRF Update": self.update_form,  # v12.10.118
        }.get(step_name)

    # ------------------------- 信号路由 -------------------------
    def _connect_components(self):
        def _set_running_icon(step):
            original = self.step_original_texts[step]
            self.step_btns[step].setText(f"{original}  ⏳")

        # 把每个 Form 的 🔄 刷新按钮路由到 _refresh_step
        for form in self._get_all_forms():
            if hasattr(form, 'refresh_btn') and hasattr(form, '_step_name'):
                form.refresh_btn.clicked.connect(lambda checked, s=form._step_name: self._refresh_step(s))

        # ----- 01 Unzip Source -----
        self.unzip_form.sig_run_started.connect(lambda: self._clear_log_for_step("Unzip Source"))
        self.unzip_form.sig_run_started.connect(lambda: _set_running_icon("Unzip Source"))
        self.unzip_form.sig_run_started.connect(lambda: self._start_elapsed("Unzip Source"))
        self.unzip_form.sig_log.connect(lambda msg: self._append_and_scroll("Unzip Source", msg))
        self.unzip_form.sig_status.connect(lambda msg, color: self._set_status("Unzip Source", msg, color))
        self.unzip_form.sig_step_update.connect(lambda txt: (
            self.step_btns["Unzip Source"].setText(txt), self._stop_elapsed("Unzip Source")))
        # 兜底：Form 主动通知"运行结束（不算步骤完成）"
        self.unzip_form.sig_run_finished.connect(lambda: self._stop_elapsed("Unzip Source"))

        # ----- 02 EDC Data Recode -----
        self.edc_form.sig_run_started.connect(lambda: self._clear_log_for_step("EDC Data Recode"))
        self.edc_form.sig_run_started.connect(lambda: _set_running_icon("EDC Data Recode"))
        self.edc_form.sig_run_started.connect(lambda: self._start_elapsed("EDC Data Recode"))
        self.edc_form.sig_log.connect(lambda msg: self._append_and_scroll("EDC Data Recode", msg))
        self.edc_form.sig_status.connect(lambda msg, color: self._set_status("EDC Data Recode", msg, color))
        self.edc_form.sig_step_update.connect(lambda txt: (
            self.step_btns["EDC Data Recode"].setText(txt), self._stop_elapsed("EDC Data Recode")))
        self.edc_form.sig_run_finished.connect(lambda: self._stop_elapsed("EDC Data Recode"))

        # ----- 03 Import EDC Definition（v12.10.34：从 SDTM-01 转移过来）-----
        # 与 EDC Data Recode 同样的单步运行型范式：sig_run_started 清空日志 + 计时；
        # sig_step_update 推 step 按钮文本 + 停止计时；sig_run_finished 兜底停止计时。
        self.import_form.sig_run_started.connect(lambda: self._clear_log_for_step("Import EDC Definition"))
        self.import_form.sig_run_started.connect(lambda: _set_running_icon("Import EDC Definition"))
        self.import_form.sig_run_started.connect(lambda: self._start_elapsed("Import EDC Definition"))
        self.import_form.sig_log.connect(lambda msg: self._append_and_scroll("Import EDC Definition", msg))
        self.import_form.sig_status.connect(lambda msg, color: self._set_status("Import EDC Definition", msg, color))
        self.import_form.sig_step_update.connect(lambda txt: (
            self.step_btns["Import EDC Definition"].setText(txt), self._stop_elapsed("Import EDC Definition")))
        self.import_form.sig_run_finished.connect(lambda: self._stop_elapsed("Import EDC Definition"))

        # ----- 04 CRF Annotation（v12.10.34：原 03，顺移到 04）-----
        # 与 04 Batch Run 类似：CRF Annotation 有多个独立操作（提取字段 / 生成 xfdf / Final），
        # 用 sig_run_started 累加日志（不 clear），让用户能看到完整工作链路。
        self.crf_form.sig_run_started.connect(lambda: _set_running_icon("CRF Annotation"))
        self.crf_form.sig_run_started.connect(lambda: self._start_elapsed("CRF Annotation"))
        self.crf_form.sig_log.connect(lambda msg: self._append_and_scroll("CRF Annotation", msg))
        self.crf_form.sig_status.connect(lambda msg, color: self._set_status("CRF Annotation", msg, color))
        self.crf_form.sig_step_update.connect(lambda txt: (
            self.step_btns["CRF Annotation"].setText(txt), self._stop_elapsed("CRF Annotation")))
        self.crf_form.sig_run_finished.connect(lambda: self._stop_elapsed("CRF Annotation"))
        # annomap 更新通知 → 自动重载 + 切到编辑 Tab
        self.crf_form.sig_annomap_updated.connect(self._on_annomap_updated)
        # v12.9.5：autoanno_only 启动/结束信号 → 切换 annomap tab 顶部按钮中止状态
        # 关键：这两个信号**仅**在 autoanno_only 模式 emit；首次运行（full）走 sig_run_started/finished 老路
        self.crf_form.sig_autoanno_started.connect(self._on_autoanno_started)
        self.crf_form.sig_autoanno_finished.connect(self._on_autoanno_finished)

        # ----- 05 aCRF Update（v12.10.118）-----
        # 表单自带右面板，已在 create_right_panel() 内自连 sig_log→自身日志框、
        # sig_status→自身状态栏、sig_run_started→清空自身日志。这里**只**补 stepper 侧的
        # 步骤按钮 running 图标 / 计时 / step 文本，避免与表单自路由重复导致双份日志。
        self.update_form.sig_run_started.connect(lambda: _set_running_icon("aCRF Update"))
        self.update_form.sig_run_started.connect(lambda: self._start_elapsed("aCRF Update"))
        self.update_form.sig_step_update.connect(lambda txt: (
            self.step_btns["aCRF Update"].setText(txt), self._stop_elapsed("aCRF Update")))
        self.update_form.sig_run_finished.connect(lambda: self._stop_elapsed("aCRF Update"))
        # v12.9.8：Final 完成 → 切到「运行日志」tab
        self.crf_form.sig_final_finished.connect(self._on_final_finished_switch_log)

    def _on_annomap_updated(self, path):
        """v12.7：autoanno 跑完 → 加载到 Tab 2 + 自动切到 Tab 2"""
        self._load_annomap_into_table(path)
        # 切到 annomap 编辑 Tab（即第 2 个 Tab，index=1）
        # right_stack 下当前是 CRF Annotation 步骤的 panel，里面第一个 child 是 QTabWidget
        try:
            cur_widget = self.right_stack.currentWidget()
            # cur_widget 是 QFrame（包 QTabWidget 的容器），找它内部第一个 QTabWidget
            from PySide6.QtWidgets import QTabWidget
            tab_w = cur_widget.findChild(QTabWidget)
            if tab_w is not None:
                tab_w.setCurrentIndex(1)
        except Exception:
            pass

    def _set_status(self, step, msg, color):
        lbl = self.log_status_lbls[step]
        lbl.setText(msg)
        lbl.setStyleSheet(f"font-size: 13px; font-weight: bold; color: {color}; padding-top: 5px;")

    # ------------------------- 全局快捷键路由 -------------------------
    def _current_step_form(self):
        idx = self.left_stack.currentIndex()
        if 0 <= idx < len(self.steps):
            return self._get_form(self.steps[idx])
        return None

    def action_refresh(self):
        form = self._current_step_form()
        if form is not None:
            fn = getattr(form, "action_refresh", None)
            if callable(fn):
                fn()

    def action_run(self):
        form = self._current_step_form()
        if form is not None:
            fn = getattr(form, "action_run", None)
            if callable(fn):
                fn()
