# -*- coding: utf-8 -*-
"""
gui/adam_stepper.py
===================
ADaM 两步导航器（01 Initial PGM / 02 Batch Run）。

设计原则：仿 TFLs 模块，复用现成的 InitPgmForm / BatchRunForm，**强制 type=adam**：
  - 01 Initial PGM：force_type="adam" → 91_initial_pgm 的 TYPE= 段被强制覆盖为
    %str(adam)，无视脚本里写的多 type 集合。仅生成 ADaM 的 dev/qc 程序。
  - 02 Batch Run：force_type="adam" → BatchGenRunner 扫描 92_batch_call 时只保留
    type=adam 的宏调用段。其它 sdtm/table/figure/listing 段被忽略。

为什么 TFLs 不限制 type 而 ADaM 限制：
  - TFLs 的 03 Initial PGM 有"防覆盖"功能，所有 type 都能跑，且 04 Batch Run 的
    matrix 让用户选择性运行；用户可控、安全。
  - ADaM 的需求是"只跑 ADaM"，其它 type 应该完全屏蔽，避免误生成。

模块结构：
  - 顶部步骤栏（01 Initial PGM / 02 Batch Run，可点击切换）
  - 左侧：InitPgmForm(force_type='adam') / BatchRunForm(force_type='adam')
  - 右侧：每步独立日志面板（含 📂 07_logs / 📂 utility/documentation 按钮 — 仅 Batch Run）
  - 路径变化时统一推送到 form
"""
import os
import time

from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                               QStackedWidget, QTextEdit, QFrame, QSplitter, QFileDialog, QCheckBox)
from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QTextOption

from modules.tfls_init_pgm import InitPgmForm
from ui_utils import show_dialog, log_textedit_style, ChevronStepBar, StepProxy
from gui.log_search import attach_log_search  # v12.10.102：日志框内 Ctrl+F 搜索

try:
    from modules.tfls_batch_run import BatchRunForm
except ImportError:
    BatchRunForm = None


class AdamWidget(QWidget):
    """ADaM 两步导航容器：步骤栏 + 左右分栏（仿 TFLsWidget 简化版）"""

    def __init__(self):
        super().__init__()
        self.base_path = ""
        self.p3 = ""
        self.p4 = ""

        self.steps = ["Initial PGM", "Batch Run"]
        self.step_original_texts = {step: f"0{i + 1} {step}" for i, step in enumerate(self.steps)}

        self.step_btns = {}
        self.log_texts = {}
        self.log_status_lbls = {}
        self.log_action_btns = {}    # Initial PGM "📄 打开合并日志"
        self.export_btns = {}
        self.check_logs_btns = {}    # Batch Run "📂 07_logs"
        self.check_doc_btns = {}     # Batch Run "📂 utility/documentation"
        # v12.10.13：日志过滤
        self._log_entries = {}
        self._log_filters = {}
        self._log_filter_chks = {}

        # 运行耗时跟踪
        self._run_start_times = {}
        self._elapsed_label_cache = {}
        self._elapsed_timer = QTimer(self)
        self._elapsed_timer.setInterval(2000)
        self._elapsed_timer.timeout.connect(self._tick_running_elapsed)

        self._setup_ui()
        self._connect_components()

    # ------------------------- UI 构造 -------------------------
    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # 顶部步骤栏
        stepper_frame = QFrame()
        stepper_frame.setStyleSheet("background-color: #FFFFFF; border: 1px solid #E4E7ED; border-radius: 6px;")
        stepper_layout = QHBoxLayout(stepper_frame)
        stepper_layout.setContentsMargins(10, 8, 10, 8)

        # v12.10.90：步骤栏改 chevron 箭头管道（方案B）。
        self.step_bar = ChevronStepBar(self.steps, self.step_original_texts)
        self.step_bar.step_clicked.connect(self.switch_step)
        stepper_layout.addWidget(self.step_bar)
        self.step_btns = {s: StepProxy(self.step_bar, s) for s in self.steps}

        layout.addWidget(stepper_frame)
        layout.addSpacing(10)

        # 左右分栏
        self.splitter = QSplitter(Qt.Horizontal)
        self.splitter.setStyleSheet("QSplitter::handle { background-color: #EBEEF5; width: 4px; }")

        self.left_stack = QStackedWidget()
        self.right_stack = QStackedWidget()
        self.right_stack.setStyleSheet("background-color: #FFFFFF; border: 1px solid #E4E7ED; border-radius: 6px;")

        self.splitter.addWidget(self.left_stack)
        self.splitter.addWidget(self.right_stack)
        self.splitter.setStretchFactor(0, 4)
        self.splitter.setStretchFactor(1, 6)
        layout.addWidget(self.splitter, 1)

        # 各模块表单（force_type='adam' 锁定）
        self.init_pgm_form = InitPgmForm(force_type="adam")
        self.left_stack.addWidget(self.init_pgm_form)
        self.right_stack.addWidget(self._create_right_log_panel("Initial PGM"))

        if BatchRunForm:
            self.batch_run_form = BatchRunForm(force_type="adam")
            self.left_stack.addWidget(self.batch_run_form)
            self.right_stack.addWidget(self._create_right_log_panel("Batch Run"))
        else:
            w = QWidget()
            l = QVBoxLayout(w)
            lbl = QLabel("【Batch Run】组件加载失败...")
            lbl.setAlignment(Qt.AlignCenter)
            lbl.setStyleSheet("color: #909399; font-size: 16px;")
            l.addWidget(lbl)
            self.left_stack.addWidget(w)
            self.right_stack.addWidget(self._create_right_log_panel("Batch Run"))

        self.switch_step("Initial PGM")

    def _create_right_log_panel(self, step_name):
        """与 TFLs stepper 风格一致的日志面板（含按钮区）"""
        rw = QFrame()
        rl = QVBoxLayout(rw)
        rl.setContentsMargins(10, 10, 10, 10)

        log_header = QHBoxLayout()
        title_lbl = QLabel(f"📄 {step_name} 运行日志")
        title_lbl.setStyleSheet("font-size: 13px; font-weight: bold; color: #606266; border: none;")
        log_header.addWidget(title_lbl)
        log_header.addStretch()

        btn_container = QHBoxLayout()
        btn_container.setSpacing(8)

        # [自定义动作] 按钮 — Initial PGM 用它承载"打开合并日志"
        act_btn = QPushButton()
        act_btn.setStyleSheet("""
            QPushButton { background-color: #F0F2F5; color: #606266; border: 1px solid #DCDFE6; padding: 4px 10px; border-radius: 4px; font-size:12px; font-weight:bold;}
            QPushButton:hover { background-color: #E4E7ED; }
        """)
        act_btn.setVisible(False)
        self.log_action_btns[step_name] = act_btn
        btn_container.addWidget(act_btn)

        # v12.10.12：原右上角的「📂 07_logs」+「📂 utility/documentation」按钮
        # 已迁到 batch_run_form 左侧 footer，紧邻"运行 Log/Compare Check"。
        # 这里保留 check_logs_btns / check_doc_btns 字典定义为空。

        # [导出日志]
        exp_btn = QPushButton("📋 导出日志")
        exp_btn.setStyleSheet("""
            QPushButton { background-color: #ECF5FF; color: #409EFF; border: 1px solid #B3D8FF; padding: 4px 10px; border-radius: 4px; font-size:12px; font-weight:bold;}
            QPushButton:hover { background-color: #409EFF; color: #FFFFFF; }
        """)
        exp_btn.clicked.connect(lambda checked, s=step_name: self._export_log(s))
        self.export_btns[step_name] = exp_btn
        btn_container.addWidget(exp_btn)

        log_header.addLayout(btn_container)
        rl.addLayout(log_header)

        # v12.10.13：过滤行（与 tfls_stepper 同款）
        filter_row = QHBoxLayout()
        filter_row.setContentsMargins(0, 0, 0, 4)
        filter_lbl = QLabel("过滤：")
        filter_lbl.setStyleSheet("color: #909399; font-size: 11px; border: none;")
        filter_row.addWidget(filter_lbl)

        # v12.10.108：筛选语义改为「正向选择」——两框默认不勾选 = 全展示；
        # 勾 WARNING 只看 WARNING，勾 ERROR 只看 ERROR（NOTE 不进筛选）。
        self._log_filters[step_name] = {"WARNING": False, "ERROR": False}
        self._log_filter_chks[step_name] = {}

        # v12.10.13 修订：仅 WARNING / ERROR 可过滤
        for level, label, color in [
            ("WARNING", "⚠ WARNING", "#E6A23C"),
            ("ERROR", "❌ ERROR", "#F56C6C"),
        ]:
            chk = QCheckBox(label)
            chk.setChecked(False)
            chk.setStyleSheet(
                f"QCheckBox {{ color: {color}; font-size: 11px; border: none; spacing: 4px; }}"
                f"QCheckBox::indicator {{ width: 12px; height: 12px; border: 1px solid #DCDFE6; border-radius: 2px; background-color: #FFFFFF; }}"
                f"QCheckBox::indicator:hover {{ border: 1px solid {color}; }}"
                f"QCheckBox::indicator:checked {{ background-color: {color}; border: 1px solid {color}; }}"
            )
            chk.toggled.connect(
                lambda checked, s=step_name, lv=level: self._on_log_filter_toggled(s, lv, checked)
            )
            self._log_filter_chks[step_name][level] = chk
            filter_row.addWidget(chk)

        filter_row.addStretch()
        rl.addLayout(filter_row)

        # 日志文本区
        txt = QTextEdit()
        txt.setReadOnly(True)
        attach_log_search(txt)  # v12.10.102：日志框内 Ctrl+F 搜索
        txt.setLineWrapMode(QTextEdit.WidgetWidth)
        txt.setWordWrapMode(QTextOption.WrapAnywhere)
        txt.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        txt.setStyleSheet(
            log_textedit_style(with_padding=True))
        rl.addWidget(txt)

        # 底部状态
        stat = QLabel("就绪")
        stat.setAlignment(Qt.AlignCenter)
        stat.setStyleSheet("font-size: 13px; font-weight: bold; color: #909399; padding-top: 5px;")
        rl.addWidget(stat)

        self.log_texts[step_name] = txt
        self.log_status_lbls[step_name] = stat
        return rw

    # ------------------------- 信号联通 -------------------------
    def _connect_components(self):
        def _set_running_icon(step_name):
            cur = self.step_btns[step_name].text()
            base = self.step_original_texts[step_name]
            if "⏳" not in cur:
                self.step_btns[step_name].setText(f"{base} ⏳")

        # Initial PGM
        self.init_pgm_form.sig_run_started.connect(lambda: self._clear_log_for_step("Initial PGM"))
        self.init_pgm_form.sig_run_started.connect(lambda: _set_running_icon("Initial PGM"))
        self.init_pgm_form.sig_run_started.connect(lambda: self._start_elapsed("Initial PGM"))
        self.init_pgm_form.sig_log.connect(lambda msg: self._append_and_scroll("Initial PGM", msg))
        self.init_pgm_form.sig_status.connect(lambda msg, color: self._set_status("Initial PGM", msg, color))
        self.init_pgm_form.sig_step_update.connect(lambda txt: (
            self.step_btns["Initial PGM"].setText(txt), self._stop_elapsed("Initial PGM")))

        btn_init = self.log_action_btns["Initial PGM"]
        btn_init.setText("📄 打开合并日志")
        btn_init.setVisible(True)
        btn_init.clicked.connect(self._open_init_merged_log)

        # Batch Run
        if BatchRunForm and hasattr(self, 'batch_run_form'):
            self.batch_run_form.sig_clear_log.connect(lambda: self._clear_log_for_step("Batch Run"))
            self.batch_run_form.sig_run_started.connect(lambda: _set_running_icon("Batch Run"))
            self.batch_run_form.sig_run_started.connect(lambda: self._start_elapsed("Batch Run"))
            self.batch_run_form.sig_log.connect(lambda msg: self._append_and_scroll("Batch Run", msg))
            self.batch_run_form.sig_status.connect(lambda msg, color: self._set_status("Batch Run", msg, color))
            self.batch_run_form.sig_step_update.connect(lambda txt: (
                self.step_btns["Batch Run"].setText(txt), self._stop_elapsed("Batch Run")))
            self.batch_run_form.sig_run_finished.connect(lambda: self._stop_elapsed("Batch Run"))
            # v12.10.12：sig_show_check_paths 不再使用（results 按钮已迁到 form 内部 footer）

    # ------------------------- 工具函数 -------------------------
    def _set_status(self, step, msg, color):
        lbl = self.log_status_lbls[step]
        lbl.setText(msg)
        lbl.setStyleSheet(f"font-size: 13px; font-weight: bold; color: {color}; padding-top: 5px;")

    @staticmethod
    def _classify_msg_level(msg):
        if not msg:
            return "NOTE"
        upper = msg.upper()
        if "#F56C6C" in msg or "❌" in msg or " ERROR" in upper or upper.startswith("ERROR") or "ERROR:" in upper:
            return "ERROR"
        if "#E6A23C" in msg or "⚠" in msg or "WARNING" in upper:
            return "WARNING"
        return "NOTE"

    def _should_show(self, step, level):
        """v12.10.108：正向筛选。无勾选 → 全展示；有勾选 → 仅展示被勾选的级别。"""
        f = self._log_filters.get(step, {})
        active = [lv for lv in ("WARNING", "ERROR") if f.get(lv)]
        if not active:
            return True
        return level in active

    def _append_and_scroll(self, step, msg):
        """v12.10.13：先存原始条目 + 按过滤决定是否渲染（与 tfls_stepper 同款）"""
        level = self._classify_msg_level(msg)
        self._log_entries.setdefault(step, []).append((level, msg))
        if not self._should_show(step, level):
            return
        txt_widget = self.log_texts[step]
        txt_widget.append(msg)
        QTimer.singleShot(10, lambda: txt_widget.verticalScrollBar().setValue(txt_widget.verticalScrollBar().maximum()))

    def _on_log_filter_toggled(self, step, level, checked):
        self._log_filters.setdefault(step, {"WARNING": False, "ERROR": False})[level] = checked
        self._rerender_log(step)

    def _rerender_log(self, step):
        txt_widget = self.log_texts.get(step)
        if txt_widget is None:
            return
        txt_widget.clear()
        for lvl, msg in self._log_entries.get(step, []):
            if self._should_show(step, lvl):
                txt_widget.append(msg)
        QTimer.singleShot(
            10, lambda: txt_widget.verticalScrollBar().setValue(txt_widget.verticalScrollBar().maximum())
        )

    def _clear_log_for_step(self, step):
        txt = self.log_texts.get(step)
        if txt is not None:
            txt.clear()
        self._log_entries[step] = []

    def _export_log(self, step_name):
        """v12.10.60：导出改为「汇总」——把面板日志全文追加到团队共享
        使用反馈.xlsx（Z:\\projects\\Z_PYTHON\\SPAhub\\），不再写本地 txt。"""
        from modules.log_summary import append_log_summary
        txt_widget = self.log_texts.get(step_name)
        if txt_widget is None or not txt_widget.toPlainText().strip():
            show_dialog(self, "提示", "当前日志为空，无法汇总。", "info")
            return
        content = txt_widget.toPlainText().strip()
        project = self.base_path or "(未选择项目)"  # base_path 即四级目录拼接全路径
        res = append_log_summary(
            project=project, module="adam", step=step_name, log_text=content)
        if res.get("ok"):
            show_dialog(
                self, "已汇总到反馈簿",
                f"日志已汇总到团队《使用反馈》第 {res['row']} 行。\n"
                f"提交人：{res['submitter']}　模块：adam　步骤：{step_name}",
                "info", path=res["path"])
        else:
            show_dialog(
                self, "汇总失败（已暂存本地）",
                f"{res.get('error', '未知错误')}\n\n本地暂存：{res.get('path', '(无)')}",
                "warning", path=res.get("path") or None)

    def _open_init_merged_log(self):
        log_path = os.path.join(self.base_path, "utility", "tools", "91_initial_pgm_call.log")
        if os.path.exists(log_path):
            os.startfile(log_path)
        else:
            self.log_texts["Initial PGM"].append(
                "<span style='color:#E6A23C;'>⚠️ 找不到合并日志文件 (91_initial_pgm_call.log)，可能尚未运行。</span>")

    def _show_check_paths_for_batch_run(self, logs_dir, doc_dir):
        """Log/Compare Check 完成后绑定 + 显示两个文件夹按钮（与 tfls_stepper 同款）"""
        btn_logs = self.check_logs_btns.get("Batch Run")
        btn_doc = self.check_doc_btns.get("Batch Run")

        def _open_dir(path):
            try:
                if path and os.path.isdir(path):
                    os.startfile(path)
                else:
                    self.log_texts["Batch Run"].append(
                        f"<span style='color:#E6A23C;'>⚠️ 文件夹不存在：{path}</span>"
                    )
            except Exception as e:
                self.log_texts["Batch Run"].append(
                    f"<span style='color:#F56C6C;'>❌ 打开文件夹失败：{e}</span>"
                )

        if btn_logs is not None:
            try: btn_logs.clicked.disconnect()
            except Exception: pass
            btn_logs.clicked.connect(lambda checked=False, p=logs_dir: _open_dir(p))
            btn_logs.setVisible(True)

        if btn_doc is not None:
            try: btn_doc.clicked.disconnect()
            except Exception: pass
            btn_doc.clicked.connect(lambda checked=False, p=doc_dir: _open_dir(p))
            btn_doc.setVisible(True)

    # ------------------------- 计时器 -------------------------
    def _start_elapsed(self, step_name):
        self._run_start_times[step_name] = {"start": time.time()}
        self._elapsed_label_cache.pop(step_name, None)
        if not self._elapsed_timer.isActive():
            self._elapsed_timer.start()

    def _stop_elapsed(self, step_name):
        if step_name not in self._run_start_times:
            return
        elapsed = time.time() - self._run_start_times[step_name]["start"]
        del self._run_start_times[step_name]
        self._elapsed_label_cache.pop(step_name, None)
        if not self._run_start_times:
            self._elapsed_timer.stop()
        # 在状态文本末尾追加最终耗时
        stat = self.log_status_lbls.get(step_name)
        if stat is not None:
            cur_text = stat.text()
            base_text = cur_text.split("  (耗时:")[0] if "(耗时:" in cur_text else cur_text
            stat.setText(f"{base_text}  (耗时: {self._format_elapsed(elapsed)})")

    def _tick_running_elapsed(self):
        for step_name, rec in list(self._run_start_times.items()):
            elapsed = time.time() - rec["start"]
            stat = self.log_status_lbls.get(step_name)
            if stat is None:
                continue
            cur_text = stat.text()
            base_text = cur_text.split("  (耗时:")[0] if "(耗时:" in cur_text else cur_text
            new_text = f"{base_text}  (耗时: {self._format_elapsed(elapsed)})"
            if self._elapsed_label_cache.get(step_name) != new_text:
                stat.setText(new_text)
                self._elapsed_label_cache[step_name] = new_text

    @staticmethod
    def _format_elapsed(sec):
        if sec < 60:
            return f"{sec:.1f}s"
        m, s = divmod(int(sec), 60)
        return f"{m}m{s}s"

    # ------------------------- 切换 / 路径更新 -------------------------
    def switch_step(self, step_name):
        for name, btn in self.step_btns.items():
            btn.setChecked(name == step_name)
        if step_name in self.steps:
            idx = self.steps.index(step_name)
            self.left_stack.setCurrentIndex(idx)
            self.right_stack.setCurrentIndex(idx)
            # Batch Run 5:5（脚本 matrix 较宽），Initial PGM 4:6（左侧表单较窄）
            try:
                total = sum(self.splitter.sizes()) or 1200
                if step_name == "Batch Run":
                    self.splitter.setSizes([int(total * 5 / 10), int(total * 5 / 10)])
                else:
                    self.splitter.setSizes([int(total * 4 / 10), int(total * 6 / 10)])
            except Exception:
                pass

    def _get_all_forms(self):
        forms = [self.init_pgm_form]
        if hasattr(self, 'batch_run_form'):
            forms.append(self.batch_run_form)
        return forms

    def update_path(self, base_path, p3, p4):
        """主控推送 4 级路径到 ADaM 模块各 form"""
        self.base_path = base_path
        self.p3 = p3
        self.p4 = p4

        try:
            rel = os.path.relpath(base_path, "Z:\\")
            levels = [x for x in rel.split(os.sep) if x and x != ".."]
            paths_complete = len(levels) >= 4
        except Exception:
            paths_complete = False

        # 复位耗时
        self._run_start_times.clear()
        self._elapsed_label_cache.clear()
        if self._elapsed_timer.isActive():
            self._elapsed_timer.stop()

        if not paths_complete:
            for step in self.steps:
                self._clear_log_for_step(step)
                self.log_status_lbls[step].setText("就绪")
                self.log_status_lbls[step].setStyleSheet(
                    "font-size: 13px; font-weight: bold; color: #909399; padding-top: 5px;")
                self.step_btns[step].setText(self.step_original_texts[step])
                if step in self.check_logs_btns:
                    self.check_logs_btns[step].setVisible(False)
                if step in self.check_doc_btns:
                    self.check_doc_btns[step].setVisible(False)
            for form in self._get_all_forms():
                if hasattr(form, 'set_wait_hint'):
                    form.set_wait_hint(True)
            return

        # 路径齐全
        for form in self._get_all_forms():
            if hasattr(form, 'set_wait_hint'):
                form.set_wait_hint(False)

        pdt_path = os.path.join(base_path, "utility", "documentation",
                                f"{p3}_{p4}_PDT.xlsx" if (p3 or p4) else "项目层面_PDT.xlsx")
        self.init_pgm_form.update_paths(base_path, pdt_path)
        if BatchRunForm and hasattr(self, 'batch_run_form'):
            self.batch_run_form.update_paths(base_path)

        for step in self.steps:
            self._clear_log_for_step(step)
            self.log_status_lbls[step].setText("就绪")
            self.log_status_lbls[step].setStyleSheet(
                "font-size: 13px; font-weight: bold; color: #909399; padding-top: 5px;")
            self.step_btns[step].setText(self.step_original_texts[step])
            if step in self.check_logs_btns:
                self.check_logs_btns[step].setVisible(False)
            if step in self.check_doc_btns:
                self.check_doc_btns[step].setVisible(False)

    # ============================================================
    # 路径切换时主控调 refresh_caches（更新 4：弹窗后通知 form 主动刷新）
    # ============================================================
    def refresh_caches(self):
        """主控通知：项目路径已切换，主动刷新 form 缓存。"""
        for form in self._get_all_forms():
            for m in ("action_refresh", "refresh_paths"):
                fn = getattr(form, m, None)
                if callable(fn):
                    try:
                        fn()
                    except Exception:
                        pass
                    break
