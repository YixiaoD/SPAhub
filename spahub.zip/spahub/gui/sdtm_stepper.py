# -*- coding: utf-8 -*-
"""
gui/sdtm_stepper.py
===================
SDTM 三步导航器（01 PDT Gen / 02 SDTM Gen / 03 Batch Run）。

v12.10.34：原 SDTM-01 Import EDC Definition 已转移到 aCRF-03，本 stepper 仅保留三步：
    01 PDT Gen / 02 SDTM Gen / 03 Batch Run。导入逻辑见 gui/acrf_stepper.py 的 03 步。

布局 / 风格对齐 aCRFWidget + TFLsWidget：
  - 顶部步骤栏（可点击切换；运行中 ⏳；完成 ✅ / ⚠️ / ❌ / 🟥）
  - 左：业务表单
  - 右：每步独立的运行日志面板
      • 01 / 03 步：单 panel，与其它 stepper 同款
      • 02 SDTM Gen 步：QTabWidget 容器，两个 tab —
          - 「📄 generate_pds 日志」（接 sig_log_pds）
          - 「📄 sdtm_template 日志」（接 sig_log_template）
        子步运行启动时自动切到对应 tab
  - 信号总线：sig_log / sig_status / sig_step_update / sig_run_started / sig_run_finished
  - 路径未齐全：广播 set_wait_hint(True) 给各 Form 让其显示等待提示

注：03 步使用 BatchRunForm 的子类 SdtmBatchRunForm（与 TFLs 04 完全同套机制）—
    用 sig_clear_log 控制日志清空时机，不靠 sig_run_started 清。
"""
import os
import time
from datetime import datetime

from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                               QStackedWidget, QTextEdit, QFrame, QFileDialog,
                               QSplitter, QTabWidget)
from PySide6.QtCore import Qt, QTimer, Signal, QThread
from PySide6.QtGui import QTextOption

from modules.sdtm_pdt import SdtmPdtForm
from modules.sdtm_generate import SdtmGenerateForm
from modules.sdtm_batch_run import SdtmBatchRunForm
from ui_utils import show_dialog, scan_status_lbl_style, log_textedit_style, ChevronStepBar, StepProxy
from gui.log_search import attach_log_search  # v12.10.102：日志框内 Ctrl+F 搜索


# ============================================================================
# 后台刷新工作线程（与 tfls_stepper 同款）
# ============================================================================
class _RefreshWorker(QThread):
    finished = Signal(str)

    def __init__(self, step_name, refresh_func):
        super().__init__()
        self.step_name = step_name
        self._refresh_func = refresh_func

    def run(self):
        try:
            self._refresh_func()
        finally:
            self.finished.emit(self.step_name)


# ============================================================================
# SdtmWidget 主体
# ============================================================================
class SdtmWidget(QWidget):
    """SDTM 三步导航容器：步骤栏 + 左右分栏（4:6，03 步 Batch Run 切到 6:4）

    v12.10.34：原 SDTM-01 Import EDC Definition 已转移到 aCRF-03，本 stepper 只剩 3 步。
    """

    # 步骤名固定（用作 step_btns / log_texts 的字典键）
    _STEPS = ["PDT Gen", "SDTM Gen", "Batch Run"]

    def __init__(self):
        super().__init__()
        self.base_path = ""
        self.p3 = ""
        self.p4 = ""

        self.steps = list(self._STEPS)
        self.step_original_texts = {step: f"0{i + 1} {step}" for i, step in enumerate(self.steps)}

        self.step_btns = {}            # step → step 栏按钮
        self.log_texts = {}            # step → QTextEdit（SDTM Gen 步留空，由 _sdtm_gen_* 单独承载）
        self.log_status_lbls = {}      # step → 底部状态 QLabel
        self.export_btns = {}          # step → "📋 导出日志" 按钮
        self.archive_btns = {}         # step → "📂 归档路径" 按钮（仅 01 PDT Gen 触发归档时显示）
        # v12.10.123：运行日志 WARNING/ERROR 正向筛选（widget 键 —— SDTM Gen 两 tab 各一键）
        self._log_entries = {}         # key -> [(level, msg), ...]
        self._log_filters = {}         # key -> {"WARNING": bool, "ERROR": bool}
        self._log_filter_chks = {}     # key -> {level: QCheckBox}
        self._log_widgets = {}         # key -> QTextEdit

        # SDTM Gen 步专属：两个 tab 内的 QTextEdit + tab 容器
        self._sdtm_gen_pds_text = None
        self._sdtm_gen_template_text = None
        self._sdtm_gen_tab_widget = None

        # 耗时跟踪（与 acrf_stepper / tfls_stepper 同款）
        self._run_start_times = {}
        self._elapsed_label_cache = {}
        self._elapsed_timer = QTimer(self)
        self._elapsed_timer.setInterval(2000)
        self._elapsed_timer.timeout.connect(self._tick_running_elapsed)

        self._setup_ui()
        self._connect_components()

    # ------------------------- UI -------------------------
    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # --- 顶部步骤栏 ---
        stepper_frame = QFrame()
        stepper_frame.setStyleSheet("background-color: #FFFFFF; border: 1px solid #E4E7ED; border-radius: 6px;")
        stepper_layout = QHBoxLayout(stepper_frame)
        stepper_layout.setContentsMargins(10, 8, 10, 8)

        # v12.10.90：步骤栏改 chevron 箭头管道（方案B）。
        self.step_bar = ChevronStepBar(self.steps, self.step_original_texts)
        self.step_bar.step_clicked.connect(self.switch_step)
        stepper_layout.addWidget(self.step_bar)
        self.step_btns = {s: StepProxy(self.step_bar, s) for s in self.steps}

        layout.addWidget(stepper_frame)
        layout.addSpacing(10)

        # --- 左右分栏 ---
        self.splitter = QSplitter(Qt.Horizontal)
        self.splitter.setStyleSheet("QSplitter::handle { background-color: #EBEEF5; width: 4px; }")
        self.splitter.setChildrenCollapsible(False)

        self.left_stack = QStackedWidget()
        self.right_stack = QStackedWidget()
        self.right_stack.setStyleSheet("background-color: #FFFFFF; border: 1px solid #E4E7ED; border-radius: 6px;")

        self.splitter.addWidget(self.left_stack)
        self.splitter.addWidget(self.right_stack)
        self.splitter.setStretchFactor(0, 4)
        self.splitter.setStretchFactor(1, 6)
        self.splitter.setSizes([480, 720])
        layout.addWidget(self.splitter, 1)

        # --- 各模块表单 + 对应日志面板 ---
        # v12.10.34：原 import_form (Import EDC Definition) 已转移到 aCRF-03，本 stepper 只剩 3 步
        self.pdt_form = SdtmPdtForm()
        self.gen_form = SdtmGenerateForm()
        self.batch_form = SdtmBatchRunForm()

        self.left_stack.addWidget(self.pdt_form)
        self.right_stack.addWidget(self._create_right_log_panel("PDT Gen"))

        self.left_stack.addWidget(self.gen_form)
        self.right_stack.addWidget(self._create_sdtm_gen_right_panel())

        self.left_stack.addWidget(self.batch_form)
        self.right_stack.addWidget(self._create_right_log_panel("Batch Run"))

        self.switch_step("PDT Gen")

    def _create_right_log_panel(self, step_name):
        """通用单 panel 日志（参考 acrf_stepper）"""
        rw = QFrame()
        rl = QVBoxLayout(rw)
        rl.setContentsMargins(10, 10, 10, 10)

        log_header = QHBoxLayout()
        title_lbl = QLabel(f"📄 {step_name} 运行日志")
        title_lbl.setStyleSheet("font-size: 13px; font-weight: bold; color: #606266; border: none;")
        log_header.addWidget(title_lbl)
        log_header.addStretch()

        # [归档路径] 按钮 —— 仅 01 PDT Gen 触发历史归档时会显示（与 tfls 一致）
        arc_btn = QPushButton("📂 归档路径")
        arc_btn.setStyleSheet("""
            QPushButton { background-color: #FEF0F0; color: #F56C6C; border: 1px solid #FBC4C4; padding: 4px 10px; border-radius: 4px; font-size:12px;}
            QPushButton:hover { background-color: #F56C6C; color: #FFFFFF; }
        """)
        arc_btn.setVisible(False)
        self.archive_btns[step_name] = arc_btn
        log_header.addWidget(arc_btn)

        exp_btn = QPushButton("📋 导出日志")
        exp_btn.setStyleSheet("""
            QPushButton { background-color: #ECF5FF; color: #409EFF; border: 1px solid #B3D8FF; padding: 4px 10px; border-radius: 4px; font-size:12px; font-weight:bold;}
            QPushButton:hover { background-color: #409EFF; color: #FFFFFF; }
        """)
        exp_btn.clicked.connect(lambda checked, s=step_name: self._export_log(s))
        self.export_btns[step_name] = exp_btn
        log_header.addWidget(exp_btn)
        rl.addLayout(log_header)

        txt = QTextEdit()
        txt.setReadOnly(True)
        attach_log_search(txt)  # v12.10.102：日志框内 Ctrl+F 搜索
        txt.setLineWrapMode(QTextEdit.WidgetWidth)
        txt.setWordWrapMode(QTextOption.WrapAnywhere)
        txt.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        txt.setStyleSheet(
            log_textedit_style(with_padding=True))
        self._make_log_filter_row(step_name, txt, rl)   # v12.10.123：WARNING/ERROR 筛选
        rl.addWidget(txt)

        stat = QLabel("就绪")
        stat.setAlignment(Qt.AlignCenter)
        stat.setStyleSheet("font-size: 13px; font-weight: bold; color: #909399; padding-top: 5px;")
        rl.addWidget(stat)

        self.log_texts[step_name] = txt
        self.log_status_lbls[step_name] = stat
        return rw

    def _create_sdtm_gen_right_panel(self):
        """
        SDTM Gen 专属右侧面板：QTabWidget 包两个独立日志 + 一个共享底部状态栏。

        Tab 1：📄 generate_pds 日志（接 sig_log_pds）
        Tab 2：📄 sdtm_template 日志（接 sig_log_template）
        底部 status 标签：与其他步骤一致，显示运行状态 / 耗时
        """
        rw = QFrame()
        rl = QVBoxLayout(rw)
        rl.setContentsMargins(10, 10, 10, 10)
        rl.setSpacing(8)

        # 顶部行：标题 + 当前 tab 的导出按钮
        log_header = QHBoxLayout()
        title_lbl = QLabel("📄 SDTM Gen 运行日志")
        title_lbl.setStyleSheet("font-size: 13px; font-weight: bold; color: #606266; border: none;")
        log_header.addWidget(title_lbl)
        log_header.addStretch()
        # 导出按钮（按当前 tab 导出）
        exp_btn = QPushButton("📋 导出日志")
        exp_btn.setStyleSheet("""
            QPushButton { background-color: #ECF5FF; color: #409EFF; border: 1px solid #B3D8FF; padding: 4px 10px; border-radius: 4px; font-size:12px; font-weight:bold;}
            QPushButton:hover { background-color: #409EFF; color: #FFFFFF; }
        """)
        exp_btn.clicked.connect(lambda: self._export_log("SDTM Gen"))
        self.export_btns["SDTM Gen"] = exp_btn
        log_header.addWidget(exp_btn)
        rl.addLayout(log_header)

        tabs = QTabWidget()
        tabs.setStyleSheet("""
            QTabWidget::pane { border: 1px solid #E4E7ED; border-radius: 4px; }
            QTabBar::tab { background: #F5F7FA; color: #606266; padding: 6px 14px; border: 1px solid #E4E7ED; border-bottom: none; border-top-left-radius: 4px; border-top-right-radius: 4px; }
            QTabBar::tab:selected { background: #FFFFFF; color: #409EFF; font-weight: bold; }
        """)

        def _make_text_edit():
            t = QTextEdit()
            t.setReadOnly(True)
            attach_log_search(t)  # v12.10.102：日志框内 Ctrl+F 搜索
            t.setLineWrapMode(QTextEdit.WidgetWidth)
            t.setWordWrapMode(QTextOption.WrapAnywhere)
            t.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
            t.setStyleSheet(
                log_textedit_style(with_padding=True))
            return t

        # Tab 1：generate_pds 日志
        tab_pds = QFrame()
        tab_pds_lay = QVBoxLayout(tab_pds)
        tab_pds_lay.setContentsMargins(8, 8, 8, 8)
        self._sdtm_gen_pds_text = _make_text_edit()
        self._make_log_filter_row("SDTM Gen::pds", self._sdtm_gen_pds_text, tab_pds_lay)
        tab_pds_lay.addWidget(self._sdtm_gen_pds_text)
        tabs.addTab(tab_pds, "📄 generate_pds")

        # Tab 2：sdtm_template 日志
        tab_tpl = QFrame()
        tab_tpl_lay = QVBoxLayout(tab_tpl)
        tab_tpl_lay.setContentsMargins(8, 8, 8, 8)
        self._sdtm_gen_template_text = _make_text_edit()
        self._make_log_filter_row("SDTM Gen::tpl", self._sdtm_gen_template_text, tab_tpl_lay)
        tab_tpl_lay.addWidget(self._sdtm_gen_template_text)
        tabs.addTab(tab_tpl, "📄 sdtm_template")

        rl.addWidget(tabs)
        self._sdtm_gen_tab_widget = tabs

        # 底部状态栏（与其他步骤一致）
        stat = QLabel("就绪")
        stat.setAlignment(Qt.AlignCenter)
        stat.setStyleSheet("font-size: 13px; font-weight: bold; color: #909399; padding-top: 5px;")
        rl.addWidget(stat)

        self.log_status_lbls["SDTM Gen"] = stat
        # 注意：log_texts["SDTM Gen"] 不指向单一控件，而是个 list（用于 _export_log 拼接两 tab 文本）
        self.log_texts["SDTM Gen"] = None  # 标记位

        # v12.10.5：双子步独立状态 — 跟随当前 tab 切换显示对应子步的状态/耗时
        # 字典：tab key("pds"/"tpl") → (status_text, status_color)
        # 切换 tab 时，stat label 显示当前激活 tab 对应的状态
        self._sdtm_gen_sub_status = {
            "pds": ("就绪", "#909399"),
            "tpl": ("就绪", "#909399"),
        }
        # tab index 0 = generate_pds = "pds"; index 1 = sdtm_template = "tpl"
        self._sdtm_gen_tab_keys = ["pds", "tpl"]
        tabs.currentChanged.connect(self._on_sdtm_gen_tab_changed)

        return rw

    def _refresh_sdtm_gen_stat_label(self):
        """
        v12.10.10：SDTM Gen 状态栏统一刷新函数。

        根据当前激活 tab + `_sdtm_gen_sub_status` 字典 + `_run_start_times` 复合 key 是否在跑，
        合成 "基础状态文本  (耗时: 5.2s)" 写到 stat label。

        被以下三处调用：
          1. tab 切换 (_on_sdtm_gen_tab_changed)
          2. 子步状态变化 (_on_sdtm_gen_status_pds / _on_sdtm_gen_status_tpl)
          3. 计时器 tick (_tick_running_elapsed 内对 SDTM Gen 复合 key 的特殊分支)

        统一刷新避免了之前 v12.10.5 的"两 tab 共享 stat label，被 tick 直接覆盖
        破坏 tab 切换" bug —— stat label 现在只反映当前激活 tab 对应子步的真实状态。
        """
        if not hasattr(self, "_sdtm_gen_tab_widget") or self._sdtm_gen_tab_widget is None:
            return
        try:
            idx = self._sdtm_gen_tab_widget.currentIndex()
            sub = self._sdtm_gen_tab_keys[idx]      # "pds" / "tpl"
        except Exception:
            return
        base_text, color = self._sdtm_gen_sub_status.get(sub, ("就绪", "#909399"))
        rec = self._run_start_times.get(f"SDTM Gen:{sub}")
        if rec is not None:
            elapsed = time.time() - rec["start"]
            text = f"{base_text}  (耗时: {self._format_elapsed(elapsed)})"
        else:
            text = base_text
        stat = self.log_status_lbls.get("SDTM Gen")
        if stat is not None:
            stat.setText(text)
            stat.setStyleSheet(
                f"font-size: 13px; font-weight: bold; color: {color}; padding-top: 5px;")

    def _on_sdtm_gen_tab_changed(self, idx):
        """SDTM Gen 内两个 tab 切换时，把状态 label 同步到当前 tab 对应子步的状态（含耗时）。"""
        self._refresh_sdtm_gen_stat_label()

    def _on_sdtm_gen_status_pds(self, text, color):
        """generate_pds 子步状态更新：写入字典 + 刷新（仅当前激活 tab 是 pds 时显示更新）"""
        self._sdtm_gen_sub_status["pds"] = (text, color)
        self._refresh_sdtm_gen_stat_label()

    def _on_sdtm_gen_status_tpl(self, text, color):
        """sdtm_template 子步状态更新：写入字典 + 刷新（仅当前激活 tab 是 tpl 时显示更新）"""
        self._sdtm_gen_sub_status["tpl"] = (text, color)
        self._refresh_sdtm_gen_stat_label()

    # ------------------------- 步骤切换 -------------------------
    def switch_step(self, step_name):
        for name, btn in self.step_btns.items():
            btn.setChecked(name == step_name)
        if step_name in self.steps:
            idx = self.steps.index(step_name)
            self.left_stack.setCurrentIndex(idx)
            self.right_stack.setCurrentIndex(idx)
            self._apply_splitter_ratio_for_step(step_name)

    def _apply_splitter_ratio_for_step(self, step_name):
        """切到 SDTM Batch Run 时左右比例改为 6:4，让脚本矩阵能完整显示。"""
        total = self.splitter.width()
        if total <= 0:
            return
        left_pct = 0.60 if step_name == "Batch Run" else 0.40
        left_w = int(total * left_pct)
        right_w = total - left_w
        self.splitter.setSizes([left_w, right_w])

    # ------------------------- 日志追加 / 导出 -------------------------
    def _append_and_scroll(self, step_name, msg):
        """通用追加（用于 01 / 02 / 04 步）；SDTM Gen 步走 _append_pds / _append_template。"""
        self._append_log_by_key(step_name, msg)

    def _append_pds(self, msg):
        self._append_log_by_key("SDTM Gen::pds", msg)

    def _append_template(self, msg):
        self._append_log_by_key("SDTM Gen::tpl", msg)

    # -------- 运行日志 WARNING/ERROR 正向筛选（widget 键；与 adam/tfls 同款语义）--------
    def _make_log_filter_row(self, key, text_widget, target_layout):
        from PySide6.QtWidgets import QCheckBox, QHBoxLayout, QLabel
        self._log_widgets[key] = text_widget
        self._log_filters[key] = {"WARNING": False, "ERROR": False}
        self._log_filter_chks[key] = {}
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 4)
        lbl = QLabel("过滤：")
        lbl.setStyleSheet("color: #909399; font-size: 11px; border: none;")
        row.addWidget(lbl)
        for level, label, color in [("WARNING", "⚠ WARNING", "#E6A23C"), ("ERROR", "❌ ERROR", "#F56C6C")]:
            chk = QCheckBox(label)
            chk.setChecked(False)
            chk.setStyleSheet(
                f"QCheckBox {{ color: {color}; font-size: 11px; border: none; spacing: 4px; }}"
                f"QCheckBox::indicator {{ width: 12px; height: 12px; border: 1px solid #DCDFE6; border-radius: 2px; background-color: #FFFFFF; }}"
                f"QCheckBox::indicator:hover {{ border: 1px solid {color}; }}"
                f"QCheckBox::indicator:checked {{ background-color: {color}; border: 1px solid {color}; }}"
            )
            chk.toggled.connect(lambda checked, k=key, lv=level: self._on_log_filter_toggled(k, lv, checked))
            self._log_filter_chks[key][level] = chk
            row.addWidget(chk)
        row.addStretch()
        target_layout.addLayout(row)

    @staticmethod
    def _classify_msg_level(msg):
        if not msg:
            return "NOTE"
        upper = msg.upper()
        if "#F56C6C" in msg or "❌" in msg or " ERROR" in upper or upper.startswith("ERROR") or "ERROR:" in upper:
            return "ERROR"
        if "#E6A23C" in msg or "⚠" in msg or "WARNING" in upper:
            return "WARNING"
        return "NOTE"

    def _should_show_log(self, key, level):
        f = self._log_filters.get(key, {})
        active = [lv for lv in ("WARNING", "ERROR") if f.get(lv)]
        if not active:
            return True
        return level in active

    def _append_log_by_key(self, key, msg):
        widget = self._log_widgets.get(key)
        if widget is None:
            return
        level = self._classify_msg_level(msg)
        self._log_entries.setdefault(key, []).append((level, msg))
        if not self._should_show_log(key, level):
            return
        widget.append(msg)
        sb = widget.verticalScrollBar()
        sb.setValue(sb.maximum())

    def _on_log_filter_toggled(self, key, level, checked):
        self._log_filters.setdefault(key, {"WARNING": False, "ERROR": False})[level] = checked
        self._rerender_log(key)

    def _rerender_log(self, key):
        widget = self._log_widgets.get(key)
        if widget is None:
            return
        widget.clear()
        for lvl, msg in self._log_entries.get(key, []):
            if self._should_show_log(key, lvl):
                widget.append(msg)
        sb = widget.verticalScrollBar()
        sb.setValue(sb.maximum())

    def _clear_log_key(self, key):
        widget = self._log_widgets.get(key)
        if widget is not None:
            widget.clear()
        self._log_entries[key] = []

    def _export_log(self, step_name):
        """导出指定步骤日志 — SDTM Gen 步把两个 tab 内容合并。
        v12.10.60：导出改为「汇总」——追加到团队共享 使用反馈.xlsx
        （Z:\\projects\\Z_PYTHON\\SPAhub\\），不再写本地 txt。"""
        from modules.log_summary import append_log_summary

        if step_name == "SDTM Gen":
            content_pds = self._sdtm_gen_pds_text.toPlainText() if self._sdtm_gen_pds_text else ""
            content_tpl = self._sdtm_gen_template_text.toPlainText() if self._sdtm_gen_template_text else ""
            content = (
                "===== 第一步：%generate_pds =====\n" + content_pds + "\n\n"
                "===== 第二步：%sdtm_template =====\n" + content_tpl
            ).strip()
        else:
            txt = self.log_texts.get(step_name)
            content = (txt.toPlainText() if txt is not None else "").strip()

        if not content:
            show_dialog(self, "提示", "日志为空，没有可汇总的内容。", "warning")
            return

        project = self.base_path or "(未选择项目)"  # base_path 即四级目录拼接全路径
        res = append_log_summary(
            project=project, module="sdtm", step=step_name, log_text=content)
        if res.get("ok"):
            show_dialog(
                self, "已汇总到反馈簿",
                f"日志已汇总到团队《使用反馈》第 {res['row']} 行。\n"
                f"提交人：{res['submitter']}　模块：sdtm　步骤：{step_name}",
                "info", path=res["path"])
        else:
            show_dialog(
                self, "汇总失败（已暂存本地）",
                f"{res.get('error', '未知错误')}\n\n本地暂存：{res.get('path', '(无)')}",
                "warning", path=res.get("path") or None)

    # ------------------------- 状态 / 耗时 -------------------------
    def _set_status(self, step, msg, color):
        lbl = self.log_status_lbls.get(step)
        if lbl is None:
            return
        lbl.setText(msg)
        lbl.setStyleSheet(f"font-size: 13px; font-weight: bold; color: {color}; padding-top: 5px;")

    def _start_elapsed(self, step_name):
        self._run_start_times[step_name] = {"start": time.time()}
        self._elapsed_label_cache.pop(step_name, None)
        if not self._elapsed_timer.isActive():
            self._elapsed_timer.start()

    def _stop_elapsed(self, step_name):
        if step_name not in self._run_start_times:
            return
        elapsed = time.time() - self._run_start_times[step_name]["start"]
        del self._run_start_times[step_name]
        self._elapsed_label_cache.pop(step_name, None)
        if not self._run_start_times:
            self._elapsed_timer.stop()
        stat = self.log_status_lbls.get(step_name)
        if stat is not None:
            cur = stat.text()
            if "(耗时:" not in cur:
                stat.setText(f"{cur}  (耗时: {self._format_elapsed(elapsed)})")

    def _tick_running_elapsed(self):
        # v12.10.10：SDTM Gen 双子步用复合 key（"SDTM Gen:pds" / "SDTM Gen:tpl"）
        # 跳过原直接写 stat label 的逻辑，统一调 _refresh_sdtm_gen_stat_label
        # 让 stat label 只反映当前激活 tab 对应子步的耗时（避免 PDS 在跑但用户切到 Template tab
        # 看到 PDS 耗时刷新到 Template stat 上的混淆）。
        sdtm_gen_tick_needed = False
        for step_name, rec in list(self._run_start_times.items()):
            if step_name.startswith("SDTM Gen:"):
                sdtm_gen_tick_needed = True
                continue   # 由 _refresh_sdtm_gen_stat_label 统一处理
            elapsed = time.time() - rec["start"]
            stat = self.log_status_lbls.get(step_name)
            if stat is None:
                continue
            cur_text = stat.text()
            base_text = cur_text.split("  (耗时:")[0] if "(耗时:" in cur_text else cur_text
            new_text = f"{base_text}  (耗时: {self._format_elapsed(elapsed)})"
            if self._elapsed_label_cache.get(step_name) != new_text:
                stat.setText(new_text)
                self._elapsed_label_cache[step_name] = new_text
        if sdtm_gen_tick_needed:
            self._refresh_sdtm_gen_stat_label()

    @staticmethod
    def _format_elapsed(sec):
        if sec < 60:
            return f"{sec:.1f}s"
        m, s = divmod(int(sec), 60)
        return f"{m}m{s}s"

    # ------------------------- 路径推送 -------------------------
    def update_path(self, base_path, p3, p4):
        """与 aCRFWidget 同款语义 + 去重"""
        new_key = (base_path, p3, p4)
        if getattr(self, "_last_pushed_path", None) == new_key:
            return
        self._last_pushed_path = new_key

        self.base_path = base_path
        self.p3 = p3
        self.p4 = p4

        try:
            rel = os.path.relpath(base_path, "Z:\\")
            levels = [x for x in rel.split(os.sep) if x and x != ".."]
            paths_complete = len(levels) >= 4
        except Exception:
            paths_complete = False

        # 复位耗时
        self._run_start_times.clear()
        self._elapsed_label_cache.clear()
        if self._elapsed_timer.isActive():
            self._elapsed_timer.stop()

        if not paths_complete:
            for step in self.steps:
                self._clear_step_log(step)
                self.log_status_lbls[step].setText("就绪")
                self.log_status_lbls[step].setStyleSheet(
                    "font-size: 13px; font-weight: bold; color: #909399; padding-top: 5px;")
                self.step_btns[step].setText(self.step_original_texts[step])
            # v12.10.5：SDTM Gen 双子步字典也要复位
            self._sdtm_gen_sub_status = {"pds": ("就绪", "#909399"), "tpl": ("就绪", "#909399")}
            for form in self._get_all_forms():
                if hasattr(form, 'set_wait_hint'):
                    form.set_wait_hint(True)
            self._clear_all_subform_inputs()
            return

        # 齐全：隐藏等待提示 + 推路径
        for form in self._get_all_forms():
            if hasattr(form, 'set_wait_hint'):
                form.set_wait_hint(False)

        # v12.10.34：去掉 self.import_form.update_paths(base_path)（已转移到 aCRF-03）
        self.pdt_form.update_paths(base_path)
        self.gen_form.update_paths(base_path)
        self.batch_form.update_paths(base_path)

        # 01 PDT Gen 的归档按钮始终可见 — 指向 utility/documentation/99_archive
        # （tfls 的 PDT Gen 仅触发 "already exists" 时才显示；SDTM 这里始终可见，
        # 让用户随时能查看历史 PDT 备份；目录不存在时点击不响应）
        archive_dir = os.path.join(base_path, "utility", "documentation", "99_archive")
        self._pdt_archive_path = archive_dir
        self.archive_btns["PDT Gen"].setVisible(True)

        for step in self.steps:
            self._clear_step_log(step)
            self.log_status_lbls[step].setText("就绪")
            self.log_status_lbls[step].setStyleSheet(
                "font-size: 13px; font-weight: bold; color: #909399; padding-top: 5px;")
            self.step_btns[step].setText(self.step_original_texts[step])
        # v12.10.5：SDTM Gen 双子步字典也要复位
        self._sdtm_gen_sub_status = {"pds": ("就绪", "#909399"), "tpl": ("就绪", "#909399")}

    def _clear_step_log(self, step_name):
        if step_name == "SDTM Gen":
            self._clear_log_key("SDTM Gen::pds")
            self._clear_log_key("SDTM Gen::tpl")
        else:
            self._clear_log_key(step_name)

    def _clear_all_subform_inputs(self):
        # 路径未齐全时清空每个 form 的常见输入字段（保守清理，避免回归）
        for form in self._get_all_forms():
            for attr in ("setup_entry", "sas_entry", "dir_entry", "ecrf_entry",
                         "draft_pdf_entry", "final_pdf_entry", "toc_entry",
                         "pdt_entry", "sas_92_entry", "pre_path_entry"):
                w = getattr(form, attr, None)
                if w is not None:
                    try:
                        w.clear()
                    except Exception:
                        pass
            macro_lbl = getattr(form, "macro_lbl", None)
            if macro_lbl is not None:
                macro_lbl.setText("(尚未读取)")
                macro_lbl.setStyleSheet(
                    "border: 1px solid #E4E7ED; background: #F8F9FA; color: #606266; padding: 6px 10px; border-radius: 4px;")
            form.base_path = ""

    def _get_all_forms(self):
        # v12.10.34：去掉 self.import_form（已转移到 aCRF-03）
        return [self.pdt_form, self.gen_form, self.batch_form]

    def _get_form(self, step_name):
        return {
            "PDT Gen": self.pdt_form,
            "SDTM Gen": self.gen_form,
            "Batch Run": self.batch_form,
        }.get(step_name)

    def _refresh_step(self, step_name):
        """左侧 🔄 刷新按钮入口"""
        if not self.base_path:
            return
        form = self._get_form(step_name)
        if form and hasattr(form, 'scan_lbl'):
            form.scan_lbl.setText("正在刷新...")
            form.scan_lbl.setStyleSheet(scan_status_lbl_style("#409EFF"))

        def _do():
            # v12.10.34：去掉 Import EDC Definition 分支
            if step_name == "PDT Gen":
                self.pdt_form.update_paths(self.base_path)
            elif step_name == "SDTM Gen":
                self.gen_form.update_paths(self.base_path)
            elif step_name == "Batch Run":
                self.batch_form.update_paths(self.base_path)

        # SDTM Gen 的 update_paths 会启动 domain_list 后台扫描（已自带子线程），主线程同步即可
        _do()
        if form and hasattr(form, 'scan_lbl'):
            # SDTM Gen 自带"⏳ 正在扫描"提示 — 避免覆盖
            if step_name != "SDTM Gen":
                form.scan_lbl.setText("✅ 刷新完成")
                form.scan_lbl.setStyleSheet(scan_status_lbl_style("#67C23A"))

    # ------------------------- 信号路由 -------------------------
    def _connect_components(self):
        def _set_running_icon(step):
            original = self.step_original_texts[step]
            self.step_btns[step].setText(f"{original}  ⏳")

        # 把每个 form 的 🔄 刷新按钮路由到 _refresh_step
        for form in self._get_all_forms():
            if hasattr(form, 'refresh_btn') and hasattr(form, '_step_name'):
                # form._step_name 是 form 内部用的简称（如 "PDT Gen"）
                # 我们的 stepper 用的是 "PDT Gen" 等，得做一次 form → step 反查
                pass
        # 用直接绑定的方式更稳：
        # v12.10.34：去掉 import_form refresh 路由
        if hasattr(self.pdt_form, "refresh_btn"):
            self.pdt_form.refresh_btn.clicked.connect(lambda: self._refresh_step("PDT Gen"))
        if hasattr(self.gen_form, "refresh_btn"):
            # SDTM Gen 的 refresh_btn 已绑定到 _kick_domain_scan（form 内部），
            # 这里只需追加一个"标识 stepper 已知刷新"动作 — 但 form 自身处理 scan_lbl，stepper 不需重复。
            pass
        if hasattr(self.batch_form, "refresh_btn"):
            self.batch_form.refresh_btn.clicked.connect(lambda: self._refresh_step("Batch Run"))

        # v12.10.34：删除 01 Import EDC Definition 信号路由（已转移到 aCRF-03，由 acrf_stepper 接管）

        # ----- 01 PDT Gen -----
        self.pdt_form.sig_run_started.connect(lambda: self._clear_step_log("PDT Gen"))
        self.pdt_form.sig_run_started.connect(lambda: _set_running_icon("PDT Gen"))
        self.pdt_form.sig_run_started.connect(lambda: self._start_elapsed("PDT Gen"))
        self.pdt_form.sig_log.connect(lambda msg: self._append_and_scroll("PDT Gen", msg))
        self.pdt_form.sig_status.connect(lambda msg, color: self._set_status("PDT Gen", msg, color))
        self.pdt_form.sig_step_update.connect(lambda txt: (
            self.step_btns["PDT Gen"].setText(txt),
            self._stop_elapsed("PDT Gen")))

        # PDT Gen 专有：归档目录按钮（与 tfls 一致 — 仅触发"already exists"归档保护时显示）
        self._pdt_archive_path = ""

        def _on_pdt_archive_show(show, path):
            self._pdt_archive_path = path
            self.archive_btns["PDT Gen"].setVisible(show)

        self.pdt_form.sig_show_archive.connect(_on_pdt_archive_show)
        self.archive_btns["PDT Gen"].clicked.connect(
            lambda: os.startfile(self._pdt_archive_path)
            if self._pdt_archive_path and os.path.exists(self._pdt_archive_path) else None)

        # ----- 02 SDTM Gen（双子步信号 → 双 tab） -----
        # 累加日志：运行启动只切 tab + 启计时，**不**清空之前的日志
        # 仅在用户点 "🔄 刷新 domain list" 时通过 sig_clear_log_pds / sig_clear_log_template 清空
        # v12.10.10：用复合 key 区分两子步计时，避免 stat label 在两 tab 间错位刷新
        def _pds_started():
            if self._sdtm_gen_tab_widget is not None:
                self._sdtm_gen_tab_widget.setCurrentIndex(0)
            _set_running_icon("SDTM Gen")
            self._start_elapsed("SDTM Gen:pds")

        def _template_started():
            if self._sdtm_gen_tab_widget is not None:
                self._sdtm_gen_tab_widget.setCurrentIndex(1)
            _set_running_icon("SDTM Gen")
            self._start_elapsed("SDTM Gen:tpl")

        self.gen_form.sig_run_started_pds.connect(_pds_started)
        self.gen_form.sig_run_started_template.connect(_template_started)

        # 仅"🔄 刷新 domain list"才清空对应 tab 日志
        def _clear_pds_tab():
            self._clear_log_key("SDTM Gen::pds")

        def _clear_template_tab():
            self._clear_log_key("SDTM Gen::tpl")

        self.gen_form.sig_clear_log_pds.connect(_clear_pds_tab)
        self.gen_form.sig_clear_log_template.connect(_clear_template_tab)

        # 双子步日志 → 各自 tab
        self.gen_form.sig_log_pds.connect(self._append_pds)
        self.gen_form.sig_log_template.connect(self._append_template)

        # v12.10.5：双子步独立状态 — 接到各自的 _on_sdtm_gen_status_xxx，
        # 由该方法决定写入字典 + 是否同步到 stat label（取决于当前 tab）。
        # 老的 sig_status 不再 connect（也已不再 emit；保留信号定义仅作兼容）。
        self.gen_form.sig_status_pds.connect(self._on_sdtm_gen_status_pds)
        self.gen_form.sig_status_tpl.connect(self._on_sdtm_gen_status_tpl)
        self.gen_form.sig_step_update.connect(lambda txt: (
            self.step_btns["SDTM Gen"].setText(txt),))
        # v12.10.10：双子步 finished 各自停对应复合 key 的计时
        self.gen_form.sig_run_finished_pds.connect(lambda: self._stop_elapsed("SDTM Gen:pds"))
        self.gen_form.sig_run_finished_pds.connect(self._refresh_sdtm_gen_stat_label)
        self.gen_form.sig_run_finished_tpl.connect(lambda: self._stop_elapsed("SDTM Gen:tpl"))
        self.gen_form.sig_run_finished_tpl.connect(self._refresh_sdtm_gen_stat_label)

        # ----- 03 SDTM Batch Run（与 TFLs 04 同套机制：sig_clear_log 控制清空） -----
        self.batch_form.sig_clear_log.connect(lambda: self._clear_step_log("Batch Run"))
        self.batch_form.sig_run_started.connect(lambda: _set_running_icon("Batch Run"))
        self.batch_form.sig_run_started.connect(lambda: self._start_elapsed("Batch Run"))
        self.batch_form.sig_log.connect(lambda msg: self._append_and_scroll("Batch Run", msg))
        self.batch_form.sig_status.connect(lambda msg, color: self._set_status("Batch Run", msg, color))
        self.batch_form.sig_step_update.connect(lambda txt: (
            self.step_btns["Batch Run"].setText(txt),
            self._stop_elapsed("Batch Run")))
        self.batch_form.sig_run_finished.connect(lambda: self._stop_elapsed("Batch Run"))

    # ------------------------- 全局快捷键路由 -------------------------
    def _current_step_form(self):
        idx = self.left_stack.currentIndex()
        if 0 <= idx < len(self.steps):
            return self._get_form(self.steps[idx])
        return None

    def action_refresh(self):
        form = self._current_step_form()
        if form is not None:
            fn = getattr(form, "action_refresh", None)
            if callable(fn):
                fn()

    def action_run(self):
        form = self._current_step_form()
        if form is not None:
            fn = getattr(form, "action_run", None)
            if callable(fn):
                fn()
