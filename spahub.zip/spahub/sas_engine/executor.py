# -*- coding: utf-8 -*-
"""
sas_engine/executor.py
======================
SAS 执行与日志审阅引擎（与 GUI 解耦的纯逻辑层）。

核心接口：
  - run_sas(sas_file_path, ...)           提交 SAS 文件给 IOM 会话执行并回传结果
  - review_log_from_content(log, ...)      对 SAS 日志文本做 ERROR/WARNING 扫描
  - convert_windows_path_to_linux(...)     Z:\\ ↔ /u01/.../ 路径双向转换
  - convert_linux_path_to_windows(...)

日志审阅策略：
  - ERROR_PATTERN / WARNING_PATTERN 匹配"ERROR:" / "WARNING:"（大小写不敏感）
  - 汇总时分类为 errors / warnings / notes / highlight，并提取 key_note
"""
import os
import re
import subprocess
import sys

# saspy 在 run_sas 第一次被调用时才导入。
# 原因：saspy 的 import 会读 sascfg.py 并初始化 IOM 配置常量，
# 在网络盘环境下耗时 1~3 秒。延迟到真正运行 SAS 时才付出此代价，
# 应用冷启动可整体提速。
saspy = None  # 占位，真实模块在 _ensure_saspy() 中加载

def _ensure_saspy():
    """首次调用时 import saspy，后续调用复用全局引用"""
    global saspy
    if saspy is None:
        import saspy as _saspy
        saspy = _saspy
    return saspy

# 平台 / 路径常量
IS_LINUX = sys.platform.startswith('linux')
LINUX_PATH_PREFIX = '/u01/app/sas/sas9.4/DocumentRepository/DDT/'
WINDOWS_PATH_PREFIX = 'Z:\\'

# 日志行模式（ERROR/WARNING/NOTE 识别）
ERROR_PATTERN = re.compile(r'ERROR\s*::|ERROR\s*:', re.IGNORECASE)
WARNING_PATTERN = re.compile(r'WARNING\s*::|WARNING\s*:', re.IGNORECASE)
ERROR_LINE_PATTERN = re.compile(r'^\s*ERROR\s*:', re.IGNORECASE)
WARNING_LINE_PATTERN = re.compile(r'^\s*WARNING\s*:', re.IGNORECASE)
NOTE_LINE_PATTERN = re.compile(r'^\s*NOTE\s*:', re.IGNORECASE)


# =============================================================================
# 路径转换
# =============================================================================
def convert_linux_path_to_windows(linux_path):
    """/u01/app/sas/... → Z:\\..."""
    windows_path = linux_path.replace('/u01/app/sas/sas9.4/DocumentRepository/DDT', 'Z:')
    return windows_path.replace('/', '\\')


def convert_windows_path_to_linux(windows_path):
    """Z:\\... → /u01/app/sas/..."""
    p = windows_path.replace('\\', '/')
    if p.upper().startswith('Z:/'):
        return LINUX_PATH_PREFIX + p[3:].lstrip('/')
    return p


# =============================================================================
# 日志审阅：抽取 error/warning/note、摘要生成
# =============================================================================
def _extract_log_findings(log_text: str):
    """逐行扫描 log_text，分类 error/warning/note，并提取高亮行"""
    findings = {"errors": [], "warnings": [], "notes": [], "highlight": [], "key_note": ""}
    if not log_text: return findings
    for raw_line in log_text.splitlines(keepends=True):
        stripped = raw_line.strip()
        if ERROR_LINE_PATTERN.match(raw_line):
            findings["errors"].append(stripped)
            findings["highlight"].append((raw_line, "error"))
        elif WARNING_LINE_PATTERN.match(raw_line):
            findings["warnings"].append(stripped)
            findings["highlight"].append((raw_line, "warning"))
        elif NOTE_LINE_PATTERN.match(raw_line):
            findings["notes"].append(stripped)
    for note in findings["notes"]:
        note_lower = note.lower()
        if "proc compare" in note_lower or "no unequal" in note_lower:
            findings["key_note"] = note
            break
    return findings


def _build_log_summary(findings: dict) -> str:
    """汇总 findings 为一行摘要字符串（形如 "❌ 2 个错误 | ⚠ 1 个警告"）"""
    parts = []
    err_count = len(findings.get("errors", []))
    warn_count = len(findings.get("warnings", []))
    key_note = findings.get("key_note", "")
    if err_count: parts.append(f"❌ {err_count} 个错误")
    if warn_count: parts.append(f"⚠ {warn_count} 个警告")
    if key_note: parts.append(f"📋 {key_note}")
    return " | ".join(parts)


# =============================================================================
# 日志内容审阅封装
# =============================================================================
def review_log_from_content(log_content: str, source_label: str = "(来自 SAS 会话)") -> bool:
    """外部入口：判断日志文本中是否有 ERROR/WARNING"""
    return _review_log_content(log_content or "", source_label)


def _review_log_content(log_content: str, source_label: str, on_window_close=None) -> bool:
    """内部实现：提取 findings 并返回 has_issue 布尔值"""
    if not (log_content or "").strip(): return False
    findings = _extract_log_findings(log_content)
    has_issue = len(findings["errors"]) > 0 or len(findings["warnings"]) > 0
    return has_issue


def check_for_errors_in_log(log_file_path, fallback_log_content=None, on_window_close=None):
    """
    从日志文件读取内容并审阅；若文件打不开，降级使用 fallback_log_content。
    路径会按平台自动做 Linux ↔ Windows 转换。
    """
    actual_log_path = log_file_path if IS_LINUX else convert_linux_path_to_windows(log_file_path)
    try:
        with open(actual_log_path, 'r', encoding='utf-8', errors='replace') as log_file:
            return _review_log_content(log_file.read(), actual_log_path, on_window_close=on_window_close)
    except Exception:
        if fallback_log_content and str(fallback_log_content).strip():
            return _review_log_content(str(fallback_log_content), "(来自 SAS 会话)", on_window_close=on_window_close)
        return False


# =============================================================================
# SAS 执行核心
# =============================================================================
def run_sas(sas_file_path: str, sas_session=None, check_log=True, return_summary=False, return_details=False):
    """
    通用 SAS 执行接口。

    参数：
      sas_file_path    Windows 路径或 Linux 路径皆可，自动做转换
      sas_session      可选，复用现有 saspy 会话；否则本函数内部新建
      check_log        是否在返回前调用 review_log_from_content
      return_summary   是否返回 (has_issue, summary_str)
      return_details   是否返回完整 (has_issue, summary, log_text, source_label)

    返回值形态取决于 return_summary / return_details 组合。
    """
    macro_file_path = '/u01/app/sas/sas9.4/DocumentRepository/DDT/projects/utility/macros/01_general/autorun.sas'
    sas_file_path_linux = convert_windows_path_to_linux(sas_file_path)
    sas_file_name_no_ext = os.path.splitext(os.path.basename(sas_file_path_linux))[0]
    base_path = os.path.dirname(sas_file_path_linux)

    if '06_programs' in sas_file_path_linux or '09_validation' in sas_file_path_linux:
        log_output_path = f"{base_path}/07_logs/{sas_file_name_no_ext}.log"
    else:
        log_output_path = f"{base_path}/{sas_file_name_no_ext}.log"

    sas_code = f"""
proc printto log='{log_output_path}' new; run;
%let _sasprogramfile = '{sas_file_path_linux}';
%include '{macro_file_path}';
%include '{sas_file_path_linux}';
proc printto; run;
"""
    own_session = sas_session is None
    # v12.10.30：frozen 模式下 __file__ 在 _MEIPASS 临时目录里。
    # sascfg.py 通过 PyInstaller --add-data 打进 _MEIPASS/sas_engine/，所以
    # 用 bundle_root() 找它（而不是依赖 __file__ 的 dirname，后者在 frozen
    # 模式下行为虽然恰好相同但语义不直观）。开发模式行为不变。
    try:
        from app_paths import is_frozen, bundle_root
        if is_frozen():
            cfg_file_path = os.path.join(bundle_root(), 'sas_engine', 'sascfg.py')
        else:
            cfg_file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sascfg.py')
    except ImportError:
        # app_paths 不可用（非常异常情况）— 兜底走 __file__ 路径
        cfg_file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sascfg.py')

    if own_session:
        _ensure_saspy()  # 首次调用时按需 import saspy
        sas = saspy.SASsession(cfgname='winiomIWA', cfgfile=cfg_file_path)
    else:
        sas = sas_session

    session_ended = [False]

    def on_log_window_close():
        if not session_ended[0] and own_session:
            session_ended[0] = True
            try:
                sas.endsas()
            except Exception:
                pass

    try:
        sas_output = {}
        crash_err_msg = ""

        # 1. 尝试提交，拦截 0xff 等解码崩溃
        try:
            sas_output = sas.submit(sas_code)
        except Exception as submit_error:
            # 智能静默过滤掉 saspy 的并发断联假报错
            err_str = str(submit_error)
            if "No SAS process attached" not in err_str and "terminated unexpectedly" not in err_str:
                crash_err_msg = f"SAS 接口通信异常: {err_str}"
            else:
                pass

        # 2. ================= 核心修复：日志强制穿透拾取 =================
        # 哪怕 saspy 崩溃了，也强制去读服务器写在硬盘上的真实 .log 文件！
        actual_log_path_win = convert_linux_path_to_windows(log_output_path)
        real_log_content = ""

        if os.path.exists(actual_log_path_win):
            try:
                with open(actual_log_path_win, 'r', encoding='utf-8', errors='replace') as f:
                    real_log_content = f.read()
            except Exception:
                pass

        if not real_log_content:
            real_log_content = sas_output.get('LOG', '') if isinstance(sas_output, dict) else ''
        # ==========================================================

        findings = _extract_log_findings(real_log_content)

        # 3. 将通讯崩溃信息追加，防止被彻底掩盖
        if crash_err_msg:
            real_log_content += f"\n\n[Python 调用层异常]: {crash_err_msg}"
            # 【修复1】：将底层通信崩溃归类为 Warning，避免触发致命的 ❌ 1 个错误
            if not findings["errors"] and not findings["warnings"]:
                findings["warnings"].append(crash_err_msg)

        summary = _build_log_summary(findings)
        if not summary:
            if crash_err_msg:
                summary = "⚠️ 运行完成（接口通信警告）"
            elif len(findings["errors"]) > 0 or len(findings["warnings"]) > 0:
                summary = "❌ 运行完成（发现错误或警告）"
            else:
                summary = "✅ 运行成功"

        source_label = actual_log_path_win

        if not check_log:
            has_issue = len(findings["errors"]) > 0 or len(findings["warnings"]) > 0 or bool(crash_err_msg)
            if return_details: return has_issue, summary, real_log_content, source_label
            if return_summary: return has_issue, summary
            return has_issue

        has_issue = check_for_errors_in_log(log_output_path, fallback_log_content=real_log_content,
                                            on_window_close=on_log_window_close if own_session else None)

        if return_details: return has_issue, summary, real_log_content, source_label
        if return_summary: return has_issue, summary
        return has_issue

    finally:
        if own_session and not session_ended[0]:
            try:
                sas.endsas()
            except Exception:
                pass
