# -*- coding: utf-8 -*-
"""
sas_engine/sascfg.py
====================
SASPy IOM 连接配置。

作用：
  saspy 在初始化会话时会从本文件读取 SAS_config_names / SAS_config_options /
  SAS_output_options / <连接名> 等字典。这里使用 winiomIWA（Windows IOM + 集成
  Windows 认证 SSPI），指向后端 SAS 服务器 sas-hrsh-pro.hengrui.com。

Java 路径查找策略（_get_java_path）：
  1. PyInstaller 打包场景：优先找 _MEIPASS/jre 或 exe 同级 jre
  2. 源码运行场景：项目内 jre/bin/java.exe
  3. 最终兜底：系统 PATH 中的 java
"""
import os
import sys


def _get_java_path() -> str:
    """按优先级定位可用的 java 可执行文件路径"""
    # PyInstaller --onefile: 解压到 _MEIPASS
    if getattr(sys, 'frozen', False):
        meipass = getattr(sys, '_MEIPASS', '')
        if meipass:
            bundled_java = os.path.join(meipass, 'jre', 'bin', 'java.exe')
            if os.path.isfile(bundled_java):
                return bundled_java

        # PyInstaller --onedir: jre 与 exe 同级
        exe_dir = os.path.dirname(sys.executable)
        bundled_java = os.path.join(exe_dir, 'jre', 'bin', 'java.exe')
        if os.path.isfile(bundled_java):
            return bundled_java

    # 源码运行：项目目录内的 jre
    project_dir = os.path.dirname(os.path.abspath(__file__))
    local_java = os.path.join(project_dir, 'jre', 'bin', 'java.exe')
    if os.path.isfile(local_java):
        return local_java

    # 兜底：依赖系统 PATH
    return 'java'


# saspy 入口：告诉 saspy 使用哪个连接
SAS_config_names = ['winiomIWA']

# saspy 通用选项
SAS_config_options = {
    'lock_down': False,
    'verbose': True,
    'prompt': True,
}

# 默认输出格式（HTML5 + HTMLBlue 样式）
SAS_output_options = {
    'output': 'html5',
    'style': 'HTMLBlue',
    'asis': False,
}

# IOM 连接参数（使用 Windows 集成认证 SSPI，无需密码）
winiomIWA = {
    'java': _get_java_path(),
    'iomhost': 'sas-hrsh-pro.hengrui.com',
    'iomport': 8591,
    'sspi': True,
    'encoding': 'utf-8',
}