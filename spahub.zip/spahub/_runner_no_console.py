# -*- coding: utf-8 -*-
"""
_runner_no_console.py
=====================
ScriptRunnerThread 用的 user script wrapper。

职责：
  1. 装 no-window-popen monkey-patch（避免 user script 内 subprocess.Popen 拉
     robocopy / xcopy / 7z 等 console 应用时弹黑窗）
  2. 同时把没显式指定 stdout/stderr 的子进程默认设 DEVNULL，防 Windows 句柄共享
     bug：robocopy 退出关闭继承自父的 stdout 句柄会反向破坏父 python 的 PIPE，
     导致 ScriptRunnerThread 的 readline 永不收 EOF → finished_signal 不发 →
     UI 计时器一直跑

  3. 用 runpy.run_path 执行 user script，保留 user script 的 __file__ / argv 语义

共享 _no_window_popen.install() 提供 (1)，本文件再叠加 (2) 的 stdout/stderr DEVNULL。
"""
import sys
import os
import subprocess as _sp
import runpy

# 把 SPAhub 项目根加进 sys.path，以便能 import _no_window_popen
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _no_window_popen import install as _install_creationflags
_install_creationflags()  # 装第一层 patch（CREATE_NO_WINDOW）

# 在第一层基础上再叠加 stdout/stderr DEVNULL 隔离（防 Windows 句柄共享 bug）
_orig_popen = _sp.Popen


class _NoInheritStdoutPopen(_orig_popen):
    def __init__(self, *args, **kwargs):
        # 第 5/6 位置是 stdout/stderr，若 *args 已含 ≥5 个，说明用 positional 传 stdout，不动；
        # 否则按 kwargs 检测。
        argc = len(args)
        if "stdout" not in kwargs and argc < 5:
            kwargs["stdout"] = _sp.DEVNULL
        if "stderr" not in kwargs and argc < 6:
            kwargs["stderr"] = _sp.DEVNULL
        super().__init__(*args, **kwargs)


_sp.Popen = _NoInheritStdoutPopen


# ---------------------------------------------------------------------------
# Run user script
# ---------------------------------------------------------------------------
if len(sys.argv) < 2:
    sys.stderr.write("Usage: _runner_no_console.py <user_script_path>\n")
    sys.exit(2)

target = sys.argv[1]
if not os.path.isfile(target):
    sys.stderr.write(f"User script not found: {target}\n")
    sys.exit(2)

# 让 user script 看到自己的 __file__ / argv[0] 是它本身
sys.argv = [target] + sys.argv[2:]
sys.path.insert(0, os.path.dirname(os.path.abspath(target)))

try:
    runpy.run_path(target, run_name="__main__")
except SystemExit:
    raise
except Exception:
    import traceback
    traceback.print_exc()
    sys.exit(1)
