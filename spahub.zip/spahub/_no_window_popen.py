# -*- coding: utf-8 -*-
"""
_no_window_popen.py
===================
共享的 subprocess.Popen monkey-patch — 让本进程内所有 subprocess.Popen 默认带
CREATE_NO_WINDOW，消除 pythonw.exe 父进程下"子级 console 应用弹黑窗"问题。

调用场景：
  - main.py 启动时              （主 GUI 进程）
  - _runner_no_console.py       （ScriptRunnerThread 拉起的 user script wrapper）
  - child_command_run_sas 的 -c code （SAS Runner 子进程，saspy 在里面 spawn java）
  - pdt_post_process_runner.py 顶部  （win32com 子进程）

为什么需要这层（dev 模式 + pythonw.exe 父进程）：
  - 父 pythonw.exe 没有 console
  - 父用 subprocess.Popen 拉子 python.exe，加 creationflags=CREATE_NO_WINDOW → 子无 console ✓
  - 子 python.exe 内 saspy 启动 SAS 会话时 spawn java.exe（saspy 内部 Popen 不带
    任何 creationflags）→ Windows 看到 console subsystem 应用 + 父进程无 console
    → 给 java.exe 分配新 console → **黑窗冒出来** ✗
  - 把本模块导入并调 install()，monkey-patch 后续所有 subprocess.Popen 默认带
    CREATE_NO_WINDOW，java/cmd/robocopy 等子进程统一隐藏

调用方式：
    from _no_window_popen import install
    install()
"""
import os
import subprocess as _sp


CREATE_NO_WINDOW = 0x08000000
DETACHED_PROCESS = 0x00000008
CREATE_NEW_CONSOLE = 0x00000010
# 注意：CREATE_NEW_PROCESS_GROUP (0x00000200) 跟 console 显示无关，
# 它只是用来隔离 Ctrl+C 信号 — saspy 在 spawn java 时常加这个标志。
# 不能把它当成"用户要 console"的信号，否则会跳过 patch。


def install():
    """幂等地把 subprocess.Popen 替换为 _NoWinPopen。
    多次调用安全，已 patch 过会直接 return。
    非 Windows 平台 no-op（Linux/Mac 不需要 console 隐藏）。"""
    if os.name != "nt":
        return
    if getattr(_sp.Popen, "_saseg_no_window_patched", False):
        return  # 已 patch，幂等

    _orig_popen = _sp.Popen

    class _NoWinPopen(_orig_popen):
        def __init__(self, *args, **kwargs):
            # 调用方已显式要 console / detached → 不动
            # 注意只检查 CREATE_NEW_CONSOLE 和 DETACHED_PROCESS，不检查
            # CREATE_NEW_PROCESS_GROUP（saspy spawn java 时会带这个，但与 console 无关）
            cf = kwargs.get("creationflags", 0) or 0
            if not (cf & (CREATE_NEW_CONSOLE | DETACHED_PROCESS)):
                kwargs["creationflags"] = cf | CREATE_NO_WINDOW
            super().__init__(*args, **kwargs)

    _NoWinPopen._saseg_no_window_patched = True
    _sp.Popen = _NoWinPopen
